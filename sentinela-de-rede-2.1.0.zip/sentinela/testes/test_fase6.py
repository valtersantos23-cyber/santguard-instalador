"""Fase 6: mitigação com aprovação (RTBH e bloqueio), travas de segurança e expiração."""

import time
import unittest

from testes.base import SENHA_FORTE, CasoBase, simulador
from sentinela import autenticacao as auth, banco, config, equipamentos, mitigacao
from sentinela.mitigacao import MITIGADOR
from sentinela.tempo_real import TEMPO_REAL


class TestMitigacao(CasoBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        config.CFG["fluxo"]["redes_proprias"] = ["177.10.0.0/22", "2804:abcd::/32"]
        banco.executar("UPDATE equipamentos SET ativo = 0")   # isola dos outros testes
        cls.borda = simulador.mikrotik("BORDA-MIT")
        cls.borda.senha = "escrita-123"                        # só a credencial de mitigação entra
        simulador.EQUIPAMENTOS["10.90.0.1"] = cls.borda
        cls.eid, erro = equipamentos.salvar({"nome": "Borda MIT", "host": "10.90.0.1", "tipo": "mikrotik_routeros",
                                             "usuario": "leitura", "senha": "senha-leitura", "funcao": "borda",
                                             "mit_usuario": "sentinela-rw", "mit_senha": "escrita-123"}, 1)
        assert not erro, erro
        cls.cisco = simulador.cisco("BORDA-CISCO")
        simulador.EQUIPAMENTOS["10.90.0.2"] = cls.cisco
        cls.cid, _ = equipamentos.salvar({"nome": "Borda Cisco", "host": "10.90.0.2", "tipo": "cisco_ios",
                                          "usuario": "u", "senha": simulador.Equipamento.senha, "funcao": "borda"}, 1)

    def setUp(self):
        banco.executar("DELETE FROM mitigacoes")
        mitigacao.salvar_config(1, {"automatico_rtbh": False, "nunca_bloquear": ""})
        self.borda.configuracoes = []
        self.cisco.configuracoes = []

    def test_ddos_propoe_e_aprovacao_aplica_com_credencial_de_escrita(self):
        MITIGADOR.ao_ddos({"alvo": "177.10.0.5", "vetor": "Amplificação DNS", "bps": 2.5e9, "incidente_id": None, "empresa_id": 1})
        m = banco.um("SELECT * FROM mitigacoes WHERE alvo = '177.10.0.5'")
        self.assertEqual((m["tipo"], m["estado"]), ("rtbh", "pendente"))
        self.assertEqual(self.borda.configuracoes, [])          # nada enviado antes da aprovação

        ok, log = MITIGADOR.aprovar(m["id"], "joao.noc", 1)
        self.assertTrue(ok, log)
        self.assertEqual(self.borda.configuracoes[0]["usuario"], "sentinela-rw")
        self.assertEqual(self.borda.configuracoes[0]["comandos"],
                         [f'/ip route add dst-address=177.10.0.5/32 blackhole comment="sentinela-rtbh-{m["id"]}"'])
        self.assertEqual(self.cisco.configuracoes[0]["comandos"], ["ip route 177.10.0.5 255.255.255.255 Null0 tag 666"])
        ativa = banco.um("SELECT * FROM mitigacoes WHERE id = ?", (m["id"],))
        self.assertEqual((ativa["estado"], ativa["aprovado_por"]), ("ativa", "joao.noc"))

        # duplicada não cria outra
        _, nova = MITIGADOR.propor(1, "rtbh", "177.10.0.5", "de novo", [self.eid])
        self.assertFalse(nova)

        # expiração desfaz
        self.assertEqual(MITIGADOR.expirar(agora=time.time() + 61 * 60), 1)
        self.assertEqual(self.borda.configuracoes[-1]["comandos"],
                         [f'/ip route remove [find comment="sentinela-rtbh-{m["id"]}"]'])
        self.assertEqual(self.cisco.configuracoes[-1]["comandos"], ["no ip route 177.10.0.5 255.255.255.255 Null0 tag 666"])
        self.assertEqual(banco.um("SELECT estado FROM mitigacoes WHERE id = ?", (m["id"],))["estado"], "removida")

    def test_ipv6(self):
        m, _ = MITIGADOR.propor(1, "rtbh", "2804:abcd::10", "teste", [self.eid])
        MITIGADOR.aprovar(m["id"], "admin", 1)
        self.assertIn("/ipv6 route add dst-address=2804:abcd::10/128 blackhole", self.borda.configuracoes[0]["comandos"][0])

    def test_travas_de_seguranca(self):
        with self.assertRaisesRegex(ValueError, "não pertence às suas redes"):
            MITIGADOR.propor(1, "rtbh", "8.8.8.8", "x", [self.eid])
        with self.assertRaisesRegex(ValueError, "único endereço"):
            MITIGADOR.propor(1, "rtbh", "177.10.0.0/22", "x", [self.eid])
        mitigacao.salvar_config(1, {"nunca_bloquear": "203.0.113.0/24\n177.10.0.1"})
        with self.assertRaisesRegex(ValueError, "nunca bloquear"):
            MITIGADOR.propor(1, "bloqueio", "203.0.113.50", "x", [self.eid])
        with self.assertRaisesRegex(ValueError, "nunca bloquear"):
            MITIGADOR.propor(1, "rtbh", "177.10.0.1", "x", [self.eid])
        with self.assertRaises(ValueError):
            mitigacao.salvar_config(1, {"modelos": {"rtbh": {"cisco_ios": {"aplicar": ["ip route {inexistente}"], "remover": []}}}})

    def test_erro_do_roteador_vira_estado_erro(self):
        self.cisco.resposta_config = "% Invalid input detected at '^' marker.\n"
        try:
            m, _ = MITIGADOR.propor(1, "rtbh", "177.10.0.9", "x", [self.cid])
            ok, log = MITIGADOR.aprovar(m["id"], "admin", 1)
        finally:
            self.cisco.resposta_config = ""
        self.assertFalse(ok)
        self.assertIn("Invalid input", log)
        self.assertEqual(banco.um("SELECT estado FROM mitigacoes WHERE id = ?", (m["id"],))["estado"], "erro")

    def test_automatico_acima_do_limite(self):
        mitigacao.salvar_config(1, {"automatico_rtbh": True, "automatico_rtbh_gbps": 2})
        MITIGADOR.ao_ddos({"alvo": "177.10.0.77", "vetor": "UDP flood", "bps": 1.0e9, "empresa_id": 1})
        MITIGADOR.ao_ddos({"alvo": "177.10.0.78", "vetor": "UDP flood", "bps": 3.0e9, "empresa_id": 1})
        time.sleep(0.5)
        estados = {m["alvo"]: m["estado"] for m in banco.consultar("SELECT alvo, estado FROM mitigacoes")}
        self.assertEqual(estados, {"177.10.0.77": "pendente", "177.10.0.78": "ativa"})

    def test_forca_bruta_propoe_bloqueio(self):
        TEMPO_REAL.ao_forca_bruta[:] = [MITIGADOR.ao_forca_bruta]
        TEMPO_REAL._mapa["quando"] = 0
        for i in range(6):
            TEMPO_REAL.tratar_syslog(f"login failure for user admin from 198.51.100.{i % 2 + 7} via ssh", "10.90.0.1")
        propostas = banco.consultar("SELECT * FROM mitigacoes WHERE tipo = 'bloqueio' ORDER BY alvo")
        self.assertEqual([p["alvo"] for p in propostas], ["198.51.100.7", "198.51.100.8"])
        MITIGADOR.aprovar(propostas[0]["id"], "admin", 1)
        self.assertIn("address-list add list=sentinela-bloqueio address=198.51.100.7 timeout=1440m",
                      self.borda.configuracoes[0]["comandos"][0])

    def test_api_permissoes(self):
        if not banco.um("SELECT id FROM usuarios WHERE usuario = 'leitor.mit'"):
            auth.criar_usuario("leitor.mit", SENHA_FORTE, "leitura", empresa_id=1)
            banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = 'leitor.mit'")
        m, _ = MITIGADOR.propor(1, "rtbh", "177.10.0.33", "x", [self.eid])
        c = self.cliente()
        _, csrf = self.login(c, "leitor.mit", SENHA_FORTE)
        self.assertEqual(c.get("/api/mitigacoes").status_code, 200)
        self.assertIsNone(c.get("/api/mitigacoes").get_json()["config"])          # leitura não vê os comandos
        self.assertEqual(self.post(c, f"/api/mitigacoes/{m['id']}/aprovar", csrf).status_code, 403)
        self.assertEqual(self.borda.configuracoes, [])


if __name__ == "__main__":
    unittest.main()
