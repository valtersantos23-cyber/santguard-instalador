"""Prepara um ambiente isolado (pasta de dados temporária) para os testes."""

import os
import shutil
import sys
import tempfile
import unittest

PASTA_TESTE = tempfile.mkdtemp(prefix="sentinela_teste_")
os.environ["SENTINELA_DADOS"] = PASTA_TESTE
os.environ["SENTINELA_TEMPO_REAL_SYSLOG"] = "false"
os.environ["SENTINELA_FLUXO_ATIVO"] = "false"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from testes import simulador  # noqa: E402

simulador.instalar()

from sentinela import banco  # noqa: E402

banco.migrar()

from testes import licenca_teste  # noqa: E402

licenca_teste.ativar(dias=365)  # sem licença da instalação o sistema fica bloqueado

SENHA_FORTE = "Sentinela#2026forte"


class CasoBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from sentinela.web.app import app
        cls.app = app
        app.testing = True

    def cliente(self):
        return self.app.test_client()

    def login(self, cliente, usuario, senha):
        r = cliente.post("/api/login", json={"usuario": usuario, "senha": senha}, headers={"X-Sentinela": "1"})
        if r.status_code != 200:
            return r, None
        sessao = cliente.get("/api/sessao").get_json()
        return r, sessao.get("csrf")

    def post(self, cliente, url, csrf, dados=None):
        return cliente.post(url, json=dados or {}, headers={"X-Sentinela": "1", "X-CSRF-Token": csrf or ""})


def limpar():
    shutil.rmtree(PASTA_TESTE, ignore_errors=True)
