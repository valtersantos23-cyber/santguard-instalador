"""Fase 4: alertas (WhatsApp Meta/Evolution, e-mail, Telegram, webhook), escala, manutenção e PDF."""

import hashlib
import hmac
import http.server
import json
import socket
import threading
import time
import unittest

from testes.base import SENHA_FORTE, CasoBase
from sentinela import alertas, autenticacao as auth, banco, incidentes, relatorios


class ServidorHttpFalso:
    def __init__(self):
        self.pedidos = []
        dono = self

        class Tratador(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                corpo = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                dono.pedidos.append({"caminho": self.path, "corpo": corpo,
                                     "cabecalhos": {k.lower(): v for k, v in self.headers.items()}})
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'{"ok":true}')

            def log_message(self, *a):
                pass

        self.servidor = http.server.HTTPServer(("127.0.0.1", 0), Tratador)
        self.url = f"http://127.0.0.1:{self.servidor.server_port}"
        threading.Thread(target=self.servidor.serve_forever, daemon=True).start()


class ServidorSmtpFalso:
    def __init__(self):
        self.mensagens = []
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(5)
        self.porta = self.sock.getsockname()[1]
        threading.Thread(target=self._laco, daemon=True).start()

    def _laco(self):
        while True:
            con, _ = self.sock.accept()
            arq = con.makefile("rwb")
            responder = lambda t: (arq.write(t.encode() + b"\r\n"), arq.flush())
            responder("220 smtp falso")
            dados = None
            while True:
                bruta = arq.readline()
                if not bruta:   # conexão fechada (linha vazia no corpo do e-mail é normal)
                    break
                linha = bruta.decode().rstrip("\r\n")
                if dados is not None:
                    if linha == ".":
                        self.mensagens.append("\n".join(dados))
                        dados = None
                        responder("250 ok")
                    else:
                        dados.append(linha)
                    continue
                comando = linha.split(" ")[0].upper()
                if comando in ("EHLO", "HELO"):
                    responder("250 smtp falso")
                elif comando == "DATA":
                    dados = []
                    responder("354 envie")
                elif comando == "QUIT":
                    responder("221 tchau")
                    break
                else:
                    responder("250 ok")
            con.close()


class TestAlertas(CasoBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.http = ServidorHttpFalso()
        cls.smtp = ServidorSmtpFalso()
        for nome, nivel, fone, mail in (("plantao1", 1, "(48) 99999-0001", "n1@prov.com.br"),
                                        ("plantao2", 2, "48999990002", "n2@prov.com.br")):
            if not banco.um("SELECT id FROM usuarios WHERE usuario = ?", (nome,)):
                uid = auth.criar_usuario(nome, SENHA_FORTE, "operador", telefone=fone, email=mail, empresa_id=1)
                banco.executar("INSERT INTO plantao (usuario_id, nivel) VALUES (?, ?)", (uid, nivel))

    def configurar(self, **extra):
        cfg = {"geral": {"nome_empresa": "Provedor Teste", "painel_url": "https://noc.teste:8443",
                         "severidade_minima": "media", "escalonar_minutos": 15, "max_alertas_5min": 50},
               "whatsapp": {"modo": "evolution", "evolution_url": self.http.url, "evolution_instancia": "noc",
                            "evolution_chave": "chave-evo"},
               "email": {"ativo": True, "servidor": "127.0.0.1", "porta": self.smtp.porta, "seguranca": "nenhuma",
                         "remetente": "sentinela@prov.com.br"},
               "webhook": {"ativo": True, "url": self.http.url + "/gancho", "segredo": "segredo-webhook"}}
        for canal, valores in extra.items():
            cfg.setdefault(canal, {}).update(valores)
        alertas.salvar_config(1, cfg)
        alertas.NOTIFICADOR._recentes.clear()

    def incidente(self, severidade="alta", equip_id=None):
        inc_id = banco.executar("INSERT INTO incidentes (equip_id, equipamento, tipo, severidade, titulo, chave, empresa_id) "
                                "VALUES (?, 'BORDA-01 (10.0.0.1)', 'Força bruta', ?, 'Força bruta: 50 falhas', ?, 1)",
                                (equip_id, severidade, f"teste|{time.time()}"))
        return incidentes.obter(inc_id)

    def test_config_guarda_segredos_cifrados(self):
        self.configurar()
        bruto = banco.ler_config_empresa(1, "alertas")
        self.assertNotIn("chave-evo", bruto)
        self.assertNotIn("segredo-webhook", bruto)
        publica = alertas.config_publica(1)
        self.assertTrue(publica["whatsapp"]["evolution_chave_definido"])
        self.assertNotIn("evolution_chave_cif", publica["whatsapp"])
        alertas.salvar_config(1, {"whatsapp": {"evolution_chave": ""}})     # vazio = manter
        self.assertTrue(alertas.config_publica(1)["whatsapp"]["evolution_chave_definido"])
        with self.assertRaises(alertas.ErroAlerta):
            alertas.salvar_config(1, {"webhook": {"url": "file:///etc/passwd"}})

    def test_envio_nivel1_e_escalonamento(self):
        self.configurar()
        self.http.pedidos.clear()
        self.smtp.mensagens.clear()
        inc = self.incidente()
        resultado = alertas.NOTIFICADOR.notificar(inc, 1)
        self.assertTrue(all(ok for _, _, ok, _ in resultado), resultado)
        canais = sorted(c for c, _, _, _ in resultado)
        self.assertEqual(canais, ["email", "webhook", "whatsapp"])

        evo = next(p for p in self.http.pedidos if p["caminho"] == "/message/sendText/noc")
        corpo = json.loads(evo["corpo"])
        self.assertEqual(corpo["number"], "5548999990001")          # 55 adicionado
        self.assertIn("Força bruta", corpo["text"])
        self.assertEqual(evo["cabecalhos"]["apikey"], "chave-evo")

        gancho = next(p for p in self.http.pedidos if p["caminho"] == "/gancho")
        esperado = "sha256=" + hmac.new(b"segredo-webhook", gancho["corpo"], hashlib.sha256).hexdigest()
        self.assertEqual(gancho["cabecalhos"]["x-sentinela-assinatura"], esperado)
        time.sleep(0.2)
        self.assertTrue(any("n1@prov.com.br" in m for m in self.smtp.mensagens))

        # escalonamento: não reconhecido em 15 min => nível 2
        banco.executar("UPDATE incidentes SET nivel_escalonamento = 1, proximo_escalonamento = ? WHERE id = ?",
                       (time.time() - 1, inc["id"]))
        self.http.pedidos.clear()
        self.assertEqual(alertas.NOTIFICADOR.escalonar(), 1)
        textos = [json.loads(p["corpo"])["text"] for p in self.http.pedidos if "sendText" in p["caminho"]]
        self.assertTrue(textos and "ESCALONADO (nível 2)" in textos[0])
        self.assertEqual(json.loads(self.http.pedidos[0]["corpo"])["number"], "5548999990002")

        # reconhecido: não escalona mais
        incidentes.reconhecer(inc["id"], "plantao1", 1)
        banco.executar("UPDATE incidentes SET proximo_escalonamento = ? WHERE id = ?", (time.time() - 1, inc["id"]))
        self.assertEqual(alertas.NOTIFICADOR.escalonar(), 0)

    def test_whatsapp_meta(self):
        self.configurar(whatsapp={"modo": "meta", "meta_phone_id": "123456", "meta_token": "tok-meta"})
        capturado = {}
        original = alertas._post_json
        alertas._post_json = lambda url, dados, cab=None, timeout=10, **k: capturado.update(url=url, dados=dados, cab=cab) or (200, "")
        try:
            alertas.enviar_whatsapp(alertas.ler_config(1), "+55 48 99999-0001", "linha 1\nlinha 2\n\tlinha 3")
        finally:
            alertas._post_json = original
        self.assertEqual(capturado["url"], "https://graph.facebook.com/v21.0/123456/messages")
        self.assertEqual(capturado["cab"], {"Authorization": "Bearer tok-meta"})
        tpl = capturado["dados"]["template"]
        self.assertEqual(tpl["name"], "alerta_sentinela")
        self.assertEqual(tpl["components"][0]["parameters"][0]["text"], "linha 1 · linha 2 · linha 3")  # sem quebras

    def test_manutencao_silencia_e_severidade_minima(self):
        self.configurar()
        from sentinela import equipamentos
        eid, _ = equipamentos.salvar({"nome": "Em manutenção", "host": "10.77.0.1", "tipo": "cisco_ios",
                                      "usuario": "u", "senha": "x"}, 1)
        banco.executar("INSERT INTO manutencoes (equip_id, inicio, fim, motivo, empresa_id) VALUES (?, datetime('now','localtime','-1 hour'), "
                       "datetime('now','localtime','+1 hour'), 'troca de placa', 1)", (eid,))
        banco.executar("UPDATE manutencoes SET inicio = substr(inicio, 1, 16), fim = substr(fim, 1, 16)")
        inc = self.incidente(equip_id=eid)
        self.assertEqual(alertas.NOTIFICADOR.notificar(inc, 1), [])
        self.assertIn("troca de placa", incidentes.obter(inc["id"])["silenciado"])
        self.assertEqual(alertas.NOTIFICADOR.notificar(self.incidente(severidade="baixa"), 1), [])

    def test_limite_anti_enxurrada(self):
        self.configurar(geral={"max_alertas_5min": 3})
        enviados = [bool(alertas.NOTIFICADOR.notificar(self.incidente(), 1)) for _ in range(5)]
        self.assertEqual(enviados, [True, True, True, False, False])

    def test_api_e_permissoes(self):
        c = self.cliente()
        _, csrf = self.login(c, "plantao1", SENHA_FORTE)
        if c.get("/api/sessao").get_json().get("trocar_senha"):
            banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = 'plantao1'")
        self.assertEqual(c.get("/api/config/alertas").status_code, 403)         # operador não configura alertas
        r = self.post(c, "/api/manutencoes", csrf, {"alvo": "todos", "inicio": "2030-01-01T10:00", "fim": "2030-01-01T12:00",
                                                    "motivo": "janela"})
        self.assertEqual(r.status_code, 200, r.get_json())                   # mas agenda manutenção
        r = self.post(c, "/api/manutencoes", csrf, {"alvo": "todos", "inicio": "2030-01-02T10:00", "fim": "2030-01-01T12:00"})
        self.assertIn("depois do início", r.get_json()["mensagem"])


class TestRelatorio(CasoBase):
    def test_pdf(self):
        agora = time.time()
        banco.executar("DELETE FROM envios")
        banco.executar("DELETE FROM incidentes")   # isola dos outros testes (os tempos médios dependem só destes)
        for i in range(12):
            banco.executar("INSERT INTO incidentes (equip_id, equipamento, tipo, severidade, titulo, estado, reconhecido_em, "
                           "resolvido_em, empresa_id) VALUES (NULL, ?, ?, ?, 'teste', 'resolvido', datetime('now','localtime','+5 minutes'), "
                           "datetime('now','localtime','+40 minutes'), 1)",
                           (f"EQUIP-{i % 3}", ["Força bruta", "DDoS volumétrico", "Configuração alterada"][i % 3],
                            ["alta", "media"][i % 2]))
        banco.executar("INSERT INTO ddos (alvo, inicio, ultimo, fim, pico_bps, pico_pps, vetor, origens, fontes, estado, empresa_id) "
                       "VALUES ('177.10.0.5', ?, ?, ?, 2.4e9, 350000, 'Amplificação DNS', '[]', 812, 'encerrado', 1)",
                       (agora - 900, agora - 60, agora - 60))
        hoje = time.localtime()
        pdf = relatorios.gerar_pdf(1, hoje.tm_year, hoje.tm_mon, "Provedor Teste")
        self.assertTrue(pdf.startswith(b"%PDF"))
        self.assertGreater(len(pdf), 3000)
        dados = relatorios.dados_do_periodo(1, hoje.tm_year, hoje.tm_mon)
        self.assertAlmostEqual(dados["mtta"], 300, delta=5)
        self.assertAlmostEqual(dados["mttr"], 2400, delta=5)
        with open(f"{__import__('testes.base', fromlist=['x']).PASTA_TESTE}/relatorio_teste.pdf", "wb") as f:
            f.write(pdf)


if __name__ == "__main__":
    unittest.main()
