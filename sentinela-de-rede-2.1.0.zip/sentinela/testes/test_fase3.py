"""Fase 3: decodificação NetFlow v5/v9, IPFIX e sFlow v5, classificação e detecção de DDoS."""

import socket
import time
import unittest

from testes import gerador_fluxo as g
from testes.base import CasoBase
from sentinela import banco, config, incidentes
from sentinela.fluxo import ColetorFluxo, Decodificador, _Estatistica, classificar
from sentinela.tempo_real import TEMPO_REAL

FLUXO_TESTE = ("203.0.113.9", "177.10.0.5", 6, 51000, 443, 0x02, 1500, 3)


class TestDecodificacao(unittest.TestCase):
    def test_netflow_v5_com_amostragem(self):
        d = Decodificador()
        fluxos = d.netflow_v5(g.netflow_v5([FLUXO_TESTE], amostragem=0x4000 | 100), "10.0.0.1")
        self.assertEqual(fluxos, [("203.0.113.9", "177.10.0.5", 6, 51000, 443, 2, 150000, 300, 0.0)])

    def test_netflow_v9_template_e_opcoes(self):
        d = Decodificador()
        self.assertEqual(d.netflow_v9_ipfix(g.netflow_v9([FLUXO_TESTE], amostragem=512), "10.0.0.2"),
                         [("203.0.113.9", "177.10.0.5", 6, 51000, 443, 2, 1500 * 512, 3 * 512, None)])
        # dados sem template no mesmo pacote: usa o template guardado
        self.assertEqual(len(d.netflow_v9_ipfix(g.netflow_v9([FLUXO_TESTE] * 3, enviar_template=False), "10.0.0.2")), 3)
        # outro exportador não conhece o template
        self.assertEqual(d.netflow_v9_ipfix(g.netflow_v9([FLUXO_TESTE], enviar_template=False), "10.0.0.3"), [])

    def test_netflow_v9_ipv6(self):
        d = Decodificador()
        f = ("2001:db8::1", "2804:abcd::10", 17, 53, 40000, 0, 9000, 6)
        self.assertEqual(d.netflow_v9_ipfix(g.netflow_v9([f], ipv6=True), "10.0.0.2")[0][:2], ("2001:db8::1", "2804:abcd::10"))

    def test_ipfix_com_campo_de_fabricante(self):
        d = Decodificador()
        fluxos = d.netflow_v9_ipfix(g.ipfix([FLUXO_TESTE, FLUXO_TESTE]), "10.0.0.4")
        self.assertEqual(len(fluxos), 2)
        self.assertEqual(fluxos[0], ("203.0.113.9", "177.10.0.5", 6, 51000, 443, 2, 1500, 3, None))

    def test_sflow(self):
        d = Decodificador()
        for expandido, vlan in ((False, None), (True, 100)):
            fluxos = d.sflow_v5(g.sflow_v5([("203.0.113.9", "177.10.0.5", 6, 51000, 443, 0x02, 64)], taxa=2048,
                                           expandido=expandido, vlan=vlan), "10.0.0.5")
            self.assertEqual(fluxos, [("203.0.113.9", "177.10.0.5", 6, 51000, 443, 2, 64 * 2048, 2048, None)],
                             (expandido, vlan))
        f6 = d.sflow_v5(g.sflow_v5([("2001:db8::9", "2804:abcd::5", 17, 123, 5000, 0, 468)]), "10.0.0.5")
        self.assertEqual(f6[0][:5], ("2001:db8::9", "2804:abcd::5", 17, 123, 5000))

    def test_pacote_lixo_nao_quebra(self):
        c = ColetorFluxo()
        for lixo in (b"", b"\x00\x05", b"\x00\x09" + b"\xff" * 30, b"\x00\x0a\x00\x08" + b"\x01" * 20, b"\x00\x00\x00\x05" * 5):
            c.processar_pacote(lixo, "10.0.0.9")
        self.assertGreaterEqual(c.ignorados, 1)


class TestClassificacao(unittest.TestCase):
    def _est(self, fluxos):
        c = ColetorFluxo()
        c.somar([f + (None,) for f in fluxos])
        return next(iter(c.janela.values()))

    def test_vetores(self):
        self.assertEqual(classificar(self._est(g.fluxos_syn_flood("177.10.0.5", 50)))[0], "SYN flood")
        self.assertEqual(classificar(self._est(g.fluxos_dns_amplificacao("177.10.0.5", 20)))[0], "Amplificação DNS")
        ntp = [(f"198.51.100.{i}", "177.10.0.5", 17, 123, 999, 0, 10_000, 20) for i in range(20)]
        self.assertEqual(classificar(self._est(ntp))[0], "Amplificação NTP")
        udp = [(f"198.51.100.{i}", "177.10.0.5", 17, 30000 + i, 80, 0, 10_000, 20) for i in range(20)]
        self.assertEqual(classificar(self._est(udp))[0], "UDP flood")
        icmp = [("198.51.100.1", "177.10.0.5", 1, 0, 0, 0, 10_000, 20)]
        self.assertEqual(classificar(self._est(icmp))[0], "ICMP flood")


class TestDeteccao(CasoBase):
    def setUp(self):
        config.CFG["fluxo"]["redes_proprias"] = ["177.10.0.0/22", "2804:abcd::/32"]
        config.CFG["fluxo"]["limite_mbps"] = 500
        config.CFG["fluxo"]["limite_kpps"] = 100

    def test_ddos_abre_incidente_e_encerra(self):
        c = ColetorFluxo()
        mitigacoes = []
        c.ao_detectar.append(mitigacoes.append)
        inicio = time.time()
        c.inicio_janela = inicio
        # 50 refletores DNS x 40 MB em 10 s = 1,6 Gbps para 177.10.0.5
        c.processar_pacote(g.netflow_v9(g.fluxos_dns_amplificacao("177.10.0.5")), "10.0.0.1")
        # tráfego normal para outro cliente e tráfego de SAÍDA (destino fora das nossas redes)
        c.processar_pacote(g.netflow_v5([("8.8.8.8", "177.10.0.6", 17, 53, 5353, 0, 1_000_000, 1000)]), "10.0.0.1")
        c.processar_pacote(g.netflow_v5([("177.10.0.6", "8.8.8.8", 17, 5353, 53, 0, 900_000_000, 900_000)]), "10.0.0.1")
        c.fechar_janela(agora=inicio + 10)

        self.assertIn((1, "177.10.0.5"), c.ativos)
        self.assertNotIn((1, "177.10.0.6"), c.ativos)
        self.assertNotIn("8.8.8.8", [t["ip"] for t in c.ultima[1]["top"]])   # saída não é analisada
        ataque = c.ativos[(1, "177.10.0.5")]
        self.assertEqual(ataque["vetor"], "Amplificação DNS")
        self.assertAlmostEqual(ataque["pico_bps"], 1.6e9, delta=1e8)
        self.assertEqual(len(mitigacoes), 1)
        inc = incidentes.obter(ataque["incidente_id"])
        self.assertEqual(inc["tipo"], "DDoS volumétrico")
        self.assertIn("Amplificação DNS", inc["titulo"])
        self.assertTrue(TEMPO_REAL.ativos("ip:1:177.10.0.5"))

        # continua no ciclo seguinte: mesmo ataque, mesmo incidente
        c.processar_pacote(g.netflow_v9(g.fluxos_dns_amplificacao("177.10.0.5", 80), enviar_template=False), "10.0.0.1")
        c.fechar_janela(agora=inicio + 20)
        self.assertEqual(len(mitigacoes), 1)
        self.assertGreater(c.ativos[(1, "177.10.0.5")]["pico_bps"], 2e9)

        # sem tráfego por mais que a janela: ataque encerrado
        c.fechar_janela(agora=inicio + 20 + 11 * 60)
        self.assertNotIn((1, "177.10.0.5"), c.ativos)
        linha = banco.um("SELECT * FROM ddos WHERE id = ?", (ataque["id"],))
        self.assertEqual(linha["estado"], "encerrado")

    def test_taxa_usa_a_duracao_do_fluxo(self):
        # 60 s de tráfego exportados de uma vez (timeout ativo de 1 min): 750 MB em 60 s = 100 Mbps.
        # Somando na janela de 10 s daria 600 Mbps (errado); com a duração do fluxo fica 100 Mbps.
        c = ColetorFluxo()
        inicio = time.time()
        c.inicio_janela = inicio
        fluxo = ("198.51.100.1", "177.10.0.8", 17, 53, 4444, 0, 750_000_000, 600_000)
        recebidos = c.processar_pacote(g.netflow_v9([fluxo], duracao_ms=60_000), "10.0.0.1")
        self.assertEqual(recebidos[0][8], 60.0)
        c.fechar_janela(agora=inicio + 10)
        alvo = next(t for t in c.ultima[1]["top"] if t["ip"] == "177.10.0.8")
        self.assertAlmostEqual(alvo["bps"], 1e8, delta=1e5)
        self.assertAlmostEqual(alvo["pps"], 10_000, delta=1)
        # NetFlow v5 com First/Last também
        c2 = ColetorFluxo()
        c2.inicio_janela = inicio
        c2.processar_pacote(g.netflow_v5([fluxo], duracao_ms=30_000), "10.0.0.1")
        c2.fechar_janela(agora=inicio + 10)
        self.assertAlmostEqual(c2.ultima[1]["top"][0]["bps"], 2e8, delta=1e5)

    def test_syn_flood_por_pacotes_via_udp_real(self):
        config.CFG["fluxo"]["aceitar_qualquer_exportador"] = True
        self.addCleanup(config.CFG["fluxo"].update, aceitar_qualquer_exportador=False)
        c = ColetorFluxo()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("127.0.0.1", 0))
        porta = sock.getsockname()[1]
        sock.close()
        import threading
        threading.Thread(target=c._escutar, args=(porta, "netflow"), daemon=True).start()
        time.sleep(0.2)
        inicio = time.time()
        c.inicio_janela = inicio
        envio = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 200 fluxos x 10.000 pacotes pequenos = 2 Mpps / 10 s = 200 kpps (bps baixo)
        fluxos = g.fluxos_syn_flood("2804:abcd::10", 200, bytes_por_fluxo=600_000, pacotes=10_000)
        fluxos = [(f"2001:db8::{i:x}", d, p, sp, dp, fl, b, pk) for i, (o, d, p, sp, dp, fl, b, pk) in enumerate(fluxos)]
        for i in range(0, 200, 20):
            envio.sendto(g.netflow_v9(fluxos[i:i + 20], ipv6=True, template_id=270), ("127.0.0.1", porta))
        time.sleep(0.5)
        c.fechar_janela(agora=inicio + 10)
        self.assertIn((1, "2804:abcd::10"), c.ativos)
        self.assertEqual(c.ativos[(1, "2804:abcd::10")]["vetor"], "SYN flood")
        self.assertEqual(c.decodificador.exportadores["127.0.0.1"]["versao"], "NetFlow v9")


if __name__ == "__main__":
    unittest.main()
