"""Fase 1: login, perfis, 2FA, CSRF, cofre, equipamentos, monitoramento e incidentes."""

import time
import unittest

from testes.base import SENHA_FORTE, CasoBase, simulador
from sentinela import autenticacao as auth, banco, incidentes
from sentinela.monitor import MONITOR
from sentinela.tempo_real import TEMPO_REAL


class TestSenhasE2FA(unittest.TestCase):
    def test_totp_vetor_rfc6238(self):
        # RFC 6238, apêndice B: segredo "12345678901234567890", T=59s -> 94287082 (8 dígitos)
        segredo = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
        self.assertEqual(auth.codigo_totp(segredo, 59 // 30), "287082")
        self.assertTrue(auth.conferir_totp(segredo, "287082", agora=59))
        self.assertFalse(auth.conferir_totp(segredo, "287083", agora=59))

    def test_totp_nao_aceita_reuso(self):
        segredo = auth.gerar_segredo_totp()
        codigo = auth.codigo_totp(segredo, int(time.time() // 30))
        self.assertTrue(auth.conferir_totp(segredo, codigo, usuario_id=999))
        self.assertFalse(auth.conferir_totp(segredo, codigo, usuario_id=999))

    def test_hash_de_senha(self):
        h = auth.gerar_hash("Correta#123x")
        self.assertTrue(auth.conferir_hash("Correta#123x", h))
        self.assertFalse(auth.conferir_hash("Errada#123x", h))
        self.assertNotIn("Correta", h)

    def test_politica_de_senha(self):
        self.assertIsNotNone(auth.problema_na_senha("curta"))
        self.assertIsNotNone(auth.problema_na_senha("somenteminusculas"))
        self.assertIsNotNone(auth.problema_na_senha("Joao.Silva#2026", "joao.silva"))
        self.assertIsNone(auth.problema_na_senha(SENHA_FORTE))


class TestPainel(CasoBase):
    def test_01_fluxo_completo(self):
        c = self.cliente()
        # sem login: API fechada
        self.assertEqual(c.get("/api/equipamentos").status_code, 401)
        self.assertFalse(c.get("/api/sessao").get_json()["configurado"])

        # primeiro admin: recusado de fora, aceito do próprio servidor
        r = c.post("/api/configurar-admin", json={"usuario": "admin", "senha": SENHA_FORTE},
                   headers={"X-Sentinela": "1"}, environ_base={"REMOTE_ADDR": "203.0.113.50"})
        self.assertEqual(r.status_code, 403)
        r = c.post("/api/configurar-admin", json={"usuario": "admin", "senha": "fraca"}, headers={"X-Sentinela": "1"})
        self.assertEqual(r.status_code, 400)
        r = c.post("/api/configurar-admin", json={"usuario": "admin", "senha": SENHA_FORTE}, headers={"X-Sentinela": "1"})
        self.assertEqual(r.status_code, 200, r.get_json())
        r = c.post("/api/configurar-admin", json={"usuario": "outro", "senha": SENHA_FORTE}, headers={"X-Sentinela": "1"})
        self.assertEqual(r.status_code, 403)

        # login
        r, csrf = self.login(c, "admin", SENHA_FORTE)
        self.assertEqual(r.status_code, 200)
        cookie = r.headers.get("Set-Cookie")
        self.assertIn("HttpOnly", cookie)
        self.assertIn("SameSite=Strict", cookie)

        # proteções de POST
        self.assertEqual(c.post("/api/verificar", json={}).status_code, 403)          # sem X-Sentinela
        self.assertEqual(c.post("/api/verificar", json={}, headers={"X-Sentinela": "1"}).status_code, 403)  # sem CSRF
        self.assertEqual(self.post(c, "/api/verificar", csrf).status_code, 200)

        # cabeçalhos de segurança
        r = c.get("/")
        self.assertIn("frame-ancestors 'none'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")

        # equipamento: senha vai cifrada para o banco
        simulador.EQUIPAMENTOS["10.0.0.1"] = simulador.mikrotik("Borda01")
        r = self.post(c, "/api/equipamentos", csrf, {"nome": "Borda", "host": "10.0.0.1", "tipo": "mikrotik_routeros",
                                                     "usuario": "monitor", "senha": simulador.Equipamento.senha,
                                                     "funcao": "borda"})
        self.assertEqual(r.status_code, 200, r.get_json())
        bruto = banco.um("SELECT * FROM equipamentos WHERE host = '10.0.0.1'")
        self.assertNotIn(simulador.Equipamento.senha, str(bruto))
        r = self.post(c, "/api/equipamentos", csrf, {"nome": "Dup", "host": "10.0.0.1", "tipo": "mikrotik_routeros",
                                                     "usuario": "x", "senha": "y"})
        self.assertIn("Já existe", r.get_json()["mensagem"])
        r = self.post(c, "/api/equipamentos/testar", csrf, {"host": "10.0.0.1", "tipo": "mikrotik_routeros",
                                                            "usuario": "m", "senha": simulador.Equipamento.senha})
        self.assertIn("Borda01", r.get_json()["mensagem"])
        r = self.post(c, "/api/equipamentos/testar", csrf, {"host": "10.0.0.1", "tipo": "mikrotik_routeros",
                                                            "usuario": "m", "senha": "errada"})
        self.assertIn("usuário ou senha inválidos", r.get_json()["mensagem"])

        # usuário somente leitura
        r = self.post(c, "/api/usuarios", csrf, {"usuario": "noc.leitura", "senha": SENHA_FORTE, "papel": "leitura"})
        self.assertEqual(r.status_code, 200, r.get_json())
        c2 = self.cliente()
        r, csrf2 = self.login(c2, "noc.leitura", SENHA_FORTE)
        self.assertTrue(c2.get("/api/sessao").get_json()["trocar_senha"])
        self.assertEqual(c2.get("/api/equipamentos").status_code, 403)      # precisa trocar a senha antes
        r = self.post(c2, "/api/minha-conta/senha", csrf2, {"atual": SENHA_FORTE, "nova": "Outra#Senha2026x"})
        self.assertEqual(r.status_code, 200, r.get_json())
        csrf2 = c2.get("/api/sessao").get_json()["csrf"]
        self.assertEqual(c2.get("/api/equipamentos").status_code, 200)
        self.assertEqual(self.post(c2, "/api/verificar", csrf2).status_code, 403)       # leitura não opera
        self.assertEqual(self.post(c2, "/api/equipamentos", csrf2, {}).status_code, 403)
        self.assertEqual(c2.get("/api/usuarios").status_code, 403)
        self.assertEqual(c2.get("/api/arquivo?caminho=x").status_code, 403)

        # o primeiro admin é do FORNECEDOR: não aparece na lista de usuários da empresa
        self.assertTrue(c.get("/api/sessao").get_json()["fornecedor"])
        nomes = [u["usuario"] for u in c.get("/api/usuarios").get_json()["usuarios"]]
        self.assertNotIn("admin", nomes)
        admin_id = banco.um("SELECT id FROM usuarios WHERE usuario='admin'")["id"]
        self.assertEqual(self.post(c, f"/api/usuarios/{admin_id}", csrf, {"papel": "leitura"}).status_code, 404)

        # o admin da empresa não pode rebaixar a si mesmo se for o último
        r = self.post(c, "/api/usuarios", csrf, {"usuario": "gerente", "senha": SENHA_FORTE, "papel": "admin"})
        self.assertEqual(r.status_code, 200, r.get_json())
        banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = 'gerente'")
        c3 = self.cliente()
        _, csrf3 = self.login(c3, "gerente", SENHA_FORTE)
        gerente_id = banco.um("SELECT id FROM usuarios WHERE usuario='gerente'")["id"]
        r = self.post(c3, f"/api/usuarios/{gerente_id}", csrf3, {"papel": "leitura"})
        self.assertIn("último administrador", r.get_json()["mensagem"])
        self.assertEqual(c3.get("/api/fornecedor/empresas").status_code, 403)   # não é fornecedor

        # auditoria registrou as ações
        acoes = [l["acao"] for l in c.get("/api/auditoria").get_json()["registros"]]
        for esperado in ("Login", "Equipamento cadastrado", "Usuário criado", "Senha alterada", "Teste de conexão"):
            self.assertIn(esperado, acoes)

    def test_02_bloqueio_por_tentativas(self):
        c = self.cliente()
        auth.criar_usuario("alvo", SENHA_FORTE, "leitura", empresa_id=1)
        for _ in range(5):
            r, _ = self.login(c, "alvo", "errada")
            self.assertEqual(r.status_code, 401)
        r, _ = self.login(c, "alvo", SENHA_FORTE)      # senha certa, mas bloqueado
        self.assertIn("Muitas tentativas", r.get_json()["mensagem"])
        r, _ = self.login(c, "naoexiste", "x")
        self.assertIn("Muitas tentativas", r.get_json()["mensagem"])  # IP também bloqueado
        banco.executar("DELETE FROM tentativas_login")

    def test_03_2fa(self):
        auth.criar_usuario("op2fa", SENHA_FORTE, "operador", empresa_id=1)
        c = self.cliente()
        _, csrf = self.login(c, "op2fa", SENHA_FORTE)
        r = self.post(c, "/api/minha-conta/2fa/iniciar", csrf)
        segredo = r.get_json()["segredo"]
        self.assertEqual(self.post(c, "/api/minha-conta/2fa/confirmar", csrf, {"codigo": "000000"}).status_code, 400)
        passo = int(time.time() // 30)
        r = self.post(c, "/api/minha-conta/2fa/confirmar", csrf, {"codigo": auth.codigo_totp(segredo, passo - 1)})
        self.assertEqual(r.status_code, 200, r.get_json())

        c2 = self.cliente()
        r, _ = self.login(c2, "op2fa", SENHA_FORTE)
        self.assertTrue(r.get_json()["precisa_2fa"])
        self.assertEqual(c2.get("/api/equipamentos").status_code, 401)   # sessão provisória não acessa nada
        r = c2.post("/api/login/2fa", json={"codigo": "123456"}, headers={"X-Sentinela": "1"})
        self.assertEqual(r.status_code, 401)
        r = c2.post("/api/login/2fa", json={"codigo": auth.codigo_totp(segredo, passo)}, headers={"X-Sentinela": "1"})
        self.assertEqual(r.status_code, 200, r.get_json())
        self.assertEqual(c2.get("/api/equipamentos").status_code, 200)

    def test_04_caminho_proibido(self):
        c = self.cliente()
        _, csrf = self.login(c, "admin", SENHA_FORTE)
        for caminho in ("../sentinela.db", "../chave_mestra.key", "/etc/passwd", "..\\sentinela.db"):
            self.assertEqual(c.get(f"/api/arquivo?caminho={caminho}").status_code, 404, caminho)


class TestMonitoramento(CasoBase):
    def test_deteccao_e_incidentes(self):
        from sentinela import equipamentos
        logs = "\n".join(f"10:0{i}:00 system,error,critical login failure for user admin from 203.0.113.7 via ssh"
                         for i in range(6))
        dev = simulador.mikrotik("BordaTeste", cpu=95)
        simulador.EQUIPAMENTOS["10.0.0.9"] = dev
        eid, _ = equipamentos.salvar({"nome": "BT", "host": "10.0.0.9", "tipo": "mikrotik_routeros",
                                      "usuario": "u", "senha": simulador.Equipamento.senha}, 1)
        equip = equipamentos.obter(eid, 1, segredos=True)

        r = MONITOR.verificar(equip)              # 1º ciclo: linha de base, mas CPU já está alta
        self.assertEqual(r["alertas"], ["CPU em 95% (possível DDoS/flood)"])
        dev.respostas["/log print"] = logs
        dev.respostas["/export"] += "\n/user add name=hacker group=full\n"
        r = MONITOR.verificar(equip)
        tipos = sorted(r["alertas"])
        self.assertTrue(any("força bruta" in a for a in tipos), tipos)
        self.assertTrue(any("Configuração alterada" in a for a in tipos), tipos)

        abertos = incidentes.listar(1, "abertos", equip_id=eid)
        self.assertEqual(sorted(i["tipo"] for i in abertos), ["Configuração alterada", "DDoS/flood", "Força bruta"])
        ddos = next(i for i in abertos if i["tipo"] == "DDoS/flood")
        self.assertEqual(ddos["ocorrencias"], 2)    # agrupou as duas ocorrências de CPU alta
        self.assertTrue(next(i for i in abertos if i["tipo"] == "Força bruta")["pasta"])

        backups = banco.consultar("SELECT * FROM backups WHERE equip_id = ?", (eid,))
        self.assertEqual(len(backups), 2)          # 1º backup + o alterado
        MONITOR.verificar(equip)
        self.assertEqual(len(banco.consultar("SELECT * FROM backups WHERE equip_id = ?", (eid,))), 2)  # sem mudança

        self.assertTrue(incidentes.reconhecer(ddos["id"], "admin", 1))
        self.assertFalse(incidentes.reconhecer(ddos["id"], "admin", 1))
        self.assertTrue(incidentes.resolver(ddos["id"], "admin", 1))

    def test_syslog_tempo_real(self):
        from sentinela import equipamentos
        simulador.EQUIPAMENTOS["127.0.0.1"] = simulador.mikrotik("SyslogTeste")
        eid, _ = equipamentos.salvar({"nome": "SL", "host": "127.0.0.1", "tipo": "mikrotik_routeros",
                                      "usuario": "u", "senha": simulador.Equipamento.senha}, 1)
        capturas = []
        TEMPO_REAL.capturar = lambda *a: capturas.append(a)
        TEMPO_REAL._mapa["quando"] = 0
        for i in range(5):
            TEMPO_REAL.tratar_syslog(f"<86>login failure for user admin from 198.51.100.{i % 2} via ssh", "127.0.0.1")
        TEMPO_REAL.tratar_syslog("<86>login failure for user x from 6.6.6.6", "192.0.2.99")   # não cadastrado
        estado = TEMPO_REAL.estado(1, fornecedor=True)
        maquina = next(m for m in estado["maquinas"] if m["id"] == eid)
        self.assertEqual(maquina["estado"], "ataque")
        self.assertEqual(maquina["ataques"][0]["tipo"], "Força bruta")
        self.assertEqual(maquina["ataques"][0]["qtd"], 5)
        self.assertEqual(estado["syslog"]["ignoradas"], 1)
        self.assertEqual(len(capturas), 1)
        self.assertTrue(incidentes.listar(1, "abertos", equip_id=eid))


if __name__ == "__main__":
    unittest.main()
