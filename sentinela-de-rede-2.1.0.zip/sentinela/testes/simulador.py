"""Simula o netmiko e equipamentos de rede, para testar sem hardware.

Uso nos testes:
    from testes import simulador
    simulador.instalar()                 # substitui o netmiko
    simulador.EQUIPAMENTOS["10.0.0.1"] = simulador.Mikrotik(...)
"""

import sys
import types


class ErroAutenticacao(Exception):
    pass


class ErroTimeout(Exception):
    pass


ErroAutenticacao.__name__ = "NetmikoAuthenticationException"
ErroTimeout.__name__ = "NetmikoTimeoutException"


class Equipamento:
    """Equipamento genérico: responde comandos a partir de um dicionário."""

    senha = "senha-correta"

    def __init__(self, respostas=None, hostname="R1", senha=None):
        self.respostas = dict(respostas or {})
        self.hostname = hostname
        if senha:
            self.senha = senha
        self.comandos = []

    def responder(self, comando):
        self.comandos.append(comando)
        resposta = self.respostas.get(comando, f"% comando desconhecido: {comando}")
        return resposta() if callable(resposta) else resposta


def mikrotik(hostname="Borda01", logs="", cpu=10, extra_config=""):
    return Equipamento({
        "/export": f"# by RouterOS 7.15\n/system identity\nset name={hostname}\n/ip service\nset telnet disabled=yes\n{extra_config}",
        "/log print": logs,
        "/system resource print": f"uptime: 1d\ncpu-load: {cpu}%\nfree-memory: 100MiB",
        "/user active print": "0 admin ssh 203.0.113.7",
        "/ip firewall connection print count-only": "1234",
        "/interface print stats": "ether1 rx 1000 tx 2000",
    }, hostname)


def cisco(hostname="CORE1", cpu=5, extra_config=""):
    return Equipamento({
        "show running-config": f"!\nhostname {hostname}\nline vty 0 4\n transport input ssh\n{extra_config}",
        "show logging": "",
        "show processes cpu | include CPU utilization": f"CPU utilization for five seconds: {cpu}%/0%",
        "show users": "", "show processes cpu sorted": "", "show ip interface brief": "",
    }, hostname)


EQUIPAMENTOS = {}   # host -> Equipamento
CONEXOES = []       # histórico de conexões (para conferir nos testes)


class ConexaoFalsa:
    def __init__(self, **k):
        self.k = k
        CONEXOES.append(k)
        host = k["host"]
        if host not in EQUIPAMENTOS:
            raise ErroTimeout(f"timeout ao conectar em {host}")
        self.equip = EQUIPAMENTOS[host]
        if k["password"] != self.equip.senha:
            raise ErroAutenticacao("Authentication failed")

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def disconnect(self):
        pass

    def check_enable_mode(self):
        return True

    def enable(self):
        pass

    def find_prompt(self):
        return f"{self.equip.hostname}#"

    def send_command(self, comando, **k):
        return self.equip.responder(comando)

    def send_command_timing(self, comando, **k):
        return self.equip.responder(comando)

    def send_config_set(self, comandos, **k):
        aplicados = getattr(self.equip, "configuracoes", None)
        if aplicados is None:
            aplicados = self.equip.configuracoes = []
        aplicados.append({"usuario": self.k["username"], "comandos": list(comandos)})
        return getattr(self.equip, "resposta_config", "") + "\n".join(comandos)

    def commit(self, **k):
        return "\ncommit complete"

    def save_config(self, *a, **k):
        return "[OK]"


def instalar():
    modulo = types.ModuleType("netmiko")
    modulo.ConnectHandler = ConexaoFalsa
    modulo.NetmikoAuthenticationException = ErroAutenticacao
    modulo.NetmikoTimeoutException = ErroTimeout
    sys.modules["netmiko"] = modulo
