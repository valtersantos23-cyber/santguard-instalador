"""Agente SNMP simulado (v2c e v3 SHA/AES), para testar o coletor sem equipamento real."""

import hashlib
import hmac
import os
import socket
import struct
import threading
import time

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms

try:  # CFB foi movido para 'decrepit' nas versões novas da biblioteca
    from cryptography.hazmat.decrepit.ciphers.modes import CFB
except ImportError:  # versões antigas
    from cryptography.hazmat.primitives.ciphers.modes import CFB

from sentinela import snmp as s


def _chave_oid(o):
    return tuple(int(p) for p in o.split("."))


class AgenteSnmp:
    def __init__(self, mib, community="segredo", usuario="sentinela", senha_auth="authsenha123",
                 senha_priv="privsenha123", porta=0):
        self.mib = dict(mib)          # oid -> (tag, bytes_valor)
        self.community = community.encode()
        self.usuario = usuario.encode()
        self.engine_id = b"\x80\x00\x1f\x88\x80" + os.urandom(8)
        self.boots, self.inicio = 7, time.time() - 1000
        self.k_auth = s.chave_localizada(senha_auth, self.engine_id)
        self.k_priv = s.chave_localizada(senha_priv, self.engine_id)[:16]
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", porta))
        self.porta = self.sock.getsockname()[1]
        self.pedidos = 0
        threading.Thread(target=self._laco, daemon=True).start()

    def definir(self, o, tag, valor):
        self.mib[o] = (tag, valor)

    def tempo(self):
        return int(time.time() - self.inicio)

    # ---------------------------------------------------------------- MIB
    def _ordenados(self):
        return sorted(self.mib, key=_chave_oid)

    def _responder_pdu(self, pdu):
        tipo, id_req, a, b, varbinds = s.ler_pdu(pdu)
        tag_pdu, corpo, _ = s.ler_tlv(pdu)
        campos = s.ler_sequencia(corpo)
        saida = []
        if tipo == s.GET:
            for o, _ in varbinds:
                t, v = self.mib.get(o, (0x81, b""))
                saida.append((o, t, v))
        elif tipo in (s.GETNEXT, s.GETBULK):
            repeticoes = s.valor_python(*campos[2]) if tipo == s.GETBULK else 1
            ordenados = self._ordenados()
            for o, _ in varbinds:
                atual = o
                for _ in range(repeticoes):
                    proximo = next((x for x in ordenados if _chave_oid(x) > _chave_oid(atual)), None)
                    if proximo is None:
                        saida.append((atual, 0x82, b""))
                        break
                    t, v = self.mib[proximo]
                    saida.append((proximo, t, v))
                    atual = proximo
        vbs = s.sequencia(*[s.sequencia(s.oid(o), s.tlv(t, v)) for o, t, v in saida])
        return s.sequencia(s.inteiro(id_req), s.inteiro(0), s.inteiro(0), vbs, tag=s.RESPOSTA)

    # ---------------------------------------------------------------- mensagens
    def _laco(self):
        while True:
            dados, origem = self.sock.recvfrom(65535)
            self.pedidos += 1
            try:
                resposta = self._tratar(dados)
            except Exception:
                resposta = None
            if resposta:
                self.sock.sendto(resposta, origem)

    def _tratar(self, dados):
        campos = s.ler_sequencia(s.ler_tlv(dados)[1])
        versao = s.valor_python(*campos[0])
        if versao == 1:
            if campos[1][1] != self.community:
                return None  # community errada: agente real não responde
            pdu = s.tlv(campos[2][0], campos[2][1])
            return s.sequencia(s.inteiro(1), s.texto(self.community), self._responder_pdu(pdu))
        return self._tratar_v3(dados, campos)

    def _relatorio(self, id_msg, oid_erro):
        pdu = s.sequencia(s.inteiro(0), s.inteiro(0), s.inteiro(0),
                          s.sequencia(s.sequencia(s.oid(oid_erro), s.inteiro(1, 0x41))), tag=s.REPORT)
        params = s.sequencia(s.texto(self.engine_id), s.inteiro(self.boots), s.inteiro(self.tempo()),
                             s.texto(b""), s.texto(b""), s.texto(b""))
        scoped = s.sequencia(s.texto(self.engine_id), s.texto(b""), pdu)
        return s.sequencia(s.inteiro(3), s.sequencia(s.inteiro(id_msg), s.inteiro(65507), s.texto(b"\x00"), s.inteiro(3)),
                           s.texto(params), scoped)

    def _tratar_v3(self, dados, campos):
        globais = s.ler_sequencia(campos[1][1])
        id_msg = s.valor_python(*globais[0])
        flags = globais[2][1][0]
        seg = s.ler_sequencia(s.ler_tlv(campos[2][1])[1])
        engine, boots, tempo, usuario, auth, sal = (seg[0][1], s.valor_python(*seg[1]), s.valor_python(*seg[2]),
                                                    seg[3][1], seg[4][1], seg[5][1])
        if not engine:
            return self._relatorio(id_msg, "1.3.6.1.6.3.15.1.1.4.0")
        if usuario != self.usuario:
            return self._relatorio(id_msg, "1.3.6.1.6.3.15.1.1.3.0")
        if flags & 0x01:
            zerada = dados.replace(auth, b"\x00" * 12, 1)
            if hmac.new(self.k_auth, zerada, hashlib.sha1).digest()[:12] != auth:
                return self._relatorio(id_msg, "1.3.6.1.6.3.15.1.1.5.0")
            if abs(tempo - self.tempo()) > 150:
                return self._relatorio(id_msg, "1.3.6.1.6.3.15.1.1.2.0")
        corpo = campos[3]
        if flags & 0x02:
            iv = struct.pack(">II", boots, tempo) + sal
            claro = Cipher(algorithms.AES(self.k_priv), CFB(iv)).decryptor().update(corpo[1])
            try:
                corpo = s.ler_tlv(claro)[:2]
                partes = s.ler_sequencia(corpo[1])
                pdu = s.tlv(partes[2][0], partes[2][1])
                s.ler_pdu(pdu)
            except Exception:
                return self._relatorio(id_msg, "1.3.6.1.6.3.15.1.1.6.0")
        else:
            partes = s.ler_sequencia(corpo[1])
            pdu = s.tlv(partes[2][0], partes[2][1])

        resposta_pdu = self._responder_pdu(pdu)
        scoped = s.sequencia(s.texto(self.engine_id), s.texto(b""), resposta_pdu)
        novo_sal = os.urandom(8)
        t = self.tempo()
        if flags & 0x02:
            iv = struct.pack(">II", self.boots, t) + novo_sal
            cifra = Cipher(algorithms.AES(self.k_priv), CFB(iv)).encryptor()
            scoped = s.texto(cifra.update(scoped) + cifra.finalize())
        else:
            novo_sal = b""

        def montar(auth_params):
            params = s.sequencia(s.texto(self.engine_id), s.inteiro(self.boots), s.inteiro(t), s.texto(self.usuario),
                                 s.texto(auth_params), s.texto(novo_sal))
            return s.sequencia(s.inteiro(3), s.sequencia(s.inteiro(id_msg), s.inteiro(65507),
                                                         s.texto(bytes([flags & 0x03])), s.inteiro(3)),
                               s.texto(params), scoped)
        mensagem = montar(b"\x00" * 12 if flags & 0x01 else b"")
        if flags & 0x01:
            mensagem = montar(hmac.new(self.k_auth, mensagem, hashlib.sha1).digest()[:12])
        return mensagem


def mib_mikrotik(cpu=12, ram_total=1048576, ram_usada=262144, in_octets=0, out_octets=0, oper=1):
    """MIB parecida com a de um MikroTik: hrProcessorLoad, hrStorage e interfaces."""
    i = lambda n: (0x02, s.inteiro(n)[2:])
    g = lambda n: (0x42, n.to_bytes(4, "big"))
    c64 = lambda n: (0x46, n.to_bytes(8, "big"))
    txt = lambda t: (0x04, t.encode())
    return {
        "1.3.6.1.2.1.1.1.0": txt("RouterOS CCR2004"),
        "1.3.6.1.2.1.1.3.0": (0x43, (8640000).to_bytes(4, "big")),   # 1 dia em centésimos
        "1.3.6.1.2.1.1.5.0": txt("BORDA-SNMP"),
        "1.3.6.1.2.1.25.3.3.1.2.1": i(cpu), "1.3.6.1.2.1.25.3.3.1.2.2": i(cpu),
        "1.3.6.1.2.1.25.2.3.1.2.65536": (0x06, s.oid("1.3.6.1.2.1.25.2.1.2")[2:]),
        "1.3.6.1.2.1.25.2.3.1.4.65536": i(1024),
        "1.3.6.1.2.1.25.2.3.1.5.65536": i(ram_total),
        "1.3.6.1.2.1.25.2.3.1.6.65536": i(ram_usada),
        "1.3.6.1.2.1.2.2.1.8.1": i(oper), "1.3.6.1.2.1.2.2.1.8.2": i(1),
        "1.3.6.1.2.1.2.2.1.14.1": (0x41, (0).to_bytes(4, "big")), "1.3.6.1.2.1.2.2.1.14.2": (0x41, (0).to_bytes(4, "big")),
        "1.3.6.1.2.1.31.1.1.1.1.1": txt("sfp-sfpplus1"), "1.3.6.1.2.1.31.1.1.1.1.2": txt("ether2"),
        "1.3.6.1.2.1.31.1.1.1.6.1": c64(in_octets), "1.3.6.1.2.1.31.1.1.1.6.2": c64(0),
        "1.3.6.1.2.1.31.1.1.1.10.1": c64(out_octets), "1.3.6.1.2.1.31.1.1.1.10.2": c64(0),
        "1.3.6.1.2.1.31.1.1.1.15.1": g(10000), "1.3.6.1.2.1.31.1.1.1.15.2": g(1000),
        "1.3.6.1.2.1.31.1.1.1.18.1": txt("UPLINK OPERADORA A"), "1.3.6.1.2.1.31.1.1.1.18.2": txt(""),
    }
