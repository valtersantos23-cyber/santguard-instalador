"""Sobe o Sentinela com equipamentos simulados, para testar a interface no navegador.

    python testes/servidor_demo.py [pasta_de_dados]
"""

import os
import sys
import tempfile

pasta = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix="sentinela_demo_")
os.environ["SENTINELA_DADOS"] = pasta
os.environ.setdefault("SENTINELA_WEB_PORTA", "8443")
os.environ.setdefault("SENTINELA_TEMPO_REAL_SYSLOG_PORTA", "5514")
os.environ.setdefault("SENTINELA_FLUXO_PORTA_NETFLOW", "12055")
os.environ.setdefault("SENTINELA_FLUXO_PORTA_SFLOW", "16343")
os.environ.setdefault("SENTINELA_FLUXO_REDES_PROPRIAS", "177.10.0.0/22,2804:abcd::/32")
os.environ.setdefault("SENTINELA_BGP_INTERVALO_MINUTOS", "1")
os.environ.setdefault("SENTINELA_OLT_INTERVALO_MINUTOS", "1")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from testes import simulador  # noqa: E402

MIKROTIK = """Flags: E - established
 0 E name="transito-a-1"
     remote.address=10.3.3.1 .as=65030 .id=10.3.3.1 .capabilities=mp,rr,as4 .afi=ip
     local.role=ebgp .address=10.3.3.2 .as=64500 .id=10.3.3.2
     hold-time=1m30s keepalive-time=30s uptime=5d3h prefix-count=948000

 1   name="transito-b-1"
     remote.address=10.3.3.5 .as=65031
     local.role=ebgp .address=10.3.3.6 .as=64500
"""


def zte_estado(working):
    linhas = ["OnuIndex                 Admin State  OMCC State  Phase State  Channel", "-" * 70]
    for i in range(1, 13):
        fase = "working" if i <= working else ("LOS" if i % 3 else "DyingGasp")
        linhas.append(f"gpon-onu_1/2/1:{i}         enable       enable      {fase:<12} 1(GPON)")
    return "\n".join(linhas)

simulador.instalar()
falhas = "\n".join(f"10:0{i}:00 system,error,critical login failure for user admin from 203.0.113.7 via ssh"
                   for i in range(6))
borda = simulador.mikrotik("BORDA-POP-CENTRO", cpu=12)
borda.respostas["/routing/bgp/session/print detail without-paging"] = MIKROTIK
olt = simulador.Equipamento({"show gpon onu state": zte_estado(12),
                             "show pon power onu-rx gpon-olt_1/2/1": "\n".join(
                                 f"gpon-onu_1/2/1:{i}     -{18 + i}.10(dbm)" for i in range(1, 13))}, "OLT-CENTRO")
simulador.EQUIPAMENTOS.update({
    "127.0.0.1": borda,
    "10.0.0.10": simulador.cisco("CORE-01", cpu=35),
    "10.0.0.20": simulador.mikrotik("CONCENTRADOR-01", cpu=97),
    "10.0.0.30": olt,
})
simulador.EQUIPAMENTOS["10.0.0.10"].respostas["show logging"] = falhas

if os.environ.get("DEMO_QUEDA_OLT"):
    olt.respostas["show gpon onu state"] = zte_estado(2)

from sentinela import servidor  # noqa: E402

print("Pasta de dados:", pasta, flush=True)
servidor.iniciar()
