"""Licença da instalação: ativação por solicitação/liberação, bloqueios, limites e antifraude."""

import json
import os
import subprocess
import sys
import time

from testes.base import SENHA_FORTE, CasoBase, simulador
from testes import licenca_teste
from sentinela import autenticacao as auth, banco, ed25519, empresas, licenca

DIA = 86400


class TestLicencaInstalacao(CasoBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        for usuario, forn in (("forn.lic", True), ("admin.lic", False)):
            if not banco.um("SELECT id FROM usuarios WHERE usuario = ?", (usuario,)):
                auth.criar_usuario(usuario, SENHA_FORTE, "admin", fornecedor=forn,
                                   **({} if forn else {"empresa_id": 1}))
                banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = ?", (usuario,))

    def setUp(self):
        self.arquivo = licenca._arquivo()
        self.original = self.arquivo.read_text(encoding="utf-8")
        self.relogio_original = licenca._relogio
        self.agora = time.time()
        licenca._relogio = lambda: self.agora
        licenca._limpar_cache()

    def tearDown(self):
        licenca._relogio = self.relogio_original
        licenca._maquina_memo = None
        self.arquivo.write_text(self.original, encoding="utf-8")
        licenca._limpar_cache()

    # ------------------------------------------------------------ ajudantes
    def entrar(self, usuario):
        c = self.cliente()
        r, csrf = self.login(c, usuario, SENHA_FORTE)
        self.assertEqual(r.status_code, 200, r.get_json())
        return c, csrf

    def sem_licenca(self):
        self.arquivo.unlink()
        licenca._limpar_cache()

    def avancar(self, dias):
        self.agora += dias * DIA
        licenca._limpar_cache()

    # ------------------------------------------------------------ testes
    def test_sem_licenca_bloqueia_tudo_menos_a_ativacao(self):
        self.sem_licenca()
        self.assertEqual(licenca.estado()["situacao"], "sem_licenca")
        self.assertEqual(empresas.ids_ativos(), set())  # monitoramento parado

        ca, _ = self.entrar("admin.lic")
        sessao = ca.get("/api/sessao").get_json()
        self.assertFalse(sessao["licenca"]["valida"])
        r = ca.get("/api/equipamentos")
        self.assertEqual(r.status_code, 402)
        self.assertIn("Avise o administrador", r.get_json()["mensagem"])
        self.assertEqual(ca.get("/api/fornecedor/licenca").status_code, 403)  # provedor não ativa

        cf, csrf = self.entrar("forn.lic")
        self.assertEqual(cf.get("/api/aovivo").status_code, 402)
        self.assertEqual(cf.get("/api/fornecedor/empresas").status_code, 402)
        d = cf.get("/api/fornecedor/licenca").get_json()
        self.assertEqual(d["licenca"]["situacao"], "sem_licenca")

        # fluxo completo pelo painel
        r = self.post(cf, "/api/fornecedor/licenca/solicitar", csrf)
        self.assertEqual(r.status_code, 200)
        chave = licenca_teste.emitir(r.get_json()["codigo"], dias=30, agora=self.agora)
        r = self.post(cf, "/api/fornecedor/licenca/ativar", csrf, {"codigo": chave.lower().replace("-", " ")})
        self.assertEqual(r.status_code, 200, r.get_json())
        self.assertEqual(r.get_json()["licenca"]["dias_restantes"], 30)
        self.assertEqual(ca.get("/api/equipamentos").status_code, 200)
        self.assertIn(1, empresas.ids_ativos())
        acoes = [l["acao"] for l in banco.consultar("SELECT acao FROM auditoria ORDER BY id DESC LIMIT 5")]
        self.assertIn("Licença do sistema ativada", acoes)

    def test_vencimento_e_aviso(self):
        self.sem_licenca()
        licenca_teste.ativar(dias=30)
        self.avancar(22)
        cf, _ = self.entrar("forn.lic")
        self.assertIn("vence em 8 dia", cf.get("/api/sessao").get_json()["licenca"]["aviso"])
        ca, _ = self.entrar("admin.lic")
        self.assertEqual(ca.get("/api/sessao").get_json()["licenca"]["aviso"], "")  # aviso só para o fornecedor
        self.avancar(8)
        lic = licenca.estado()
        self.assertEqual(lic["situacao"], "vencida")
        self.assertEqual(empresas.ids_ativos(), set())
        self.assertEqual(ca.get("/api/equipamentos").status_code, 402)

    def test_renovacao_aceita_novo_codigo_e_recusa_reuso(self):
        self.sem_licenca()
        sol = licenca.gerar_solicitacao()
        chave = licenca_teste.emitir(sol, agora=self.agora)
        licenca.ativar(chave)
        with self.assertRaisesRegex(licenca.LicencaErro, "nenhuma solicitação"):
            licenca.ativar(chave)
        self.arquivo.unlink()  # apagar o arquivo não faz a chave antiga voltar a valer
        licenca.gerar_solicitacao()
        with self.assertRaisesRegex(licenca.LicencaErro, "nenhuma solicitação"):
            licenca.ativar(chave)

    def test_outro_servidor_e_falsificacao(self):
        self.sem_licenca()
        sol = licenca.gerar_solicitacao()
        pirata = licenca_teste.emitir(sol, chave=ed25519.gerar_chave_privada(), agora=self.agora)
        with self.assertRaisesRegex(licenca.LicencaErro, "assinatura"):
            licenca.ativar(pirata)
        chave = licenca_teste.emitir(sol, agora=self.agora)
        licenca._maquina_memo = b"OUTRAMAQ"
        with self.assertRaisesRegex(licenca.LicencaErro, "outro servidor"):
            licenca.ativar(chave)
        # copiar a pasta de dados para outro servidor também não funciona
        licenca._maquina_memo = None
        licenca.ativar(chave)
        licenca._maquina_memo = b"OUTRAMAQ"
        licenca._limpar_cache()
        self.assertIn("outro servidor", licenca.estado()["texto"])

    def test_erros_de_digitacao(self):
        self.sem_licenca()
        chave = licenca_teste.emitir(licenca.gerar_solicitacao(), agora=self.agora)
        troca = "A" if chave[30] != "A" else "B"
        with self.assertRaisesRegex(licenca.LicencaErro, "digitado errado"):
            licenca.ativar(chave[:30] + troca + chave[31:])
        with self.assertRaisesRegex(licenca.LicencaErro, "SOLICITAÇÃO"):
            licenca.ativar(licenca.gerar_solicitacao())

    def test_relogio_atrasado_e_arquivo_editado(self):
        self.sem_licenca()
        licenca_teste.ativar(dias=30)
        self.avancar(20)
        self.assertTrue(licenca.estado()["valida"])
        self.avancar(-10)
        self.assertEqual(licenca.estado()["situacao"], "relogio")
        self.avancar(10)
        self.assertTrue(licenca.estado()["valida"])
        dados = json.loads(self.arquivo.read_text())
        dados["ultimo_uso"] = 0
        self.arquivo.write_text(json.dumps(dados))
        licenca._limpar_cache()
        self.assertIn("alterado", licenca.estado()["texto"])

    def test_limites_de_equipamentos_e_empresas(self):
        self.sem_licenca()
        n_equip = banco.um("SELECT COUNT(*) AS n FROM equipamentos")["n"]
        n_empr = banco.um("SELECT COUNT(*) AS n FROM empresas")["n"]
        licenca_teste.ativar(dias=30, equipamentos=n_equip + 1, empresas=n_empr)

        ca, csrf_a = self.entrar("admin.lic")
        simulador.EQUIPAMENTOS["10.250.0.1"] = simulador.mikrotik("LIC1")
        simulador.EQUIPAMENTOS["10.250.0.2"] = simulador.mikrotik("LIC2")
        base = {"tipo": "mikrotik_routeros", "usuario": "u", "senha": simulador.Equipamento.senha}
        r = self.post(ca, "/api/equipamentos", csrf_a, {**base, "nome": "Lic 1", "host": "10.250.0.1"})
        self.assertEqual(r.status_code, 200, r.get_json())
        r = self.post(ca, "/api/equipamentos", csrf_a, {**base, "nome": "Lic 2", "host": "10.250.0.2"})
        self.assertIn("Limite da licença do sistema", r.get_json()["mensagem"])

        cf, csrf_f = self.entrar("forn.lic")
        r = self.post(cf, "/api/fornecedor/empresas", csrf_f, {"nome": "Empresa Extra Lic"})
        self.assertIn("Limite da licença do sistema", r.get_json()["mensagem"])
        d = cf.get("/api/fornecedor/licenca").get_json()
        self.assertEqual(d["licenca"]["limite_equipamentos"], n_equip + 1)
        self.assertEqual(d["uso"]["equipamentos"], n_equip + 1)

    def test_tela_de_registro_sem_login(self):
        self.sem_licenca()
        c = self.cliente()  # ninguém logado
        r1 = c.get("/api/registro").get_json()
        self.assertFalse(r1["valida"])
        self.assertEqual(c.get("/api/registro").get_json()["serial"], r1["serial"])  # serial fixo
        self.assertEqual(c.get("/api/equipamentos").status_code, 401)  # o resto continua exigindo login

        h = {"X-Sentinela": "1"}
        r = c.post("/api/registro/ativar", json={"codigo": "ABCDE-FGHIJ"}, headers=h)
        self.assertEqual(r.status_code, 400)
        chave = licenca_teste.emitir(r1["serial"], agora=self.agora)
        r = c.post("/api/registro/ativar", json={"codigo": chave}, headers=h)
        self.assertEqual(r.status_code, 200, r.get_json())
        self.assertEqual(c.get("/api/registro").get_json(), {"valida": True})  # ativado: não mostra o serial
        r = c.post("/api/registro/ativar", json={"codigo": chave}, headers=h)
        self.assertEqual(r.status_code, 409)  # renovação só pela aba Licença, com login
        self.assertEqual(c.post("/api/registro/ativar", json={"codigo": chave}).status_code, 403)  # sem cabeçalho

        # depois de usado, o serial seguinte é outro
        self.assertNotEqual(licenca.serial_atual(), r1["serial"])

    def test_serial_muda_depois_de_30_dias(self):
        self.sem_licenca()
        s1 = licenca.serial_atual()
        self.avancar(29)
        self.assertEqual(licenca.serial_atual(), s1)
        self.avancar(2)
        self.assertNotEqual(licenca.serial_atual(), s1)

    def test_linha_de_comando(self):
        env = dict(os.environ, SENTINELA_DADOS=str(licenca.pasta_dados()))
        r = subprocess.run([sys.executable, "-m", "sentinela", "licenca"], capture_output=True, text=True,
                           env=env, cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))), timeout=60)
        # o processo novo não tem a chave pública de teste, então a licença aparece como inválida
        self.assertEqual(r.returncode, 2, r.stderr)
        self.assertIn("Servidor (ID)", r.stdout)
        self.assertIn("licenca-solicitar", r.stdout)
