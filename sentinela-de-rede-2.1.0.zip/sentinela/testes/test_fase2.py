"""Fase 2: SNMP (v2c/v3), coleta de CPU/memória/interfaces, alertas e métricas."""

import time
import unittest

from testes.base import SENHA_FORTE, CasoBase, simulador
from testes.agente_snmp import AgenteSnmp, mib_mikrotik
from sentinela import autenticacao as auth, banco, config, equipamentos, incidentes, snmp
from sentinela.coletor_snmp import COLETOR


class TestSnmp(unittest.TestCase):
    def test_chave_rfc3414(self):
        chave = snmp.chave_localizada("maplesyrup", bytes.fromhex("000000000000000000000002"))
        self.assertEqual(chave.hex(), "6695febc9288e36282235fc7151f128497b38f3f")

    def test_ber_oid_ida_e_volta(self):
        for o in ("1.3.6.1.2.1.1.3.0", "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5", "1.3.6.1.4.1.14988.1.1.1.3.1.4.4294967295"):
            tag, valor, _ = snmp.ler_tlv(snmp.oid(o))
            self.assertEqual(snmp.oid_para_texto(valor), o)

    def test_inteiros(self):
        for n in (0, 1, 127, 128, 255, 256, -1, -129, 2 ** 31 - 1):
            tag, valor, _ = snmp.ler_tlv(snmp.inteiro(n))
            self.assertEqual(snmp.valor_python(tag, valor), n)


class TestColetor(CasoBase):
    def test_coleta_v3_completa(self):
        agente = AgenteSnmp(mib_mikrotik(cpu=20, in_octets=10_000_000, out_octets=5_000_000))
        simulador.EQUIPAMENTOS["10.9.9.1"] = simulador.mikrotik("BORDA-SNMP")
        eid, erro = equipamentos.salvar({
            "nome": "Borda SNMP", "host": "127.0.0.1", "porta": 2201, "tipo": "mikrotik_routeros", "usuario": "u",
            "senha": "x", "funcao": "borda", "snmp_versao": "3", "snmp_porta": agente.porta,
            "snmp_v3_usuario": "sentinela", "snmp_v3_auth": "authsenha123", "snmp_v3_priv": "privsenha123"}, 1)
        self.assertIsNone(erro)
        equip = equipamentos.obter(eid, 1, segredos=True)

        r = COLETOR.coletar(equip)
        self.assertIsNone(r["erro"], r)
        st = banco.um("SELECT * FROM status WHERE equip_id = ?", (eid,))
        self.assertEqual((st["cpu"], st["memoria"], st["uptime"]), (20, 25, 86400))
        self.assertEqual(len(COLETOR.interfaces[eid]), 2)

        # tráfego: +125 MB em ~1s na entrada => ~1 Gbps
        time.sleep(1)
        agente.definir("1.3.6.1.2.1.31.1.1.1.6.1", 0x46, (10_000_000 + 125_000_000).to_bytes(8, "big"))
        COLETOR.coletar(equip)
        uplink = next(i for i in COLETOR.interfaces[eid] if i["nome"] == "sfp-sfpplus1")
        self.assertGreater(uplink["bps_in"], 700_000_000)
        self.assertEqual(uplink["descricao"], "UPLINK OPERADORA A")

        # uplink cai (roteador de borda => alerta)
        agente.definir("1.3.6.1.2.1.2.2.1.8.1", 0x02, b"\x02")
        COLETOR.coletar(equip)
        quedas = [i for i in incidentes.listar(1, "abertos", equip_id=eid) if i["tipo"] == "Interface caiu"]
        self.assertEqual(len(quedas), 1)
        self.assertIn("UPLINK OPERADORA A", quedas[0]["titulo"])

        # CPU alta: só alerta na 2ª coleta seguida
        agente.definir("1.3.6.1.2.1.25.3.3.1.2.1", 0x02, b"\x62")   # 98
        agente.definir("1.3.6.1.2.1.25.3.3.1.2.2", 0x02, b"\x62")
        COLETOR.coletar(equip)
        self.assertFalse([i for i in incidentes.listar(1, "abertos", equip_id=eid) if i["tipo"] == "DDoS/flood"])
        COLETOR.coletar(equip)
        ddos = [i for i in incidentes.listar(1, "abertos", equip_id=eid) if i["tipo"] == "DDoS/flood"]
        self.assertEqual(len(ddos), 1)
        self.assertIn("CPU em 98%", ddos[0]["titulo"])

    def test_erro_snmp_vira_status(self):
        eid, _ = equipamentos.salvar({"nome": "Sem SNMP", "host": "127.0.0.1", "porta": 2202, "tipo": "cisco_ios",
                                      "usuario": "u", "senha": "x", "snmp_versao": "2c", "snmp_porta": 9,
                                      "snmp_community": "errada"}, 1)
        equip = equipamentos.obter(eid, 1, segredos=True)
        r = COLETOR.coletar(equip)
        self.assertIn("sem resposta", r["erro"])
        self.assertIn("sem resposta", banco.um("SELECT snmp_erro FROM status WHERE equip_id = ?", (eid,))["snmp_erro"])

    def test_metricas(self):
        c = self.cliente()
        self.assertEqual(c.get("/metrics").status_code, 404)        # desligado por padrão
        config.CFG["metricas"]["token"] = "token-de-teste-bem-longo-123"
        try:
            self.assertEqual(c.get("/metrics").status_code, 401)
            self.assertEqual(c.get("/metrics", headers={"Authorization": "Bearer errado"}).status_code, 401)
            r = c.get("/metrics", headers={"Authorization": "Bearer token-de-teste-bem-longo-123"})
            self.assertEqual(r.status_code, 200)
            texto = r.get_data(as_text=True)
            self.assertIn("sentinela_equipamento_disponivel{", texto)
            self.assertIn("# TYPE sentinela_cpu_percentual gauge", texto)
        finally:
            config.CFG["metricas"]["token"] = ""

    def test_api_testar_snmp(self):
        agente = AgenteSnmp(mib_mikrotik())
        if not banco.um("SELECT id FROM usuarios WHERE usuario = 'admsnmp'"):
            auth.criar_usuario("admsnmp", SENHA_FORTE, "admin", empresa_id=1)
        c = self.cliente()
        _, csrf = self.login(c, "admsnmp", SENHA_FORTE)
        r = self.post(c, "/api/equipamentos/testar-snmp", csrf, {
            "host": "127.0.0.1", "tipo": "mikrotik_routeros", "usuario": "u", "senha": "x",
            "snmp_versao": "2c", "snmp_porta": agente.porta, "snmp_community": "segredo"})
        self.assertTrue(r.get_json()["ok"], r.get_json())
        self.assertIn("BORDA-SNMP", r.get_json()["mensagem"])


if __name__ == "__main__":
    unittest.main()
