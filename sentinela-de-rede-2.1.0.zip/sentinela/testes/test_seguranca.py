"""Regressões dos achados da revisão de segurança."""

import struct
import threading
import time
import unittest

from testes import gerador_fluxo as g
from testes.base import CasoBase
from sentinela import alertas, config, equipamentos, mitigacao
from sentinela.fluxo import ColetorFluxo
from sentinela.mitigacao import MITIGADOR


class TestRevisao(CasoBase):
    def setUp(self):
        config.CFG["fluxo"]["redes_proprias"] = ["177.10.0.0/22", "2804:abcd::/32"]

    def test_scope_id_ipv6_nao_injeta_comando(self):
        cfg = mitigacao.ler_config(1)
        for alvo in ("2804:abcd::5%eth0\n/system reset-configuration", "2804:abcd::5%eth0", "177.10.0.5 ",
                     "177.10.0.5\n/user add", "177.10.0.5;reboot"):
            with self.assertRaises(ValueError, msg=repr(alvo)):
                mitigacao.validar_alvo("rtbh", alvo.rstrip(" ") + (" x" if alvo.endswith(" ") else ""), cfg, 1)
        self.assertEqual(mitigacao.validar_alvo("rtbh", "2804:abcd::5", cfg, 1), "2804:abcd::5")

    def test_duracao_fora_da_faixa(self):
        eid, _ = equipamentos.salvar({"nome": "B", "host": "10.123.0.1", "tipo": "cisco_ios", "usuario": "u",
                                      "senha": "x", "funcao": "borda"}, 1)
        for duracao in (-50, 1, 99999):
            with self.assertRaises(ValueError):
                MITIGADOR.propor(1, "rtbh", "177.10.0.44", "x", [eid], duracao_min=duracao)

    def test_template_com_campo_de_tamanho_zero_nao_trava(self):
        c = ColetorFluxo()
        tpl = struct.pack(">HH", 400, 2) + struct.pack(">HHHH", 8, 0, 12, 0)
        conjunto_tpl = struct.pack(">HH", 0, 4 + len(tpl)) + tpl
        dados = struct.pack(">HH", 400, 12) + b"\x00" * 8
        pacote = struct.pack(">HHIIII", 9, 2, 1, int(time.time()), 1, 1) + conjunto_tpl + dados
        terminou = threading.Event()
        threading.Thread(target=lambda: (c.processar_pacote(pacote, "10.0.0.1"), terminou.set()), daemon=True).start()
        self.assertTrue(terminou.wait(2), "o coletor travou")

    def test_exportador_nao_cadastrado_e_ignorado(self):
        c = ColetorFluxo()
        pacote = g.netflow_v5(g.fluxos_syn_flood("177.10.0.5", 10))
        self.assertEqual(c.processar_pacote(pacote, "198.51.100.66", verificar_origem=True), [])
        self.assertEqual(c.ultimo_ignorado, "198.51.100.66")
        equipamentos.salvar({"nome": "Exportador", "host": "10.124.0.1", "tipo": "cisco_ios", "usuario": "u", "senha": "x"}, 1)
        from sentinela.tempo_real import TEMPO_REAL
        TEMPO_REAL._mapa["quando"] = 0
        self.assertEqual(len(c.processar_pacote(pacote, "10.124.0.1", verificar_origem=True)), 10)

    def test_webhook_para_metadados_recusado(self):
        for url in ("http://169.254.169.254/latest/meta-data", "http://[fe80::1]/x"):
            with self.assertRaises(alertas.ErroAlerta, msg=url):
                alertas.salvar_config(1, {"webhook": {"url": url}})
        alertas.salvar_config(1, {"webhook": {"url": "http://192.168.0.10:8080/evolution"}})   # LAN é permitida


if __name__ == "__main__":
    unittest.main()
