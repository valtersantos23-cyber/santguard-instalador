"""Gera pacotes NetFlow v5/v9, IPFIX e sFlow v5 (como os roteadores enviam), para testes e demonstração."""

import ipaddress
import random
import struct
import time


def _ip4(t):
    return ipaddress.ip_address(t).packed


def netflow_v5(fluxos, amostragem=0, duracao_ms=0):
    """fluxos: lista de (origem, destino, proto, sporta, dporta, flags, bytes, pacotes)."""
    cab = struct.pack(">HHIIIIBBH", 5, len(fluxos), 1000, int(time.time()), 0, 1, 0, 0, amostragem)
    corpo = b""
    for o, d, proto, sp, dp, flags, b, p in fluxos:
        corpo += _ip4(o) + _ip4(d) + _ip4("0.0.0.0") + struct.pack(">HHIIII", 1, 2, p, b, 5000, 5000 + duracao_ms)
        corpo += struct.pack(">HHBBBBHHBBH", sp, dp, 0, flags, proto, 0, 0, 0, 24, 24, 0)
    return cab + corpo


CAMPOS_V4 = [(8, 4), (12, 4), (4, 1), (7, 2), (11, 2), (6, 1), (1, 4), (2, 4)]
CAMPOS_TEMPO = [(22, 4), (21, 4)]   # FIRST_SWITCHED, LAST_SWITCHED (uptime em ms)
CAMPOS_V6 = [(27, 16), (28, 16), (4, 1), (7, 2), (11, 2), (6, 1), (1, 8), (2, 8)]


def _registro(campos, fluxo, duracao_ms=0):
    o, d, proto, sp, dp, flags, b, p = fluxo
    valores = {8: _ip4(o) if ":" not in o else None, 12: _ip4(d) if ":" not in d else None,
               27: ipaddress.ip_address(o).packed, 28: ipaddress.ip_address(d).packed,
               4: proto, 7: sp, 11: dp, 6: flags, 1: b, 2: p, 22: 100_000, 21: 100_000 + duracao_ms}
    saida = b""
    for tipo, tam in campos:
        v = valores[tipo]
        saida += v if isinstance(v, bytes) else v.to_bytes(tam, "big")
    return saida


def _alinhar(b):
    return b + b"\x00" * (-len(b) % 4)


def netflow_v9(fluxos, template_id=260, amostragem=None, enviar_template=True, ipv6=False, duracao_ms=None):
    campos = (CAMPOS_V6 if ipv6 else CAMPOS_V4) + (CAMPOS_TEMPO if duracao_ms is not None else [])
    conjuntos = []
    if enviar_template:
        tpl = struct.pack(">HH", template_id, len(campos)) + b"".join(struct.pack(">HH", t, l) for t, l in campos)
        conjuntos.append(struct.pack(">HH", 0, 4 + len(tpl)) + tpl)
        if amostragem:
            # template de opções: escopo System(1, 4 bytes) + SAMPLING_INTERVAL(34, 4 bytes)
            opc = struct.pack(">HHH", 300, 4, 4) + struct.pack(">HHHH", 1, 4, 34, 4)
            opc = _alinhar(struct.pack(">HH", 1, 4 + len(opc)) + opc)
            conjuntos.append(opc[:2] + struct.pack(">H", len(opc)) + opc[4:])
            dados_opc = _alinhar(struct.pack(">HH", 300, 0) + struct.pack(">II", 0, amostragem))
            conjuntos.append(dados_opc[:2] + struct.pack(">H", len(dados_opc)) + dados_opc[4:])
    dados = b"".join(_registro(campos, f, duracao_ms or 0) for f in fluxos)
    bloco = _alinhar(struct.pack(">HH", template_id, 0) + dados)
    conjuntos.append(bloco[:2] + struct.pack(">H", len(bloco)) + bloco[4:])
    cab = struct.pack(">HHIIII", 9, len(fluxos), 1000, int(time.time()), 1, 7)
    return cab + b"".join(conjuntos)


def ipfix(fluxos, template_id=300, enviar_template=True):
    conjuntos = []
    if enviar_template:
        tpl = struct.pack(">HH", template_id, len(CAMPOS_V4)) + b"".join(struct.pack(">HH", t, l) for t, l in CAMPOS_V4)
        # um campo de fabricante (enterprise) para testar o pulo
        tpl = struct.pack(">HH", template_id, len(CAMPOS_V4) + 1) + b"".join(
            struct.pack(">HH", t, l) for t, l in CAMPOS_V4) + struct.pack(">HHI", 0x8000 | 100, 2, 14988)
        conjuntos.append(struct.pack(">HH", 2, 4 + len(tpl)) + tpl)
    dados = b"".join(_registro(CAMPOS_V4, f) + b"\x00\x07" for f in fluxos)
    conjuntos.append(struct.pack(">HH", template_id, 4 + len(dados)) + dados)
    corpo = b"".join(conjuntos)
    return struct.pack(">HHIII", 10, 16 + len(corpo), int(time.time()), 1, 9) + corpo


def _quadro(o, d, proto, sp, dp, flags, vlan=None):
    eth = b"\x00\x11\x22\x33\x44\x55" + b"\x66\x77\x88\x99\xaa\xbb"
    if vlan:
        eth += struct.pack(">HH", 0x8100, vlan)
    if ":" in d:
        eth += struct.pack(">H", 0x86DD)
        ip = struct.pack(">IHBB", 0x60000000, 40, proto, 64) + ipaddress.ip_address(o).packed + ipaddress.ip_address(d).packed
    else:
        eth += struct.pack(">H", 0x0800)
        ip = struct.pack(">BBHHHBBH", 0x45, 0, 60, 0, 0, 64, proto, 0) + _ip4(o) + _ip4(d)
    l4 = b""
    if proto == 6:
        l4 = struct.pack(">HHIIBBHHH", sp, dp, 0, 0, 0x50, flags, 1024, 0, 0)
    elif proto == 17:
        l4 = struct.pack(">HHHH", sp, dp, 40, 0)
    return eth + ip + l4


def sflow_v5(amostras, taxa=1000, expandido=False, vlan=None):
    """amostras: lista de (origem, destino, proto, sporta, dporta, flags, tamanho_quadro)."""
    corpo = b""
    for o, d, proto, sp, dp, flags, tam in amostras:
        cab = _quadro(o, d, proto, sp, dp, flags, vlan)
        cab_pad = cab + b"\x00" * (-len(cab) % 4)
        registro = struct.pack(">IIII", 1, tam, 4, len(cab)) + cab_pad
        reg = struct.pack(">II", 1, len(registro)) + registro
        if expandido:
            # sequência, tipo e índice da origem, taxa, pool, descartes, entrada (formato, valor), saída, nº registros
            amostra = struct.pack(">IIIIIIIIIII", 1, 0, 3, taxa, 100000, 0, 0, 1, 0, 2, 1) + reg
        else:
            amostra = struct.pack(">IIIIIIII", 1, 3, taxa, 100000, 0, 1, 2, 1) + reg
        corpo += struct.pack(">II", 3 if expandido else 1, len(amostra)) + amostra
    cab = struct.pack(">II", 5, 1) + _ip4("10.0.0.1") + struct.pack(">IIII", 0, 1, 1000, len(amostras))
    return cab + corpo


def fluxos_syn_flood(alvo, quantidade=200, bytes_por_fluxo=6_000_000, pacotes=100_000):
    return [(f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}",
             alvo, 6, random.randint(1024, 65535), 443, 0x02, bytes_por_fluxo, pacotes) for _ in range(quantidade)]


def fluxos_dns_amplificacao(alvo, refletores=50, bytes_por_fluxo=40_000_000):
    return [(f"198.51.100.{i}", alvo, 17, 53, random.randint(1024, 65535), 0, bytes_por_fluxo, 12_000)
            for i in range(1, refletores + 1)]
