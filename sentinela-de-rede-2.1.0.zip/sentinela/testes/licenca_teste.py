"""Licença para os testes: cria um par de chaves descartável e faz um "mini fornecedor".

Usa exatamente o mesmo caminho da produção (solicitação -> liberação assinada -> ativação).
"""

import time

from sentinela import ed25519, licenca
from sentinela.licenca_formato import Liberacao, Solicitacao

CHAVE_PRIVADA = ed25519.gerar_chave_privada()
licenca.CHAVE_PUBLICA = ed25519.chave_publica(CHAVE_PRIVADA).hex()
_proximo_id = [1]


def emitir(codigo_solicitacao, dias=30, equipamentos=0, empresas=0, chave=None, agora=None):
    sol = Solicitacao.de_codigo(codigo_solicitacao)
    agora = int(agora if agora is not None else time.time())
    lib = Liberacao(sol.produto, sol.maquina, sol.nonce, _proximo_id[0], agora, agora + dias * 86400,
                    equipamentos, empresas)
    _proximo_id[0] += 1
    assinatura = ed25519.assinar(chave or CHAVE_PRIVADA, lib.corpo())
    return Liberacao(**{**lib.__dict__, "assinatura": assinatura}).para_codigo()


def ativar(dias=30, equipamentos=0, empresas=0):
    return licenca.ativar(emitir(licenca.gerar_solicitacao(), dias, equipamentos, empresas, agora=licenca._relogio()))
