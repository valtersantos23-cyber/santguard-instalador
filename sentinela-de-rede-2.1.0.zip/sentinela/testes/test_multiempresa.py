"""Multiempresa: um provedor nunca vê nem altera os dados de outro; licença e painel do fornecedor."""

import unittest

from testes.base import SENHA_FORTE, CasoBase, simulador
from sentinela import autenticacao as auth, banco, empresas, equipamentos, incidentes
from sentinela.monitor import MONITOR


class TestMultiempresa(CasoBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        if not banco.um("SELECT id FROM usuarios WHERE usuario = 'forn.mt'"):
            auth.criar_usuario("forn.mt", SENHA_FORTE, "admin", fornecedor=True)
            banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = 'forn.mt'")

    # ------------------------------------------------------------ ajudantes
    def entrar(self, usuario):
        c = self.cliente()
        r, csrf = self.login(c, usuario, SENHA_FORTE)
        self.assertEqual(r.status_code, 200, r.get_json())
        return c, csrf

    def criar_empresa(self, cf, csrf_f, nome, admin, redes, **extra):
        r = self.post(cf, "/api/fornecedor/empresas", csrf_f,
                      {"nome": nome, "redes": redes, "plano": "Pro", **extra,
                       "admin": {"usuario": admin, "senha": SENHA_FORTE, "nome": f"Admin {nome}"}})
        self.assertEqual(r.status_code, 200, r.get_json())
        banco.executar("UPDATE usuarios SET trocar_senha = 0 WHERE usuario = ?", (admin,))
        return r.get_json()["id"]

    def cadastrar(self, c, csrf, nome, host, senha=None):
        simulador.EQUIPAMENTOS[host] = simulador.mikrotik(nome.upper())
        r = self.post(c, "/api/equipamentos", csrf, {"nome": nome, "host": host, "tipo": "mikrotik_routeros",
                                                     "usuario": "u", "senha": senha or simulador.Equipamento.senha,
                                                     "funcao": "borda"})
        return r

    # ------------------------------------------------------------ o teste
    def test_isolamento_completo(self):
        cf, csrf_f = self.entrar("forn.mt")
        a = self.criar_empresa(cf, csrf_f, "Provedor Alfa", "admin.alfa", "100.64.10.0/24")
        b = self.criar_empresa(cf, csrf_f, "Provedor Beta", "admin.beta", "100.64.20.0/24")

        # uma rede só tem uma dona
        r = self.post(cf, "/api/fornecedor/empresas", csrf_f, {"nome": "Gama", "redes": "100.64.10.128/25"})
        self.assertIn("já pertence a outra empresa", r.get_json()["mensagem"])
        ca, csrf_a = self.entrar("admin.alfa")
        cb, csrf_b = self.entrar("admin.beta")
        r = self.post(cb, "/api/empresa/rede", csrf_b, {"redes": ["100.64.10.0/24"]})
        self.assertIn("já pertence a outra empresa", r.get_json()["mensagem"])

        # cada um cadastra o seu roteador
        self.assertEqual(self.cadastrar(ca, csrf_a, "Borda Alfa", "10.201.0.1").status_code, 200)
        self.assertEqual(self.cadastrar(cb, csrf_b, "Borda Beta", "10.202.0.1").status_code, 200)
        id_a = banco.um("SELECT id FROM equipamentos WHERE host = '10.201.0.1'")["id"]
        id_b = banco.um("SELECT id FROM equipamentos WHERE host = '10.202.0.1'")["id"]

        # mesmo IP em outra empresa: recusado sem revelar quem é o dono
        r = self.cadastrar(cb, csrf_b, "Copia", "10.201.0.1")
        self.assertIn("já está em uso neste servidor", r.get_json()["mensagem"])
        self.assertNotIn("Alfa", r.get_json()["mensagem"])

        # provedor cliente não cadastra o próprio servidor central como "equipamento"
        for host in ("127.0.0.1", "localhost", "169.254.169.254", "::1"):
            r = self.cadastrar(cb, csrf_b, "Sonda", host)
            self.assertIn("não permitido", r.get_json()["mensagem"], host)

        # listas: cada um só vê o seu
        hosts_b = [e["host"] for e in cb.get("/api/equipamentos").get_json()["equipamentos"]]
        self.assertEqual(hosts_b, ["10.202.0.1"])
        nomes_b = [m["nome"] for m in cb.get("/api/aovivo").get_json()["maquinas"]]
        self.assertNotIn("Borda Alfa", nomes_b)
        usuarios_b = [u["usuario"] for u in cb.get("/api/usuarios").get_json()["usuarios"]]
        self.assertEqual(usuarios_b, ["admin.beta"])

        # B não mexe no equipamento de A (editar, remover, testar com a senha salva, interfaces, ONUs)
        self.assertNotEqual(self.post(cb, f"/api/equipamentos/{id_a}", csrf_b, {"nome": "x", "host": "10.9.9.9",
                                                                              "tipo": "cisco_ios"}).status_code, 200)
        self.assertEqual(self.post(cb, f"/api/equipamentos/{id_a}/remover", csrf_b).status_code, 404)
        r = self.post(cb, "/api/equipamentos/testar", csrf_b, {"id": id_a, "host": "10.201.0.1",
                                                              "tipo": "mikrotik_routeros", "usuario": "u", "senha": ""})
        self.assertIn("não encontrado", r.get_json()["mensagem"])
        self.assertEqual(cb.get(f"/api/equipamentos/{id_a}/interfaces").status_code, 404)
        self.assertEqual(cb.get(f"/api/olts/{id_a}/onus").status_code, 404)
        self.assertEqual(banco.um("SELECT nome FROM equipamentos WHERE id = ?", (id_a,))["nome"], "Borda Alfa")

        # incidentes e arquivos de A ficam invisíveis para B
        MONITOR.verificar(equipamentos.obter(id_a, a, segredos=True))
        inc, _ = incidentes.abrir(id_a, "Borda Alfa", "Força bruta", "teste isolamento", detalhes="x")
        self.assertEqual(inc["empresa_id"], a)
        self.assertNotIn(inc["id"], [i["id"] for i in cb.get("/api/incidentes").get_json()["incidentes"]])
        self.assertIn(inc["id"], [i["id"] for i in ca.get("/api/incidentes").get_json()["incidentes"]])
        self.assertNotEqual(self.post(cb, f"/api/incidentes/{inc['id']}/reconhecer", csrf_b).status_code, 200)
        self.assertEqual(incidentes.obter(inc["id"])["estado"], "aberto")
        arquivo = banco.um("SELECT arquivo FROM backups WHERE equip_id = ?", (id_a,))["arquivo"]
        self.assertTrue(arquivo.startswith(f"empresa_{a}/"), arquivo)
        self.assertEqual(ca.get(f"/api/arquivo?caminho={arquivo}").status_code, 200)
        self.assertEqual(cb.get(f"/api/arquivo?caminho={arquivo}").status_code, 404)
        self.assertEqual(cb.get(f"/api/arquivo?caminho=../empresa_{a}/x").status_code, 404)
        self.assertEqual(cb.get("/api/backups").get_json()["grupos"], [])

        # mitigação: B não usa o roteador de A, nem bloqueia os IPs de A, nem aprova as mitigações de A
        r = self.post(cb, "/api/mitigacoes", csrf_b, {"tipo": "rtbh", "alvo": "100.64.20.5", "equip_ids": [id_a]})
        self.assertEqual(r.status_code, 400, r.get_json())
        r = self.post(cb, "/api/mitigacoes", csrf_b, {"tipo": "rtbh", "alvo": "100.64.10.5", "equip_ids": [id_b]})
        self.assertIn("não pertence", r.get_json()["mensagem"])
        r = self.post(ca, "/api/mitigacoes", csrf_a, {"tipo": "rtbh", "alvo": "100.64.10.5", "equip_ids": [id_a]})
        self.assertEqual(r.status_code, 200, r.get_json())
        mid = r.get_json()["id"]
        self.assertEqual(self.post(cb, f"/api/mitigacoes/{mid}/aprovar", csrf_b).status_code, 404)
        self.assertEqual(self.post(cb, f"/api/mitigacoes/{mid}/rejeitar", csrf_b).status_code, 404)
        self.assertEqual(cb.get("/api/mitigacoes").get_json()["mitigacoes"], [])

        # usuários, manutenções, alertas e auditoria
        uid_a = banco.um("SELECT id FROM usuarios WHERE usuario = 'admin.alfa'")["id"]
        self.assertEqual(self.post(cb, f"/api/usuarios/{uid_a}", csrf_b, {"papel": "leitura"}).status_code, 404)
        self.assertEqual(self.post(cb, f"/api/usuarios/{uid_a}/senha", csrf_b, {"senha": SENHA_FORTE}).status_code, 404)
        self.assertEqual(self.post(cb, f"/api/usuarios/{uid_a}/remover", csrf_b).status_code, 404)
        self.assertNotEqual(self.post(cb, "/api/plantao", csrf_b, {"usuario_id": uid_a, "nivel": 1}).status_code, 200)
        r = self.post(cb, "/api/manutencoes", csrf_b, {"alvo": f"e:{id_a}", "inicio": "2030-01-01T10:00",
                                                       "fim": "2030-01-01T11:00"})
        self.assertIn("não encontrado", r.get_json()["mensagem"])
        self.post(ca, "/api/manutencoes", csrf_a, {"alvo": "todos", "inicio": "2030-01-01T10:00", "fim": "2030-01-01T11:00"})
        man_a = banco.um("SELECT id FROM manutencoes WHERE empresa_id = ? ORDER BY id DESC", (a,))["id"]
        self.assertEqual(self.post(cb, f"/api/manutencoes/{man_a}/remover", csrf_b).status_code, 404)
        self.post(ca, "/api/config/alertas", csrf_a, {"geral": {"nome_empresa": "Alfa Telecom"}})
        self.assertNotEqual(cb.get("/api/config/alertas").get_json()["config"]["geral"]["nome_empresa"], "Alfa Telecom")
        acoes_b = cb.get("/api/auditoria").get_json()["registros"]
        self.assertFalse([x for x in acoes_b if "Alfa" in (x["alvo"] or "")])

        # provedor não usa a área do fornecedor nem troca de empresa
        self.assertEqual(cb.get("/api/fornecedor/empresas").status_code, 403)
        self.assertEqual(self.post(cb, f"/api/fornecedor/entrar/{a}", csrf_b).status_code, 403)
        self.assertEqual(cb.get("/api/sessao").get_json()["empresa"]["id"], b)

        # fornecedor: vê todas as empresas e entra em qualquer uma para suporte
        lista = {e["nome"]: e for e in cf.get("/api/fornecedor/empresas").get_json()["empresas"]}
        self.assertEqual(lista["Provedor Alfa"]["equipamentos"], 1)
        self.assertEqual(self.post(cf, f"/api/fornecedor/entrar/{a}", csrf_f).status_code, 200)
        self.assertEqual([e["host"] for e in cf.get("/api/equipamentos").get_json()["equipamentos"]], ["10.201.0.1"])
        self.assertEqual(self.post(cf, f"/api/fornecedor/entrar/{b}", csrf_f).status_code, 200)
        self.assertEqual([e["host"] for e in cf.get("/api/equipamentos").get_json()["equipamentos"]], ["10.202.0.1"])

        # licença: limite de equipamentos
        self.post(cf, f"/api/fornecedor/empresas/{b}", csrf_f, {"limite_equipamentos": 1})
        r = self.cadastrar(cb, csrf_b, "Segundo", "10.202.0.2")
        self.assertIn("Limite da licença", r.get_json()["mensagem"])
        self.assertEqual(empresas.obter(b)["redes"], ["100.64.20.0/24"])     # edição parcial manteve o resto

        # licença: suspensa derruba a sessão e bloqueia o login; o monitoramento dela para
        self.post(cf, f"/api/fornecedor/empresas/{b}", csrf_f, {"ativo": False})
        self.assertEqual(cb.get("/api/equipamentos").status_code, 401)
        r, _ = self.login(self.cliente(), "admin.beta", SENHA_FORTE)
        self.assertEqual(r.status_code, 401)
        self.assertIn("suspensa", r.get_json()["mensagem"])
        self.assertNotIn(id_b, [e["id"] for e in equipamentos.listar(equipamentos.TODAS, somente_ativos=True)])
        self.assertEqual(ca.get("/api/equipamentos").status_code, 200)       # A continua normal

        # vencida
        self.post(cf, f"/api/fornecedor/empresas/{b}", csrf_f, {"ativo": True, "validade": "2020-01-01"})
        r, _ = self.login(self.cliente(), "admin.beta", SENHA_FORTE)
        self.assertIn("vencida", r.get_json()["mensagem"])

        # remover empresa exige digitar o nome e apaga tudo dela
        r = self.post(cf, f"/api/fornecedor/empresas/{b}/remover", csrf_f, {"confirmar": "errado"})
        self.assertEqual(r.status_code, 400)
        r = self.post(cf, f"/api/fornecedor/empresas/{b}/remover", csrf_f, {"confirmar": "provedor beta"})
        self.assertEqual(r.status_code, 200, r.get_json())
        self.assertIsNone(banco.um("SELECT id FROM equipamentos WHERE id = ?", (id_b,)))
        self.assertIsNone(banco.um("SELECT id FROM usuarios WHERE usuario = 'admin.beta'"))
        self.assertIsNotNone(banco.um("SELECT id FROM equipamentos WHERE id = ?", (id_a,)))

    def test_fluxo_atribuido_pela_empresa_do_exportador(self):
        from sentinela.fluxo import ColetorFluxo
        from testes import gerador_fluxo as g
        e = empresas.salvar({"nome": "Fluxo Delta", "redes": ["100.65.0.0/24"]})[0]
        eq, erro = equipamentos.salvar({"nome": "Exp Delta", "host": "10.203.0.1", "tipo": "cisco_ios",
                                        "usuario": "u", "senha": "x", "funcao": "borda"}, e)
        self.assertIsNone(erro)
        from sentinela.tempo_real import TEMPO_REAL
        TEMPO_REAL._mapa["quando"] = 0
        c = ColetorFluxo()
        import time
        inicio = time.time()
        c.inicio_janela = inicio
        c.processar_pacote(g.netflow_v9(g.fluxos_dns_amplificacao("100.65.0.9")), "10.203.0.1")
        c.fechar_janela(agora=inicio + 10)
        self.assertIn((e, "100.65.0.9"), c.ativos)
        inc = incidentes.obter(c.ativos[(e, "100.65.0.9")]["incidente_id"])
        self.assertEqual(inc["empresa_id"], e)
        self.assertEqual([a["alvo"] for a in c.estado(1)["ativos"]], [])   # outra empresa não vê
        self.assertEqual([a["alvo"] for a in c.estado(e)["ativos"]], ["100.65.0.9"])
        self.assertFalse([h for h in c.estado(1)["historico"] if h["alvo"] == "100.65.0.9"])

    def test_redes_do_config_valem_so_para_a_empresa_1(self):
        from sentinela import config
        config.CFG["fluxo"]["redes_proprias"] = ["177.10.0.0/22"]
        e = empresas.salvar({"nome": "Sem Redes Epsilon"})[0]
        self.assertEqual(empresas.redes(e), [])
        self.assertEqual(empresas.redes(1), ["177.10.0.0/22"])

    def test_provedor_nao_aponta_alertas_para_a_rede_interna_do_servidor(self):
        from sentinela import alertas
        e = empresas.salvar({"nome": "SSRF Zeta"})[0]
        for url in ("http://127.0.0.1:8443/api", "http://10.0.0.5/gancho", "http://192.168.1.1/"):
            with self.assertRaises(alertas.ErroAlerta, msg=url):
                alertas.salvar_config(e, {"webhook": {"url": url}})
        with self.assertRaises(alertas.ErroAlerta):
            alertas.salvar_config(e, {"email": {"servidor": "127.0.0.1"}})
        alertas.salvar_config(e, {"webhook": {"url": "https://8.8.8.8/gancho"}})      # público: ok
        alertas.salvar_config(1, {"webhook": {"url": "http://192.168.0.10/gancho"}})  # empresa principal: LAN ok
        cfg = alertas.ler_config(e)
        cfg["webhook"]["url"] = "http://127.0.0.1:9/x"                               # mesmo se gravado antes
        with self.assertRaises(alertas.ErroAlerta):
            alertas.enviar_webhook(cfg, {"teste": 1})


if __name__ == "__main__":
    unittest.main()
