"""Fase 5: BGP (leitura por fabricante, quedas, variação de prefixos), RPKI/sequestro e OLTs."""

import http.server
import json
import threading
import unittest
import urllib.parse

from testes.base import CasoBase, simulador
from sentinela import banco, config, equipamentos, incidentes
from sentinela.bgp import BGP, ler_sessoes
from sentinela.olt import OLT, ler_onus_huawei, ler_onus_zte, resumir

CISCO = """BGP router identifier 10.0.0.1, local AS number 64500
Neighbor        V           AS MsgRcvd MsgSent   TblVer  InQ OutQ Up/Down  State/PfxRcd
10.0.0.2        4        65001  123456  123400  9000000    0    0 3w2d       945120
10.0.0.6        4        65002       0       0        1    0    0 never    Idle
2001:DB8::2
                4        65003    5000    5001  9000000    0    0 1d02h      210345
"""
HUAWEI = """ BGP local router ID : 10.0.0.1
 Local AS number : 64500
 Total number of peers : 2                 Peers in established state : 1

  Peer            V          AS  MsgRcvd  MsgSent  OutQ  Up/Down       State  PrefRcv
  10.1.1.2        4       65010    18000    17000     0 0049h12m Established   950000
  10.1.1.6        4       65011        0        0     0 00:01:10      Active        0
"""
JUNIPER = """Groups: 2 Peers: 2 Down peers: 1
Peer                     AS      InPkt     OutPkt    OutQ   Flaps Last Up/Dwn State|#Active/Received/Accepted/Damped...
10.2.2.1              65020    1234567     123456       0       1     3w4d 2:31 Establ
  inet.0: 900000/950000/949000/0
10.2.2.5              65021          0          0       0       5        12:03 Connect
"""
MIKROTIK = """Flags: E - established
 0 E name="transito-a-1"
     remote.address=10.3.3.1 .as=65030 .id=10.3.3.1 .capabilities=mp,rr,as4 .afi=ip
     local.role=ebgp .address=10.3.3.2 .as=64500 .id=10.3.3.2
     hold-time=1m30s keepalive-time=30s uptime=5d3h prefix-count=948000

 1   name="transito-b-1"
     remote.address=10.3.3.5 .as=65031
     local.role=ebgp .address=10.3.3.6 .as=64500
"""


class TestLeituraBgp(unittest.TestCase):
    def test_cisco(self):
        s = {x["vizinho"]: x for x in ler_sessoes(CISCO, "cisco_ios")}
        self.assertEqual((s["10.0.0.2"]["asn"], s["10.0.0.2"]["estabelecida"], s["10.0.0.2"]["prefixos"]), (65001, True, 945120))
        self.assertEqual((s["10.0.0.6"]["estado"], s["10.0.0.6"]["estabelecida"]), ("Idle", False))
        self.assertEqual(s["2001:DB8::2"]["prefixos"], 210345)       # linha quebrada do IPv6

    def test_huawei(self):
        s = {x["vizinho"]: x for x in ler_sessoes(HUAWEI, "huawei")}
        self.assertEqual((s["10.1.1.2"]["asn"], s["10.1.1.2"]["estabelecida"], s["10.1.1.2"]["prefixos"]), (65010, True, 950000))
        self.assertFalse(s["10.1.1.6"]["estabelecida"])

    def test_juniper(self):
        s = {x["vizinho"]: x for x in ler_sessoes(JUNIPER, "juniper_junos")}
        self.assertEqual((s["10.2.2.1"]["asn"], s["10.2.2.1"]["estabelecida"], s["10.2.2.1"]["prefixos"]), (65020, True, 950000))
        self.assertEqual(s["10.2.2.5"]["estado"], "Connect")

    def test_mikrotik(self):
        s = {x["vizinho"]: x for x in ler_sessoes(MIKROTIK, "mikrotik_routeros")}
        self.assertEqual((s["10.3.3.1"]["asn"], s["10.3.3.1"]["estabelecida"], s["10.3.3.1"]["prefixos"]), (65030, True, 948000))
        self.assertEqual(s["10.3.3.1"]["descricao"], "transito-a-1")
        self.assertFalse(s["10.3.3.5"]["estabelecida"])


class TestMonitorBgp(CasoBase):
    def test_queda_e_vazamento(self):
        dev = simulador.Equipamento({"show ip bgp all summary": CISCO}, "BORDA-BGP")
        simulador.EQUIPAMENTOS["10.50.0.1"] = dev
        eid, _ = equipamentos.salvar({"nome": "Borda BGP", "host": "10.50.0.1", "tipo": "cisco_ios", "usuario": "u",
                                      "senha": simulador.Equipamento.senha, "funcao": "borda"}, 1)
        equip = equipamentos.obter(eid, 1, segredos=True)
        BGP.verificar(equip)
        self.assertEqual(banco.um("SELECT COUNT(*) AS n FROM bgp_sessoes WHERE equip_id = ?", (eid,))["n"], 3)
        dev.respostas["show ip bgp all summary"] = CISCO.replace("3w2d       945120", "00:00:05   Active") \
                                                         .replace("1d02h      210345", "1d02h      480000")
        BGP.verificar(equip)
        abertos = {i["tipo"]: i for i in incidentes.listar(1, "abertos", equip_id=eid)}
        self.assertIn("10.0.0.2 (AS65001) caiu", abertos["Sessão BGP"]["titulo"])
        self.assertEqual(abertos["Sessão BGP"]["severidade"], "alta")
        self.assertIn("vazamento", abertos["Prefixos BGP"]["titulo"])


class RipestatFalso:
    def __init__(self, respostas):
        self.respostas = respostas

        class T(http.server.BaseHTTPRequestHandler):
            def do_GET(s):
                u = urllib.parse.urlparse(s.path)
                q = dict(urllib.parse.parse_qsl(u.query))
                chave = (u.path.split("/")[2], q.get("prefix") or q.get("resource"))
                corpo = json.dumps({"data": self.respostas.get(chave, {})}).encode()
                s.send_response(200)
                s.end_headers()
                s.wfile.write(corpo)

            def log_message(s, *a):
                pass

        self.srv = http.server.HTTPServer(("127.0.0.1", 0), T)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.srv.server_port}"


class TestRpki(CasoBase):
    def test_invalido_e_sequestro(self):
        falso = RipestatFalso({
            ("rpki-validation", "177.10.0.0/22"): {"status": "valid", "validating_roas": [
                {"origin": "64500", "prefix": "177.10.0.0/22", "max_length": 24, "validity": "valid"}]},
            ("prefix-overview", "177.10.0.0/22"): {"announced": True, "asns": [{"asn": 64500}, {"asn": 666}]},
            ("rpki-validation", "177.10.4.0/22"): {"status": "invalid_asn", "validating_roas": []},
            ("prefix-overview", "177.10.4.0/22"): {"announced": True, "asns": [{"asn": 64500}]},
        })
        config.CFG["bgp"].update(asn=64500, prefixos=["177.10.0.0/22", "177.10.4.0/22"], ripestat_url=falso.url)
        try:
            resultado = {r["prefixo"]: r for r in BGP.verificar_rpki()}
        finally:
            config.CFG["bgp"].update(asn=0, prefixos=[], ripestat_url="https://stat.ripe.net")
        self.assertEqual(resultado["177.10.0.0/22"]["status"], "valid")
        self.assertEqual(resultado["177.10.0.0/22"]["origens"], [666, 64500])
        tipos = {i["tipo"]: i for i in incidentes.listar(1, "abertos")}
        self.assertIn("AS666", tipos["Sequestro de prefixo"]["titulo"])
        self.assertIn("177.10.4.0/22", tipos["RPKI inválido"]["titulo"])


HUAWEI_ONT = """  -----------------------------------------------------------------------------
  F/S/P   ONT         SN         Control     Run      Config   Match    Protect
          ID                     flag        state    state    state    side
  -----------------------------------------------------------------------------
""" + "".join(f"  0/ 1/0   {i:3d}  48575443{i:08X}  active      {'online' if i < 10 else 'offline'}   normal   match    no\n"
              for i in range(12))


def zte_estado(working):
    linhas = ["OnuIndex                 Admin State  OMCC State  Phase State  Channel", "-" * 70]
    for i in range(1, 13):
        fase = "working" if i <= working else ("LOS" if i % 3 else "DyingGasp")
        linhas.append(f"gpon-onu_1/2/1:{i}         enable       enable      {fase:<12} 1(GPON)")
    return "\n".join(linhas)


class TestOlt(CasoBase):
    def test_leitura(self):
        onus = ler_onus_huawei(HUAWEI_ONT)
        self.assertEqual(len(onus), 12)
        self.assertEqual(resumir(onus)["0/1/0"]["online"], 10)
        z = resumir(ler_onus_zte(zte_estado(9)))["1/2/1"]
        self.assertEqual((z["online"], z["los"], z["sem_energia"]), (9, 2, 1))

    def test_queda_em_massa_zte(self):
        sinal = "\n".join(f"gpon-onu_1/2/1:{i}     -{20 + i}.335(dbm)" for i in range(1, 13))
        dev = simulador.Equipamento({"show gpon onu state": zte_estado(12),
                                     "show pon power onu-rx gpon-olt_1/2/1": sinal}, "OLT-ZTE")
        simulador.EQUIPAMENTOS["10.60.0.1"] = dev
        eid, _ = equipamentos.salvar({"nome": "OLT Centro", "host": "10.60.0.1", "tipo": "zte_olt", "usuario": "u",
                                      "senha": simulador.Equipamento.senha, "funcao": "olt"}, 1)
        equip = equipamentos.obter(eid, 1, segredos=True)
        OLT.verificar(equip)
        pon = banco.um("SELECT * FROM olt_pons WHERE equip_id = ?", (eid,))
        self.assertEqual((pon["online"], pon["sinal_ruim"]), (12, 6))     # -28 dBm para baixo
        dev.respostas["show gpon onu state"] = zte_estado(2)               # 10 caem de uma vez
        OLT.verificar(equip)
        inc = [i for i in incidentes.listar(1, "abertos", equip_id=eid) if i["tipo"] == "Queda em massa de ONUs"]
        self.assertEqual(len(inc), 1)
        self.assertIn("10 de 12", inc[0]["titulo"])
        self.assertIn("rompimento de fibra", inc[0]["titulo"])
        offline = OLT.onus(eid, filtro="offline")
        self.assertEqual(len(offline), 10)


if __name__ == "__main__":
    unittest.main()
