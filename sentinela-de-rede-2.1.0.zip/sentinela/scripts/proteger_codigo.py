"""Protege o código do Sentinela antes de ir para o cliente: compila tudo e APAGA os .py.

    python scripts/proteger_codigo.py PASTA_DO_PACOTE

O que fica no cliente é só o bytecode (.pyc), sem os comentários, sem as docstrings e sem o
texto do código. O programa funciona igual, mas não dá para abrir os arquivos num editor, ler o
código ou copiá-lo e alterá-lo como se fosse o original.

IMPORTANTE: rode com o MESMO Python que vai executar o Sentinela (o bytecode muda entre versões
3.11, 3.12, 3.13...). O gerar_instalador.ps1 usa o Python embutido do instalador e o Dockerfile
usa o Python da imagem, então já fica certo.

Só os .py são compilados. Os arquivos do painel (HTML, CSS, JS) continuam como estão: eles são
enviados ao navegador de quem acessa o painel, então não há como escondê-los.
"""

import compileall
import pathlib
import py_compile
import sys


def proteger(pasta):
    pasta = pathlib.Path(pasta).resolve()
    if not (pasta / "__init__.py").exists() and not (pasta / "__init__.pyc").exists():
        raise SystemExit(f"{pasta} não parece ser o pacote do Sentinela (falta o __init__.py)")
    fontes = sorted(pasta.rglob("*.py"))
    if not fontes:
        print("Nada a fazer: o código já está protegido.")
        return 0
    # legacy=True grava modulo.pyc ao lado do modulo.py: assim o Python carrega o .pyc sem o fonte.
    # optimize=2 remove as docstrings e os asserts.
    ok = compileall.compile_dir(str(pasta), quiet=1, legacy=True, optimize=2, force=True,
                                invalidation_mode=py_compile.PycInvalidationMode.UNCHECKED_HASH)
    if not ok:
        raise SystemExit("ERRO: algum arquivo não compilou. Nada foi apagado.")
    for fonte in fontes:
        if not fonte.with_suffix(".pyc").exists():
            raise SystemExit(f"ERRO: {fonte} não gerou o .pyc. Nada foi apagado.")
    for fonte in fontes:
        fonte.unlink()
    for cache in pasta.rglob("__pycache__"):
        for arq in cache.iterdir():
            arq.unlink()
        cache.rmdir()
    print(f"Código protegido: {len(fontes)} arquivos .py compilados e removidos (Python {sys.version.split()[0]}).")
    return len(fontes)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    proteger(sys.argv[1])
