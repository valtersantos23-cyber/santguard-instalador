﻿<#
  Remove o serviço e as regras de firewall do Sentinela. NÃO apaga a pasta de dados.
  Uso (PowerShell como Administrador):  .\scripts\windows\desinstalar.ps1
#>
$NomeTarefa = "Sentinela de Rede"
if (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $NomeTarefa -Confirm:$false
    Write-Host "Serviço removido."
}
Get-NetFirewallRule -DisplayName "Sentinela - *" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
    Where-Object { $_.CommandLine -like "*-m sentinela*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Write-Host "Regras de firewall removidas. Os dados continuam em $env:ProgramData\Sentinela."
