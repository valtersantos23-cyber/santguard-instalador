﻿<#
  Gera o instalador do Sentinela de Rede para Windows (dist\Sentinela-de-Rede-X.Y.Z-instalador.exe).

  O instalador já leva o Python embutido e todas as dependências: quem instala NÃO precisa ter Python.

  Uso: dê dois cliques em GERAR_INSTALADOR.cmd (pasta principal), ou no PowerShell:
      powershell -ExecutionPolicy Bypass -File scripts\windows\gerar_instalador.ps1

  Precisa de: internet, um Python 3.9+ neste PC (só para baixar as dependências) e o Inno Setup 6
  (se não estiver instalado, o script tenta instalar com winget).
#>
param(
    [string]$VersaoPython = "3.12.10"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # deixa o download muito mais rápido no PowerShell 5
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Raiz = (Resolve-Path "$PSScriptRoot\..\..").Path
$Build = Join-Path $Raiz "build\instalador"
$Cache = Join-Path $Raiz "build\cache"

function Etapa($texto) { Write-Host "`n==> $texto" -ForegroundColor Cyan }
function Falha($texto) { Write-Host "`nERRO: $texto" -ForegroundColor Red; exit 1 }

# ------------------------------------------------------------------ versão do Sentinela
$init = Get-Content (Join-Path $Raiz "sentinela\__init__.py") -Raw
if ($init -notmatch 'VERSAO\s*=\s*"([^"]+)"') { Falha "não encontrei a versão em sentinela\__init__.py" }
$Versao = $Matches[1]
Write-Host "Sentinela de Rede $Versao  (Python embutido $VersaoPython)" -ForegroundColor Green

# ------------------------------------------------------------------ chave pública da licença
$licenca = Get-Content (Join-Path $Raiz "sentinela\licenca.py") -Raw
if ($licenca -notmatch 'CHAVE_PUBLICA = "[0-9a-f]{64}"') {
    Falha "a chave pública da licença não está gravada em sentinela\licenca.py.`n       Rode no gerador de licenças:  python gerador.py aplicar-chave --sentinela `"$Raiz`""
}

# ------------------------------------------------------------------ Python local (só para o pip)
Etapa "Procurando um Python neste PC (usado apenas para baixar as dependências)"
$py = $null
foreach ($candidato in @("py", "python")) {
    $cmd = Get-Command $candidato -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notlike "*WindowsApps*") { $py = $cmd.Source; break }
}
if (-not $py) { Falha "instale o Python (python.org) para gerar o instalador. Quem for INSTALAR não precisa dele." }
$pyArgs = @()
if ((Split-Path $py -Leaf) -ieq "py.exe") { $pyArgs = @("-3") }
& $py @pyArgs --version

# ------------------------------------------------------------------ pasta de montagem
Etapa "Preparando a pasta de montagem"
if (Test-Path $Build) { Remove-Item -Recurse -Force $Build }
New-Item -ItemType Directory -Force -Path "$Build\python", "$Build\app", "$Build\scripts", $Cache | Out-Null

# ------------------------------------------------------------------ Python embutido
Etapa "Baixando o Python $VersaoPython embutido (embeddable)"
$zip = Join-Path $Cache "python-$VersaoPython-embed-amd64.zip"
if (-not (Test-Path $zip)) {
    $url = "https://www.python.org/ftp/python/$VersaoPython/python-$VersaoPython-embed-amd64.zip"
    try { Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing }
    catch { Falha "não consegui baixar $url ($($_.Exception.Message))" }
}
Expand-Archive -Path $zip -DestinationPath "$Build\python" -Force

# O arquivo ._pth controla onde o Python embutido procura módulos
$partes = $VersaoPython.Split(".")
$curta = "$($partes[0])$($partes[1])"      # ex.: 312
$pth = Get-ChildItem "$Build\python" -Filter "python*._pth" | Select-Object -First 1
if (-not $pth) { Falha "arquivo ._pth não encontrado no Python embutido" }
@("python$curta.zip", ".", "..\app", "Lib\site-packages", "import site") |
    Set-Content -Path $pth.FullName -Encoding ASCII

# ------------------------------------------------------------------ dependências (rodas para Windows 64 bits)
Etapa "Baixando e instalando as dependências no Python embutido"
& $py @pyArgs -m pip install --disable-pip-version-check --quiet `
    --target "$Build\python\Lib\site-packages" `
    --platform win_amd64 --python-version "$($partes[0]).$($partes[1])" --implementation cp `
    --only-binary=:all: --no-compile --upgrade `
    -r (Join-Path $Raiz "requirements.txt")
if ($LASTEXITCODE -ne 0) { Falha "o pip não conseguiu baixar as dependências (veja a mensagem acima)" }
Remove-Item -Recurse -Force "$Build\python\Lib\site-packages\bin" -ErrorAction SilentlyContinue

# ------------------------------------------------------------------ aplicação
Etapa "Copiando o Sentinela"
Copy-Item -Recurse -Path (Join-Path $Raiz "sentinela") -Destination "$Build\app\sentinela"
Get-ChildItem "$Build\app" -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
Copy-Item (Join-Path $Raiz "config.exemplo.toml"), (Join-Path $Raiz "README.md") "$Build\app\"
Copy-Item (Join-Path $Raiz "instalador\scripts\*") "$Build\scripts\"

# ------------------------------------------------------------------ proteção do código
# Compila com o próprio Python embutido (mesma versão que vai rodar no cliente) e apaga os .py:
# o cliente recebe só o bytecode, sem o código-fonte legível.
Etapa "Protegendo o código (compilando e removendo os .py)"
& "$Build\python\python.exe" (Join-Path $Raiz "scripts\proteger_codigo.py") "$Build\app\sentinela"
if ($LASTEXITCODE -ne 0) { Falha "não consegui proteger o código (veja a mensagem acima)" }
if (Get-ChildItem "$Build\app\sentinela" -Recurse -Filter "*.py") { Falha "ainda há arquivos .py no pacote" }

# ------------------------------------------------------------------ teste rápido do pacote
Etapa "Testando o Python embutido com o Sentinela"
& "$Build\python\python.exe" -c "import sentinela, flask, cheroot, cryptography, netmiko, reportlab, sqlite3, ssl; print('Sentinela', sentinela.VERSAO, '- todas as bibliotecas carregaram')"
if ($LASTEXITCODE -ne 0) { Falha "o pacote montado não funciona (veja a mensagem acima)" }

# ------------------------------------------------------------------ Inno Setup
Etapa "Procurando o Inno Setup 6"
function Achar-Iscc {
    $locais = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
                "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe")
    foreach ($l in $locais) { if ($l -and (Test-Path $l)) { return $l } }
    $cmd = Get-Command iscc -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}
$iscc = Achar-Iscc
if (-not $iscc) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Instalando o Inno Setup com o winget..."
        winget install --id JRSoftware.InnoSetup -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
    } elseif (Get-Command choco -ErrorAction SilentlyContinue) {
        choco install innosetup -y --no-progress | Out-Host
    }
    $iscc = Achar-Iscc
}
if (-not $iscc) { Falha "instale o Inno Setup 6 (https://jrsoftware.org/isdl.php) e rode de novo." }

# ------------------------------------------------------------------ compilação
Etapa "Gerando o instalador"
& $iscc "/DVersao=$Versao" "/DOrigem=$Build" (Join-Path $Raiz "instalador\sentinela.iss")
if ($LASTEXITCODE -ne 0) { Falha "o Inno Setup não conseguiu gerar o instalador" }

$exe = Join-Path $Raiz "dist\Sentinela-de-Rede-$Versao-instalador.exe"
$tamanho = [math]::Round((Get-Item $exe).Length / 1MB, 1)
Write-Host "`nPRONTO! Instalador gerado ($tamanho MB):" -ForegroundColor Green
Write-Host "  $exe" -ForegroundColor Green
