﻿<#
  Instala o Sentinela de Rede como serviço no Windows (inicia junto com o Windows e
  reinicia sozinho se cair).

  Uso (PowerShell como Administrador, dentro da pasta do Sentinela):
      Set-ExecutionPolicy -Scope Process Bypass
      .\scripts\windows\instalar.ps1

  Requisitos: Python 3.11 ou mais novo instalado "para todos os usuários".
#>
param(
    [string]$PastaDados = "$env:ProgramData\Sentinela",
    [int]$PortaPainel = 8443
)

$ErrorActionPreference = "Stop"
$NomeTarefa = "Sentinela de Rede"
$Raiz = (Resolve-Path "$PSScriptRoot\..\..").Path

function Escrever($texto, $cor = "Cyan") { Write-Host $texto -ForegroundColor $cor }

# ---------------------------------------------------------------- administrador?
$identidade = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $identidade.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Escrever "Abra o PowerShell como Administrador e rode de novo." Red
    exit 1
}

# ---------------------------------------------------------------- Python
$python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $python -or $python -like "*WindowsApps*") {
    Escrever "Python não encontrado. Instale o Python 3.12 de python.org marcando:" Red
    Escrever "  [x] Add python.exe to PATH   e   [x] Install for all users" Red
    exit 1
}
if ($python -like "*\AppData\*") {
    Escrever "Aviso: o Python está instalado só para o seu usuário ($python)." Yellow
    Escrever "O serviço roda como SYSTEM e pode não enxergá-lo. Recomendo reinstalar 'para todos os usuários'." Yellow
}
$versao = & $python -c "import sys; print('%d.%d' % sys.version_info[:2])"
if ([version]$versao -lt [version]"3.11") {
    Escrever "Python $versao é antigo demais. Instale o 3.11 ou mais novo." Red
    exit 1
}
Escrever "Python $versao em $python"

# ---------------------------------------------------------------- dependências
Escrever "Instalando dependências..."
& $python -m pip install --upgrade pip --quiet
& $python -m pip install -r "$Raiz\requirements.txt" --quiet
if ($LASTEXITCODE -ne 0) { Escrever "Falha ao instalar as dependências." Red; exit 1 }

# ---------------------------------------------------------------- pasta de dados (acesso só de Administradores e SYSTEM)
New-Item -ItemType Directory -Force -Path $PastaDados | Out-Null
& icacls $PastaDados /inheritance:r /grant:r "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" | Out-Null
if (-not (Test-Path "$PastaDados\config.toml")) {
    Copy-Item "$Raiz\config.exemplo.toml" "$PastaDados\config.toml"
}
Escrever "Dados em $PastaDados (acesso restrito a Administradores e SYSTEM)"

# ---------------------------------------------------------------- script de inicialização
$Iniciador = "$PastaDados\iniciar_sentinela.cmd"
@"
@echo off
set SENTINELA_DADOS=$PastaDados
set SENTINELA_WEB_PORTA=$PortaPainel
cd /d "$Raiz"
"$python" -m sentinela >> "$PastaDados\sentinela.log" 2>&1
"@ | Set-Content -Encoding OEM $Iniciador

# ---------------------------------------------------------------- tarefa agendada (serviço)
if (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $NomeTarefa -Confirm:$false
}
$acao = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$Iniciador`"" -WorkingDirectory $Raiz
$gatilho = New-ScheduledTaskTrigger -AtStartup
$usuario = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$ajustes = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -StartWhenAvailable -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $NomeTarefa -Action $acao -Trigger $gatilho -Principal $usuario -Settings $ajustes `
    -Description "Sentinela de Rede: monitoramento de segurança de roteadores e switches" | Out-Null
Escrever "Serviço '$NomeTarefa' registrado (inicia com o Windows)."

# ---------------------------------------------------------------- firewall
$regras = @(
    @{ Nome = "Sentinela - Painel HTTPS"; Protocolo = "TCP"; Porta = $PortaPainel },
    @{ Nome = "Sentinela - Syslog";       Protocolo = "UDP"; Porta = 514 },
    @{ Nome = "Sentinela - NetFlow";      Protocolo = "UDP"; Porta = 2055 },
    @{ Nome = "Sentinela - sFlow";        Protocolo = "UDP"; Porta = 6343 }
)
foreach ($r in $regras) {
    Get-NetFirewallRule -DisplayName $r.Nome -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -DisplayName $r.Nome -Direction Inbound -Action Allow -Protocol $r.Protocolo `
        -LocalPort $r.Porta -Profile Domain,Private | Out-Null
}
Escrever "Firewall liberado (redes de domínio e privadas)."

# ---------------------------------------------------------------- primeiro administrador
$env:SENTINELA_DADOS = $PastaDados
Push-Location $Raiz
$temUsuario = & $python -c "from sentinela import banco, autenticacao as a; banco.migrar(); print(a.contar_usuarios())"
if ($temUsuario -eq "0") {
    Escrever "`nCrie agora o primeiro administrador:" Green
    & $python -m sentinela criar-admin
}
Pop-Location

Start-ScheduledTask -TaskName $NomeTarefa
Start-Sleep -Seconds 4
Escrever "`nPronto! Abra https://localhost:$PortaPainel" Green
Escrever "Log: $PastaDados\sentinela.log"
Escrever "IMPORTANTE: faça backup do arquivo $PastaDados\chave_mestra.key em local seguro (pendrive/cofre)." Yellow
