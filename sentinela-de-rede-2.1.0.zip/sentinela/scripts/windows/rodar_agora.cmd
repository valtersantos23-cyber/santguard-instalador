@echo off
rem Roda o Sentinela nesta janela (para testes). Para rodar como servico, use instalar.ps1.
rem Usa um ambiente Python proprio (pasta .venv), separado de outros projetos.
setlocal
cd /d "%~dp0\..\.."

rem ignora o ambiente virtual de outro projeto que esteja ativo (sempre usamos .venv\Scripts\python.exe)
if defined VIRTUAL_ENV echo Ignorando o ambiente virtual de outro projeto: %VIRTUAL_ENV%
set VIRTUAL_ENV=
set PYTHONHOME=

if not exist ".venv\Scripts\python.exe" (
    echo Criando o ambiente do Sentinela em .venv ...
    py -3 -m venv .venv 2>nul
    if not exist ".venv\Scripts\python.exe" python -m venv .venv
    if not exist ".venv\Scripts\python.exe" (
        echo Nao consegui criar o ambiente. Confira se o Python 3.11+ esta instalado.
        pause
        exit /b 1
    )
)

echo Instalando/atualizando dependencias...
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo Falha ao instalar as dependencias.
    pause
    exit /b 1
)

if not exist dados mkdir dados
set SENTINELA_DADOS=%cd%\dados
set SENTINELA_ABRIR_NAVEGADOR=1
echo.
echo Iniciando... o navegador vai abrir sozinho em alguns segundos.
echo Se nao abrir, acesse: https://localhost:8443
echo.
".venv\Scripts\python.exe" -m sentinela
pause
