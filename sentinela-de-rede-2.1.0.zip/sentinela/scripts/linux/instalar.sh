#!/usr/bin/env bash
# Instala o Sentinela de Rede como serviço systemd (Debian/Ubuntu/Rocky), sem Docker.
#   sudo ./scripts/linux/instalar.sh
set -euo pipefail

DESTINO=/opt/sentinela
DADOS=/var/lib/sentinela
USUARIO=sentinela
ORIGEM="$(cd "$(dirname "$0")/../.." && pwd)"

if [[ $EUID -ne 0 ]]; then echo "Rode com sudo."; exit 1; fi
command -v python3 >/dev/null || { echo "Instale o python3 (3.11+)."; exit 1; }
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' || { echo "Python 3.11 ou mais novo é necessário."; exit 1; }

id -u "$USUARIO" >/dev/null 2>&1 || useradd --system --home "$DADOS" --shell /usr/sbin/nologin "$USUARIO"
mkdir -p "$DESTINO" "$DADOS"
cp -r "$ORIGEM/sentinela" "$ORIGEM/requirements.txt" "$DESTINO/"
[[ -f "$DADOS/config.toml" ]] || cp "$ORIGEM/config.exemplo.toml" "$DADOS/config.toml"

python3 -m venv "$DESTINO/venv"
"$DESTINO/venv/bin/pip" install --quiet --upgrade pip
"$DESTINO/venv/bin/pip" install --quiet -r "$DESTINO/requirements.txt"
# Proteção do código: deixa em /opt só o bytecode (compilado com o Python do venv), sem os .py legíveis
if [[ "$(realpath "$ORIGEM")" != "$(realpath "$DESTINO")" ]]; then
  rm -rf "$DESTINO/sentinela" && cp -r "$ORIGEM/sentinela" "$DESTINO/"
  "$DESTINO/venv/bin/python" "$ORIGEM/scripts/proteger_codigo.py" "$DESTINO/sentinela"
fi

chown -R "$USUARIO":"$USUARIO" "$DADOS"
chmod 700 "$DADOS"

cp "$ORIGEM/scripts/linux/sentinela.service" /etc/systemd/system/sentinela.service
systemctl daemon-reload
systemctl enable sentinela

if [[ "$(sudo -u "$USUARIO" SENTINELA_DADOS="$DADOS" "$DESTINO/venv/bin/python" -c 'import sys; sys.path.insert(0, "/opt/sentinela"); from sentinela import banco, autenticacao as a; banco.migrar(); print(a.contar_usuarios())')" == "0" ]]; then
  echo; echo "Crie o primeiro administrador:"
  (cd "$DESTINO" && sudo -u "$USUARIO" SENTINELA_DADOS="$DADOS" "$DESTINO/venv/bin/python" -m sentinela criar-admin)
fi

systemctl restart sentinela
echo
echo "Pronto! Painel: https://$(hostname -I | awk '{print $1}'):8443"
echo "Logs:   journalctl -u sentinela -f"
echo "IMPORTANTE: guarde uma cópia de $DADOS/chave_mestra.key em local seguro."
