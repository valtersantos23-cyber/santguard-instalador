@echo off
rem Gera o instalador do Sentinela de Rede (pasta dist). De dois cliques neste arquivo.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\windows\gerar_instalador.ps1"
echo.
if exist dist explorer dist
pause
