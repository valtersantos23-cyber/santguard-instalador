# Sentinela de Rede

Monitoramento de segurança para provedores de internet: backups e auditoria de configuração,
detecção de ataques em tempo real (força bruta, DDoS volumétrico, tráfego suspeito), BGP/RPKI,
OLTs GPON, alertas com escala de plantão e mitigação com aprovação humana.

Fabricantes: **MikroTik, Cisco IOS/IOS-XE, Huawei, Juniper, ZTE** (roteadores e switches) e
**OLTs Huawei e ZTE** (Fiberhome e Parks com suporte básico).

**Multiempresa:** um único servidor atende vários provedores. O fornecedor cadastra cada provedor
(empresa) com a sua licença, e cada um acessa o mesmo painel vendo só os próprios dados.
Veja [Modo servidor: vários provedores](#modo-servidor-vários-provedores).

---

## O que ele faz

| Área | Recursos |
|---|---|
| **Ao vivo** | Tela em tempo real com máquinas e clientes sob ataque, IPs atacantes, linha do tempo, som e tela cheia |
| **Força bruta** | Pelo syslog (na hora) e pelos logs via SSH; captura backup e evidências automaticamente |
| **DDoS** | Coletor NetFlow v5/v9, IPFIX e sFlow v5; detecta por IP de destino (Mbps e pacotes/s) e identifica o vetor: SYN flood, UDP flood, ICMP, amplificação DNS/NTP/memcached/SSDP/CLDAP etc. |
| **Recursos** | CPU, memória, uptime e tráfego das interfaces por SNMP v2c/v3 (SHA + AES), queda de uplink |
| **Configuração** | Backup a cada verificação com histórico de mudanças (diff), alerta de alteração, auditoria de segurança |
| **BGP** | Sessões que caem, variação brusca de prefixos (vazamento de rotas), RPKI dos seus prefixos e detecção de sequestro (hijack) |
| **OLTs** | ONUs online/offline por PON, LOS × falta de energia, sinal óptico ruim e queda em massa (rompimento de fibra) |
| **Alertas** | WhatsApp (API oficial da Meta ou Evolution API), e-mail, Telegram e webhook assinado; escala de plantão em 3 níveis com escalonamento, manutenções programadas e limite anti-enxurrada |
| **Mitigação** | RTBH (blackhole do IP atacado) e bloqueio de IP atacante, sempre propostos e só aplicados após aprovação; expiram sozinhos |
| **Relatórios** | PDF mensal: resumo, incidentes, DDoS, tempos médios de reconhecimento/resolução (MTTA/MTTR), auditoria |
| **Segurança do painel** | HTTPS, login com perfis (Administrador, Operador/NOC, Leitura), 2FA (TOTP), bloqueio por tentativas, senhas cifradas, registro de atividades |
| **Integrações** | Métricas no formato Prometheus (Grafana, Zabbix) em `/metrics` |
| **Multiempresa** | Painel do fornecedor para cadastrar provedores, licença (plano, limite de equipamentos, validade), suspensão, acesso de suporte e auditoria de todas as empresas |

---

## Instalação

### Opção 1: Docker (recomendado para servidor Linux)

```bash
mkdir -p dados && sudo chown 10001 dados
docker compose up -d --build
docker compose exec sentinela python -m sentinela criar-admin
```

Painel: `https://IP_DO_SERVIDOR:8443`

### Opção 2: Linux sem Docker (systemd)

```bash
sudo ./scripts/linux/instalar.sh
```

Instala em `/opt/sentinela`, dados em `/var/lib/sentinela`, roda como serviço `sentinela`
(`journalctl -u sentinela -f` para ver os logs).

### Opção 3: Instalador para Windows (recomendado para Windows)

Um único `.exe` que já traz o Python e todas as dependências: quem instala **não precisa de Python**.

**Gerar o instalador** (uma vez, no seu PC com internet):

1. Dê dois cliques em **`GERAR_INSTALADOR.cmd`** na pasta principal.
2. O script baixa o Python embutido e as dependências, testa o pacote e gera
   `dist\Sentinela-de-Rede-X.Y.Z-instalador.exe`. Se o Inno Setup 6 não estiver instalado,
   ele tenta instalar com o `winget` (ou baixe em https://jrsoftware.org/isdl.php).

Requisitos só para **gerar**: internet e um Python 3.9+ no PC.

**Ícone / logotipo:** o ícone fica em `instalador/icone.ico` (instalador, atalhos e desinstalador) e
`sentinela/web/static/icone.png` (painel). Para usar o seu logotipo, troque esses dois arquivos mantendo
os nomes (o `.ico` de preferência com 256×256). Para redesenhar o ícone padrão: `python instalador/gerar_icone.py`.

Sem Windows à mão? Suba o projeto para o GitHub e rode **Actions → Instalador Windows → Run workflow**:
o `.exe` fica disponível em *Artifacts*.

**O que o instalador faz:**
- instala em `C:\Program Files\Sentinela de Rede` e guarda os dados em `C:\ProgramData\Sentinela`
  (acesso só de administradores);
- registra o serviço (inicia com o Windows e reinicia sozinho se cair);
- libera o Firewall (opcional) e cria os atalhos no Menu Iniciar: Abrir o painel, Reiniciar, Parar,
  Ver o log e Pasta de dados;
- abre o painel no final, para você criar o administrador;
- ao atualizar, para o serviço e mantém os dados e o `config.toml`;
- ao desinstalar, pergunta se deve apagar também os dados (o padrão é manter).

O instalador não é assinado digitalmente, então o Windows SmartScreen mostra "O Windows protegeu o
computador": clique em **Mais informações → Executar assim mesmo**. Para distribuir a clientes, vale
comprar um certificado de assinatura de código (code signing).

### Opção 3b: Windows com Python já instalado (sem gerar instalador)

1. Instale o Python 3.12 de python.org marcando **Add python.exe to PATH** e **Install for all users**.
2. Abra o PowerShell **como Administrador** na pasta do Sentinela e rode:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\windows\instalar.ps1
```

O script instala as dependências, cria a pasta de dados em `C:\ProgramData\Sentinela` (acesso só
de administradores), registra o serviço, libera o Firewall e pede o primeiro administrador.

Para só testar, sem instalar como serviço: `scripts\windows\rodar_agora.cmd`.

### Opção 4: manual (qualquer sistema)

```bash
python -m pip install -r requirements.txt
python -m sentinela criar-admin
python -m sentinela
```

> **Importante:** faça backup do arquivo `chave_mestra.key` (na pasta de dados) em um local
> seguro e **separado** do banco. Sem ele as senhas cadastradas não podem ser lidas; com ele e
> o banco juntos, qualquer pessoa consegue lê-las. Em produção, prefira passar a chave pela
> variável de ambiente `SENTINELA_CHAVE_MESTRA`.

---

## Licença (ativação do servidor)

Cada servidor do Sentinela precisa ser ativado pelo fornecedor. A licença vale por um período
(normalmente **30 dias**) e define o **limite de equipamentos** e o **limite de empresas** do servidor.

```
 COMPUTADOR DO CLIENTE                        FORNECEDOR
 1. instala e abre o painel:
    TELA DE REGISTRO mostra o SERIAL
    KEAQN-6TGZ6-E3BDT-...       ───────────►  2. cola o serial no Gerador de liberação
                                                 → "Gerar liberação" (30 dias, limites)
 3. cola a chave na tela        ◄───────────     JQAQN-6TGZ6-...
    → "Registrar" → sistema liberado
```

A **tela de registro** aparece logo ao abrir o painel, antes até de criar o administrador, sempre que o
servidor não tem licença válida. O **serial não muda** até ser usado (ou por 30 dias), então o cliente pode
fechar e abrir o sistema à vontade. Para **renovar** antes de vencer, o administrador usa a aba 🔑 Licença,
que mostra o serial da renovação.

- **Sem licença válida** (não ativado, vencida ou relógio atrasado), o monitoramento para e o painel
  volta para a tela de registro. **Os dados continuam guardados** e tudo volta a funcionar assim que a
  licença é ativada.
- **Renovação:** pela aba 🔑 Licença, a qualquer momento. Renovando antes de vencer, os dias que
  faltam se somam aos novos. O painel avisa o administrador **10 dias antes** do vencimento.
- **Segurança:** a chave de liberação é assinada digitalmente (Ed25519) e só funciona **neste servidor**
  e **para aquela solicitação**. Não serve em outro servidor, não pode ser reutilizada e não pode ser
  falsificada sem a chave privada do fornecedor. Atrasar o relógio do servidor bloqueia a licença.
- O ID do servidor aparece na aba Licença. No Windows ele vem do `MachineGuid`. No Docker, do
  `/etc/machine-id` do servidor, que o `docker-compose.yml` monta no container.

Pela linha de comando (útil em servidor sem navegador):

```bash
python -m sentinela licenca              # situação
python -m sentinela licenca-solicitar    # mostra o serial para enviar ao fornecedor
python -m sentinela licenca-ativar       # cola a chave recebida
# Docker:  docker compose exec sentinela python -m sentinela licenca-solicitar
```

> **Para o fornecedor:** as liberações são geradas pelo pacote separado **gerador-licencas-sentinela**,
> que **nunca** deve ir para o cliente. Antes de gerar o instalador ou a imagem Docker de cada versão
> nova, grave a sua chave pública no projeto com `python gerador.py aplicar-chave --sentinela PASTA`.
> O `GERAR_INSTALADOR.cmd` se recusa a gerar o instalador sem ela. Para operar você mesmo um servidor
> central multiempresa, emita para ele uma licença longa, por exemplo `--dias 3650 --equipamentos 0 --empresas 0`.

### Proteção do código

O instalador do Windows, a imagem Docker e o instalador do Linux levam **só o código compilado** (bytecode
`.pyc`, sem comentários nem docstrings). Os arquivos `.py` legíveis **não vão para o cliente**: ele não consegue
abrir o código num editor para ler, copiar ou alterar (por exemplo, para tirar a checagem de licença). Quem faz
isso é `scripts/proteger_codigo.py`, chamado automaticamente pelo `gerar_instalador.ps1`, pelo `Dockerfile` e pelo
`instalar.sh`, sempre com o mesmo Python que vai rodar o sistema.

Seja realista sobre o que isso garante:

- **Bloqueia** a cópia casual e a alteração simples do código, e esconde a lógica de quem só abre os arquivos.
- **Não é impossível de reverter.** Existem ferramentas que reconstroem parte do código a partir do bytecode,
  com bastante trabalho. Nenhuma proteção de software instalado no computador de outra pessoa é absoluta.
  Para subir mais um degrau, dá para compilar para código de máquina com Nuitka (veja abaixo).
- **A licença continua sendo a principal proteção:** uma cópia do Sentinela instalada por outra empresa não
  funciona sem uma liberação assinada por você.
- **A proteção jurídica completa a técnica:** registre o software no INPI e tenha um contrato de licença de
  uso (EULA) proibindo cópia, engenharia reversa e redistribuição. Isso dá base para agir contra quem copiar.
- **Os arquivos do painel** (HTML, CSS e JavaScript) são enviados ao navegador de quem acessa o painel, então
  continuam legíveis. Isso vale para qualquer sistema web.

**Nuitka (opcional, proteção mais forte):** compila o pacote para `.pyd` (código de máquina). Exige no PC que
gera o instalador o Python **da mesma versão** do Python embutido (3.12) e um compilador C (o Nuitka oferece
baixar o MinGW sozinho). Ainda não está automatizado no `gerar_instalador.ps1` porque não pôde ser testado
num Windows real.

A licença do servidor é diferente da **licença por empresa** (plano, limite e validade de cada provedor
no modo multiempresa, abaixo). As duas valem ao mesmo tempo: a do servidor por fora, a de cada empresa por dentro.

---

## Primeiros passos

0. **Registre o servidor** na tela de registro que aparece ao abrir o painel (veja acima).
1. **Crie o administrador do fornecedor** no primeiro acesso (pelo próprio servidor) ou com
   `python -m sentinela criar-admin`. Ele gerencia as empresas; recomenda-se `exigir_2fa_admin = true`
   no `config.toml`.
2. **Cadastre a empresa** (aba 🏢 Empresas) com os blocos de IP e o ASN dela, e o primeiro
   administrador. Usando para um provedor só? Basta renomear a "Empresa principal" e entrar nela.
3. **Cadastre os equipamentos** na aba ⚙️ Equipamentos, use **Testar conexão SSH** e **Testar SNMP**.
   Use um usuário **somente leitura** para o monitoramento. Para mitigação, cadastre à parte um
   usuário com permissão de escrita (campo "Usuário de mitigação").
4. **Envie os logs (syslog)** dos equipamentos para o servidor, na porta UDP 514. A tela Ao vivo
   mostra os comandos prontos para cada fabricante (botão "Como configurar os equipamentos").
5. **Envie fluxo (NetFlow/IPFIX/sFlow)** dos roteadores de borda para as portas UDP 2055 (NetFlow/IPFIX)
   e 6343 (sFlow). A aba 🌊 DDoS mostra os comandos. Use **timeout ativo de 1 minuto**.
6. **Configure os alertas** na aba 🔔 Alertas e monte a **escala de plantão**.
7. **Crie os usuários** do NOC na aba 👥 Usuários (eles trocam a senha no primeiro acesso).

### Comandos úteis

```bash
python -m sentinela criar-admin                   # administrador do FORNECEDOR
python -m sentinela redefinir-senha USUARIO      # usuário troca no próximo login
python -m sentinela remover-2fa USUARIO          # perdeu o celular
python -m sentinela importar-json equipamentos.json   # do script antigo
python -m sentinela licenca                      # situação da licença do servidor
python -m sentinela licenca-solicitar            # serial para o fornecedor
python -m sentinela licenca-ativar               # aplica a chave de liberação
```

---

## Modo servidor: vários provedores

O Sentinela roda como **um servidor central** (de preferência uma VPS Linux com Docker) e atende vários
provedores. Há dois tipos de conta:

- **Fornecedor** (você): cria e edita as empresas, define a licença, suspende, remove, cria o primeiro
  administrador de cada provedor e entra em qualquer empresa pelo seletor no topo para dar suporte
  (tudo fica registrado na auditoria daquela empresa). As contas do fornecedor não aparecem para os provedores.
- **Usuários do provedor** (Administrador, Operador/NOC, Leitura): veem e alteram **só** os dados da própria
  empresa: equipamentos, incidentes, backups, DDoS, BGP, OLTs, mitigações, alertas, plantão, relatórios e auditoria.

**Licença por empresa:** plano (texto livre), limite de equipamentos (0 = sem limite) e validade. O provedor
é avisado 15 dias antes do vencimento. Vencida ou suspensa, os usuários dele perdem o acesso na hora (até as
sessões abertas) e o monitoramento dos equipamentos dele para. Os dados ficam guardados até você remover a empresa.

**Como os dados são separados:**

| Dado | Como o servidor sabe de quem é |
|---|---|
| Equipamentos, sites, usuários | Gravados com a empresa de quem cadastrou |
| Syslog, NetFlow/sFlow | Pelo IP do equipamento que enviou (cada IP:porta só pode estar em uma empresa) |
| DDoS, RPKI, mitigação | Pelos blocos de IP e ASN da empresa (uma rede só pode ter uma dona); a mitigação só aceita IPs e roteadores da própria empresa |
| Backups e evidências | Pasta `backups/empresa_<id>/`; um provedor não abre arquivos de outro |
| Alertas | Configuração, canais, escala de plantão e limite anti-enxurrada separados por empresa |

**Antes de oferecer como serviço, leve em conta:**

- **O servidor central guarda as senhas dos roteadores de todos os provedores** (cifradas, com a chave
  `chave_mestra.key`). Proteja-o como o ativo mais valioso: acesso SSH só por chave, firewall, atualizações,
  backup cifrado da pasta de dados e 2FA obrigatório (`exigir_2fa_admin = true`).
- **Alcance:** o servidor precisa chegar aos equipamentos por SSH/SNMP e receber syslog/fluxo deles. O caminho
  mais seguro é uma **VPN por provedor** (WireGuard, por exemplo) até a VPS, em vez de abrir SSH dos roteadores para a internet.
- **IPs únicos:** como o syslog e o fluxo são identificados pelo IP de origem, dois provedores não podem usar o
  mesmo IP de equipamento no mesmo servidor. Se dois provedores usam a mesma faixa privada, use NAT diferente na
  VPN de cada um.
- Provedores clientes **não podem** cadastrar o próprio servidor (127.0.0.1, link-local) como equipamento, nem
  apontar webhook/Evolution/SMTP para a rede interna do servidor (`alertas_rede_interna_para_todos = false`).
  A "Empresa principal" (id 1) pode, porque é a do próprio servidor.
- Os blocos de IP e o ASN que estavam no `config.toml` (instalações antigas) valem só para a "Empresa principal".
- As métricas em `/metrics` trazem todas as empresas (rótulo `empresa`): o token é só do fornecedor.

**Atualizando de uma versão antiga:** na primeira execução o banco é migrado sozinho. Tudo o que existia vai
para a empresa "Empresa principal", os administradores antigos viram administradores do fornecedor, e os
operadores e leitores ficam na empresa principal. Os backups são movidos para `backups/empresa_1/`.

---

## Mitigação: leia antes de usar

- **RTBH** descarta todo o tráfego para o IP atacado (o cliente fica fora do ar, mas o resto da rede
  é salvo). Pré-requisito: o roteador de borda precisa anunciar as rotas blackhole ao seu trânsito com a
  **community de blackhole da operadora** (geralmente `65535:666`, RFC 7999). **Confirme com o seu
  provedor de trânsito** e teste em horário de manutenção antes de usar em produção.
- Os comandos de cada fabricante podem ser ajustados em 🛡 Mitigação → "Configurar comandos e regras".
- Travas: RTBH só para IPs das suas redes, lista "nunca bloquear" (coloque os IPs do NOC, servidores,
  DNS), um IP por vez, tudo registrado na auditoria.
- O modo automático (sem aprovação) vem **desligado**. Lembre que pacotes UDP de syslog e NetFlow podem
  ter o IP de origem falsificado. Por isso o Sentinela só aceita syslog e fluxo vindos de IPs de
  equipamentos cadastrados, nunca aplica nada sem aprovação por padrão, e recomenda-se restringir essas
  portas no firewall para aceitar só os seus roteadores (e aplicar anti-spoofing/BCP 38 na borda).

---

## Testes

```bash
python -m unittest discover -s testes -t .
```

66 testes automatizados cobrindo: login, 2FA (vetor oficial do RFC 6238), CSRF, permissões por perfil,
cofre, SNMP v2c/v3 (vetor oficial do RFC 3414 e agente simulado), NetFlow v5/v9, IPFIX e sFlow,
classificação de DDoS, alertas (servidores HTTP e SMTP de teste), escalonamento, PDF, BGP em 4 formatos,
RPKI/sequestro, OLTs, mitigação, regressões da revisão de segurança, **isolamento entre empresas**
(`testes/test_multiempresa.py`: um provedor tentando ver, alterar ou usar equipamentos, incidentes, arquivos,
mitigações, usuários, manutenções e alertas de outro; licença; suspensão; remoção; destinos internos bloqueados)
e **licença do servidor** (`testes/test_licenca.py`: bloqueio sem licença, ativação pelo painel, vencimento,
renovação, reuso, chave falsificada, outro servidor, relógio atrasado, limites e linha de comando).

O código passou por uma revisão de segurança independente. Os achados (injeção de comando via scope-id
IPv6 na mitigação, travamento do coletor NetFlow com template malformado, duração de mitigação sem
limite, força bruta no 2FA, fluxo aceito de qualquer origem e destinos link-local em webhooks) foram
corrigidos e têm testes de regressão em `testes/test_seguranca.py`.

Para ver a interface com equipamentos simulados: `python testes/servidor_demo.py` e abra
`https://localhost:8443`.

### O que foi testado com simulação (e o que conferir no seu ambiente)

Os testes usam equipamentos simulados que reproduzem as saídas dos fabricantes. Antes de vender ou
colocar em produção, valide em equipamentos reais, principalmente:

- Os comandos e o formato de saída do **seu modelo/firmware** (BGP, OLT, logs), em especial ZTE,
  Fiberhome e Parks, que variam muito entre versões.
- A **mitigação** (RTBH e bloqueio) em laboratório, junto com a configuração BGP de blackhole.
- O envio real pela **API da Meta** (exige um modelo de mensagem aprovado) e pela Evolution API.
- O script do Windows (`instalar.ps1`), que não pôde ser executado no ambiente de desenvolvimento.

---

## Arquitetura

```
sentinela/
  __main__.py      linha de comando
  servidor.py      inicialização, HTTPS (certificado autoassinado gerado na hora)
  config.py        config.toml + variáveis de ambiente
  banco.py         SQLite (WAL) com migrações
  cofre.py         segredos cifrados (Fernet/AES)
  autenticacao.py  usuários, senhas (scrypt), sessões, 2FA, bloqueio, auditoria
  licenca.py       licença do servidor: solicitação, ativação, limites, antifraude
  licenca_formato.py  formato dos códigos (idêntico ao do gerador do fornecedor)
  ed25519.py       assinatura digital da licença (RFC 8032, sem dependências)
scripts/proteger_codigo.py  compila o pacote e remove os .py antes de ir para o cliente
  qrcode.py        gerador de QR code (sem dependências) para o 2FA
  equipamentos.py  cadastro de equipamentos e sites
  fabricantes.py   comandos e regras de auditoria por fabricante (ajuste aqui)
  ssh.py           conexão SSH (netmiko) com tratamento de paginação
  monitor.py       verificação periódica, backup, auditoria, captura de evidências
  tempo_real.py    syslog e ataques em andamento (tela Ao vivo)
  snmp.py          cliente SNMP v2c/v3 próprio
  coletor_snmp.py  CPU, memória, interfaces
  fluxo.py         NetFlow/IPFIX/sFlow e detecção de DDoS
  bgp.py           sessões BGP, RPKI e sequestro de prefixo (RIPEstat)
  olt.py           OLTs GPON
  alertas.py       WhatsApp, e-mail, Telegram, webhook, escala e escalonamento
  mitigacao.py     RTBH e bloqueio com aprovação
  relatorios.py    PDF mensal
  incidentes.py    eventos e incidentes
  armazenamento.py backups e evidências em disco
  web/             painel (Flask + interface sem dependências externas)
```

Portas: **8443/tcp** (painel), **514/udp** (syslog), **2055/udp** (NetFlow/IPFIX), **6343/udp** (sFlow).
