@echo off
rem Iniciado pela tarefa agendada "Sentinela de Rede" (conta SYSTEM, ao ligar o Windows).
setlocal
set "APP=%~dp0.."
set "SENTINELA_DADOS=%ProgramData%\Sentinela"
set "LOG=%SENTINELA_DADOS%\sentinela.log"
if not exist "%SENTINELA_DADOS%" mkdir "%SENTINELA_DADOS%"

rem guarda no maximo ~10 MB de log (o anterior vira sentinela.log.1)
if exist "%LOG%" for %%F in ("%LOG%") do if %%~zF GTR 10485760 move /y "%LOG%" "%LOG%.1" >nul

cd /d "%APP%\app"
echo ===== %DATE% %TIME% iniciando =====>> "%LOG%"
"%APP%\python\python.exe" -X utf8 -u -m sentinela >> "%LOG%" 2>&1
