﻿<#
  Controle do serviço do Sentinela de Rede (usado pelo instalador e pelos atalhos do Menu Iniciar).
    -Acao instalar | remover | iniciar | parar | reiniciar | log | firewall
#>
param(
    [ValidateSet("instalar", "remover", "iniciar", "parar", "reiniciar", "log", "firewall")]
    [string]$Acao = "iniciar"
)

$ErrorActionPreference = "Stop"
$NomeTarefa = "Sentinela de Rede"
$App = (Resolve-Path "$PSScriptRoot\..").Path
$Dados = Join-Path $env:ProgramData "Sentinela"
$Python = Join-Path $App "python\python.exe"

# Atalhos do Menu Iniciar rodam sem privilégio: pede elevação (UAC) e roda de novo
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-Acao", $Acao)
    exit
}

function Parar {
    if (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue) {
        Stop-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue
    }
    # garante que o Python do Sentinela terminou (Stop-ScheduledTask nem sempre encerra o processo filho)
    Get-CimInstance Win32_Process -Filter "Name='python.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -and ($_.ExecutablePath -ieq $Python) } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
}

function Iniciar {
    Start-ScheduledTask -TaskName $NomeTarefa
}

switch ($Acao) {
    "instalar" {
        Parar
        New-Item -ItemType Directory -Force -Path $Dados | Out-Null
        # pasta de dados: acesso só de Administradores e SYSTEM (guarda a chave mestra e o banco)
        & icacls $Dados /inheritance:r /grant:r "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" | Out-Null

        if (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue) {
            Unregister-ScheduledTask -TaskName $NomeTarefa -Confirm:$false
        }
        $iniciador = Join-Path $App "scripts\iniciar_servico.cmd"
        $acaoTarefa = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument "/c `"$iniciador`"" -WorkingDirectory (Join-Path $App "app")
        $gatilho = New-ScheduledTaskTrigger -AtStartup
        $usuario = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
        $ajustes = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) `
            -StartWhenAvailable -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $NomeTarefa -Action $acaoTarefa -Trigger $gatilho -Principal $usuario `
            -Settings $ajustes -Description "Sentinela de Rede: monitoramento de segurança de roteadores e switches" | Out-Null
        Iniciar
        # espera o painel responder (até 90 s) para o instalador abrir o navegador já com tudo no ar
        for ($i = 0; $i -lt 90; $i++) {
            try {
                $cliente = New-Object Net.Sockets.TcpClient
                $cliente.Connect("127.0.0.1", 8443)
                $cliente.Close()
                break
            } catch { Start-Sleep -Seconds 1 }
        }
    }
    "remover" {
        Parar
        if (Get-ScheduledTask -TaskName $NomeTarefa -ErrorAction SilentlyContinue) {
            Unregister-ScheduledTask -TaskName $NomeTarefa -Confirm:$false
        }
        Get-NetFirewallRule -DisplayName "Sentinela - *" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    }
    "iniciar" { Iniciar }
    "parar" { Parar }
    "reiniciar" { Parar; Iniciar }
    "log" {
        $log = Join-Path $Dados "sentinela.log"
        if (-not (Test-Path $log)) { New-Item -ItemType File -Path $log | Out-Null }
        Start-Process notepad.exe -ArgumentList "`"$log`""
    }
    "firewall" {
        $regras = @(
            @{ Nome = "Sentinela - Painel HTTPS"; Protocolo = "TCP"; Porta = 8443 },
            @{ Nome = "Sentinela - Syslog";       Protocolo = "UDP"; Porta = 514 },
            @{ Nome = "Sentinela - NetFlow";      Protocolo = "UDP"; Porta = 2055 },
            @{ Nome = "Sentinela - sFlow";        Protocolo = "UDP"; Porta = 6343 }
        )
        foreach ($r in $regras) {
            Get-NetFirewallRule -DisplayName $r.Nome -ErrorAction SilentlyContinue | Remove-NetFirewallRule
            New-NetFirewallRule -DisplayName $r.Nome -Direction Inbound -Action Allow -Protocol $r.Protocolo `
                -LocalPort $r.Porta -Profile Domain, Private | Out-Null
        }
    }
}
