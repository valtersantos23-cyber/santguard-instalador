﻿; Instalador do Sentinela de Rede para Windows (Inno Setup 6)
;
; Não compile este arquivo diretamente: use GERAR_INSTALADOR.cmd na pasta principal,
; que baixa o Python embutido, instala as dependências e chama o compilador.

#ifndef Versao
  #define Versao "2.1.0"
#endif
#ifndef Origem
  #define Origem "..\build\instalador"
#endif

[Setup]
AppId={{8C1B5E3A-6F2D-4C1B-9E7A-5A3D2C1B0F9E}
AppName=Sentinela de Rede
AppVersion={#Versao}
AppVerName=Sentinela de Rede {#Versao}
AppPublisher=Sentinela de Rede
DefaultDirName={autopf}\Sentinela de Rede
DefaultGroupName=Sentinela de Rede
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=Sentinela-de-Rede-{#Versao}-instalador
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
WizardStyle=modern
MinVersion=10.0
UninstallDisplayName=Sentinela de Rede
SetupIconFile=icone.ico
UninstallDisplayIcon={app}\icone.ico
CloseApplications=no
SetupLogging=yes

[Languages]
Name: "ptbr"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "firewall"; Description: "Liberar no Firewall do Windows (painel 8443/TCP, syslog 514/UDP, NetFlow 2055/UDP, sFlow 6343/UDP)"
Name: "atalho"; Description: "Criar atalho do painel na Área de Trabalho"

[Dirs]
Name: "{commonappdata}\Sentinela"; Flags: uninsneveruninstall

[Files]
Source: "{#Origem}\python\*"; DestDir: "{app}\python"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "{#Origem}\app\*"; DestDir: "{app}\app"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "{#Origem}\scripts\*"; DestDir: "{app}\scripts"; Flags: ignoreversion
Source: "icone.ico"; DestDir: "{app}"; Flags: ignoreversion
; configuração inicial: só na primeira instalação (nunca sobrescreve a do cliente)
Source: "{#Origem}\app\config.exemplo.toml"; DestDir: "{commonappdata}\Sentinela"; DestName: "config.toml"; Flags: onlyifdoesntexist uninsneveruninstall

[INI]
Filename: "{app}\Abrir painel.url"; Section: "InternetShortcut"; Key: "URL"; String: "https://localhost:8443"
Filename: "{app}\Abrir painel.url"; Section: "InternetShortcut"; Key: "IconFile"; String: "{app}\icone.ico"
Filename: "{app}\Abrir painel.url"; Section: "InternetShortcut"; Key: "IconIndex"; String: "0"

[Icons]
Name: "{group}\Abrir o painel do Sentinela"; Filename: "{app}\Abrir painel.url"; IconFilename: "{app}\icone.ico"
Name: "{group}\Reiniciar o Sentinela"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\scripts\servico.ps1"" -Acao reiniciar"; IconFilename: "{app}\icone.ico"
Name: "{group}\Parar o Sentinela"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\scripts\servico.ps1"" -Acao parar"; IconFilename: "{app}\icone.ico"
Name: "{group}\Ver o log"; Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\scripts\servico.ps1"" -Acao log"; IconFilename: "{app}\icone.ico"
Name: "{group}\Pasta de dados (backups e evidências)"; Filename: "{commonappdata}\Sentinela"; IconFilename: "{app}\icone.ico"
Name: "{group}\Desinstalar o Sentinela"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Sentinela de Rede"; Filename: "{app}\Abrir painel.url"; Tasks: atalho; IconFilename: "{app}\icone.ico"

[Run]
Filename: "{app}\python\python.exe"; Parameters: "-m compileall -q ""{app}\app"" ""{app}\python\Lib\site-packages"""; StatusMsg: "Preparando os arquivos..."; Flags: runhidden waituntilterminated
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\servico.ps1"" -Acao firewall"; StatusMsg: "Liberando o Firewall..."; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\servico.ps1"" -Acao instalar"; StatusMsg: "Registrando e iniciando o serviço..."; Flags: runhidden waituntilterminated
Filename: "{app}\Abrir painel.url"; Description: "Abrir o painel agora (crie o usuário administrador na primeira tela)"; Flags: postinstall shellexec nowait skipifsilent

[UninstallRun]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\scripts\servico.ps1"" -Acao remover"; Flags: runhidden waituntilterminated; RunOnceId: "RemoverServico"

[UninstallDelete]
; remove o cache do Python gerado depois da instalação (os dados ficam em ProgramData)
Type: filesandordirs; Name: "{app}"

[Code]
// Antes de instalar/atualizar: para o serviço, senão os arquivos ficam presos em uso
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Codigo: Integer;
  Script: String;
begin
  Script := ExpandConstant('{app}\scripts\servico.ps1');
  if FileExists(Script) then
    Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
         '-NoProfile -ExecutionPolicy Bypass -File "' + Script + '" -Acao parar',
         '', SW_HIDE, ewWaitUntilTerminated, Codigo);
  Result := '';
end;

// Ao desinstalar: pergunta se apaga também os dados (padrão: NÃO apagar)
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    if SuppressibleMsgBox('Deseja apagar também os DADOS do Sentinela?' + #13#10#13#10 +
         'Isso inclui usuários, equipamentos, backups das configurações, evidências de ataques e a chave mestra.' + #13#10#13#10 +
         'Escolha NÃO se pretende reinstalar ou atualizar.',
         mbConfirmation, MB_YESNO or MB_DEFBUTTON2, IDNO) = IDYES then
      DelTree(ExpandConstant('{commonappdata}\Sentinela'), True, True, True);
  end;
end;

// Mensagem final
procedure CurPageChanged(CurPageID: Integer);
begin
  if CurPageID = wpFinished then
    WizardForm.FinishedLabel.Caption :=
      'O Sentinela de Rede foi instalado e já está rodando como serviço (inicia junto com o Windows).' + #13#10#13#10 +
      'Painel: https://localhost:8443' + #13#10 +
      'O navegador vai avisar que o certificado não é confiável: clique em Avançado e Continuar.' + #13#10#13#10 +
      'IMPORTANTE: faça uma cópia do arquivo C:\ProgramData\Sentinela\chave_mestra.key em local seguro.';
end;
