"""Desenha o ícone do Sentinela de Rede (escudo com linha de pulso) e salva:
  instalador/icone.ico                       (instalador, atalhos e desinstalador; 16 a 256 px)
  sentinela/web/static/icone.png             (aba do navegador e tela de login)

Uso: python instalador/gerar_icone.py          (precisa do Pillow: pip install pillow)

Para usar um logotipo próprio: troque instalador/icone.ico (formato .ico, de preferência com
256x256) e sentinela/web/static/icone.png pelos seus arquivos, com os mesmos nomes.
"""

import math
import pathlib

from PIL import Image, ImageDraw, ImageFilter

RAIZ = pathlib.Path(__file__).resolve().parent.parent
GRANDE = 1024


def bezier(p0, p1, p2, p3, passos=40):
    pontos = []
    for i in range(passos + 1):
        t = i / passos
        a, b, c, d = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3
        pontos.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))
    return pontos


def escudo(cx, topo, largura, altura, curva_topo):
    """Contorno de escudo: topo levemente arqueado, laterais retas que curvam até a ponta."""
    e, d = cx - largura / 2, cx + largura / 2
    base = topo + altura
    pontos = bezier((e, topo + curva_topo), (cx - largura * 0.25, topo), (cx - largura * 0.1, topo - curva_topo * 0.4), (cx, topo - curva_topo * 0.2))
    pontos += bezier((cx, topo - curva_topo * 0.2), (cx + largura * 0.1, topo - curva_topo * 0.4), (cx + largura * 0.25, topo), (d, topo + curva_topo))
    pontos += bezier((d, topo + curva_topo), (d, topo + altura * 0.45), (d - largura * 0.08, topo + altura * 0.78), (cx, base))
    pontos += bezier((cx, base), (e + largura * 0.08, topo + altura * 0.78), (e, topo + altura * 0.45), (e, topo + curva_topo))
    return pontos


def desenhar(tamanho=GRANDE, detalhe=True):
    s = tamanho
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))

    # sombra suave
    sombra = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(sombra).polygon(escudo(s / 2, s * 0.10 + s * 0.02, s * 0.78, s * 0.84, s * 0.07), fill=(0, 0, 0, 120))
    img.alpha_composite(sombra.filter(ImageFilter.GaussianBlur(s * 0.02)))

    # escudo com degradê azul (de cima para baixo)
    forma = escudo(s / 2, s * 0.10, s * 0.78, s * 0.84, s * 0.07)
    mascara = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mascara).polygon(forma, fill=255)
    degrade = Image.new("RGBA", (s, s))
    topo_cor, base_cor = (56, 139, 253), (13, 42, 92)
    pix = ImageDraw.Draw(degrade)
    for y in range(s):
        t = min(1, max(0, (y - s * 0.1) / (s * 0.84)))
        cor = tuple(int(topo_cor[i] + (base_cor[i] - topo_cor[i]) * t) for i in range(3)) + (255,)
        pix.line([(0, y), (s, y)], fill=cor)
    img.paste(degrade, (0, 0), mascara)

    d = ImageDraw.Draw(img)
    # borda clara
    d.line(forma + [forma[0]], fill=(200, 225, 255, 255), width=max(2, int(s * 0.028)), joint="curve")

    # anel interno (só nos tamanhos maiores)
    if detalhe:
        interno = escudo(s / 2, s * 0.17, s * 0.62, s * 0.70, s * 0.055)
        d.line(interno + [interno[0]], fill=(255, 255, 255, 60), width=max(1, int(s * 0.008)), joint="curve")

    # linha de pulso (monitoramento), da esquerda para a direita
    y0 = s * 0.50
    pulso = [(s * 0.20, y0), (s * 0.36, y0), (s * 0.42, y0 - s * 0.06), (s * 0.49, y0 + s * 0.17),
             (s * 0.57, y0 - s * 0.24), (s * 0.63, y0 + s * 0.04), (s * 0.67, y0), (s * 0.80, y0)]
    largura = max(2, int(s * (0.055 if detalhe else 0.075)))
    brilho = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(brilho).line(pulso, fill=(80, 250, 180, 170), width=largura * 2, joint="curve")
    img.alpha_composite(brilho.filter(ImageFilter.GaussianBlur(s * 0.018)))
    d.line(pulso, fill=(110, 255, 200, 255), width=largura, joint="curve")
    for x, y in (pulso[0], pulso[-1]):
        r = largura * 0.5
        d.ellipse([x - r, y - r, x + r, y + r], fill=(110, 255, 200, 255))
    return img


def main():
    grande = desenhar(GRANDE, detalhe=True)
    simples = desenhar(GRANDE, detalhe=False)   # traço mais grosso, para 16-32 px
    tamanhos = [16, 20, 24, 32, 40, 48, 64, 128, 256]
    imagens = [(simples if t <= 32 else grande).resize((t, t), Image.LANCZOS) for t in tamanhos]

    ico = RAIZ / "instalador" / "icone.ico"
    imagens[-1].save(ico, format="ICO", sizes=[(t, t) for t in tamanhos], append_images=imagens[:-1])
    png = RAIZ / "sentinela" / "web" / "static" / "icone.png"
    grande.resize((192, 192), Image.LANCZOS).save(png, optimize=True)
    previa = RAIZ / "build" / "previa_icone.png"
    previa.parent.mkdir(exist_ok=True)
    folha = Image.new("RGBA", (sum(tamanhos) + 20 * len(tamanhos) + 276, 296), (240, 240, 240, 255))
    x = 10
    for t, im in zip(tamanhos, imagens):
        folha.alpha_composite(im, (x, 280 - t))
        x += t + 20
    folha.alpha_composite(grande.resize((256, 256), Image.LANCZOS), (x, 20))
    folha.save(previa)
    print(f"Ícone salvo em {ico} e {png}")


if __name__ == "__main__":
    main()
