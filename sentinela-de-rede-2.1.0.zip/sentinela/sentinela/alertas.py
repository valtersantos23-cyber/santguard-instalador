"""Alertas: WhatsApp (Meta oficial ou Evolution API), e-mail, Telegram e webhook,
com escala de plantão, escalonamento, janelas de manutenção e limite anti-enxurrada.

Configuração guardada no banco (tela Configurações). Segredos ficam cifrados no cofre.
"""

import datetime
import email.message
import hashlib
import hmac
import json
import smtplib
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from . import banco, cofre, incidentes
from .config import CFG

SEVERIDADES = {"baixa": 1, "media": 2, "alta": 3}

# Configuração padrão. Campos terminados em "_cif" são segredos (cifrados).
PADRAO = {
    "geral": {"nome_empresa": "Meu Provedor", "painel_url": "", "severidade_minima": "media",
              "escalonar_minutos": 15, "max_alertas_5min": 20},
    "whatsapp": {"modo": "desligado",  # desligado | meta | evolution
                 "meta_phone_id": "", "meta_token_cif": None, "meta_modelo": "alerta_sentinela",
                 "meta_idioma": "pt_BR", "meta_versao": "v21.0",
                 "evolution_url": "", "evolution_instancia": "", "evolution_chave_cif": None, "evolution_v1": False},
    "email": {"ativo": False, "servidor": "", "porta": 587, "seguranca": "starttls",  # starttls | ssl | nenhuma
              "usuario": "", "senha_cif": None, "remetente": ""},
    "telegram": {"ativo": False, "token_cif": None, "chat_id": ""},
    "webhook": {"ativo": False, "url": "", "segredo_cif": None},
}


class ErroAlerta(Exception):
    pass


# ======================================================================= configuração

class ConfigAlertas(dict):
    """Configuração de uma empresa. `rede_interna` diz se ela pode mandar alertas para IPs internos."""
    rede_interna = True


def rede_interna_permitida(empresa_id):
    """Só a empresa principal (a do próprio servidor) pode apontar webhook/Evolution/SMTP para a rede interna.
    Um provedor cliente apontando para 127.0.0.1 ou 10.x acessaria serviços internos do SERVIDOR (SSRF)."""
    return empresa_id == 1 or bool(CFG["seguranca"].get("alertas_rede_interna_para_todos"))


def ler_config(empresa_id):
    """Configuração de alertas DA EMPRESA (cada provedor tem os seus canais e a sua escala)."""
    salvo = json.loads(banco.ler_config_empresa(empresa_id, "alertas", "{}") or "{}")
    cfg = ConfigAlertas({canal: dict(valores) for canal, valores in PADRAO.items()})
    cfg.rede_interna = rede_interna_permitida(empresa_id)
    linha = banco.um("SELECT nome FROM empresas WHERE id = ?", (empresa_id,))
    if linha:  # o nome padrão nas mensagens é o do provedor
        cfg["geral"]["nome_empresa"] = linha["nome"]
    for canal, valores in salvo.items():
        if canal in cfg:
            cfg[canal].update({k: v for k, v in valores.items() if k in cfg[canal]})
    return cfg


def config_publica(empresa_id):
    """Configuração sem os segredos (para a tela): só indica se cada segredo está preenchido."""
    cfg = ler_config(empresa_id)
    for canal in cfg.values():
        for chave in [k for k in canal if k.endswith("_cif")]:
            canal[chave[:-4] + "_definido"] = bool(canal.pop(chave))
    return cfg


def salvar_config(empresa_id, novos):
    """Recebe a config da tela. Segredos vêm sem o sufixo _cif; vazio = manter o atual."""
    cfg = ler_config(empresa_id)
    for canal, valores in novos.items():
        if canal not in cfg or not isinstance(valores, dict):
            continue
        for chave, valor in valores.items():
            if chave + "_cif" in cfg[canal]:
                if valor:
                    cfg[canal][chave + "_cif"] = cofre.cifrar(str(valor))
            elif chave in cfg[canal] and not chave.endswith("_cif"):
                padrao = PADRAO[canal][chave]
                if isinstance(padrao, bool):
                    valor = bool(valor)
                elif isinstance(padrao, int):
                    try:
                        valor = int(valor)
                    except (TypeError, ValueError):
                        raise ErroAlerta(f"Valor inválido para {canal}.{chave}")
                else:
                    valor = str(valor).strip()
                cfg[canal][chave] = valor
    for canal, chave in (("webhook", "url"), ("whatsapp", "evolution_url")):
        url = cfg[canal][chave]
        if url:
            partes = urllib.parse.urlparse(url)
            if partes.scheme not in ("http", "https") or not partes.hostname:
                raise ErroAlerta("As URLs precisam começar com http:// ou https://")
            _recusar_link_local(partes.hostname, rede_interna_permitida(empresa_id))
    if cfg["email"]["servidor"]:
        _recusar_link_local(cfg["email"]["servidor"], rede_interna_permitida(empresa_id))
    if cfg["whatsapp"]["modo"] not in ("desligado", "meta", "evolution"):
        raise ErroAlerta("Modo de WhatsApp inválido")
    if cfg["geral"]["severidade_minima"] not in SEVERIDADES:
        raise ErroAlerta("Severidade inválida")
    banco.gravar_config_empresa(empresa_id, "alertas", json.dumps(cfg, ensure_ascii=False))
    return cfg


def _recusar_link_local(host, rede_interna=True):
    """Bloqueia endereços de metadados de nuvem/link-local (169.254.x.x, fe80::). Rede interna só é permitida
    para a empresa principal (a Evolution API costuma rodar no próprio servidor ou na LAN)."""
    import ipaddress
    import socket
    try:
        enderecos = {i[4][0] for i in socket.getaddrinfo(host, None)}
    except OSError:
        return
    for e in enderecos:
        ip = ipaddress.ip_address(e.split("%")[0])
        if ip.is_link_local or ip.is_multicast or ip.is_unspecified:
            raise ErroAlerta(f"Destino não permitido ({e}): endereço link-local/metadados")
        if not rede_interna and (ip.is_private or ip.is_loopback or ip.is_reserved or not ip.is_global):
            raise ErroAlerta(f"Destino não permitido ({e}): use um endereço público (rede interna do servidor é bloqueada)")


def _segredo(cfg, canal, chave):
    try:
        return cofre.decifrar(cfg[canal].get(chave + "_cif"))
    except cofre.ErroCofre:
        return None


# ======================================================================= envio (HTTP)

def _post_json(url, dados, cabecalhos=None, timeout=10, rede_interna=True):
    host = urllib.parse.urlparse(url).hostname
    if host:
        _recusar_link_local(host, rede_interna)
    corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
    pedido = urllib.request.Request(url, data=corpo, method="POST",
                                    headers={"Content-Type": "application/json", **(cabecalhos or {})})
    try:
        with urllib.request.urlopen(pedido, timeout=timeout) as resposta:
            return resposta.status, resposta.read(2000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        detalhe = e.read(500).decode("utf-8", "replace")
        raise ErroAlerta(f"HTTP {e.code}: {detalhe}") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ErroAlerta(f"sem conexão: {getattr(e, 'reason', e)}") from e


def numero_whatsapp(telefone):
    digitos = "".join(c for c in telefone or "" if c.isdigit())
    if len(digitos) in (10, 11):  # número brasileiro sem o 55
        digitos = "55" + digitos
    return digitos


def enviar_whatsapp(cfg, telefone, texto):
    w = cfg["whatsapp"]
    numero = numero_whatsapp(telefone)
    if len(numero) < 12:
        raise ErroAlerta(f"telefone inválido: {telefone}")
    if w["modo"] == "meta":
        token = _segredo(cfg, "whatsapp", "meta_token")
        if not (token and w["meta_phone_id"]):
            raise ErroAlerta("WhatsApp (Meta): informe o Phone Number ID e o token")
        # parâmetros de modelo não aceitam quebra de linha nem tabulação
        parametro = " · ".join(l.strip() for l in texto.splitlines() if l.strip())[:1000]
        url = f"https://graph.facebook.com/{w['meta_versao']}/{urllib.parse.quote(w['meta_phone_id'])}/messages"
        _post_json(url, {
            "messaging_product": "whatsapp", "recipient_type": "individual", "to": numero, "type": "template",
            "template": {"name": w["meta_modelo"], "language": {"code": w["meta_idioma"]},
                         "components": [{"type": "body", "parameters": [{"type": "text", "text": parametro}]}]},
        }, {"Authorization": f"Bearer {token}"}, rede_interna=getattr(cfg, "rede_interna", True))
    elif w["modo"] == "evolution":
        chave = _segredo(cfg, "whatsapp", "evolution_chave")
        if not (chave and w["evolution_url"] and w["evolution_instancia"]):
            raise ErroAlerta("Evolution API: informe a URL, a instância e a chave")
        url = f"{w['evolution_url'].rstrip('/')}/message/sendText/{urllib.parse.quote(w['evolution_instancia'])}"
        corpo = {"number": numero, "textMessage": {"text": texto}} if w["evolution_v1"] else {"number": numero, "text": texto}
        _post_json(url, corpo, {"apikey": chave}, rede_interna=getattr(cfg, "rede_interna", True))
    else:
        raise ErroAlerta("WhatsApp desligado")


def enviar_email(cfg, destino, assunto, texto):
    e = cfg["email"]
    if not (e["servidor"] and e["remetente"]):
        raise ErroAlerta("E-mail: informe o servidor SMTP e o remetente")
    msg = email.message.EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = e["remetente"], destino, assunto
    msg.set_content(texto)
    contexto = ssl.create_default_context()
    try:
        _recusar_link_local(e["servidor"], getattr(cfg, "rede_interna", True))
        if e["seguranca"] == "ssl":
            conexao = smtplib.SMTP_SSL(e["servidor"], int(e["porta"]), timeout=15, context=contexto)
        else:
            conexao = smtplib.SMTP(e["servidor"], int(e["porta"]), timeout=15)
        with conexao:
            if e["seguranca"] == "starttls":
                conexao.starttls(context=contexto)
            senha = _segredo(cfg, "email", "senha")
            if e["usuario"] and senha:
                conexao.login(e["usuario"], senha)
            conexao.send_message(msg)
    except (smtplib.SMTPException, OSError) as erro:
        raise ErroAlerta(f"SMTP: {erro}") from erro


def enviar_telegram(cfg, texto):
    token = _segredo(cfg, "telegram", "token")
    if not (token and cfg["telegram"]["chat_id"]):
        raise ErroAlerta("Telegram: informe o token do bot e o chat ID")
    _post_json(f"https://api.telegram.org/bot{token}/sendMessage",
               {"chat_id": cfg["telegram"]["chat_id"], "text": texto, "disable_web_page_preview": True},
               rede_interna=getattr(cfg, "rede_interna", True))


def enviar_webhook(cfg, dados):
    url = cfg["webhook"]["url"]
    if not url:
        raise ErroAlerta("Webhook: informe a URL")
    corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
    cabecalhos = {}
    segredo = _segredo(cfg, "webhook", "segredo")
    if segredo:  # quem recebe pode conferir que veio mesmo do Sentinela
        cabecalhos["X-Sentinela-Assinatura"] = "sha256=" + hmac.new(segredo.encode(), corpo, hashlib.sha256).hexdigest()
    _post_json(url, dados, cabecalhos, rede_interna=getattr(cfg, "rede_interna", True))


# ======================================================================= mensagens

def texto_incidente(inc, cfg, nivel=1):
    geral = cfg["geral"]
    sev = inc["severidade"].upper()
    linhas = [f"🚨 [{sev}] {inc['tipo']} — {inc['equipamento']}", inc["titulo"],
              f"Aberto em {inc['abertura']} · Incidente #{inc['id']}"]
    if nivel > 1:
        linhas.insert(0, f"⏫ ESCALONADO (nível {nivel}): ninguém reconheceu ainda")
    if geral["painel_url"]:
        linhas.append(f"Reconheça no painel: {geral['painel_url'].rstrip('/')}/")
    linhas.append(f"— Sentinela · {geral['nome_empresa']}")
    return "\n".join(linhas)


def em_manutencao(equip_id, empresa_id):
    """Manutenção ativa que cobre o equipamento (ou a rede toda) da empresa."""
    if empresa_id is None:
        return None
    agora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    linha = banco.um(
        "SELECT m.* FROM manutencoes m LEFT JOIN equipamentos e ON e.id = ? "
        "WHERE m.empresa_id = ? AND ? BETWEEN replace(m.inicio, 'T', ' ') AND replace(m.fim, 'T', ' ') "
        "AND ((? IS NOT NULL AND m.equip_id = ?) OR (m.site_id IS NOT NULL AND m.site_id = e.site_id) "
        "OR (m.equip_id IS NULL AND m.site_id IS NULL)) LIMIT 1",
        (equip_id, int(empresa_id), agora, equip_id, equip_id))
    return linha


def _registrar_envio(incidente_id, canal, destino, nivel, ok, erro="", empresa_id=None):
    banco.executar("INSERT INTO envios (incidente_id, canal, destino, nivel, ok, erro, empresa_id) "
                   "VALUES (?, ?, ?, ?, ?, ?, ?)",
                   (incidente_id, canal, destino, nivel, int(ok), str(erro)[:500], empresa_id))


class Notificador:
    def __init__(self):
        self.trava = threading.Lock()
        self._recentes = {}          # empresa -> horários de envio (limite anti-enxurrada, por empresa)
        self._contidos = 0

    def _permitir(self, cfg, empresa_id):
        agora = time.time()
        with self.trava:
            lista = [t for t in self._recentes.get(empresa_id, []) if agora - t < 300]
            self._recentes[empresa_id] = lista
            if len(lista) >= int(cfg["geral"]["max_alertas_5min"]):
                self._contidos += 1
                return False
            lista.append(agora)
            return True

    def destinatarios(self, nivel, empresa_id):
        return banco.consultar(
            "SELECT u.usuario, u.nome, u.email, u.telefone, p.whatsapp, p.email AS quer_email "
            "FROM plantao p JOIN usuarios u ON u.id = p.usuario_id "
            "WHERE u.ativo = 1 AND p.nivel = ? AND u.empresa_id = ? AND u.fornecedor = 0", (nivel, int(empresa_id)))

    def notificar(self, inc, nivel=1):
        """Envia o incidente para o nível de plantão indicado. Retorna a lista de (canal, destino, ok, erro)."""
        resultados = []
        empresa_id = inc.get("empresa_id")
        if empresa_id is None:  # evento da plataforma: não é de nenhum provedor
            return resultados
        cfg = ler_config(empresa_id)
        if SEVERIDADES.get(inc["severidade"], 3) < SEVERIDADES[cfg["geral"]["severidade_minima"]]:
            return resultados
        manutencao = em_manutencao(inc["equip_id"], empresa_id)
        if manutencao:
            banco.executar("UPDATE incidentes SET silenciado = ? WHERE id = ?",
                           (f"manutenção: {manutencao['motivo']}", inc["id"]))
            return resultados
        if not self._permitir(cfg, empresa_id):
            incidentes.registrar_evento(inc["equip_id"], inc["equipamento"], "Alerta contido", "aviso",
                                        "Muitos alertas em 5 minutos: este não foi enviado (veja o painel)", fonte="alertas",
                                        empresa_id=empresa_id)
            return resultados

        texto = texto_incidente(inc, cfg, nivel)
        assunto = f"[Sentinela] [{inc['severidade'].upper()}] {inc['tipo']} — {inc['equipamento']}"
        tarefas = []
        if nivel == 1 and cfg["telegram"]["ativo"]:
            tarefas.append(("telegram", cfg["telegram"]["chat_id"], lambda: enviar_telegram(cfg, texto)))
        if nivel == 1 and cfg["webhook"]["ativo"]:
            tarefas.append(("webhook", cfg["webhook"]["url"], lambda: enviar_webhook(cfg, {"evento": "incidente", **inc})))
        for pessoa in self.destinatarios(nivel, empresa_id):
            if pessoa["whatsapp"] and pessoa["telefone"] and cfg["whatsapp"]["modo"] != "desligado":
                tarefas.append(("whatsapp", pessoa["telefone"],
                                lambda p=pessoa: enviar_whatsapp(cfg, p["telefone"], texto)))
            if pessoa["quer_email"] and pessoa["email"] and cfg["email"]["ativo"]:
                tarefas.append(("email", pessoa["email"], lambda p=pessoa: enviar_email(cfg, p["email"], assunto, texto)))

        for canal, destino, funcao in tarefas:
            try:
                funcao()
                resultados.append((canal, destino, True, ""))
                _registrar_envio(inc["id"], canal, destino, nivel, True, empresa_id=empresa_id)
            except Exception as e:
                resultados.append((canal, destino, False, str(e)))
                _registrar_envio(inc["id"], canal, destino, nivel, False, e, empresa_id=empresa_id)
                incidentes.registrar_evento(inc["equip_id"], inc["equipamento"], "Falha no alerta", "erro",
                                            f"{canal} para {destino}: {e}", fonte="alertas", empresa_id=empresa_id)
        return resultados

    # ---------------------------------------------------------------- ganchos
    def ao_abrir(self, inc):
        if inc.get("empresa_id") is None:
            return
        cfg = ler_config(inc["empresa_id"])
        minutos = int(cfg["geral"]["escalonar_minutos"])
        if minutos > 0:
            banco.executar("UPDATE incidentes SET nivel_escalonamento = 1, proximo_escalonamento = ? WHERE id = ?",
                           (time.time() + minutos * 60, inc["id"]))
        threading.Thread(target=self.notificar, args=(inc, 1), name="alerta", daemon=True).start()

    def escalonar(self, agora=None):
        """Incidentes ainda não reconhecidos sobem de nível (até o 3)."""
        agora = agora or time.time()
        pendentes = banco.consultar("SELECT * FROM incidentes WHERE estado = 'aberto' AND proximo_escalonamento IS NOT NULL "
                                    "AND proximo_escalonamento <= ? AND empresa_id IS NOT NULL", (agora,))
        for inc in pendentes:
            minutos = int(ler_config(inc["empresa_id"])["geral"]["escalonar_minutos"])
            nivel = inc["nivel_escalonamento"] + 1
            proximo = agora + minutos * 60 if nivel < 3 else None
            banco.executar("UPDATE incidentes SET nivel_escalonamento = ?, proximo_escalonamento = ? WHERE id = ?",
                           (nivel, proximo, inc["id"]))
            incidentes.registrar_evento(inc["equip_id"], inc["equipamento"], "Escalonamento", "aviso",
                                        f"Incidente #{inc['id']} não reconhecido: avisando o nível {nivel}", fonte="alertas",
                                        empresa_id=inc["empresa_id"])
            self.notificar(inc, nivel)
        return len(pendentes)

    def laco(self):
        while True:
            time.sleep(30)
            try:
                self.escalonar()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"Escalonamento: {e}", fonte="sistema")

    def iniciar(self):
        incidentes.AO_ABRIR.append(self.ao_abrir)
        threading.Thread(target=self.laco, name="escalonamento", daemon=True).start()

    # ---------------------------------------------------------------- teste pela tela
    def testar(self, empresa_id, canal, destino=""):
        cfg = ler_config(empresa_id)
        texto = f"✅ Teste de alerta do Sentinela de Rede ({cfg['geral']['nome_empresa']}). Se você recebeu, está funcionando."
        if canal == "whatsapp":
            enviar_whatsapp(cfg, destino, texto)
        elif canal == "email":
            enviar_email(cfg, destino, "[Sentinela] Teste de alerta", texto)
        elif canal == "telegram":
            enviar_telegram(cfg, texto)
        elif canal == "webhook":
            enviar_webhook(cfg, {"evento": "teste", "mensagem": texto})
        else:
            raise ErroAlerta("Canal desconhecido")


NOTIFICADOR = Notificador()
