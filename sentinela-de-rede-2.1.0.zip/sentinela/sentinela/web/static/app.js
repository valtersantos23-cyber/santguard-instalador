"use strict";
/* Sentinela de Rede - interface web.
   Sem scripts embutidos no HTML: todas as ações usam data-acao (ver ACOES) e os
   formulários usam data-form (ver FORMULARIOS). Isso permite uma política CSP rígida. */

// ======================================================================= utilidades
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const vazio = (t, botao) => `<div class="vazio">${t}${botao || ""}</div>`;
const tamanho = n => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(1) + " KB" : (n / 1048576).toFixed(1) + " MB";
const bps = n => n == null ? "—" : n >= 1e9 ? (n / 1e9).toFixed(2) + " Gbps" : n >= 1e6 ? (n / 1e6).toFixed(1) + " Mbps" : n >= 1e3 ? (n / 1e3).toFixed(0) + " kbps" : n + " bps";
const duracao = s => { if (s == null) return "—"; const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return d ? `${d}d ${h}h` : h ? `${h}h ${m}min` : `${m}min`; };
const ha = s => s < 60 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}min` : `${Math.floor(s / 3600)}h${String(Math.floor(s % 3600 / 60)).padStart(2, "0")}`;
const linkArquivo = (caminho, texto) => `<a class="link" data-acao="abrir-arquivo" data-caminho="${esc(caminho)}">${esc(texto)}</a>`;
const selo = (classe, texto) => `<span class="selo ${esc(classe)}">${esc(texto)}</span>`;
const ICONES = { "Força bruta": "🔐", "DDoS/flood": "🌊", "DDoS volumétrico": "🌊", "Tráfego suspeito": "🕵️",
  "Configuração alterada": "⚙️", "Falha de login": "🔑", "Sem resposta": "📵", "Falha de login no painel": "🚪",
  "Sessão BGP": "🔀", "RPKI inválido": "🛑", "Evidências capturadas": "📁", "Mitigação": "🛡️" };
const icone = t => ICONES[t] || "⚠️";

const E = {   // estado da interface
  sessao: null, aba: null, dados: {}, ultimaCarga: {}, estadoGeral: null,
  ultimoSeq: null, ataquesConhecidos: null, som: false, ajudaSyslog: false, vistos: null,
};
try { E.som = localStorage.getItem("som") === "1"; } catch (e) { /* armazenamento indisponível */ }

const pode = p => !!E.sessao && E.sessao.permissoes.includes(p);
const licencaOk = () => !E.sessao || !E.sessao.licenca || E.sessao.licenca.valida;

function toast(texto, falha) {
  const el = $("#toast");
  el.textContent = texto;
  el.classList.toggle("falha", !!falha);
  el.classList.add("ver");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => el.classList.remove("ver"), 4000);
}

// ======================================================================= comunicação
class ErroApi extends Error {}

async function api(url, dados) {
  const opcoes = { credentials: "same-origin", headers: {} };
  if (dados !== undefined) {
    opcoes.method = "POST";
    opcoes.headers["Content-Type"] = "application/json";
    opcoes.headers["X-Sentinela"] = "1";
    if (E.sessao && E.sessao.csrf) opcoes.headers["X-CSRF-Token"] = E.sessao.csrf;
    opcoes.body = JSON.stringify(dados);
  }
  const r = await fetch(url, opcoes);
  if (r.status === 401 && E.sessao && url !== "/api/login" && url !== "/api/login/2fa") {
    E.sessao = null;
    await iniciar();
    throw new ErroApi("Sessão encerrada");
  }
  if (r.status === 402 && E.sessao && licencaOk()) {  // a licença venceu com o painel aberto
    E.sessao = null;
    await iniciar();
    throw new ErroApi("Licença inválida");
  }
  const tipo = r.headers.get("Content-Type") || "";
  const corpo = tipo.includes("json") ? await r.json() : await r.text();
  if (!r.ok && typeof corpo === "object") corpo.ok = false;
  return corpo;
}

async function acaoSimples(url, dados) {
  try {
    const j = await api(url, dados || {});
    toast(j.mensagem, !j.ok);
    return j;
  } catch (e) {
    if (!(e instanceof ErroApi)) toast("Sem conexão com o servidor", true);
    return { ok: false };
  }
}

// ======================================================================= telas de acesso
function telaAcesso(html) {
  $("#app").hidden = true;
  $("#acesso").hidden = false;
  $("#acesso-conteudo").innerHTML = html;
  const primeiro = $("#acesso-conteudo input");
  if (primeiro) primeiro.focus();
}

function msgAcesso(texto, tipo) {
  const el = $("#acesso-conteudo .msg");
  if (el) { el.textContent = texto || ""; el.className = "msg " + (tipo === "ok" ? "txt-ok" : "txt-alerta"); }
}

async function iniciar() {
  let s;
  try { s = await api("/api/sessao"); } catch (e) {
    telaAcesso('<p class="txt-alerta">Não consegui falar com o servidor. Ele está rodando?</p>');
    return;
  }
  $("#versao").textContent = "versão " + s.versao;
  let reg = null;
  try { reg = await api("/api/registro"); } catch (e) { /* segue para o login */ }
  if (reg && reg.valida === false) return telaRegistro(reg);
  if (!s.configurado) {
    if (!s.local) {
      telaAcesso(`<h2>Primeiro acesso</h2><p class="aviso">Por segurança, o primeiro administrador só pode ser criado
        <b>no próprio servidor</b>: abra <code>https://localhost:porta</code> nele, ou rode:</p>
        <pre class="segredo">python -m sentinela criar-admin</pre><p class="aviso">Depois, atualize esta página.</p>`);
      return;
    }
    telaAcesso(`<h2>Primeiro acesso</h2><div class="sub">Crie o usuário administrador.</div>
      <form data-form="configurar-admin">
        <label>Usuário</label><input name="usuario" autocomplete="username" required>
        <label>Nome completo</label><input name="nome">
        <label>Senha</label><input name="senha" type="password" autocomplete="new-password" required>
        <label>Repita a senha</label><input name="senha2" type="password" autocomplete="new-password" required>
        <div class="aviso">Mínimo de 10 caracteres, com pelo menos 3 destes: minúsculas, maiúsculas, números e símbolos.</div>
        <button class="primario" type="submit">Criar administrador</button><div class="msg"></div>
      </form>`);
    return;
  }
  if (!s.logado) {
    if (s.precisa_2fa) return telaCodigo2fa();
    telaAcesso(`<form data-form="login">
        <label>Usuário</label><input name="usuario" autocomplete="username" required>
        <label>Senha</label><input name="senha" type="password" autocomplete="current-password" required>
        <button class="primario" type="submit">Entrar</button><div class="msg"></div>
      </form>`);
    return;
  }
  E.sessao = s;
  if (s.trocar_senha) {
    telaAcesso(`<h2>Defina uma nova senha</h2><div class="sub">Por segurança, troque a senha provisória antes de continuar.</div>
      <form data-form="trocar-senha-obrigatoria">
        <label>Senha atual (provisória)</label><input name="atual" type="password" autocomplete="current-password" required>
        <label>Nova senha</label><input name="nova" type="password" autocomplete="new-password" required>
        <label>Repita a nova senha</label><input name="nova2" type="password" autocomplete="new-password" required>
        <button class="primario" type="submit">Salvar e continuar</button><div class="msg"></div>
      </form>`);
    return;
  }
  if (s.configurar_2fa) {
    const j = await api("/api/minha-conta/2fa/iniciar", {});
    telaAcesso(`<h2>Ative a verificação em duas etapas</h2>
      <div class="sub">Nesta instalação o 2FA é obrigatório para administradores.</div>${blocoQr(j)}
      <form data-form="confirmar-2fa-obrigatorio">
        <label>Código de 6 dígitos do aplicativo</label><input name="codigo" class="codigo-2fa" inputmode="numeric" maxlength="6" required>
        <button class="primario" type="submit">Ativar e continuar</button><div class="msg"></div>
      </form>`);
    return;
  }
  if (!s.fornecedor && s.licenca && !s.licenca.valida) {
    telaAcesso(`<h2>🔑 Sistema bloqueado</h2><p class="txt-alerta">${esc(s.licenca.texto)}.</p>
      <p class="aviso">O monitoramento está parado até a licença ser renovada. Avise o administrador do sistema.
      Os seus dados continuam guardados.</p>
      <button data-acao="recarregar-licenca" class="primario">Tentar novamente</button> <button data-acao="sair">Sair</button>`);
    return;
  }
  iniciarApp();
}

function telaRegistro(r) {
  telaAcesso(`<h2>🔑 Registro do Sentinela de Rede</h2>
    ${r.situacao !== "sem_licenca" ? `<p class="txt-alerta">${esc(r.texto)}.</p>` : ""}
    <p class="aviso"><b>1.</b> Envie este <b>serial</b> ao fornecedor do sistema:</p>
    <div class="segredo serial">${esc(r.serial)}</div>
    <button type="button" data-acao="copiar" data-texto="${esc(r.serial)}">📋 Copiar serial</button>
    <form data-form="registro" style="margin-top:18px">
      <label><b>2.</b> Cole a chave de liberação que o fornecedor enviar:</label>
      <textarea name="codigo" rows="5" class="mono" placeholder="JQAQN-6TGZ6-E3BDT-..." required></textarea>
      <button class="primario" type="submit">✔ Registrar</button><div class="msg"></div>
    </form>
    <p class="sub">ID do servidor: <span class="mono">${esc(r.maquina)}</span> · O serial não muda até ser usado.</p>`);
}

function telaCodigo2fa() {
  telaAcesso(`<h2>Verificação em duas etapas</h2><div class="sub">Digite o código do seu aplicativo autenticador.</div>
    <form data-form="login-2fa">
      <input name="codigo" class="codigo-2fa" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required>
      <button class="primario" type="submit">Confirmar</button><div class="msg"></div>
    </form>
    <p class="aviso">Perdeu o celular? Peça a um administrador para remover o 2FA da sua conta.</p>`);
}

function blocoQr(j) {
  return `<p class="aviso">1. Instale um app autenticador (Google Authenticator, Microsoft Authenticator, Authy...).<br>
    2. Leia o QR code ${j.qr_svg ? "" : "(indisponível: digite a chave abaixo no app)"} ou digite a chave.<br>3. Informe o código gerado.</p>
    ${j.qr_svg ? `<div class="qr">${j.qr_svg}</div>` : ""}
    <div class="sub">Chave:</div><div class="segredo">${esc(j.segredo || "")}</div>`;
}

// ======================================================================= aplicação
const TELAS = {
  empresas: { titulo: "🏢 Empresas", perm: "fornecedor", fonte: "/api/fornecedor/empresas", cabecalho: cabEmpresas,
    corpo: telaEmpresas, intervalo: 15000, global: true },
  licenca: { titulo: "🔑 Licença", perm: "fornecedor", fonte: "/api/fornecedor/licenca", corpo: telaLicenca,
    intervalo: 60000, global: true },
  aovivo: { titulo: "🔴 Ao vivo", perm: "ver", fonte: "/api/aovivo", intervalo: 2000, corpo: telaAoVivo, badge: "qtd-ataque" },
  painel: { titulo: "Painel", perm: "ver", fonte: "/api/equipamentos", cabecalho: cabFiltroEquip, corpo: telaPainel },
  ddos: { titulo: "🌊 DDoS", perm: "ver", fonte: "/api/ddos", intervalo: 3000, corpo: telaDdos },
  bgp: { titulo: "🔀 BGP", perm: "ver", fonte: "/api/bgp", corpo: telaBgp, intervalo: 10000 },
  olts: { titulo: "📡 OLTs", perm: "ver", fonte: "/api/olts", corpo: telaOlts, intervalo: 15000 },
  mitigacao: { titulo: "🛡 Mitigação", perm: "ver", fonte: "/api/mitigacoes", cabecalho: cabMitigacao, corpo: telaMitigacao,
    intervalo: 4000, badge: "qtd-mit" },
  incidentes: { titulo: "Incidentes", perm: "ver", fonte: () => `/api/incidentes?estado=${encodeURIComponent($("#filtro-incidentes")?.value ?? "abertos")}`,
    cabecalho: cabIncidentes, corpo: telaIncidentes, badge: "qtd-inc" },
  equipamentos: { titulo: "⚙️ Equipamentos", perm: "ver", fonte: "/api/equipamentos", cabecalho: cabEquipamentos, corpo: telaEquipamentos },
  backups: { titulo: "Backups", perm: "operar", fonte: "/api/backups", corpo: telaBackups, intervalo: 15000 },
  auditoria: { titulo: "Auditoria de segurança", perm: "ver", fonte: "/api/estado", corpo: telaAuditoria },
  manutencoes: { titulo: "🛠 Manutenções", perm: "ver", fonte: "/api/manutencoes", cabecalho: cabManutencoes,
    corpo: telaManutencoes, intervalo: 20000 },
  relatorios: { titulo: "📄 Relatórios", perm: "ver", cabecalho: cabRelatorios },
  alertas: { titulo: "🔔 Alertas", perm: "administrar", cabecalho: () => '<div class="sub">Carregando...</div>', montar: montarAlertas },
  usuarios: { titulo: "👥 Usuários", perm: "administrar", fonte: "/api/usuarios", cabecalho: cabUsuarios, corpo: telaUsuarios, intervalo: 15000 },
  minha_empresa: { titulo: "🏢 Minha empresa", perm: "administrar", fonte: "/api/empresa", corpo: telaMinhaEmpresa, intervalo: 60000 },
  atividades: { titulo: "Registro de atividades", perm: "administrar",
    fonte: () => "/api/auditoria?busca=" + encodeURIComponent($("#busca-atividades")?.value || ""),
    cabecalho: cabAtividades, corpo: telaAtividades, intervalo: 15000 },
  conta: { titulo: "Minha conta", perm: "ver", oculta: true, cabecalho: cabConta },
};

function iniciarApp() {
  $("#acesso").hidden = true;
  $("#app").hidden = false;
  $("#nome-usuario").textContent = E.sessao.nome || E.sessao.usuario;
  $("#papel-usuario").textContent = `${E.sessao.usuario} · ${E.sessao.papel_nome}`;
  $$("[data-perm]").forEach(el => { el.hidden = !pode(el.dataset.perm); });
  montarSeletorEmpresa();
  $("#abas").innerHTML = Object.entries(TELAS).filter(([, t]) => !t.oculta && pode(t.perm))
    .map(([id, t]) => `<button data-acao="ir" data-aba="${id}">${t.titulo}${t.badge ? ` <span id="${t.badge}"></span>` : ""}</button>`).join("");
  irPara(E.aba && TELAS[E.aba] ? E.aba : (E.sessao.fornecedor && !E.sessao.empresa ? "empresas" : "aovivo"));
  if (!iniciarApp.ligado) {
    iniciarApp.ligado = true;
    setInterval(ciclo, 1000);
  }
  atualizarGeral();
}

function montarSeletorEmpresa() {
  const s = E.sessao, sel = $("#seletor-empresa"), aviso = $("#aviso-licenca");
  sel.hidden = !s.fornecedor;
  if (s.fornecedor) {
    sel.innerHTML = (s.empresa ? "" : '<option value="">— escolha uma empresa —</option>') +
      (s.empresas || []).map(e => `<option value="${e.id}"${s.empresa && e.id === s.empresa.id ? " selected" : ""}>🏢 ${esc(e.nome)}${e.situacao !== "ok" ? " (" + esc(e.situacao) + ")" : ""}</option>`).join("");
  }
  const textos = [];
  if (s.licenca && !s.licenca.valida) textos.push(`🔑 ${esc(s.licenca.texto)}. O monitoramento está parado até a ativação.`);
  else if (s.licenca && s.licenca.aviso) textos.push(`🔑 ${esc(s.licenca.aviso)}. Renove na aba Licença.`);
  if (s.fornecedor && s.empresa) textos.push(`Modo suporte: você está operando <b>${esc(s.empresa.nome)}</b>. Tudo o que fizer fica registrado na auditoria dela.`);
  if (s.empresa && s.empresa.aviso) textos.push("⚠ " + esc(s.empresa.aviso));
  aviso.innerHTML = textos.join(" · ");
  aviso.hidden = !textos.length;
  aviso.classList.toggle("perigo", !!(s.empresa && s.empresa.situacao !== "ok") || !licencaOk());
  $("#papel-usuario").textContent = `${s.usuario} · ${s.papel_nome}${s.empresa && !s.fornecedor ? " · " + s.empresa.nome : ""}`;
}

async function trocarEmpresa(id) {
  if (!id) return;
  const j = await acaoSimples(`/api/fornecedor/entrar/${id}`);
  if (!j.ok) return;
  E.sessao = await api("/api/sessao");
  E.dados = {}; E.ultimaCarga = {}; E.ultimoSeq = null; E.ataquesConhecidos = null;
  iniciarApp();
}

function irPara(aba) {
  if (!TELAS[aba] || !pode(TELAS[aba].perm)) aba = "aovivo";
  if (E.sessao.fornecedor && !E.sessao.empresa && !TELAS[aba].global && aba !== "conta") aba = "empresas";
  if (!licencaOk() && aba !== "conta") aba = "licenca";
  E.aba = aba;
  $$("#abas button").forEach(b => b.classList.toggle("ativa", b.dataset.aba === aba));
  $("#menu-usuario").hidden = true;
  const tela = TELAS[aba];
  $("#cabecalho-tela").innerHTML = tela.cabecalho ? tela.cabecalho() : "";
  $("#conteudo").innerHTML = E.dados[aba] && tela.corpo ? tela.corpo(E.dados[aba]) : (tela.corpo ? '<div class="sub">Carregando...</div>' : "");
  if (aba === "incidentes") E.vistos = null;
  if (tela.montar) tela.montar();
  carregar(aba);
}

async function carregar(aba) {
  const tela = TELAS[aba];
  if (!tela.fonte) return;
  E.ultimaCarga[aba] = Date.now();
  try {
    const url = typeof tela.fonte === "function" ? tela.fonte() : tela.fonte;
    const dados = await api(url);
    E.dados[aba] = dados;
    if (E.aba === aba && tela.corpo) $("#conteudo").innerHTML = tela.corpo(dados);
    if (aba === "aovivo") posAoVivo(dados);
  } catch (e) { /* tratado em api() */ }
}

async function atualizarGeral() {
  if (!licencaOk()) { $("#status-linha").innerHTML = '<span class="txt-alerta">🔑 Sistema não ativado: monitoramento parado</span>'; return; }
  if (!E.sessao.empresa) { $("#status-linha").textContent = "Painel do fornecedor"; return; }
  try {
    const d = await api("/api/estado");
    E.estadoGeral = d;
    let linha = d.monitorando ? `🟢 Monitorando a cada ${d.config.intervalo} min` : "⏸ Monitoramento pausado";
    if (d.ultimo_ciclo) linha += ` · Última verificação: ${d.ultimo_ciclo}`;
    if (d.proximo_ciclo) linha += ` · Próxima: ${d.proximo_ciclo}`;
    $("#status-linha").innerHTML = esc(linha) + (d.ocupado ? ` · <span class="ocupado">⏳ ${esc(d.ocupado)}</span>` : "");
    $("#btn-monitor").textContent = d.monitorando ? "⏸ Pausar" : "▶ Retomar";
  } catch (e) {
    $("#status-linha").innerHTML = '<span class="txt-alerta">⚠ Sem conexão com o servidor</span>';
  }
}

let contadorCiclo = 0;
function ciclo() {
  if (!E.sessao || $("#app").hidden) return;
  contadorCiclo++;
  const tela = TELAS[E.aba];
  if (tela.fonte && Date.now() - (E.ultimaCarga[E.aba] || 0) >= (tela.intervalo || 5000)) carregar(E.aba);
  if (!E.sessao.empresa || !licencaOk()) return;
  if (E.aba !== "aovivo" && Date.now() - (E.ultimaCarga.aovivo || 0) >= 10000) carregar("aovivo");
  if (contadorCiclo % 5 === 0) atualizarGeral();
}

// ======================================================================= ações (cliques)
const ACOES = {
  ir: el => irPara(el.dataset.aba),
  "menu-usuario": () => { $("#menu-usuario").hidden = !$("#menu-usuario").hidden; },
  sair: async () => { await api("/api/logout", {}).catch(() => {}); E.sessao = null; E.dados = {}; iniciar(); },
  verificar: () => acaoSimples("/api/verificar").then(() => setTimeout(atualizarGeral, 500)),
  backup: () => acaoSimples("/api/backup").then(() => setTimeout(atualizarGeral, 500)),
  "alternar-monitor": () => acaoSimples(E.estadoGeral?.monitorando ? "/api/pausar" : "/api/retomar").then(atualizarGeral),
  "fechar-modal": fecharModal,
  copiar: async el => {
    try { await navigator.clipboard.writeText(el.dataset.texto || ""); toast("Copiado"); }
    catch (e) { toast("Selecione o texto e copie com Ctrl+C", true); }
  },
  "recarregar-licenca": () => { E.sessao = null; iniciar(); },
  "abrir-arquivo": el => abrirArquivo(el.dataset.caminho),
  som: () => {
    E.som = !E.som;
    try { localStorage.setItem("som", E.som ? "1" : "0"); } catch (e) { /* ignorado */ }
    if (E.som) bip();
    redesenhar();
  },
  "tela-cheia": () => { if (!document.fullscreenElement) document.documentElement.requestFullscreen?.(); else document.exitFullscreen?.(); },
  "ajuda-syslog": () => { E.ajudaSyslog = !E.ajudaSyslog; redesenhar(); },
  "ajuda-fluxo": () => { E.ajudaFluxo = !E.ajudaFluxo; redesenhar(); },
  recarregar: () => carregar(E.aba),

  // incidentes
  reconhecer: el => acaoSimples(`/api/incidentes/${el.dataset.id}/reconhecer`).then(() => carregar(E.aba)),
  resolver: el => acaoSimples(`/api/incidentes/${el.dataset.id}/resolver`).then(() => carregar(E.aba)),
  "ver-incidente": el => verIncidente(el.dataset.id),

  // equipamentos
  "novo-equip": () => formEquipamento(null),
  "editar-equip": el => formEquipamento(el.dataset.id),
  "remover-equip": async el => {
    const e = buscarEquip(el.dataset.id);
    if (!e || !confirm(`Remover ${e.nome} (${e.host}) do monitoramento?\n\nOs backups e incidentes dele continuam guardados.`)) return;
    await acaoSimples(`/api/equipamentos/${e.id}/remover`);
    fecharModal(); carregar(E.aba);
  },
  "testar-equip": async () => {
    const form = $("#modal-corpo form");
    const msg = $(".msg", form);
    msg.className = "msg ocupado"; msg.textContent = "Conectando no equipamento... (até 20 segundos)";
    const botao = $("[data-acao=testar-equip]", form); botao.disabled = true;
    try {
      const j = await api("/api/equipamentos/testar", lerForm(form));
      msg.className = "msg " + (j.ok ? "txt-ok" : "txt-alerta"); msg.textContent = j.mensagem;
      if (j.ok && j.hostname && !form.nome.value) form.nome.value = j.hostname;
    } catch (e) { msg.textContent = "Sem conexão com o servidor"; }
    botao.disabled = false;
  },
  "testar-snmp": async () => {
    const form = $("#modal-corpo form");
    const msg = $(".msg", form);
    msg.className = "msg ocupado"; msg.textContent = "Consultando SNMP...";
    try {
      const j = await api("/api/equipamentos/testar-snmp", lerForm(form));
      msg.className = "msg " + (j.ok ? "txt-ok" : "txt-alerta"); msg.textContent = j.mensagem;
    } catch (e) { msg.textContent = "Sem conexão com o servidor"; }
  },
  interfaces: el => verInterfaces(el.dataset.id),
  sites: () => formSites(),
  "nova-mitigacao": () => formMitigacao(),
  "config-mitigacao": () => formConfigMitigacao(),
  "aprovar-mitigacao": async el => {
    const m = E.dados.mitigacao.mitigacoes.find(x => String(x.id) === el.dataset.id);
    if (!confirm(`Aplicar ${m.tipo_nome} de ${m.alvo} em:\n${m.equipamentos.join("\n")}\n\nOs comandos serão enviados agora.`)) return;
    await acaoSimples(`/api/mitigacoes/${m.id}/aprovar`); setTimeout(() => carregar("mitigacao"), 1500);
  },
  "rejeitar-mitigacao": el => acaoSimples(`/api/mitigacoes/${el.dataset.id}/rejeitar`).then(() => carregar("mitigacao")),
  "remover-mitigacao": async el => {
    if (confirm("Remover esta mitigação dos roteadores agora?")) {
      await acaoSimples(`/api/mitigacoes/${el.dataset.id}/remover`); setTimeout(() => carregar("mitigacao"), 1500);
    }
  },
  "log-mitigacao": el => {
    const m = E.dados.mitigacao.mitigacoes.find(x => String(x.id) === el.dataset.id);
    abrirModal(`Log da mitigação #${m.id}`, `<pre class="arquivo">${esc(m.log)}</pre>`, true);
  },
  "verificar-rpki": () => acaoSimples("/api/bgp/rpki").then(() => setTimeout(() => carregar("bgp"), 3000)),
  "ver-onus": el => verOnus(el),
  "remover-manutencao": async el => {
    if (confirm("Cancelar esta manutenção? Os alertas voltam a ser enviados.")) {
      await acaoSimples(`/api/manutencoes/${el.dataset.id}/remover`); carregar("manutencoes");
    }
  },
  "baixar-relatorio": () => {
    const mes = $("#mes-relatorio").value;
    // abre numa nova aba (o navegador mostra o PDF e permite salvar)
    window.open(`/api/relatorios/pdf?mes=${encodeURIComponent(mes)}`, "_blank", "noopener");
    toast("Gerando o relatório em uma nova aba...");
  },
  "testar-alerta": async el => {
    const canal = el.dataset.canal;
    const destino = canal === "whatsapp" ? $("#teste-whatsapp").value : canal === "email" ? $("#teste-email").value : "";
    if ((canal === "whatsapp" || canal === "email") && !destino) return toast("Informe o destino do teste", true);
    el.disabled = true;
    await acaoSimples("/api/config/alertas/testar", { canal, destino });
    el.disabled = false;
  },
  "editar-site": el => {
    const s = (E.dados.equipamentos || E.dados.painel)?.sites.find(x => String(x.id) === el.dataset.id);
    const f = $("#form-site"); f.id_site.value = s.id; f.nome.value = s.nome; f.descricao.value = s.descricao; f.nome.focus();
  },
  "remover-site": async el => {
    if (!confirm("Remover este site? Os equipamentos dele ficam sem site.")) return;
    await acaoSimples(`/api/sites/${el.dataset.id}/remover`);
    await carregar("equipamentos"); formSites();
  },

  // fornecedor: empresas
  "nova-empresa": () => formEmpresa(null),
  "editar-empresa": el => formEmpresa(Number(el.dataset.id)),
  "entrar-empresa": el => trocarEmpresa(el.dataset.id),
  "remover-empresa": el => {
    const e = buscarEmpresa(Number(el.dataset.id));
    abrirModal(`Remover ${e.nome}`, `<form class="form" data-form="remover-empresa"><input type="hidden" name="id" value="${e.id}">
      <p class="aviso txt-alerta">Isto apaga <b>TODOS</b> os dados da empresa: ${e.equipamentos} equipamento(s), ${e.usuarios} usuário(s),
      incidentes, backups, mitigações e o histórico. Não tem como desfazer.<br><br>Se quiser só bloquear o acesso, use <b>Suspender</b>.</p>
      <label>Digite o nome da empresa para confirmar: <b>${esc(e.nome)}</b></label><input name="confirmar" autocomplete="off" required>
      <div class="form-botoes"><button class="perigo" type="submit">🗑 Remover definitivamente</button><span class="msg"></span></div></form>`);
  },
  "suspender-empresa": async el => {
    const e = buscarEmpresa(Number(el.dataset.id));
    const suspender = e.ativo;
    if (suspender && !confirm(`Suspender ${e.nome}?\n\nOs usuários dela perdem o acesso na hora e o monitoramento dos equipamentos para. Os dados ficam guardados.`)) return;
    await acaoSimples(`/api/fornecedor/empresas/${e.id}`, { ativo: !suspender });
    carregar("empresas"); E.sessao = await api("/api/sessao"); montarSeletorEmpresa();
  },
  "novo-usuario-fornecedor": () => abrirModal("Novo usuário do fornecedor", `
    <form class="form" data-form="usuario-fornecedor" autocomplete="off">
      <p class="aviso">Usuários do fornecedor administram <b>todas</b> as empresas. Para a equipe de um provedor, crie o usuário dentro da empresa dele.</p>
      <div class="campos"><div><label>Usuário *</label><input name="usuario" required></div>
      <div><label>Nome completo</label><input name="nome"></div>
      <div><label>E-mail</label><input name="email" type="email"></div>
      <div><label>Senha provisória *</label><input name="senha" type="password" autocomplete="new-password" required></div></div>
      <div class="form-botoes"><button class="primario" type="submit">💾 Criar</button><span class="msg"></span></div></form>`),
  "remover-usuario-fornecedor": async el => {
    if (confirm("Remover este usuário do fornecedor?")) {
      await acaoSimples(`/api/fornecedor/usuarios/${el.dataset.id}/remover`); carregar("empresas"); montarEquipeFornecedor();
    }
  },
  "auditoria-fornecedor": () => montarAuditoriaFornecedor(),

  // usuários
  "novo-usuario": () => formUsuario(null),
  "editar-usuario": el => formUsuario(el.dataset.id),
  "senha-usuario": el => formSenhaUsuario(el.dataset.id),
  "remover-2fa-usuario": async el => {
    const u = buscarUsuario(el.dataset.id);
    if (confirm(`Remover o 2FA de ${u.usuario}? Use quando a pessoa perdeu o celular.`)) {
      await acaoSimples(`/api/usuarios/${u.id}/2fa/remover`); carregar("usuarios");
    }
  },
  "remover-usuario": async el => {
    const u = buscarUsuario(el.dataset.id);
    if (confirm(`Remover o usuário ${u.usuario}? Prefira desativar se quiser manter o histórico.`)) {
      await acaoSimples(`/api/usuarios/${u.id}/remover`); carregar("usuarios");
    }
  },

  // minha conta
  "conta-2fa-iniciar": async () => {
    const j = await api("/api/minha-conta/2fa/iniciar", {});
    if (!j.ok) return toast(j.mensagem, true);
    abrirModal("Ativar verificação em duas etapas", `${blocoQr(j)}
      <form class="form" data-form="conta-2fa-confirmar">
        <label>Código de 6 dígitos</label><input name="codigo" class="codigo-2fa" inputmode="numeric" maxlength="6" required>
        <div class="form-botoes"><button class="primario" type="submit">Ativar</button><span class="msg"></span></div>
      </form>`);
  },
  "conta-2fa-desativar": () => abrirModal("Desativar verificação em duas etapas", `
    <form class="form" data-form="conta-2fa-desativar">
      <p class="aviso">Sua conta ficará protegida só pela senha. Confirme com a sua senha:</p>
      <label>Senha</label><input name="senha" type="password" autocomplete="current-password" required>
      <div class="form-botoes"><button class="perigo" type="submit">Desativar 2FA</button><span class="msg"></span></div>
    </form>`),
};

document.addEventListener("click", e => {
  const el = e.target.closest("[data-acao]");
  if (el && ACOES[el.dataset.acao]) {
    e.preventDefault();
    ACOES[el.dataset.acao](el);
  } else if (!e.target.closest(".menu-usuario")) {
    const menu = $("#menu-usuario");
    if (menu) menu.hidden = true;
  }
});
$("#modal").addEventListener("click", e => { if (e.target.id === "modal") fecharModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") fecharModal(); });
document.addEventListener("input", e => {
  if (e.target.matches("[data-filtro]")) { if (E.dados[E.aba]) $("#conteudo").innerHTML = TELAS[E.aba].corpo(E.dados[E.aba]); }
});
document.addEventListener("change", e => {
  if (e.target.matches("[data-recarregar]")) carregar(E.aba);
  if (e.target.matches("[data-filtro]")) { if (E.dados[E.aba]) $("#conteudo").innerHTML = TELAS[E.aba].corpo(E.dados[E.aba]); }
  if (e.target.name === "snmp_versao") ajustarCamposSnmp(e.target.form);
  if (e.target.name === "whatsapp.modo") ajustarWhatsapp();
  if (e.target.id === "tipo-mit") preencherEquipMit();
  if (e.target.id === "seletor-empresa") trocarEmpresa(e.target.value);
  const linha = e.target.closest("[data-plantao]");
  if (linha) {
    api("/api/plantao", { usuario_id: linha.dataset.plantao, nivel: $("[data-campo=nivel]", linha).value,
      whatsapp: $("[data-campo=whatsapp]", linha).checked, email: $("[data-campo=email]", linha).checked })
      .then(j => toast(j.mensagem, !j.ok));
  }
});

function redesenhar() {
  const tela = TELAS[E.aba];
  if (tela.corpo && E.dados[E.aba]) $("#conteudo").innerHTML = tela.corpo(E.dados[E.aba]);
}

// ======================================================================= formulários (envio)
function lerForm(form) {
  const dados = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    dados[el.name] = el.type === "checkbox" ? el.checked : el.value;
  }
  return dados;
}

async function enviar(form, url, dados) {
  const msg = $(".msg", form);
  const botao = $("button[type=submit]", form);
  if (botao) botao.disabled = true;
  if (msg) { msg.className = "msg ocupado"; msg.textContent = "Enviando..."; }
  let j;
  try { j = await api(url, dados); } catch (e) { j = { ok: false, mensagem: "Sem conexão com o servidor" }; }
  if (botao) botao.disabled = false;
  if (msg) { msg.className = "msg " + (j.ok ? "txt-ok" : "txt-alerta"); msg.textContent = j.mensagem || ""; }
  return j;
}

const FORMULARIOS = {
  registro: async f => {
    const j = await enviar(f, "/api/registro/ativar", lerForm(f));
    if (j.ok) setTimeout(iniciar, 1200);
  },
  "configurar-admin": async f => {
    const d = lerForm(f);
    if (d.senha !== d.senha2) return msgAcesso("As senhas não conferem");
    const j = await enviar(f, "/api/configurar-admin", d);
    if (j.ok) setTimeout(iniciar, 800);
  },
  login: async f => {
    const j = await enviar(f, "/api/login", lerForm(f));
    if (j.ok) j.precisa_2fa ? telaCodigo2fa() : iniciar();
  },
  "login-2fa": async f => {
    const j = await enviar(f, "/api/login/2fa", lerForm(f));
    if (j.ok) iniciar(); else { f.codigo.value = ""; f.codigo.focus(); }
  },
  "trocar-senha-obrigatoria": async f => {
    const d = lerForm(f);
    if (d.nova !== d.nova2) return msgAcesso("As senhas não conferem");
    const j = await enviar(f, "/api/minha-conta/senha", d);
    if (j.ok) setTimeout(iniciar, 600);
  },
  "confirmar-2fa-obrigatorio": async f => {
    const j = await enviar(f, "/api/minha-conta/2fa/confirmar", lerForm(f));
    if (j.ok) setTimeout(iniciar, 600);
  },
  "trocar-senha": async f => {
    const d = lerForm(f);
    if (d.nova !== d.nova2) { $(".msg", f).textContent = "As senhas não conferem"; return; }
    const j = await enviar(f, "/api/minha-conta/senha", d);
    if (j.ok) { f.reset(); E.sessao = await api("/api/sessao"); }
  },
  "conta-2fa-confirmar": async f => {
    const j = await enviar(f, "/api/minha-conta/2fa/confirmar", lerForm(f));
    if (j.ok) { E.sessao = await api("/api/sessao"); fecharModal(); irPara("conta"); toast(j.mensagem); }
  },
  "conta-2fa-desativar": async f => {
    const j = await enviar(f, "/api/minha-conta/2fa/desativar", lerForm(f));
    if (j.ok) { E.sessao = await api("/api/sessao"); fecharModal(); irPara("conta"); toast(j.mensagem); }
  },
  equipamento: async f => {
    const d = lerForm(f);
    const url = d.id ? `/api/equipamentos/${d.id}` : "/api/equipamentos";
    const j = await enviar(f, url, d);
    if (j.ok) { fecharModal(); toast(j.mensagem); carregar(E.aba); }
  },
  site: async f => {
    const d = lerForm(f);
    const j = await enviar(f, "/api/sites", { id: d.id_site || null, nome: d.nome, descricao: d.descricao });
    if (j.ok) { await carregar("equipamentos"); formSites(); }
  },
  usuario: async f => {
    const d = lerForm(f);
    const url = d.id ? `/api/usuarios/${d.id}` : "/api/usuarios";
    const j = await enviar(f, url, d);
    if (j.ok) { fecharModal(); toast(j.mensagem); carregar("usuarios"); }
  },
  manutencao: async f => {
    const j = await enviar(f, "/api/manutencoes", lerForm(f));
    if (j.ok) { f.motivo.value = ""; carregar("manutencoes"); }
  },
  alertas: async f => {
    const dados = {};
    for (const el of f.elements) {
      if (!el.name || !el.name.includes(".")) continue;
      const [canal, chave] = el.name.split(".");
      dados[canal] = dados[canal] || {};
      dados[canal][chave] = el.type === "checkbox" ? el.checked : el.value;
    }
    const j = await enviar(f, "/api/config/alertas", dados);
    if (j.ok) setTimeout(montarAlertas, 600);
  },
  "mitigacao-manual": async f => {
    const d = lerForm(f);
    d.equip_ids = $$("input[name=equip]:checked", f).map(x => x.value);
    const j = await enviar(f, "/api/mitigacoes", d);
    if (j.ok) { fecharModal(); toast(j.mensagem); carregar("mitigacao"); }
  },
  "config-mitigacao": async f => {
    const d = lerForm(f);
    d.modelos = {};
    $$("[data-modelo]", f).forEach(el => {
      const [tipo, fab, fase] = el.dataset.modelo.split("|");
      d.modelos[tipo] = d.modelos[tipo] || {};
      d.modelos[tipo][fab] = d.modelos[tipo][fab] || {};
      d.modelos[tipo][fab][fase] = el.value.split("\n").filter(l => l.trim());
    });
    const j = await enviar(f, "/api/config/mitigacao", d);
    if (j.ok) { fecharModal(); toast(j.mensagem); carregar("mitigacao"); }
  },
  empresa: async f => {
    const d = lerForm(f);
    const dados = { nome: d.nome, documento: d.documento, contato: d.contato, email: d.email, telefone: d.telefone,
      plano: d.plano, limite_equipamentos: d.limite_equipamentos, validade: d.validade, asn: d.asn, redes: d.redes,
      prefixos: d.prefixos, observacoes: d.observacoes, ativo: d.ativo };
    if (!d.id && d.admin_usuario) dados.admin = { usuario: d.admin_usuario, senha: d.admin_senha, nome: d.admin_nome,
      email: d.admin_email, telefone: d.admin_telefone };
    const j = await enviar(f, d.id ? `/api/fornecedor/empresas/${d.id}` : "/api/fornecedor/empresas", dados);
    if (j.ok) { fecharModal(); toast(j.mensagem); carregar("empresas"); E.sessao = await api("/api/sessao"); montarSeletorEmpresa(); }
  },
  "remover-empresa": async f => {
    const d = lerForm(f);
    const j = await enviar(f, `/api/fornecedor/empresas/${d.id}/remover`, { confirmar: d.confirmar });
    if (j.ok) { fecharModal(); toast(j.mensagem); E.sessao = await api("/api/sessao"); E.dados = {}; iniciarApp(); }
  },
  "usuario-fornecedor": async f => {
    const j = await enviar(f, "/api/fornecedor/usuarios", lerForm(f));
    if (j.ok) { fecharModal(); toast(j.mensagem); montarEquipeFornecedor(); }
  },
  "rede-empresa": async f => {
    const d = lerForm(f);
    const j = await enviar(f, "/api/empresa/rede", { asn: d.asn, redes: d.redes, prefixos: d.prefixos });
    if (j.ok) carregar("minha_empresa");
  },
  "licenca-ativar": async f => {
    const j = await enviar(f, "/api/fornecedor/licenca/ativar", lerForm(f));
    if (!j.ok) return;
    toast(j.mensagem);
    E.sessao = await api("/api/sessao");
    E.dados = {}; E.ultimaCarga = {};
    iniciarApp();
  },
  "senha-usuario": async f => {
    const d = lerForm(f);
    const j = await enviar(f, `/api/usuarios/${d.id}/senha`, d);
    if (j.ok) { fecharModal(); toast(j.mensagem); }
  },
};

document.addEventListener("submit", e => {
  const form = e.target.closest("form[data-form]");
  if (!form || !FORMULARIOS[form.dataset.form]) return;
  e.preventDefault();
  FORMULARIOS[form.dataset.form](form);
});

// ======================================================================= modal
function abrirModal(titulo, html, larga) {
  $("#modal-titulo").textContent = titulo;
  $("#modal-corpo").innerHTML = html;
  $("#janela").classList.toggle("larga", !!larga);
  $("#modal").classList.add("aberto");
  const primeiro = $("#modal-corpo input:not([type=hidden]), #modal-corpo select");
  if (primeiro) primeiro.focus();
}
function fecharModal() { $("#modal").classList.remove("aberto"); }

async function abrirArquivo(caminho) {
  abrirModal(caminho, '<pre class="arquivo">Carregando...</pre>', true);
  const r = await fetch("/api/arquivo?caminho=" + encodeURIComponent(caminho), { credentials: "same-origin" });
  $("#modal-corpo pre").textContent = r.ok ? await r.text() : "Arquivo não encontrado ou sem permissão.";
}

// ======================================================================= tela: ao vivo
function posAoVivo(v) {
  const chaves = new Set([...v.maquinas.flatMap(m => m.ataques.map(a => m.id + "|" + a.tipo)),
                          ...v.alvos.flatMap(a => a.ataques.map(x => a.ip + "|" + x.tipo))]);
  if (E.ataquesConhecidos && [...chaves].some(k => !E.ataquesConhecidos.has(k))) bip();
  E.ataquesConhecidos = chaves;
  const n = v.maquinas.filter(m => m.estado === "ataque").length + v.alvos.length;
  const badge = $("#qtd-ataque");
  if (badge) badge.innerHTML = n ? `<span class="qtd">${n}</span>` : "";
  const inc = $("#qtd-inc");
  if (inc) inc.innerHTML = v.incidentes_abertos ? `<span class="qtd">${v.incidentes_abertos}</span>` : "";
  document.title = n ? `🚨 (${n}) Sob ataque · Sentinela` : "Sentinela de Rede";
  E.ultimoSeq = v.seq;
}

function bip() {
  if (!E.som) return;
  try {
    const ctx = bip.ctx || (bip.ctx = new (window.AudioContext || window.webkitAudioContext)());
    [0, 0.25].forEach(t => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = 880; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.15, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.2);
      o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.2);
    });
  } catch (e) { /* sem áudio */ }
}

function blocoAtaques(lista) {
  return lista.map(a => `<div class="bloco-ataque">
    <div class="nome">${icone(a.tipo)} ${esc(a.tipo)}</div>
    ${a.detalhe ? `<div>${esc(a.detalhe)}</div>` : ""}
    <div class="sub">Desde ${esc(a.inicio)} (há ${ha(a.duracao_seg)}) · último evento há ${ha(a.ha_seg)} · ${a.qtd} evento${a.qtd > 1 ? "s" : ""}</div>
    ${a.origens.length ? `<div class="origens">${a.origens.map(([ip, n]) => `<span class="ip">${esc(ip)} <small>${n}x</small></span>`).join("")}</div>` : ""}
  </div>`).join("");
}

function telaAoVivo(v) {
  if (!v.maquinas.length && !v.alvos.length) {
    return vazio("Nenhum equipamento cadastrado ainda.",
      pode("administrar") ? '<br><button class="primario" data-acao="ir" data-aba="equipamentos">➕ Cadastrar equipamento</button>' : "");
  }
  const atac = v.maquinas.filter(m => m.estado === "ataque");
  const total = atac.length + v.alvos.length;
  const controles = `<div class="controles">
    <button class="pequeno" data-acao="som">${E.som ? "🔔 Som ligado" : "🔕 Som desligado"}</button>
    <button class="pequeno" data-acao="tela-cheia">⛶ Tela cheia</button></div>`;
  const nomes = [...atac.map(m => m.nome), ...v.alvos.map(a => "cliente " + a.ip)];
  let h = total
    ? `<div class="banner perigo"><span class="pulso"></span><div class="texto">
         <b>${total} alvo${total > 1 ? "s" : ""} sob ataque agora</b><div class="sub">${nomes.map(esc).join(" · ")}</div></div>${controles}</div>`
    : `<div class="banner tranquilo"><span class="ponto-ok"></span><div class="texto"><b>Nenhum ataque em andamento</b>
         <div class="sub">${v.maquinas.length} equipamento(s) monitorado(s) · atualizado às ${esc(v.agora)}</div></div>${controles}</div>`;

  h += `<div class="chips">${v.maquinas.map(m => {
    const dica = m.estado === "ataque" ? m.ataques.map(a => a.tipo).join(", ") : m.erro || m.tipo_nome;
    return `<span class="chip ${esc(m.estado)}" title="${esc(dica)}"><i></i>${esc(m.nome)}</span>`;
  }).join("")}</div>`;

  if (v.alvos.length) {
    h += `<h3>Clientes sob DDoS</h3><div class="grade">${v.alvos.map(a => `<div class="card ataque pulsando">
      <div class="card-topo"><b class="mono">${esc(a.ip)}</b>${selo("ataque", "● Sob DDoS")}</div>${blocoAtaques(a.ataques)}</div>`).join("")}</div>`;
  }
  if (atac.length) {
    h += `<h3>Equipamentos sob ataque</h3><div class="grade">${atac.map(m => `<div class="card ataque pulsando">
      <div class="card-topo"><b>${esc(m.nome)}</b>${selo("ataque", "● Sob ataque")}</div>
      <div class="sub">${esc(m.apelido)} · ${esc(m.tipo_nome)}${m.site ? " · " + esc(m.site) : ""}${m.cpu != null ? ` · CPU ${m.cpu}%` : ""}</div>
      ${blocoAtaques(m.ataques)}
      ${m.incidente && pode("operar") ? `<div style="margin-top:10px">${linkArquivo(m.incidente + "/resumo.txt", "📁 Evidências capturadas")}</div>` : ""}
    </div>`).join("")}</div>`;
  }

  const max = Math.max(1, ...v.por_minuto);
  const feed = v.eventos.length ? v.eventos.map(ev => `<div class="ev ${esc(ev.gravidade)}${E.ultimoSeq !== null && ev.id > E.ultimoSeq ? " novo" : ""}">
      <span class="ev-hora">${esc(ev.hora)}</span><span class="ev-tipo">${icone(ev.tipo)} ${esc(ev.tipo)}</span>
      <span>${esc(ev.equipamento)}</span>${ev.origem ? `<span class="ip">${esc(ev.origem)}</span>` : ""}
      <div class="ev-msg">${esc(ev.mensagem)} <small>· via ${esc(ev.fonte)}</small></div></div>`).join("")
    : '<div class="sub" style="padding:14px">Nenhum evento ainda.</div>';

  h += `<div class="duas-colunas">
    <div><h3>Linha do tempo <span class="ao-vivo">● AO VIVO</span></h3><div class="feed">${feed}</div></div>
    <div>
      <h3>Eventos por minuto (30 min)</h3>
      <div class="barras">${v.por_minuto.map((n, i) => `<i class="${n ? "com" : ""}" style="height:${n ? Math.max(8, n / max * 100) : 3}%" title="${n} evento(s) há ${29 - i} min"></i>`).join("")}</div>
      <h3>IPs atacantes</h3>
      ${v.origens.length ? `<div class="tabela"><table><tr><th>IP de origem</th><th>Eventos</th></tr>${v.origens.map(([ip, n]) =>
        `<tr><td><span class="ip">${esc(ip)}</span></td><td>${n}</td></tr>`).join("")}</table></div>` : '<div class="sub">Nenhum IP atacante nos ataques ativos.</div>'}
      <h3>Logs em tempo real (syslog)</h3>${blocoSyslog(v)}
    </div></div>`;
  return h;
}

function blocoSyslog(v) {
  const s = v.syslog;
  let h = `<div class="card ${!s.ativo ? "erro" : s.recebidas ? "ok" : "neutro"}">`;
  if (!v.syslog_ligado) h += '<div class="sub">Recepção de syslog desligada na configuração.</div>';
  else if (!s.ativo) h += `<div class="txt-erro">${esc(s.erro || "Iniciando...")}</div>`;
  else if (!s.recebidas) h += `<div>Escutando em <b>${esc(v.ip_local)}</b>, porta UDP <b>${s.porta}</b>, mas nenhum log chegou ainda.</div>
      <div class="sub" style="margin-top:6px">Sem syslog, os ataques aparecem a cada verificação (${v.intervalo} min). Com syslog, na hora.</div>`;
  else h += `<div class="txt-ok">✓ Recebendo logs: ${s.recebidas} mensagem(ns), última às ${esc(s.ultima)}</div>
      ${s.ignoradas ? `<div class="sub" style="margin-top:6px">${s.ignoradas} ignorada(s) de IPs não cadastrados (último: ${esc(s.ultimo_ip_ignorado)})</div>` : ""}`;
  h += `<button class="pequeno" style="margin-top:10px" data-acao="ajuda-syslog">${E.ajudaSyslog ? "Ocultar instruções" : "📘 Como configurar os equipamentos"}</button>`;
  if (E.ajudaSyslog) {
    const ip = esc(v.ip_local), p = s.porta;
    h += `<div class="ajuda"><p>Envie os logs de cada equipamento para <b>${ip}</b>, porta UDP <b>${p}</b>:</p>
      <b>MikroTik</b><pre>/system logging action add name=sentinela target=remote remote=${ip} remote-port=${p}
/system logging add topics=system action=sentinela
/system logging add topics=critical action=sentinela
/system logging add topics=firewall action=sentinela</pre>
      <b>MikroTik: detectar varredura de portas (opcional)</b><pre>/ip firewall filter add chain=input protocol=tcp psd=21,3s,3,1 action=add-src-to-address-list address-list=scanners address-list-timeout=1d log=yes log-prefix="ATAQUE-SCAN"</pre>
      <b>Cisco</b><pre>logging host ${ip} transport udp port ${p}
logging trap informational
login on-failure log</pre>
      <b>Huawei</b><pre>info-center enable
info-center loghost ${ip}</pre>
      <b>ZTE (ZXR10)</b><pre>logging on
syslog-server host ${ip} fport ${p}</pre>
      <b>Juniper</b><pre>set system syslog host ${ip} any any
set system syslog host ${ip} port ${p}</pre>
      <p class="sub">Logs com "ATAQUE", "port scan" ou "flood" viram alerta na hora. No Windows, permita o Python no Firewall.</p></div>`;
  }
  return h + "</div>";
}

// ======================================================================= tela: DDoS
function telaDdos(d) {
  let h = "";
  if (!d.ativo) return vazio("A detecção por fluxo está desligada ([fluxo] ativo = false no config.toml).");
  if (!d.redes.length) h += `<div class="banner" style="border-color:var(--erro)"><div class="texto"><b>⚠ Cadastre as suas redes</b>
    <div class="sub">Sem os blocos de IP da empresa, todo destino é analisado (inclusive o tráfego de saída dos clientes) e a mitigação não funciona.
    ${pode("administrar") ? 'Informe em <a class="link" data-acao="ir" data-aba="minha_empresa">🏢 Minha empresa</a>, ex.: 177.10.0.0/22 e 2804:abcd::/32.' : "Peça a um administrador para cadastrar em 🏢 Minha empresa."}</div></div></div>`;
  for (const [nome, erro] of Object.entries(d.erros)) if (erro) h += `<div class="card erro" style="margin-bottom:12px">${esc(nome)}: ${esc(erro)}</div>`;

  h += d.ativos.length
    ? `<div class="banner perigo"><span class="pulso"></span><div class="texto"><b>${d.ativos.length} cliente${d.ativos.length > 1 ? "s" : ""} sob DDoS agora</b>
        <div class="sub">Limites: ${d.limites.mbps} Mbps ou ${d.limites.kpps} mil pacotes/s para um único IP</div></div></div>
       <div class="grade">${d.ativos.map(a => `<div class="card ataque pulsando">
         <div class="card-topo"><b class="mono">${esc(a.alvo)}</b>${selo("ataque", "● Sob DDoS")}</div>
         <div class="bloco-ataque"><div class="nome">🌊 ${esc(a.vetor)}</div>
         <div>Pico: <b>${bps(a.pico_bps)}</b> · ${(a.pico_pps / 1000).toFixed(0)} mil pacotes/s</div>
         <div class="sub">Desde ${esc(a.inicio)} (há ${ha(a.duracao_seg)})</div></div></div>`).join("")}</div>`
    : `<div class="banner tranquilo"><span class="ponto-ok"></span><div class="texto"><b>Nenhum DDoS em andamento</b>
        <div class="sub">Limites: ${d.limites.mbps} Mbps ou ${d.limites.kpps} mil pacotes/s para um único IP${d.redes.length ? " · redes: " + d.redes.map(esc).join(", ") : ""}</div></div></div>`;

  const j = d.ultima_janela;
  h += `<div class="duas-colunas"><div><h3>Tráfego por destino (última janela${j.inicio ? ", " + esc(j.inicio) : ""})</h3>`;
  h += j.top && j.top.length ? `<div class="tabela"><table><tr><th>IP de destino</th><th>Tráfego</th><th>Pacotes/s</th><th>Composição</th><th>Origens</th></tr>${
    j.top.map(t => `<tr><td class="mono">${esc(t.ip)}</td><td>${bps(t.bps)}</td><td>${Math.round(t.pps).toLocaleString("pt-BR")}</td>
      <td>${esc(t.vetor)}</td><td>${t.fontes}</td></tr>`).join("")}</table></div>
    <div class="sub" style="margin-top:6px">Total: ${bps(j.total_bps)} · ${Math.round(j.total_pps).toLocaleString("pt-BR")} pacotes/s</div>`
    : '<div class="vazio">Nenhum fluxo recebido ainda.</div>';
  h += `</div><div><h3>Exportadores (roteadores enviando fluxo)</h3>`;
  h += d.exportadores.length ? `<div class="tabela"><table><tr><th>Roteador</th><th>Formato</th><th>Amostragem</th><th>Último</th></tr>${
    d.exportadores.map(x => `<tr><td class="mono">${esc(x.ip)}</td><td>${esc(x.versao)}</td><td>1:${x.amostragem}</td>
      <td class="${x.ha_seg > 120 ? "txt-erro" : ""}">há ${ha(x.ha_seg)}</td></tr>`).join("")}</table></div>`
    : `<div class="card neutro">Nenhum roteador enviando fluxo ainda.</div>`;
  h += `<button class="pequeno" style="margin-top:10px" data-acao="ajuda-fluxo">📘 Como configurar NetFlow/sFlow</button>`;
  if (E.ajudaFluxo) {
    const ip = esc(d.ip_local), pn = d.portas.netflow, ps = d.portas.sflow;
    h += `<div class="ajuda card neutro"><b>MikroTik (IPFIX)</b><pre>/ip traffic-flow set enabled=yes interfaces=all active-flow-timeout=1m inactive-flow-timeout=15s
/ip traffic-flow target add dst-address=${ip} port=${pn} version=ipfix</pre>
      <b>Cisco IOS (Flexible NetFlow v9)</b><pre>flow exporter SENTINELA
 destination ${ip}
 transport udp ${pn}
 export-protocol netflow-v9
flow monitor SENTINELA
 exporter SENTINELA
 cache timeout active 60
 record netflow ipv4 original-input
interface &lt;uplink&gt;
 ip flow monitor SENTINELA input</pre>
      <b>Huawei (NetStream v9)</b><pre>ip netstream export version 9
ip netstream export host ${ip} ${pn}
ip netstream timeout active 1
interface &lt;uplink&gt;
 ip netstream inbound</pre>
      <b>Switches com sFlow (Juniper EX, Huawei, Arista...)</b><pre>set protocols sflow collector ${ip} udp-port ${ps}
set protocols sflow interfaces &lt;uplink&gt;</pre>
      <p class="sub">Use timeout ativo de 1 minuto: com timeouts longos, o ataque só aparece minutos depois.</p></div>`;
  }
  h += `</div></div>`;

  h += `<h3>Histórico de ataques DDoS</h3>`;
  h += d.historico.length ? `<div class="tabela"><table><tr><th>Início</th><th>Alvo</th><th>Vetor</th><th>Pico</th><th>Duração</th><th>Principais origens</th><th>Estado</th></tr>${
    d.historico.map(x => `<tr><td style="white-space:nowrap">${esc(x.inicio_txt)}</td><td class="mono">${esc(x.alvo)}</td><td>${esc(x.vetor)}</td>
      <td>${bps(x.pico_bps)}<div class="sub">${(x.pico_pps / 1000).toFixed(0)} kpps</div></td><td>${ha(x.duracao_seg)}</td>
      <td>${x.origens.slice(0, 3).map(([ip]) => `<span class="ip">${esc(ip)}</span>`).join(" ")}${x.fontes > 3 ? `<div class="sub">${x.fontes} origens no total</div>` : ""}</td>
      <td>${selo(x.estado === "ativo" ? "ataque" : "resolvido", x.estado)}</td></tr>`).join("")}</table></div>`
    : vazio("Nenhum ataque DDoS registrado.");
  return h;
}


// ======================================================================= tela: BGP / RPKI
function telaBgp(d) {
  if (!d.ativo) return vazio("O monitoramento BGP está desligado ([bgp] ativo = false).");
  const caidas = d.sessoes.filter(s => !s.estabelecida);
  let h = caidas.length
    ? `<div class="banner perigo"><span class="pulso"></span><div class="texto"><b>${caidas.length} sessão(ões) BGP fora do ar</b>
        <div class="sub">${caidas.map(s => `${esc(s.equipamento)} ↔ ${esc(s.vizinho)}${s.asn ? " (AS" + s.asn + ")" : ""}`).join(" · ")}</div></div></div>`
    : d.sessoes.length ? `<div class="banner tranquilo"><span class="ponto-ok"></span><div class="texto"><b>Todas as ${d.sessoes.length} sessões BGP estabelecidas</b>
        <div class="sub">Última verificação: ${esc(d.ultimo_ciclo || "—")}</div></div></div>` : "";
  for (const [id, erro] of Object.entries(d.erros || {})) h += `<div class="card erro" style="margin-bottom:10px">Falha ao ler BGP: ${esc(erro)}</div>`;

  h += "<h3>Sessões BGP</h3>";
  h += d.sessoes.length ? `<div class="tabela"><table><tr><th>Roteador</th><th>Vizinho</th><th>ASN</th><th>Estado</th><th>Prefixos recebidos</th><th>Tempo</th><th>Última mudança</th></tr>${
    d.sessoes.map(s => `<tr><td>${esc(s.equipamento)}<div class="sub mono">${esc(s.host)}</div></td>
      <td class="mono">${esc(s.vizinho)}${s.descricao ? `<div class="sub">${esc(s.descricao)}</div>` : ""}</td>
      <td>${s.asn ? "AS" + s.asn : "—"}</td><td>${selo(s.estabelecida ? "ok" : "alerta", s.estado)}</td>
      <td>${s.prefixos != null ? s.prefixos.toLocaleString("pt-BR") : "—"}</td><td>${esc(s.tempo)}</td><td class="sub">${esc(s.mudou_em || "")}</td></tr>`).join("")}</table></div>`
    : vazio("Nenhuma sessão BGP lida ainda. São verificados os equipamentos com função Roteador de borda, Core ou Concentrador.");

  h += `<h3>RPKI e origem dos seus prefixos ${d.asn ? "(AS" + d.asn + ")" : ""}</h3>`;
  if (!d.asn) {
    h += `<div class="card erro">Cadastre o ASN e os prefixos da empresa em
      ${pode("administrar") ? '<a class="link" data-acao="ir" data-aba="minha_empresa">🏢 Minha empresa</a>' : "🏢 Minha empresa (peça a um administrador)"}.
      O Sentinela confere no RIPEstat se cada prefixo tem ROA válido e se alguém de fora está anunciando o seu prefixo (sequestro).</div>`;
    return h;
  }
  if (pode("operar")) h += '<div class="barra-ferramentas"><button data-acao="verificar-rpki">🔎 Verificar RPKI agora</button></div>';
  const nomes = { valid: ["ok", "✓ Válido"], invalid_asn: ["alerta", "✗ Inválido (ASN)"], invalid_length: ["alerta", "✗ Inválido (tamanho)"],
                  invalid: ["alerta", "✗ Inválido"], unknown: ["erro", "Sem ROA"], erro: ["erro", "Erro"] };
  h += d.rpki.length ? `<div class="tabela"><table><tr><th>Prefixo</th><th>RPKI</th><th>Visível na internet</th><th>Origem vista</th><th>ROAs</th><th>Verificado</th></tr>${
    d.rpki.map(r => {
      const [cls, rot] = nomes[r.status] || ["", r.status];
      const estranhos = r.origens.filter(o => o !== d.asn);
      return `<tr><td class="mono">${esc(r.prefixo)}</td><td>${selo(cls, rot)}${r.erro ? `<div class="txt-erro" style="font-size:12px">${esc(r.erro)}</div>` : ""}</td>
        <td>${r.visivel == null ? "—" : r.visivel ? '<span class="txt-ok">sim</span>' : '<span class="txt-erro">não anunciado</span>'}</td>
        <td>${r.origens.map(o => `<span class="${o === d.asn ? "" : "ip"}">AS${o}</span>`).join(" ") || "—"}
          ${estranhos.length ? '<div class="txt-alerta" style="font-size:12px">⚠ outro ASN anunciando: possível sequestro</div>' : ""}</td>
        <td class="sub">${r.roas.map(x => `AS${esc(x.origem)} ${esc(x.prefixo)} max /${esc(x.max)}`).join("<br>") || "—"}</td>
        <td class="sub">${esc(r.verificado)}</td></tr>`;
    }).join("")}</table></div>
    <p class="sub">Sem ROA? Crie no <b>Registro.br</b> (ou na LACNIC) autorizando o seu ASN. ROA protege contra sequestro de prefixo.</p>`
    : vazio("Ainda não verificado. A verificação roda a cada 6 horas.");
  return h;
}

// ======================================================================= tela: OLTs
function telaOlts(d) {
  if (!d.olts.length) return vazio("Nenhuma OLT cadastrada. Cadastre com o fabricante \"OLT Huawei\" ou \"OLT ZTE\".",
    pode("administrar") ? '<br><button class="primario" data-acao="novo-equip">➕ Cadastrar OLT</button>' : "");
  return d.olts.map(o => {
    let h = `<div class="card ${o.erro ? "erro" : o.offline > o.total * 0.2 ? "alerta" : "ok"}" style="margin-bottom:16px">
      <div class="card-topo"><b>📡 ${esc(o.nome)} <span class="sub mono">${esc(o.host)}</span></b>${selo("", o.tipo_nome)}</div>`;
    if (!o.suportada) return h + '<div class="sub">Monitoramento de ONUs disponível para Huawei e ZTE. Esta OLT tem backup, logs e auditoria.</div></div>';
    if (o.erro) h += `<div class="txt-erro" style="margin:6px 0">${esc(o.erro)}</div>`;
    h += `<div class="contadores" style="margin-top:10px">
      <div class="contador">ONUs<b>${o.total}</b></div><div class="contador">Online<b style="color:var(--ok)">${o.online}</b></div>
      <div class="contador">Offline<b style="color:${o.offline ? "var(--alerta)" : "inherit"}">${o.offline}</b></div>
      <div class="contador">LOS (fibra)<b>${o.los}</b></div><div class="contador">Sem energia<b>${o.sem_energia}</b></div>
      <div class="contador">Sinal ruim (&lt; ${d.sinal_minimo} dBm)<b style="color:${o.sinal_ruim ? "var(--erro)" : "inherit"}">${o.sinal_ruim}</b></div></div>`;
    if (o.pons.length) {
      h += `<div class="tabela" style="margin-top:10px"><table><tr><th>PON</th><th>ONUs</th><th>Online</th><th>Offline</th><th>LOS</th><th>Sem energia</th><th>Sinal ruim</th><th></th></tr>${
        o.pons.map(p => {
          const pct = p.total ? Math.round(p.online * 100 / p.total) : 0;
          return `<tr><td class="mono">${esc(p.pon)}</td><td>${p.total}</td>
          <td><div class="barra" style="width:90px;margin:4px 0"><i style="width:${pct}%;background:${pct < 50 ? "var(--alerta)" : pct < 85 ? "var(--erro)" : "var(--ok)"}"></i></div>${p.online} (${pct}%)</td>
          <td class="${p.offline ? "txt-alerta" : ""}">${p.offline}</td><td>${p.los}</td><td>${p.sem_energia}</td><td>${p.sinal_ruim}</td>
          <td class="acoes"><button class="pequeno" data-acao="ver-onus" data-id="${esc(o.id)}" data-pon="${esc(p.pon)}">Ver ONUs</button></td></tr>`;
        }).join("")}</table></div>`;
    }
    h += `<div class="form-botoes"><button class="pequeno" data-acao="ver-onus" data-id="${esc(o.id)}" data-filtro="offline">Todas offline</button>
      <button class="pequeno" data-acao="ver-onus" data-id="${esc(o.id)}" data-filtro="sinal_ruim">Todas com sinal ruim</button>
      <span class="sub">Atualizado: ${esc(o.atualizado || "—")}</span></div>`;
    return h + "</div>";
  }).join("");
}

async function verOnus(el) {
  const params = new URLSearchParams();
  if (el.dataset.pon) params.set("pon", el.dataset.pon);
  if (el.dataset.filtro) params.set("filtro", el.dataset.filtro);
  abrirModal("ONUs", '<div class="sub">Carregando...</div>', true);
  const d = await api(`/api/olts/${encodeURIComponent(el.dataset.id)}/onus?${params}`);
  const titulo = el.dataset.pon ? `ONUs da PON ${el.dataset.pon}` : el.dataset.filtro === "offline" ? "ONUs offline" : "ONUs com sinal ruim";
  $("#modal-titulo").textContent = `${titulo} (${d.onus.length})`;
  const nomes = { online: ["ok", "online"], offline: ["alerta", "offline"], los: ["alerta", "LOS"], sem_energia: ["erro", "sem energia"] };
  $("#modal-corpo").innerHTML = d.onus.length ? `<div class="tabela"><table><tr><th>ONU</th><th>Serial</th><th>Estado</th><th>Sinal (Rx)</th></tr>${
    d.onus.map(o => { const [c, r] = nomes[o.estado] || ["", o.estado];
      return `<tr><td class="mono">${esc(o.onu)}</td><td class="mono">${esc(o.serial)}</td><td>${selo(c, r)}</td>
        <td class="${o.rx_dbm != null && o.rx_dbm < (E.dados.olts?.sinal_minimo ?? -27) ? "txt-alerta" : ""}">${o.rx_dbm != null ? o.rx_dbm.toFixed(2) + " dBm" : "—"}</td></tr>`; }).join("")}</table></div>`
    : '<div class="sub">Nenhuma ONU neste filtro.</div>';
}


// ======================================================================= tela: mitigação
function cabMitigacao() {
  let h = `<div class="card neutro" style="margin-bottom:14px"><b>Como funciona:</b> <span class="sub">o Sentinela <b>propõe</b> a mitigação ao detectar
    um DDoS (RTBH do IP atacado nos roteadores de borda) ou força bruta (bloqueio dos IPs atacantes no MikroTik atacado).
    Nada é enviado aos roteadores até um operador <b>aprovar</b>. A mitigação expira sozinha e é desfeita.</span></div>`;
  if (pode("operar")) h += `<div class="barra-ferramentas"><button class="primario" data-acao="nova-mitigacao">➕ Mitigação manual</button>
    ${pode("administrar") ? '<button data-acao="config-mitigacao">⚙️ Configurar comandos e regras</button>' : ""}</div>`;
  return h;
}

function telaMitigacao(d) {
  E.dados.mitigacao = d;
  const nomes = { pendente: ["erro", "⏳ aguardando aprovação"], aplicando: ["baixa", "aplicando..."], ativa: ["alerta", "● ATIVA"],
    removendo: ["baixa", "removendo..."], removida: ["resolvido", "removida"], rejeitada: ["", "rejeitada"], expirada: ["", "proposta expirada"],
    erro: ["alerta", "erro"] };
  const pendentes = d.mitigacoes.filter(m => m.estado === "pendente");
  const badge = $("#qtd-mit");
  if (badge) badge.innerHTML = pendentes.length ? `<span class="qtd">${pendentes.length}</span>` : "";
  if (!d.mitigacoes.length) return vazio("Nenhuma mitigação proposta ainda.");
  const linha = m => {
    const [c, r] = nomes[m.estado] || ["", m.estado];
    let acoes = "";
    if (pode("operar") && m.estado === "pendente") acoes = `<button class="pequeno primario" data-acao="aprovar-mitigacao" data-id="${m.id}">✔ Aprovar e aplicar</button>
      <button class="pequeno" data-acao="rejeitar-mitigacao" data-id="${m.id}">Rejeitar</button>`;
    if (pode("operar") && (m.estado === "ativa" || m.estado === "erro")) acoes = `<button class="pequeno perigo" data-acao="remover-mitigacao" data-id="${m.id}">Remover agora</button>`;
    return `<tr><td>#${m.id}<div class="sub">${esc(m.criado)}</div></td><td><b>${esc(m.tipo_nome)}</b><div class="sub">${esc(m.motivo)}</div></td>
      <td class="mono">${esc(m.alvo)}</td><td class="sub">${m.equipamentos.map(esc).join("<br>")}</td>
      <td>${selo(c, r)}${m.restante_seg != null ? `<div class="sub">expira em ${ha(Math.max(0, m.restante_seg))}</div>` : `<div class="sub">duração ${m.duracao_min} min</div>`}
        ${m.aprovado_por ? `<div class="sub">por ${esc(m.aprovado_por)}</div>` : ""}</td>
      <td class="acoes">${acoes}${m.log ? `<button class="pequeno" data-acao="log-mitigacao" data-id="${m.id}">Log</button>` : ""}</td></tr>`;
  };
  return `<div class="tabela"><table><tr><th>#</th><th>Ação</th><th>Alvo</th><th>Roteadores</th><th>Estado</th><th></th></tr>
    ${d.mitigacoes.map(linha).join("")}</table></div>`;
}

function formMitigacao() {
  const d = E.dados.mitigacao;
  abrirModal("Mitigação manual", `<form class="form" data-form="mitigacao-manual">
    <div class="campos">
      <div><label>Tipo</label><select name="tipo" id="tipo-mit">${opcoes(d.tipos, "rtbh")}</select></div>
      <div><label>IP alvo</label><input name="alvo" placeholder="ex.: 177.10.0.5" required></div>
      <div><label>Duração (min)</label><input name="duracao_min" type="number" min="5" max="10080" placeholder="padrão"></div>
      <div><label>Motivo</label><input name="motivo" placeholder="ex.: DDoS reportado pelo cliente"></div>
    </div>
    <label>Aplicar em</label><div id="equip-mit"></div>
    <div class="dica">RTBH: o IP precisa ser das suas redes (${esc(d.redes.join(", ") || "cadastre em 🏢 Minha empresa")}).
      Bloqueio: bloqueia o IP de origem no equipamento escolhido.</div>
    <div class="form-botoes"><button class="primario" type="submit">Criar (fica pendente de aprovação)</button><span class="msg"></span></div></form>`);
  preencherEquipMit();
}

function preencherEquipMit() {
  const d = E.dados.mitigacao, tipo = $("#tipo-mit")?.value;
  if (!tipo) return;
  const lista = d.candidatos[tipo] || [];
  $("#equip-mit").innerHTML = lista.length ? lista.map(e => `<label style="margin:6px 0"><input type="checkbox" name="equip" value="${esc(e.id)}"
      ${tipo === "rtbh" && e.funcao === "Roteador de borda" ? "checked" : ""}> ${esc(e.nome)} <span class="sub">${esc(e.host)} · ${esc(e.funcao)}
      ${e.tem_mitigacao ? "" : "· usará o usuário SSH comum"}</span></label>`).join("")
    : '<div class="txt-erro">Nenhum equipamento compatível (há modelos de comando para MikroTik, Cisco, Huawei e Juniper).</div>';
}

function formConfigMitigacao() {
  const c = E.dados.mitigacao.config;
  const blocos = Object.entries(c.modelos).map(([tipo, porFab]) => Object.entries(porFab).map(([fab, cmds]) => `
    <fieldset><legend>${esc(E.dados.mitigacao.tipos[tipo])} · ${esc(fab)}</legend><div class="campos">
      <div><label>Aplicar</label><textarea rows="3" class="mono" data-modelo="${tipo}|${fab}|aplicar">${esc(cmds.aplicar.join("\n"))}</textarea></div>
      <div><label>Remover</label><textarea rows="3" class="mono" data-modelo="${tipo}|${fab}|remover">${esc(cmds.remover.join("\n"))}</textarea></div>
    </div></fieldset>`).join("")).join("");
  abrirModal("Configurar mitigação", `<form class="form" data-form="config-mitigacao">
    <div class="campos">
      <div><label><input type="checkbox" name="propor_rtbh" ${c.propor_rtbh ? "checked" : ""}> Propor RTBH ao detectar DDoS</label></div>
      <div><label><input type="checkbox" name="propor_bloqueio" ${c.propor_bloqueio ? "checked" : ""}> Propor bloqueio em força bruta</label></div>
      <div><label>Duração do RTBH (min)</label><input name="duracao_rtbh_min" type="number" value="${c.duracao_rtbh_min}"></div>
      <div><label>Duração do bloqueio (min)</label><input name="duracao_bloqueio_min" type="number" value="${c.duracao_bloqueio_min}"></div>
      <div><label><input type="checkbox" name="automatico_rtbh" ${c.automatico_rtbh ? "checked" : ""}> Aplicar RTBH sem aprovação acima de</label>
        <input name="automatico_rtbh_gbps" type="number" step="0.1" value="${c.automatico_rtbh_gbps}"><div class="dica">Gbps. Use com cuidado.</div></div>
      <div><label>Nunca bloquear (um por linha)</label><textarea name="nunca_bloquear" rows="3" class="mono" placeholder="IPs do NOC, servidores, DNS...">${esc(c.nunca_bloquear.join("\n"))}</textarea></div>
    </div>
    <h3>Comandos por fabricante</h3>
    <p class="sub">Variáveis: {alvo} {mascara} {mascara_decimal} {id} {minutos} {familia_mikrotik}. Pré-requisito do RTBH: o roteador de borda
      precisa anunciar as rotas blackhole (tag 666 / comentário sentinela-rtbh) ao trânsito com a community de blackhole da operadora
      (geralmente 65535:666, RFC 7999). Confirme com o seu provedor de trânsito antes de usar.</p>
    ${blocos}
    <div class="form-botoes"><button class="primario" type="submit">💾 Salvar</button><span class="msg"></span></div></form>`, true);
}

// ======================================================================= tela: painel
function cabFiltroEquip() {
  return `<div class="barra-ferramentas">
    <input id="busca-equip" data-filtro placeholder="🔎 Buscar por nome, IP ou hostname">
    <select id="filtro-site" data-filtro><option value="">Todos os sites</option></select>
    <select id="filtro-status" data-filtro><option value="">Todos os status</option><option value="alerta">Sob alerta</option>
      <option value="erro">Com erro</option><option value="ok">Normais</option></select></div>`;
}

function preencherSites(sites) {
  const sel = $("#filtro-site");
  if (!sel || sel.dataset.pronto === String(sites.length)) return;
  const atual = sel.value;
  sel.innerHTML = '<option value="">Todos os sites</option>' + sites.map(s => `<option value="${s.id}">${esc(s.nome)}</option>`).join("");
  sel.value = atual;
  sel.dataset.pronto = String(sites.length);
}

function filtrarEquip(lista) {
  const busca = ($("#busca-equip")?.value || "").toLowerCase();
  const site = $("#filtro-site")?.value || "";
  const status = $("#filtro-status")?.value || "";
  return lista.filter(e => (!busca || [e.nome, e.host, e.hostname, e.site].join(" ").toLowerCase().includes(busca)) &&
    (!site || String(e.site_id) === site) && (!status || e.status === status));
}

function telaPainel(d) {
  preencherSites(d.sites);
  const eq = d.equipamentos;
  if (!eq.length) return vazio("Nenhum roteador ou switch cadastrado ainda.",
    pode("administrar") ? '<br><button class="primario" data-acao="novo-equip">➕ Cadastrar equipamento</button>' : "");
  const qtd = s => eq.filter(e => e.status === s).length;
  let h = `<div class="contadores">
    <div class="contador">Equipamentos<b>${eq.length}</b></div>
    <div class="contador">Normais<b style="color:var(--ok)">${qtd("ok")}</b></div>
    <div class="contador">Sob alerta<b style="color:var(--alerta)">${qtd("alerta")}</b></div>
    <div class="contador">Com erro<b style="color:var(--erro)">${qtd("erro")}</b></div>
    <div class="contador">Aguardando<b>${qtd("aguardando")}</b></div></div><h3>Equipamentos</h3>`;
  const lista = filtrarEquip(eq);
  if (!lista.length) return h + vazio("Nenhum equipamento corresponde ao filtro.");
  const rotulos = { ok: "● Normal", alerta: "● Alerta", erro: "● Erro", aguardando: "○ Aguardando" };
  h += `<div class="grade">${lista.map(e => {
    let c = `<div class="sub">${esc(e.nome)} · ${esc(e.tipo_nome)} · ${esc(e.funcao_nome)}${e.site ? " · " + esc(e.site) : ""}</div>`;
    for (const [rotulo, valor] of [["CPU", e.cpu], ["Memória", e.memoria]]) {
      if (valor == null) continue;
      const cor = valor >= 90 ? "var(--alerta)" : valor >= 70 ? "var(--erro)" : "var(--ok)";
      c += `<div class="sub" style="margin-top:8px">${rotulo} ${valor}%</div><div class="barra"><i style="width:${Math.min(valor, 100)}%;background:${cor}"></i></div>`;
    }
    if (e.uptime != null) c += `<div class="sub" style="margin-top:6px">⏱ Ligado há ${duracao(e.uptime)}</div>`;
    if (e.alertas.length) c += `<ul>${e.alertas.map(a => `<li class="txt-alerta">${esc(a)}</li>`).join("")}</ul>`;
    if (e.erro) c += `<div class="txt-erro" style="font-size:14px;margin:8px 0">${esc(e.erro)}</div>`;
    if (e.snmp_erro) c += `<div class="txt-erro" style="font-size:13px;margin:4px 0">SNMP: ${esc(e.snmp_erro)}</div>`;
    if (e.status === "ok") c += '<div class="txt-ok" style="font-size:14px">Nenhum sinal de ataque</div>';
    if (!e.ativo) c += '<div class="sub">⏸ Monitoramento desativado para este equipamento</div>';
    c += `<div class="sub" style="margin-top:8px">${e.verificado ? "Verificado em " + esc(e.verificado) : "Ainda não verificado"}</div><div style="margin-top:6px">`;
    if (e.incidente && pode("operar")) c += linkArquivo(e.incidente + "/resumo.txt", "📁 Último incidente");
    if (e.tem_snmp) c += `<a class="link" data-acao="interfaces" data-id="${esc(e.id)}">📶 Interfaces</a>`;
    if (pode("administrar")) c += `<a class="link" data-acao="editar-equip" data-id="${esc(e.id)}">✏️ Editar</a>`;
    return `<div class="card ${esc(e.status)}"><div class="card-topo"><b>${esc(e.hostname ? `${e.hostname} (${e.host})` : `${e.nome} (${e.host})`)}</b>${selo(e.status, rotulos[e.status] || e.status)}</div>${c}</div></div>`;
  }).join("")}</div>`;
  return h;
}

// ======================================================================= tela: incidentes
function cabIncidentes() {
  return `<div class="barra-ferramentas"><select id="filtro-incidentes" data-recarregar>
    <option value="abertos">Abertos e reconhecidos</option><option value="aberto">Só abertos</option>
    <option value="reconhecido">Só reconhecidos</option><option value="resolvido">Resolvidos</option><option value="">Todos</option>
    </select><span class="espaco"></span><span class="sub">Reconhecer um incidente interrompe o escalonamento dos alertas.</span></div>`;
}

function telaIncidentes(d) {
  if (!d.incidentes.length) return vazio("✅ Nenhum incidente neste filtro.");
  const nomes = { aberto: "Aberto", reconhecido: "Reconhecido", resolvido: "Resolvido" };
  return `<div class="tabela"><table><tr><th>Abertura</th><th>Equipamento</th><th>Incidente</th><th>Estado</th><th>Evidências</th><th></th></tr>${
    d.incidentes.map(i => `<tr>
      <td style="white-space:nowrap">${esc(i.abertura)}${i.ocorrencias > 1 ? `<div class="sub">${i.ocorrencias} ocorrências · última ${esc(i.ultima_ocorrencia)}</div>` : ""}</td>
      <td><b>${esc(i.equipamento)}</b></td>
      <td>${icone(i.tipo)} <b>${esc(i.tipo)}</b> ${selo(i.severidade, i.severidade)}<div class="txt-alerta" style="font-size:13px;margin-top:4px">${esc(i.titulo)}</div></td>
      <td>${selo(i.estado, nomes[i.estado])}${i.reconhecido_por ? `<div class="sub">por ${esc(i.reconhecido_por)}</div>` : ""}${i.resolvido_em ? `<div class="sub">resolvido ${esc(i.resolvido_em)}</div>` : ""}</td>
      <td>${pode("operar") ? i.arquivos.map(c => linkArquivo(c, "📄 " + c.split("/").pop())).join("") || '<span class="sub">—</span>' : '<span class="sub">sem permissão</span>'}</td>
      <td class="acoes">${pode("operar") && i.estado === "aberto" ? `<button class="pequeno" data-acao="reconhecer" data-id="${i.id}">✋ Reconhecer</button>` : ""}
        ${pode("operar") && i.estado !== "resolvido" ? `<button class="pequeno" data-acao="resolver" data-id="${i.id}">✓ Resolver</button>` : ""}</td>
    </tr>`).join("")}</table></div>`;
}

// ======================================================================= tela: equipamentos
function cabEquipamentos() {
  return `<div class="barra-ferramentas">
    ${pode("administrar") ? '<button class="primario" data-acao="novo-equip">➕ Cadastrar equipamento</button><button data-acao="sites">🏢 Sites</button>' : ""}
    <input id="busca-equip" data-filtro placeholder="🔎 Buscar"><select id="filtro-site" data-filtro><option value="">Todos os sites</option></select>
    <select id="filtro-status" data-filtro hidden><option value=""></option></select></div>`;
}

const buscarEquip = id => (E.dados.equipamentos || E.dados.painel)?.equipamentos.find(e => e.id === id);

function telaEquipamentos(d) {
  preencherSites(d.sites);
  if (!d.equipamentos.length) return vazio("Nenhum equipamento cadastrado.",
    pode("administrar") ? '<br><button class="primario" data-acao="novo-equip">➕ Cadastrar o primeiro</button>' : "");
  const lista = filtrarEquip(d.equipamentos);
  return `<div class="tabela"><table><tr><th>Equipamento</th><th>Endereço</th><th>Fabricante / função</th><th>Site</th><th>Acesso</th><th>Status</th><th></th></tr>${
    lista.map(e => `<tr>
      <td><b>${esc(e.nome)}</b>${e.hostname ? `<div class="sub">hostname: ${esc(e.hostname)}</div>` : ""}${!e.ativo ? '<div class="sub">⏸ desativado</div>' : ""}</td>
      <td class="mono">${esc(e.host)}:${e.porta}</td>
      <td>${esc(e.tipo_nome)}<div class="sub">${esc(e.funcao_nome)}</div></td>
      <td>${esc(e.site || "—")}</td>
      <td>SSH ${esc(e.usuario)}${e.tem_senha ? "" : ' <span class="txt-erro">(sem senha)</span>'}<div class="sub">${e.tem_snmp ? "SNMP v" + esc(e.snmp_versao) : "sem SNMP"}</div></td>
      <td>${selo(e.status, e.status)}${e.erro ? `<div class="txt-erro" style="font-size:12px;margin-top:4px">${esc(e.erro)}</div>` : ""}</td>
      <td class="acoes">${pode("administrar") ? `<button class="pequeno" data-acao="editar-equip" data-id="${esc(e.id)}">✏️ Editar</button>
        <button class="pequeno perigo" data-acao="remover-equip" data-id="${esc(e.id)}">🗑</button>` : ""}</td>
    </tr>`).join("")}</table></div>`;
}

function opcoes(mapa, atual) {
  return Object.entries(mapa).map(([v, n]) => `<option value="${esc(v)}"${String(v) === String(atual ?? "") ? " selected" : ""}>${esc(n)}</option>`).join("");
}

function formEquipamento(id) {
  const d = E.dados.equipamentos || E.dados.painel;
  if (!d) return;
  const e = id ? d.equipamentos.find(x => x.id === id) : null;
  const sites = Object.fromEntries([["", "— sem site —"], ...d.sites.map(s => [s.id, s.nome])]);
  const manter = campo => e && e[campo] ? 'placeholder="deixe em branco para manter"' : "";
  abrirModal(e ? `Editar ${e.nome}` : "Cadastrar roteador, switch ou OLT", `
    <form class="form" data-form="equipamento" autocomplete="off">
      <input type="hidden" name="id" value="${esc(e?.id || "")}">
      <div class="campos">
        <div><label>Nome / apelido</label><input name="nome" value="${esc(e?.nome || "")}" placeholder="ex.: Borda POP Centro"></div>
        <div><label>IP ou endereço *</label><input name="host" value="${esc(e?.host || "")}" placeholder="ex.: 10.0.0.1" required></div>
        <div><label>Fabricante *</label><select name="tipo" required><option value="">Selecione...</option>${opcoes(d.tipos, e?.tipo)}</select></div>
        <div><label>Função</label><select name="funcao">${opcoes(d.funcoes, e?.funcao || "outro")}</select></div>
        <div><label>Site / POP</label><select name="site_id">${opcoes(sites, e?.site_id ?? "")}</select></div>
        <div><label>Porta SSH</label><input name="porta" type="number" min="1" max="65535" value="${e?.porta || 22}"></div>
        <div><label>Usuário SSH *</label><input name="usuario" value="${esc(e?.usuario || "")}" autocomplete="off" required></div>
        <div><label>Senha SSH *</label><input name="senha" type="password" autocomplete="new-password" ${manter("tem_senha")}></div>
        <div><label>Senha de enable</label><input name="enable" type="password" autocomplete="new-password" ${manter("tem_enable") || 'placeholder="se for diferente da senha SSH"'}></div>
      </div>
      <fieldset><legend>SNMP (coleta leve de CPU, memória e interfaces)</legend><div class="campos">
        <div><label>Versão</label><select name="snmp_versao">${opcoes({ "": "Desativado", "2c": "SNMP v2c", "3": "SNMP v3 (recomendado)" }, e?.snmp_versao || "")}</select></div>
        <div><label>Porta SNMP</label><input name="snmp_porta" type="number" value="${e?.snmp_porta || 161}"></div>
        <div data-snmp="2c"><label>Community</label><input name="snmp_community" type="password" autocomplete="new-password" ${e?.tem_snmp && e.snmp_versao === "2c" ? 'placeholder="deixe em branco para manter"' : ""}></div>
        <div data-snmp="3"><label>Usuário SNMPv3</label><input name="snmp_v3_usuario" value="${esc(e?.snmp_v3_usuario || "")}"></div>
        <div data-snmp="3"><label>Senha de autenticação (SHA)</label><input name="snmp_v3_auth" type="password" autocomplete="new-password" ${e?.snmp_versao === "3" ? 'placeholder="deixe em branco para manter"' : ""}></div>
        <div data-snmp="3"><label>Senha de privacidade (AES)</label><input name="snmp_v3_priv" type="password" autocomplete="new-password" ${e?.snmp_versao === "3" ? 'placeholder="deixe em branco para manter"' : ""}></div>
      </div></fieldset>
      <fieldset><legend>Mitigação (opcional): usuário com permissão de ESCRITA</legend><div class="campos">
        <div><label>Usuário de mitigação</label><input name="mit_usuario" value="${esc(e?.mit_usuario || "")}" autocomplete="off"></div>
        <div><label>Senha de mitigação</label><input name="mit_senha" type="password" autocomplete="new-password" ${e?.tem_mitigacao ? 'placeholder="deixe em branco para manter"' : ""}></div>
      </div><div class="dica">Usado só quando um operador aprova uma mitigação (RTBH ou bloqueio). Sem ele, a mitigação usa o usuário SSH acima.</div></fieldset>
      <label><input type="checkbox" name="ativo" ${!e || e.ativo ? "checked" : ""}> Monitorar este equipamento</label>
      <div class="form-botoes">
        <button type="submit" class="primario">💾 Salvar</button>
        <button type="button" data-acao="testar-equip">🔌 Testar conexão SSH</button>
        <button type="button" data-acao="testar-snmp">📡 Testar SNMP</button>
        ${e ? `<button type="button" class="perigo" data-acao="remover-equip" data-id="${esc(e.id)}">🗑 Remover</button>` : ""}
      </div><div class="msg"></div>
      <div class="dica">🔒 As senhas são gravadas criptografadas e nunca são exibidas de volta. Use um usuário somente leitura.</div>
    </form>`, true);
  ajustarCamposSnmp($("#modal-corpo form"));
}

function ajustarCamposSnmp(form) {
  if (!form || !form.snmp_versao) return;
  const v = form.snmp_versao.value;
  $$("[data-snmp]", form).forEach(el => { el.hidden = el.dataset.snmp !== v; });
  form.snmp_porta.parentElement.hidden = !v;
}

async function verInterfaces(id) {
  abrirModal("Interfaces", '<div class="sub">Carregando...</div>', true);
  const d = await api(`/api/equipamentos/${encodeURIComponent(id)}/interfaces`);
  $("#modal-titulo").textContent = `Interfaces de ${d.equipamento || ""}`;
  if (!d.interfaces || !d.interfaces.length) {
    $("#modal-corpo").innerHTML = '<div class="sub">Ainda sem dados. A primeira coleta SNMP leva até 1 minuto, e o tráfego aparece a partir da segunda.</div>';
    return;
  }
  const lista = [...d.interfaces].sort((a, b) => ((b.bps_in || 0) + (b.bps_out || 0)) - ((a.bps_in || 0) + (a.bps_out || 0)));
  $("#modal-corpo").innerHTML = `<div class="tabela"><table><tr><th>Interface</th><th>Descrição</th><th>Estado</th><th>Velocidade</th>
    <th>Entrada</th><th>Saída</th><th>Uso</th><th>Erros</th></tr>${lista.map(i => {
      const uso = i.velocidade_mbps && i.bps_in != null ? Math.round(Math.max(i.bps_in, i.bps_out) / (i.velocidade_mbps * 1e4)) : null;
      return `<tr><td class="mono">${esc(i.nome)}</td><td>${esc(i.descricao)}</td>
        <td>${selo(i.estado === "up" ? "ok" : "alerta", i.estado)}</td><td>${i.velocidade_mbps ? bps(i.velocidade_mbps * 1e6) : "—"}</td>
        <td>${bps(i.bps_in)}</td><td>${bps(i.bps_out)}</td>
        <td>${uso == null ? "—" : `<span class="${uso >= 90 ? "txt-alerta" : uso >= 70 ? "txt-erro" : ""}">${uso}%</span>`}</td>
        <td>${i.erros_in ?? "—"}</td></tr>`;
    }).join("")}</table></div>`;
}

function formSites() {
  const d = E.dados.equipamentos || E.dados.painel;
  abrirModal("Sites / POPs", `
    ${d.sites.length ? `<div class="tabela"><table><tr><th>Site</th><th>Descrição</th><th>Equipamentos</th><th></th></tr>${d.sites.map(s => `<tr>
      <td><b>${esc(s.nome)}</b></td><td>${esc(s.descricao)}</td><td>${s.equipamentos}</td>
      <td class="acoes"><button class="pequeno" data-acao="editar-site" data-id="${s.id}">✏️</button>
      <button class="pequeno perigo" data-acao="remover-site" data-id="${s.id}">🗑</button></td></tr>`).join("")}</table></div>` : '<div class="sub">Nenhum site cadastrado.</div>'}
    <form class="form" id="form-site" data-form="site"><input type="hidden" name="id_site">
      <div class="campos"><div><label>Nome do site</label><input name="nome" placeholder="ex.: POP Centro" required></div>
      <div><label>Descrição</label><input name="descricao" placeholder="ex.: Rua X, rack 2"></div></div>
      <div class="form-botoes"><button class="primario" type="submit">💾 Salvar site</button><span class="msg"></span></div>
    </form>`);
}

// ======================================================================= tela: backups
function telaBackups(d) {
  if (!d.grupos.length) return vazio("Nenhum backup ainda. Os backups são feitos a cada verificação, quando a configuração muda.");
  return `<p class="sub">Um backup novo é guardado sempre que a configuração muda (e em todo "Backup + auditoria"). 🟡 = mudou em relação ao anterior.</p>
    <div class="grade">${d.grupos.map(g => `<div class="card ok">
    <div class="card-topo"><b>📁 ${esc(g.hostname)}</b>${selo("", `${g.total} backup${g.total !== 1 ? "s" : ""}`)}</div>
    <ul style="list-style:none;padding:0">${g.arquivos.map(a => `<li>${a.mudou ? "🟡 " : ""}${linkArquivo(a.arquivo, a.quando)} <span class="sub">${tamanho(a.tamanho)}</span></li>`).join("")}</ul>
    ${g.total > g.arquivos.length ? `<div class="sub">Mostrando os ${g.arquivos.length} mais recentes</div>` : ""}</div>`).join("")}</div>`;
}

// ======================================================================= tela: auditoria de segurança
function telaAuditoria(d) {
  const a = d.auditoria;
  if (!a) return vazio("Nenhuma auditoria feita ainda.", pode("operar") ? '<br><button class="primario" data-acao="backup">💾 Fazer backup + auditoria agora</button>' : "");
  const total = a.resultados.reduce((n, r) => n + r.problemas.length, 0);
  let h = `<p class="sub">Executada em ${esc(a.quando)} · ${total} problema(s) encontrado(s) em ${a.resultados.length} equipamento(s).</p><div class="grade">`;
  h += a.resultados.map(r => {
    const st = !r.ok ? "erro" : r.problemas.length ? "alerta" : "ok";
    const corpo = !r.ok ? `<div class="txt-erro">${esc(r.erro)}</div>`
      : r.problemas.length ? `<ul>${r.problemas.map(p => `<li>${selo(p.severidade, p.severidade)} ${esc(p.mensagem)}</li>`).join("")}</ul>`
      : '<div class="txt-ok">✓ Nenhum problema nas regras de auditoria</div>';
    const rot = st === "ok" ? "Seguro" : st === "alerta" ? `${r.problemas.length} problema${r.problemas.length > 1 ? "s" : ""}` : "Falhou";
    return `<div class="card ${st}"><div class="card-topo"><b>${esc(r.nome)}</b>${selo(st, rot)}</div>${corpo}</div>`;
  }).join("");
  return h + "</div>";
}


// ======================================================================= tela: manutenções
function cabManutencoes() {
  if (!pode("operar")) return '<p class="sub">Durante uma manutenção, os incidentes continuam registrados, mas os alertas não são enviados.</p>';
  return `<form class="form card neutro" data-form="manutencao" style="margin-bottom:16px">
    <h2>🛠 Agendar manutenção</h2><div class="sub">Silencia os alertas do alvo no período (os incidentes continuam sendo registrados).</div>
    <div class="campos">
      <div><label>Alvo</label><select name="alvo" id="alvo-manutencao"><option value="todos">Toda a rede</option></select></div>
      <div><label>Início</label><input name="inicio" type="datetime-local" required></div>
      <div><label>Fim</label><input name="fim" type="datetime-local" required></div>
      <div><label>Motivo</label><input name="motivo" placeholder="ex.: troca de fibra no POP Norte"></div>
    </div>
    <div class="form-botoes"><button class="primario" type="submit">Agendar</button><span class="msg"></span></div></form>`;
}

function telaManutencoes(d) {
  const sel = $("#alvo-manutencao");
  if (sel && !sel.dataset.pronto) {
    sel.innerHTML = '<option value="todos">Toda a rede</option>' +
      d.sites.map(s => `<option value="s:${s.id}">Site: ${esc(s.nome)}</option>`).join("") +
      d.equipamentos.map(e => `<option value="e:${esc(e.id)}">${esc(e.nome)} (${esc(e.host)})</option>`).join("");
    sel.dataset.pronto = "1";
    const agora = new Date(Date.now() - new Date().getTimezoneOffset() * 60000);
    const form = sel.form;
    form.inicio.value = agora.toISOString().slice(0, 16);
    form.fim.value = new Date(agora.getTime() + 2 * 3600000).toISOString().slice(0, 16);
  }
  if (!d.manutencoes.length) return vazio("Nenhuma manutenção agendada (nem nos últimos 30 dias).");
  const agora = new Date().toISOString().slice(0, 16).replace("T", " ");
  return `<div class="tabela"><table><tr><th>Alvo</th><th>Início</th><th>Fim</th><th>Motivo</th><th>Por</th><th>Situação</th><th></th></tr>${
    d.manutencoes.map(m => {
      const ativa = m.inicio <= agora && m.fim >= agora, futura = m.inicio > agora;
      return `<tr><td>${esc(m.equipamento || (m.site ? "Site: " + m.site : "Toda a rede"))}</td><td>${esc(m.inicio)}</td><td>${esc(m.fim)}</td>
        <td>${esc(m.motivo)}</td><td>${esc(m.criado_por)}</td>
        <td>${ativa ? selo("erro", "em andamento") : futura ? selo("baixa", "agendada") : selo("", "encerrada")}</td>
        <td class="acoes">${pode("operar") && (ativa || futura) ? `<button class="pequeno perigo" data-acao="remover-manutencao" data-id="${m.id}">Cancelar</button>` : ""}</td></tr>`;
    }).join("")}</table></div>`;
}

// ======================================================================= tela: relatórios
function cabRelatorios() {
  const meses = [];
  const hoje = new Date();
  for (let i = 0; i < 13; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const valor = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    meses.push(`<option value="${valor}">${d.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</option>`);
  }
  return `<div class="card neutro" style="max-width:640px"><h2>📄 Relatório mensal de segurança (PDF)</h2>
    <p class="sub">Resumo executivo, incidentes por tipo e por dia, ataques DDoS com pico e vetor, tempos médios de reconhecimento
    e resolução (MTTA/MTTR), alertas enviados e a última auditoria de configuração. Bom para enviar à diretoria ou a clientes corporativos.</p>
    <div class="form-botoes"><select id="mes-relatorio" style="width:auto">${meses.join("")}</select>
    <button class="primario" data-acao="baixar-relatorio">📄 Abrir PDF</button></div>
    <p class="sub" style="margin-top:12px">O nome no relatório é o configurado em 🔔 Alertas (padrão: o nome da empresa).</p></div>`;
}

// ======================================================================= tela: alertas (admin)
async function montarAlertas() {
  const d = await api("/api/config/alertas");
  if (E.aba !== "alertas") return;
  E.dados.alertas = d;
  const c = d.config, g = c.geral, w = c.whatsapp, m = c.email, t = c.telegram, h = c.webhook;
  const manter = def => def ? 'placeholder="•••••• (deixe em branco para manter)"' : "";
  const marcado = v => v ? "checked" : "";
  $("#cabecalho-tela").innerHTML = `
  <form class="form" data-form="alertas" autocomplete="off">
    <fieldset><legend>Geral</legend><div class="campos">
      <div><label>Nome da empresa</label><input name="geral.nome_empresa" value="${esc(g.nome_empresa)}"></div>
      <div><label>Endereço do painel (para o link nos alertas)</label><input name="geral.painel_url" value="${esc(g.painel_url)}" placeholder="https://sentinela.meuprovedor.com.br:8443"></div>
      <div><label>Severidade mínima para alertar</label><select name="geral.severidade_minima">${opcoes({ baixa: "Baixa (tudo)", media: "Média", alta: "Só alta" }, g.severidade_minima)}</select></div>
      <div><label>Escalonar se ninguém reconhecer em (min)</label><input name="geral.escalonar_minutos" type="number" min="0" value="${g.escalonar_minutos}"><div class="dica">0 = não escalonar</div></div>
      <div><label>Máximo de alertas a cada 5 min</label><input name="geral.max_alertas_5min" type="number" min="1" value="${g.max_alertas_5min}"><div class="dica">Evita enxurrada durante um evento grande</div></div>
    </div></fieldset>

    <fieldset><legend>WhatsApp</legend><div class="campos">
      <div><label>Integração</label><select name="whatsapp.modo">${opcoes({ desligado: "Desligado", meta: "API oficial da Meta (Cloud API)", evolution: "Evolution API (não oficial)" }, w.modo)}</select></div>
      <div data-wa="meta"><label>Phone Number ID</label><input name="whatsapp.meta_phone_id" value="${esc(w.meta_phone_id)}"></div>
      <div data-wa="meta"><label>Token de acesso</label><input name="whatsapp.meta_token" type="password" ${manter(w.meta_token_definido)}></div>
      <div data-wa="meta"><label>Nome do modelo aprovado</label><input name="whatsapp.meta_modelo" value="${esc(w.meta_modelo)}"><div class="dica">Modelo com 1 variável no corpo, ex.: "Alerta Sentinela: {{1}}"</div></div>
      <div data-wa="meta"><label>Idioma do modelo</label><input name="whatsapp.meta_idioma" value="${esc(w.meta_idioma)}"></div>
      <div data-wa="meta"><label>Versão da Graph API</label><input name="whatsapp.meta_versao" value="${esc(w.meta_versao)}"></div>
      <div data-wa="evolution"><label>URL da Evolution API</label><input name="whatsapp.evolution_url" value="${esc(w.evolution_url)}" placeholder="https://evolution.meuprovedor.com.br"></div>
      <div data-wa="evolution"><label>Instância</label><input name="whatsapp.evolution_instancia" value="${esc(w.evolution_instancia)}"></div>
      <div data-wa="evolution"><label>API key</label><input name="whatsapp.evolution_chave" type="password" ${manter(w.evolution_chave_definido)}></div>
      <div data-wa="evolution"><label><input type="checkbox" name="whatsapp.evolution_v1" ${marcado(w.evolution_v1)}> Evolution API versão 1 (antiga)</label></div>
    </div>
    <div class="form-botoes"><input id="teste-whatsapp" placeholder="Celular para teste: 48 99999-0000" style="max-width:260px">
      <button type="button" data-acao="testar-alerta" data-canal="whatsapp">📲 Enviar teste</button></div></fieldset>

    <fieldset><legend>E-mail (SMTP)</legend><div class="campos">
      <div><label><input type="checkbox" name="email.ativo" ${marcado(m.ativo)}> Enviar alertas por e-mail</label></div>
      <div><label>Servidor SMTP</label><input name="email.servidor" value="${esc(m.servidor)}" placeholder="smtp.gmail.com"></div>
      <div><label>Porta</label><input name="email.porta" type="number" value="${m.porta}"></div>
      <div><label>Segurança</label><select name="email.seguranca">${opcoes({ starttls: "STARTTLS (587)", ssl: "SSL/TLS (465)", nenhuma: "Nenhuma (não recomendado)" }, m.seguranca)}</select></div>
      <div><label>Usuário</label><input name="email.usuario" value="${esc(m.usuario)}"></div>
      <div><label>Senha</label><input name="email.senha" type="password" ${manter(m.senha_definido)}></div>
      <div><label>Remetente</label><input name="email.remetente" value="${esc(m.remetente)}" placeholder="Sentinela <noc@meuprovedor.com.br>"></div>
    </div>
    <div class="form-botoes"><input id="teste-email" placeholder="E-mail para teste" style="max-width:260px">
      <button type="button" data-acao="testar-alerta" data-canal="email">✉ Enviar teste</button></div></fieldset>

    <fieldset><legend>Telegram (grupo do NOC)</legend><div class="campos">
      <div><label><input type="checkbox" name="telegram.ativo" ${marcado(t.ativo)}> Enviar para um grupo do Telegram</label></div>
      <div><label>Token do bot (@BotFather)</label><input name="telegram.token" type="password" ${manter(t.token_definido)}></div>
      <div><label>Chat ID do grupo</label><input name="telegram.chat_id" value="${esc(t.chat_id)}" placeholder="-1001234567890"></div>
    </div><div class="form-botoes"><button type="button" data-acao="testar-alerta" data-canal="telegram">Enviar teste</button></div></fieldset>

    <fieldset><legend>Webhook (Zabbix, n8n, Slack, Discord, sistema próprio...)</legend><div class="campos">
      <div><label><input type="checkbox" name="webhook.ativo" ${marcado(h.ativo)}> Enviar cada incidente por webhook (JSON)</label></div>
      <div><label>URL</label><input name="webhook.url" value="${esc(h.url)}" placeholder="https://..."></div>
      <div><label>Segredo para assinatura (opcional)</label><input name="webhook.segredo" type="password" ${manter(h.segredo_definido)}>
        <div class="dica">Enviado como X-Sentinela-Assinatura: sha256=HMAC(corpo)</div></div>
    </div><div class="form-botoes"><button type="button" data-acao="testar-alerta" data-canal="webhook">Enviar teste</button></div></fieldset>

    <div class="form-botoes"><button class="primario" type="submit">💾 Salvar configuração de alertas</button><span class="msg"></span></div>
  </form>

  <h3>Escala de plantão</h3>
  <p class="sub">Nível 1 recebe na hora. Se ninguém reconhecer o incidente no prazo, avisa o nível 2, depois o nível 3.
    O WhatsApp e o e-mail de cada pessoa vêm do cadastro de usuários.</p>
  <div class="tabela"><table><tr><th>Usuário</th><th>Contato</th><th>Nível de plantão</th><th>WhatsApp</th><th>E-mail</th></tr>${
    d.plantao.map(u => `<tr data-plantao="${u.id}"><td><b>${esc(u.usuario)}</b><div class="sub">${esc(u.nome)}</div></td>
      <td class="sub">${esc(u.telefone || "sem celular")}<br>${esc(u.email || "sem e-mail")}</td>
      <td><select data-campo="nivel" style="width:auto">${opcoes({ 0: "Não recebe", 1: "Nível 1 (imediato)", 2: "Nível 2", 3: "Nível 3 (gerência)" }, u.nivel)}</select></td>
      <td><input type="checkbox" data-campo="whatsapp" ${marcado(u.whatsapp)}></td><td><input type="checkbox" data-campo="email" ${marcado(u.quer_email)}></td></tr>`).join("")}
  </table></div>

  <h3>Últimos envios</h3>
  ${d.envios.length ? `<div class="tabela"><table><tr><th>Quando</th><th>Incidente</th><th>Canal</th><th>Destino</th><th>Nível</th><th>Resultado</th></tr>${
    d.envios.map(e => `<tr><td>${esc(e.quando)}</td><td>#${e.incidente_id ?? "—"}</td><td>${esc(e.canal)}</td><td>${esc(e.destino)}</td>
      <td>${e.nivel}</td><td>${e.ok ? '<span class="txt-ok">✓ enviado</span>' : `<span class="txt-alerta">✗ ${esc(e.erro)}</span>`}</td></tr>`).join("")}</table></div>`
    : vazio("Nenhum alerta enviado ainda.")}`;
  ajustarWhatsapp();
}

function ajustarWhatsapp() {
  const sel = $("[name='whatsapp.modo']");
  if (!sel) return;
  $$("[data-wa]").forEach(el => { el.hidden = el.dataset.wa !== sel.value; });
}

// ======================================================================= tela: usuários
function cabUsuarios() {
  return `<div class="barra-ferramentas"><button class="primario" data-acao="novo-usuario">➕ Novo usuário</button>
    <span class="sub">Administrador: tudo · Operador (NOC): verificar, backup, incidentes e mitigação · Leitura: só visualiza</span></div>`;
}
const buscarUsuario = id => E.dados.usuarios?.usuarios.find(u => String(u.id) === String(id));

function telaUsuarios(d) {
  return `<div class="tabela"><table><tr><th>Usuário</th><th>Perfil</th><th>Contato</th><th>2FA</th><th>Último login</th><th></th></tr>${
    d.usuarios.map(u => `<tr>
      <td><b>${esc(u.usuario)}</b><div class="sub">${esc(u.nome)}</div>${!u.ativo ? '<div class="txt-erro" style="font-size:12px">desativado</div>' : ""}</td>
      <td>${esc(u.papel_nome)}</td>
      <td class="sub">${esc(u.email)}<br>${esc(u.telefone)}</td>
      <td>${u.totp_ativo ? '<span class="txt-ok">✓ ativo</span>' : '<span class="sub">não</span>'}</td>
      <td class="sub">${esc(u.ultimo_login || "nunca")}${u.trocar_senha ? '<div class="txt-erro">troca de senha pendente</div>' : ""}</td>
      <td class="acoes"><button class="pequeno" data-acao="editar-usuario" data-id="${u.id}">✏️</button>
        <button class="pequeno" data-acao="senha-usuario" data-id="${u.id}">🔑 Senha</button>
        ${u.totp_ativo ? `<button class="pequeno" data-acao="remover-2fa-usuario" data-id="${u.id}">Remover 2FA</button>` : ""}
        ${u.usuario !== E.sessao.usuario ? `<button class="pequeno perigo" data-acao="remover-usuario" data-id="${u.id}">🗑</button>` : ""}</td>
    </tr>`).join("")}</table></div>`;
}

function formUsuario(id) {
  const u = id ? buscarUsuario(id) : null;
  const papeis = E.dados.usuarios.papeis;
  abrirModal(u ? `Editar ${u.usuario}` : "Novo usuário", `
    <form class="form" data-form="usuario" autocomplete="off"><input type="hidden" name="id" value="${u?.id || ""}">
      <div class="campos">
        ${u ? "" : '<div><label>Usuário *</label><input name="usuario" required></div>'}
        <div><label>Nome completo</label><input name="nome" value="${esc(u?.nome || "")}"></div>
        <div><label>Perfil *</label><select name="papel">${opcoes(papeis, u?.papel || "leitura")}</select></div>
        <div><label>E-mail (alertas)</label><input name="email" type="email" value="${esc(u?.email || "")}"></div>
        <div><label>Celular/WhatsApp (alertas)</label><input name="telefone" value="${esc(u?.telefone || "")}" placeholder="+55 48 99999-0000"></div>
        ${u ? "" : '<div><label>Senha provisória *</label><input name="senha" type="password" autocomplete="new-password" required></div>'}
      </div>
      ${u ? `<label><input type="checkbox" name="ativo" ${u.ativo ? "checked" : ""}> Usuário ativo</label>` : '<div class="dica">O usuário vai trocar a senha provisória no primeiro login.</div>'}
      <div class="form-botoes"><button class="primario" type="submit">💾 Salvar</button><span class="msg"></span></div>
    </form>`);
}

function formSenhaUsuario(id) {
  const u = buscarUsuario(id);
  abrirModal(`Redefinir a senha de ${u.usuario}`, `
    <form class="form" data-form="senha-usuario"><input type="hidden" name="id" value="${u.id}">
      <label>Nova senha provisória</label><input name="senha" type="password" autocomplete="new-password" required>
      <div class="dica">O usuário vai trocá-la no próximo login, e as sessões abertas dele serão encerradas.</div>
      <div class="form-botoes"><button class="primario" type="submit">Redefinir</button><span class="msg"></span></div>
    </form>`);
}

// ======================================================================= tela: registro de atividades
function cabAtividades() {
  return `<div class="barra-ferramentas"><input id="busca-atividades" data-recarregar placeholder="🔎 Buscar usuário, ação, IP...">
    <button data-acao="recarregar">Buscar</button><span class="sub">Tudo que foi feito no painel fica registrado aqui.</span></div>`;
}
function telaAtividades(d) {
  if (!d.registros.length) return vazio("Nenhum registro.");
  return `<div class="tabela"><table><tr><th>Quando</th><th>Usuário</th><th>IP</th><th>Ação</th><th>Alvo</th><th>Detalhes</th></tr>${
    d.registros.map(r => `<tr><td style="white-space:nowrap">${esc(r.quando)}</td><td>${esc(r.usuario)}</td><td class="mono">${esc(r.ip)}</td>
      <td><b>${esc(r.acao)}</b></td><td>${esc(r.alvo)}</td><td class="sub">${esc(r.detalhes)}</td></tr>`).join("")}</table></div>`;
}

// ======================================================================= tela: empresas (fornecedor)
const buscarEmpresa = id => E.dados.empresas?.empresas.find(e => e.id === id);
const SITUACAO = { ok: ["ok", "Ativa"], suspensa: ["alerta", "Suspensa"], vencida: ["alerta", "Licença vencida"] };

function cabEmpresas() {
  return `<div class="barra-ferramentas"><button class="primario" data-acao="nova-empresa">➕ Nova empresa (provedor)</button>
    <button data-acao="auditoria-fornecedor">📜 Auditoria de todas as empresas</button>
    <span class="sub">Cada provedor vê só os próprios equipamentos, incidentes e usuários. Use o seletor no topo para entrar em uma empresa (suporte).</span></div>`;
}

function telaEmpresas(d) {
  setTimeout(montarEquipeFornecedor, 0);
  const ativas = d.empresas.filter(e => e.situacao === "ok").length;
  const equip = d.empresas.reduce((n, e) => n + e.equipamentos, 0);
  let h = `<div class="contadores">
    <div class="contador"><b>${d.empresas.length}</b><span>empresas</span></div>
    <div class="contador"><b>${ativas}</b><span>ativas</span></div>
    <div class="contador"><b>${equip}</b><span>equipamentos monitorados</span></div>
    <div class="contador ${d.empresas.some(e => e.ataques_ativos) ? "ataque" : ""}"><b>${d.empresas.reduce((n, e) => n + e.ataques_ativos, 0)}</b><span>sob ataque agora</span></div></div>`;
  h += d.empresas.length ? `<div class="tabela"><table><tr><th>Empresa</th><th>Plano / licença</th><th>Equipamentos</th><th>Usuários</th><th>Agora</th><th>Situação</th><th></th></tr>${
    d.empresas.map(e => {
      const [cls, rot] = SITUACAO[e.situacao] || ["", e.situacao];
      const limite = e.limite_equipamentos ? ` / ${e.limite_equipamentos}` : "";
      const cheio = e.limite_equipamentos && e.equipamentos >= e.limite_equipamentos;
      return `<tr><td><b>${esc(e.nome)}</b><div class="sub">${esc(e.documento || "")}${e.contato ? " · " + esc(e.contato) : ""}</div>
          ${e.asn ? `<div class="sub mono">AS${e.asn}</div>` : ""}</td>
        <td>${esc(e.plano || "—")}<div class="sub">${e.validade ? "válida até " + esc(e.validade.split("-").reverse().join("/")) : "sem vencimento"}</div></td>
        <td class="${cheio ? "txt-alerta" : ""}">${e.equipamentos}${limite}</td><td>${e.usuarios}</td>
        <td>${e.ataques_ativos ? selo("ataque", `● ${e.ataques_ativos} sob ataque`) : ""}${e.incidentes_abertos ? `<div class="sub">${e.incidentes_abertos} incidente(s) aberto(s)</div>` : ""}</td>
        <td>${selo(cls, rot)}${e.situacao_texto && e.situacao === "ok" ? `<div class="txt-erro" style="font-size:12px">${esc(e.situacao_texto)}</div>` : ""}</td>
        <td class="acoes"><button class="pequeno primario" data-acao="entrar-empresa" data-id="${e.id}">➜ Entrar</button>
          <button class="pequeno" data-acao="editar-empresa" data-id="${e.id}">✏️</button>
          <button class="pequeno" data-acao="suspender-empresa" data-id="${e.id}">${e.ativo ? "⏸ Suspender" : "▶ Reativar"}</button>
          <button class="pequeno perigo" data-acao="remover-empresa" data-id="${e.id}">🗑</button></td></tr>`;
    }).join("")}</table></div>`
    : vazio("Nenhuma empresa cadastrada.", '<br><button class="primario" data-acao="nova-empresa">➕ Cadastrar a primeira</button>');
  return h + '<div id="equipe-fornecedor"></div><div id="auditoria-fornecedor"></div>';
}

function formEmpresa(id) {
  const e = id ? buscarEmpresa(id) : null;
  abrirModal(e ? `Editar ${e.nome}` : "Nova empresa (provedor cliente)", `
    <form class="form" data-form="empresa" autocomplete="off"><input type="hidden" name="id" value="${e?.id || ""}">
      <div class="campos">
        <div><label>Nome da empresa *</label><input name="nome" value="${esc(e?.nome || "")}" required></div>
        <div><label>CNPJ</label><input name="documento" value="${esc(e?.documento || "")}"></div>
        <div><label>Responsável</label><input name="contato" value="${esc(e?.contato || "")}"></div>
        <div><label>E-mail</label><input name="email" type="email" value="${esc(e?.email || "")}"></div>
        <div><label>Telefone</label><input name="telefone" value="${esc(e?.telefone || "")}"></div>
      </div>
      <fieldset><legend>Licença</legend><div class="campos">
        <div><label>Plano</label><input name="plano" value="${esc(e?.plano || "")}" placeholder="ex.: Básico, Pro, Enterprise"></div>
        <div><label>Limite de equipamentos</label><input name="limite_equipamentos" type="number" min="0" value="${e?.limite_equipamentos ?? 0}"><div class="dica">0 = sem limite</div></div>
        <div><label>Válida até</label><input name="validade" type="date" value="${esc(e?.validade || "")}"><div class="dica">Em branco = sem vencimento. Vencida, o acesso é bloqueado.</div></div>
      </div><label><input type="checkbox" name="ativo" ${!e || e.ativo ? "checked" : ""}> Empresa ativa</label></fieldset>
      <fieldset><legend>Rede do provedor (o administrador dele também pode editar)</legend><div class="campos">
        <div><label>ASN</label><input name="asn" type="number" min="0" value="${e?.asn || ""}" placeholder="ex.: 264000"></div>
        <div><label>Blocos de IP (um por linha)</label><textarea name="redes" rows="3" placeholder="177.10.0.0/22&#10;2804:abcd::/32">${esc((e?.redes || []).join("\n"))}</textarea>
          <div class="dica">Usados na detecção de DDoS e para limitar a mitigação aos IPs do próprio provedor.</div></div>
        <div><label>Prefixos anunciados no BGP (RPKI)</label><textarea name="prefixos" rows="3" placeholder="em branco = os blocos de IP">${esc((e?.prefixos || []).join("\n"))}</textarea></div>
      </div></fieldset>
      ${e ? "" : `<fieldset><legend>Primeiro administrador do provedor</legend><div class="campos">
        <div><label>Usuário</label><input name="admin_usuario" placeholder="ex.: admin.provedorx"></div>
        <div><label>Nome</label><input name="admin_nome"></div>
        <div><label>E-mail</label><input name="admin_email" type="email"></div>
        <div><label>Celular/WhatsApp</label><input name="admin_telefone"></div>
        <div><label>Senha provisória</label><input name="admin_senha" type="password" autocomplete="new-password"></div>
      </div><div class="dica">Ele troca a senha no primeiro login e cadastra os equipamentos e a equipe do provedor.</div></fieldset>`}
      <label>Observações internas</label><textarea name="observacoes" rows="2">${esc(e?.observacoes || "")}</textarea>
      <div class="form-botoes"><button class="primario" type="submit">💾 Salvar</button><span class="msg"></span></div>
    </form>`, true);
}

async function montarEquipeFornecedor() {
  const alvo = $("#equipe-fornecedor");
  if (!alvo) return;
  const d = await api("/api/fornecedor/usuarios");
  if (!$("#equipe-fornecedor")) return;
  $("#equipe-fornecedor").innerHTML = `<h3>Equipe do fornecedor</h3>
    <div class="barra-ferramentas"><button class="pequeno" data-acao="novo-usuario-fornecedor">➕ Novo usuário do fornecedor</button></div>
    <div class="tabela"><table><tr><th>Usuário</th><th>Contato</th><th>2FA</th><th>Último login</th><th></th></tr>${
    d.usuarios.map(u => `<tr><td><b>${esc(u.usuario)}</b><div class="sub">${esc(u.nome)}</div></td><td class="sub">${esc(u.email)}</td>
      <td>${u.totp_ativo ? '<span class="txt-ok">✓ ativo</span>' : '<span class="txt-alerta">não</span>'}</td>
      <td class="sub">${esc(u.ultimo_login || "nunca")}</td>
      <td class="acoes">${u.usuario !== E.sessao.usuario ? `<button class="pequeno perigo" data-acao="remover-usuario-fornecedor" data-id="${u.id}">🗑</button>` : ""}</td></tr>`).join("")}
    </table></div><p class="sub">Recomendado: 2FA ativo para toda a equipe do fornecedor (eles acessam todas as empresas).</p>`;
}

async function montarAuditoriaFornecedor() {
  const busca = $("#busca-forn")?.value || "";
  const d = await api("/api/fornecedor/auditoria?busca=" + encodeURIComponent(busca));
  const alvo = $("#auditoria-fornecedor");
  if (!alvo) return;
  alvo.innerHTML = `<h3>Auditoria de todas as empresas</h3>
    <div class="barra-ferramentas"><input id="busca-forn" placeholder="🔎 Empresa, usuário, ação, IP..." value="${esc(busca)}">
    <button data-acao="auditoria-fornecedor">Buscar</button></div>
    ${d.registros.length ? `<div class="tabela"><table><tr><th>Quando</th><th>Empresa</th><th>Usuário</th><th>IP</th><th>Ação</th><th>Alvo</th></tr>${
      d.registros.map(r => `<tr><td style="white-space:nowrap">${esc(r.quando)}</td><td>${esc(r.empresa || "—")}</td><td>${esc(r.usuario)}</td>
        <td class="mono">${esc(r.ip)}</td><td><b>${esc(r.acao)}</b></td><td>${esc(r.alvo)}</td></tr>`).join("")}</table></div>` : vazio("Nenhum registro.")}`;
  alvo.scrollIntoView({ behavior: "smooth" });
}

// ======================================================================= tela: minha empresa
function telaMinhaEmpresa(d) {
  const e = d.empresa;
  const [cls, rot] = SITUACAO[e.situacao] || ["", e.situacao];
  const linhas = l => esc((l || []).join("\n"));
  return `<div class="grade">
    <div class="card ${cls}"><div class="card-topo"><b>🏢 ${esc(e.nome)}</b>${selo(cls, rot)}</div>
      <div>Plano: <b>${esc(e.plano || "—")}</b></div>
      <div>Equipamentos: <b>${d.equipamentos_usados}${e.limite_equipamentos ? " de " + e.limite_equipamentos : ""}</b></div>
      <div>Licença: <b>${e.validade ? "válida até " + esc(e.validade.split("-").reverse().join("/")) : "sem vencimento"}</b></div>
      ${e.situacao_texto ? `<div class="txt-alerta" style="margin-top:6px">${esc(e.situacao_texto)}</div>` : ""}
      <div class="sub" style="margin-top:8px">Para mudar o plano ou o limite, fale com o fornecedor do sistema.</div></div>
  </div>
  <h3>Rede da empresa</h3>
  <form class="form card neutro" data-form="rede-empresa" style="max-width:720px">
    <div class="campos">
      <div><label>ASN</label><input name="asn" type="number" min="0" value="${e.asn || ""}" placeholder="ex.: 264000"></div>
      <div><label>Blocos de IP da empresa (um por linha)</label><textarea name="redes" rows="4" placeholder="177.10.0.0/22&#10;2804:abcd::/32">${linhas(e.redes)}</textarea>
        <div class="dica">DDoS: só o tráfego para estes blocos é analisado. Mitigação: só estes IPs podem receber RTBH.</div></div>
      <div><label>Prefixos anunciados no BGP</label><textarea name="prefixos" rows="4" placeholder="em branco = os mesmos blocos acima">${linhas(e.prefixos)}</textarea>
        <div class="dica">Conferidos no RIPEstat (RPKI e sequestro de prefixo).</div></div>
    </div>
    <div class="form-botoes"><button class="primario" type="submit">💾 Salvar</button><span class="msg"></span></div>
  </form>`;
}

// ======================================================================= tela: licença da instalação
function telaLicenca(d) {
  const l = d.licenca, u = d.uso;
  const cls = l.valida ? (l.aviso ? "alerta" : "ok") : "erro";
  const data = l.expira ? new Date(l.expira).toLocaleDateString("pt-BR") : "—";
  const limite = (usado, max) => `<b>${usado}</b>${max ? " de " + max : " (sem limite)"}`;
  const digitado = $("#conteudo textarea[name=codigo]")?.value || "";  // não perde o que já foi colado
  return `<div class="grade">
    <div class="card ${cls}"><div class="card-topo"><b>🔑 Licença deste servidor</b>${selo(l.valida ? "ok" : "alerta", l.valida ? "Ativa" : "Inativa")}</div>
      <div>${esc(l.texto)}</div>
      ${l.valida ? `<div>Dias restantes: <b>${l.dias_restantes}</b></div>` : ""}
      ${l.licenca_id ? `<div>Licença nº <b>${l.licenca_id}</b> · vence em <b>${esc(data)}</b></div>` : ""}
      ${l.licenca_id ? `<div>Equipamentos: ${limite(u.equipamentos, l.limite_equipamentos)}</div>
      <div>Empresas: ${limite(u.empresas, l.limite_empresas)}</div>` : ""}
      <div class="sub" style="margin-top:8px">ID do servidor: <span class="mono">${esc(l.maquina)}</span></div>
      ${l.aviso ? `<div class="txt-alerta" style="margin-top:6px">${esc(l.aviso)}</div>` : ""}
      ${!l.valida ? '<div class="txt-alerta" style="margin-top:6px">O monitoramento está parado. Os dados continuam guardados.</div>' : ""}
    </div>
  </div>
  <h3>${l.valida ? "Renovar" : "Ativar"} o sistema</h3>
  <div class="card neutro" style="max-width:820px">
    <p><b>1.</b> Envie este <b>serial</b> ao fornecedor (e-mail, WhatsApp...).
      ${l.valida ? "Pode renovar antes de vencer: os dias que faltam não se perdem." : ""}</p>
    <div class="segredo serial">${esc(d.serial)}</div>
    <div class="form-botoes"><button data-acao="copiar" data-texto="${esc(d.serial)}">📋 Copiar serial</button></div>
    <p style="margin-top:16px"><b>2.</b> Cole aqui a chave de liberação que o fornecedor enviar:</p>
    <form class="form" data-form="licenca-ativar">
      <textarea name="codigo" rows="4" class="mono" placeholder="JQAQP-35A4Y-W3C63-..." required>${esc(digitado)}</textarea>
      <div class="form-botoes"><button class="primario" type="submit">✔ Ativar</button><span class="msg"></span></div>
    </form>
  </div>`;
}

// ======================================================================= tela: minha conta
function cabConta() {
  const s = E.sessao;
  return `<div class="grade">
    <div class="card neutro"><h2>👤 ${esc(s.nome || s.usuario)}</h2><div class="sub">Usuário: ${esc(s.usuario)}<br>Perfil: ${esc(s.papel_nome)}</div></div>
    <div class="card ${s.totp_ativo ? "ok" : "erro"}"><h2>🔐 Verificação em duas etapas</h2>
      <p class="sub">${s.totp_ativo ? "Ativa: além da senha, o login pede um código do celular." : "Desativada. Recomendado para todos, obrigatório na prática para administradores."}</p>
      ${s.totp_ativo ? '<button data-acao="conta-2fa-desativar" class="perigo">Desativar</button>' : '<button class="primario" data-acao="conta-2fa-iniciar">Ativar 2FA</button>'}</div>
  </div>
  <h3>Trocar senha</h3>
  <form class="form card neutro" data-form="trocar-senha" style="max-width:520px">
    <label>Senha atual</label><input name="atual" type="password" autocomplete="current-password" required>
    <label>Nova senha</label><input name="nova" type="password" autocomplete="new-password" required>
    <label>Repita a nova senha</label><input name="nova2" type="password" autocomplete="new-password" required>
    <div class="form-botoes"><button class="primario" type="submit">Trocar senha</button><span class="msg"></span></div>
  </form>`;
}

async function verIncidente(id) {
  const d = E.dados.incidentes;
  const i = d?.incidentes.find(x => String(x.id) === String(id));
  if (!i) return;
  abrirModal(`Incidente #${i.id}`, `<p><b>${esc(i.tipo)}</b> em ${esc(i.equipamento)}</p><p>${esc(i.detalhes)}</p>`);
}

// ======================================================================= início
iniciar();
