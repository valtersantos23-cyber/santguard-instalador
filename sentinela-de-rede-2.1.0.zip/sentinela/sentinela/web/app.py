"""Painel web (Flask): login, permissões, API e arquivos da interface.

MULTIEMPRESA: cada requisição roda no contexto de UMA empresa (g.empresa_id):
  - usuário de provedor: sempre a empresa do cadastro dele;
  - fornecedor: a empresa escolhida no seletor (suporte), e só ele acessa /api/fornecedor/*.
Toda consulta e alteração filtra por g.empresa_id. Um ID de outra empresa é tratado como inexistente.
"""

import functools
import ipaddress
import json
import pathlib
import threading

from flask import Flask, g, jsonify, request, send_from_directory

from .. import VERSAO, armazenamento, autenticacao as auth, banco, cofre, empresas, equipamentos, incidentes
from .. import licenca
from .. import fabricantes as fab
from ..config import CFG
from ..monitor import MONITOR
from ..tempo_real import TEMPO_REAL

PASTA_ESTATICA = pathlib.Path(__file__).parent / "static"

# Rotas da API que funcionam sem login
ROTAS_PUBLICAS = {"/api/sessao", "/api/login", "/api/login/2fa", "/api/configurar-admin",
                  "/api/registro", "/api/registro/ativar"}
# Rotas liberadas para quem ainda precisa trocar a senha ou configurar o 2FA obrigatório
ROTAS_RESTRITAS_OK = {"/api/sessao", "/api/logout", "/api/minha-conta/senha", "/api/minha-conta/2fa/iniciar",
                      "/api/minha-conta/2fa/confirmar"}
# Rotas que não dependem de uma empresa selecionada
ROTAS_SEM_EMPRESA = ROTAS_RESTRITAS_OK | {"/api/minha-conta/2fa/desativar"}
# Rotas que funcionam mesmo sem licença válida da instalação (para conseguir ativar)
ROTAS_SEM_LICENCA = ROTAS_SEM_EMPRESA | {"/api/fornecedor/licenca", "/api/fornecedor/licenca/solicitar",
                                        "/api/fornecedor/licenca/ativar"}

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB por requisição


# ======================================================================= utilidades

def erro(mensagem, codigo=400):
    return jsonify({"ok": False, "mensagem": mensagem}), codigo


def ok(mensagem="OK", **extra):
    return jsonify({"ok": True, "mensagem": mensagem, **extra})


def ip_cliente():
    return request.remote_addr or ""


def corpo():
    dados = request.get_json(silent=True)
    return dados if isinstance(dados, dict) else {}


def usuario_atual():
    return g.sessao["usuario"] if getattr(g, "sessao", None) else ""


def empresa_atual():
    """Empresa da requisição. Nunca None dentro das rotas de empresa (garantido no before_request)."""
    return g.empresa_id


def eh_fornecedor():
    return bool(getattr(g, "sessao", None) and g.sessao["fornecedor"])


def auditar(acao, alvo="", detalhes=""):
    quem = usuario_atual() + (" (fornecedor)" if eh_fornecedor() else "")
    auth.auditar(quem, ip_cliente(), acao, alvo, detalhes, empresa_id=getattr(g, "empresa_id", None))


def requer(permissao):
    def decorador(funcao):
        @functools.wraps(funcao)
        def interna(*args, **kwargs):
            if not auth.pode(g.sessao["papel"], permissao, g.sessao["fornecedor"]):
                return erro("Seu perfil não tem permissão para isso", 403)
            return funcao(*args, **kwargs)
        return interna
    return decorador


def precisa_configurar_2fa(sessao):
    eh_admin = sessao["papel"] == "admin" or sessao["fornecedor"]
    return bool(CFG["seguranca"]["exigir_2fa_admin"]) and eh_admin and not sessao["totp_ativo"]


# ======================================================================= segurança de cada requisição

@app.before_request
def verificar_acesso():
    g.sessao = None
    g.empresa_id = None
    token = request.cookies.get(auth.NOME_COOKIE)
    sessao = auth.obter_sessao(token) if token else None
    g.token = token

    caminho = request.path
    if not caminho.startswith("/api/"):
        return None

    # Toda ação (POST) exige um cabeçalho próprio: navegadores não deixam outro site enviá-lo
    if request.method == "POST" and request.headers.get("X-Sentinela") != "1":
        return erro("Requisição bloqueada", 403)

    if caminho in ROTAS_PUBLICAS or (caminho == "/api/login/2fa" and sessao):
        g.sessao = sessao
        return None

    if not sessao or not sessao["mfa_ok"]:
        return erro("Faça login para continuar", 401)
    g.sessao = sessao
    g.empresa_id = sessao["empresa_id"]

    if request.method == "POST" and request.headers.get("X-CSRF-Token") != sessao["csrf"]:
        return erro("Sessão inválida. Atualize a página.", 403)

    if (sessao["trocar_senha"] or precisa_configurar_2fa(sessao)) and caminho not in ROTAS_RESTRITAS_OK:
        return erro("Troque sua senha / configure o 2FA antes de continuar", 403)

    if caminho.startswith("/api/fornecedor/") and not sessao["fornecedor"]:
        return erro("Área exclusiva do fornecedor", 403)

    # Licença da instalação: sem ela, só a ativação (e a própria conta) continuam disponíveis
    if caminho not in ROTAS_SEM_LICENCA:
        lic = licenca.estado()
        if not lic["valida"]:
            if sessao["fornecedor"]:
                return erro(f"{lic['texto']}. Ative o sistema na aba Licença.", 402)
            return erro(f"{lic['texto']}. Avise o administrador do sistema.", 402)

    if caminho.startswith("/api/fornecedor/"):
        return None

    if caminho in ROTAS_SEM_EMPRESA:
        return None

    # Licença: provedor suspenso ou vencido perde o acesso na hora (mesmo com sessão aberta)
    empresa = empresas.obter(g.empresa_id)
    if not empresa:
        return erro("Selecione uma empresa" if sessao["fornecedor"] else "Empresa não encontrada", 409)
    if empresa["situacao"] != "ok" and not sessao["fornecedor"]:
        return erro(f"{empresa['situacao_texto']}. Fale com o fornecedor do sistema.", 403)
    return None


@app.after_request
def cabecalhos_seguranca(resposta):
    if resposta.mimetype != "application/pdf":  # o visualizador de PDF do navegador não convive bem com CSP
        resposta.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
    resposta.headers["X-Content-Type-Options"] = "nosniff"
    resposta.headers["X-Frame-Options"] = "DENY"
    resposta.headers["Referrer-Policy"] = "no-referrer"
    resposta.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.path.startswith("/api/"):
        resposta.headers["Cache-Control"] = "no-store"
    if request.is_secure:
        resposta.headers["Strict-Transport-Security"] = "max-age=31536000"
    return resposta


def gravar_cookie(resposta, token, duracao):
    resposta.set_cookie(auth.NOME_COOKIE, token, max_age=duracao, httponly=True, secure=request.is_secure,
                        samesite="Strict", path="/")
    return resposta


# ======================================================================= páginas

@app.get("/")
def pagina_inicial():
    return send_from_directory(PASTA_ESTATICA, "index.html")


@app.get("/static/<path:arquivo>")
def estaticos(arquivo):
    return send_from_directory(PASTA_ESTATICA, arquivo)


# ======================================================================= login e conta

def dados_sessao(sessao):
    fornecedor = bool(sessao["fornecedor"])
    papel = "admin" if fornecedor else sessao["papel"]
    empresa = empresas.obter(sessao["empresa_id"])
    dados = {
        "logado": True, "usuario": sessao["usuario"], "nome": sessao["nome"], "papel": papel,
        "papel_nome": auth.NOME_FORNECEDOR if fornecedor else auth.NOMES_PAPEIS[papel], "csrf": sessao["csrf"],
        "permissoes": sorted(auth.PERMISSOES[papel] | ({"fornecedor"} if fornecedor else set())),
        "trocar_senha": bool(sessao["trocar_senha"]), "totp_ativo": bool(sessao["totp_ativo"]),
        "configurar_2fa": precisa_configurar_2fa(sessao), "fornecedor": fornecedor,
        "empresa": {"id": empresa["id"], "nome": empresa["nome"], "situacao": empresa["situacao"],
                    "aviso": empresa["situacao_texto"]} if empresa else None,
    }
    lic = licenca.estado()
    dados["licenca"] = {"valida": lic["valida"], "situacao": lic["situacao"], "texto": lic["texto"],
                        "aviso": lic["aviso"] if fornecedor else ""}
    if fornecedor:
        dados["empresas"] = [{"id": e["id"], "nome": e["nome"], "situacao": e["situacao"]}
                             for e in (empresas.obter(l["id"]) for l in banco.consultar(
                                 "SELECT id FROM empresas ORDER BY lower(nome)"))]
    return dados


@app.get("/api/sessao")
def api_sessao():
    s = g.sessao
    base = {"versao": VERSAO, "configurado": auth.contar_usuarios() > 0, "local": _eh_local(ip_cliente())}
    if s and s["mfa_ok"]:
        return jsonify({**base, **dados_sessao(s)})
    return jsonify({**base, "logado": False, "precisa_2fa": bool(s and not s["mfa_ok"])})


def _eh_local(ip):
    try:
        return ipaddress.ip_address(ip).is_loopback
    except ValueError:
        return False


@app.post("/api/configurar-admin")
def api_configurar_admin():
    """Primeiro acesso: cria o FORNECEDOR. Só funciona sem usuários e acessando do próprio servidor."""
    if auth.contar_usuarios() > 0:
        return erro("O sistema já foi configurado", 403)
    if not _eh_local(ip_cliente()):
        return erro("Por segurança, o primeiro administrador só pode ser criado acessando pelo próprio "
                    "servidor (https://localhost:porta) ou pelo comando: python -m sentinela criar-admin", 403)
    d = corpo()
    try:
        auth.criar_usuario(d.get("usuario", ""), d.get("senha", ""), "admin", nome=d.get("nome", ""), fornecedor=True)
    except ValueError as e:
        return erro(str(e))
    auth.auditar(d.get("usuario", ""), ip_cliente(), "Primeiro administrador (fornecedor) criado")
    return ok("Administrador criado. Faça login.")


@app.post("/api/login")
def api_login():
    d = corpo()
    usuario, senha = str(d.get("usuario", "")).strip(), str(d.get("senha", ""))
    u, mensagem = auth.autenticar(usuario, senha, ip_cliente())
    if not u:
        alvo = banco.um("SELECT empresa_id FROM usuarios WHERE usuario = ?", (usuario,))
        empresa_alvo = alvo["empresa_id"] if alvo else None
        auth.auditar(usuario, ip_cliente(), "Login recusado", detalhes=mensagem, empresa_id=empresa_alvo)
        incidentes.registrar_evento(None, "Painel Sentinela", "Falha de login no painel", "aviso",
                                    f"Usuário '{usuario[:40]}': {mensagem}", ip_cliente(), "painel",
                                    empresa_id=empresa_alvo)
        return erro(mensagem, 401)

    precisa_2fa = bool(u["totp_ativo"])
    token, _ = auth.criar_sessao(u["id"], ip_cliente(), request.headers.get("User-Agent", ""), mfa_ok=not precisa_2fa)
    if not precisa_2fa:
        auth.limpar_falhas(f"ip:{ip_cliente()}")
        banco.executar("UPDATE usuarios SET ultimo_login = datetime('now', 'localtime') WHERE id = ?", (u["id"],))
        auth.auditar(u["usuario"], ip_cliente(), "Login", empresa_id=u["empresa_id"])
    duracao = 600 if precisa_2fa else int(CFG["seguranca"]["sessao_horas"]) * 3600
    return gravar_cookie(ok("Bem-vindo", precisa_2fa=precisa_2fa), token, duracao)


@app.post("/api/login/2fa")
def api_login_2fa():
    s = g.sessao
    if not s or s["mfa_ok"]:
        return erro("Faça login novamente", 401)
    chave, chave_ip = f"u:{s['usuario'].lower()}", f"ip:{ip_cliente()}"
    if auth.segundos_bloqueado(chave) or auth.segundos_bloqueado(chave_ip):
        return erro("Muitas tentativas. Aguarde alguns minutos.", 429)
    u = auth.obter_usuario(s["usuario_id"])
    if not auth.conferir_totp(auth.segredo_totp_do_usuario(u), corpo().get("codigo", ""), u["id"]):
        auth.registrar_falha(chave)
        auth.registrar_falha(chave_ip)
        auth.auditar(s["usuario"], ip_cliente(), "Código 2FA incorreto", empresa_id=u["empresa_id"])
        return erro("Código incorreto", 401)
    auth.limpar_falhas(chave, f"ip:{ip_cliente()}")
    auth.promover_sessao(g.token)
    banco.executar("UPDATE usuarios SET ultimo_login = datetime('now', 'localtime') WHERE id = ?", (u["id"],))
    auth.auditar(s["usuario"], ip_cliente(), "Login (com 2FA)", empresa_id=u["empresa_id"])
    return gravar_cookie(ok("Bem-vindo"), g.token, int(CFG["seguranca"]["sessao_horas"]) * 3600)


@app.post("/api/logout")
def api_logout():
    auth.encerrar_sessao(g.token)
    auditar("Logout")
    resposta = ok("Até logo")
    resposta.delete_cookie(auth.NOME_COOKIE, path="/")
    return resposta


@app.post("/api/minha-conta/senha")
def api_trocar_senha():
    d = corpo()
    u = auth.obter_usuario(g.sessao["usuario_id"])
    if not auth.conferir_hash(str(d.get("atual", "")), u["senha_hash"]):
        auditar("Troca de senha recusada", detalhes="senha atual incorreta")
        return erro("Senha atual incorreta")
    try:
        auth.definir_senha(u["id"], str(d.get("nova", "")))
    except ValueError as e:
        return erro(str(e))
    token, _ = auth.criar_sessao(u["id"], ip_cliente(), request.headers.get("User-Agent", ""),
                                 empresa_id=g.sessao["empresa_id"])
    auditar("Senha alterada")
    return gravar_cookie(ok("Senha alterada"), token, int(CFG["seguranca"]["sessao_horas"]) * 3600)


@app.post("/api/minha-conta/2fa/iniciar")
def api_2fa_iniciar():
    u = auth.obter_usuario(g.sessao["usuario_id"])
    if u["totp_ativo"]:
        return erro("O 2FA já está ativo")
    segredo = auth.gerar_segredo_totp()
    banco.executar("UPDATE usuarios SET totp_cif = ? WHERE id = ?", (cofre.cifrar(segredo), u["id"]))
    uri = auth.uri_totp(segredo, u["usuario"])
    from .. import qrcode
    try:
        qr = qrcode.svg(uri)
    except ValueError:
        qr = None
    return ok("Leia o QR code no app autenticador", segredo=segredo, uri=uri, qr_svg=qr)


@app.post("/api/minha-conta/2fa/confirmar")
def api_2fa_confirmar():
    u = auth.obter_usuario(g.sessao["usuario_id"])
    segredo = auth.segredo_totp_do_usuario(u)
    if not segredo or not auth.conferir_totp(segredo, corpo().get("codigo", ""), u["id"]):
        return erro("Código incorreto. Confira se o horário do celular está certo.")
    banco.executar("UPDATE usuarios SET totp_ativo = 1 WHERE id = ?", (u["id"],))
    auditar("2FA ativado")
    return ok("Verificação em duas etapas ativada")


@app.post("/api/minha-conta/2fa/desativar")
def api_2fa_desativar():
    u = auth.obter_usuario(g.sessao["usuario_id"])
    if not auth.conferir_hash(str(corpo().get("senha", "")), u["senha_hash"]):
        return erro("Senha incorreta")
    if CFG["seguranca"]["exigir_2fa_admin"] and (u["papel"] == "admin" or u["fornecedor"]):
        return erro("O 2FA é obrigatório para administradores nesta instalação")
    banco.executar("UPDATE usuarios SET totp_ativo = 0, totp_cif = NULL WHERE id = ?", (u["id"],))
    auditar("2FA desativado")
    return ok("Verificação em duas etapas desativada")


# ======================================================================= minha empresa

@app.get("/api/empresa")
def api_empresa():
    e = empresas.obter(empresa_atual())
    usados = banco.um("SELECT COUNT(*) AS n FROM equipamentos WHERE empresa_id = ?", (empresa_atual(),))["n"]
    return jsonify({"empresa": {k: e[k] for k in ("id", "nome", "plano", "limite_equipamentos", "validade", "situacao",
                                                  "situacao_texto", "asn", "redes", "prefixos")},
                    "equipamentos_usados": usados})


@app.post("/api/empresa/rede")
@requer("administrar")
def api_empresa_rede():
    d = corpo()
    mensagem = empresas.salvar_rede(empresa_atual(), d)
    if mensagem:
        return erro(mensagem)
    from ..fluxo import FLUXO
    FLUXO.carregar_redes()
    auditar("Redes e ASN da empresa alterados", "", f"ASN {d.get('asn')} redes {d.get('redes')}")
    return ok("Redes e ASN salvos")


# ======================================================================= usuários (admin da empresa)

def usuario_da_empresa(uid):
    """Usuário da empresa atual (nunca uma conta do fornecedor nem de outra empresa)."""
    u = auth.obter_usuario(uid)
    if not u or u["fornecedor"] or u["empresa_id"] != empresa_atual():
        return None
    return u


@app.get("/api/usuarios")
@requer("administrar")
def api_usuarios():
    linhas = banco.consultar("SELECT * FROM usuarios WHERE empresa_id = ? AND fornecedor = 0 ORDER BY lower(usuario)",
                             (empresa_atual(),))
    return jsonify({"usuarios": [auth.usuario_publico(u) for u in linhas], "papeis": auth.NOMES_PAPEIS})


@app.post("/api/usuarios")
@requer("administrar")
def api_usuario_criar():
    d = corpo()
    try:
        novo = auth.criar_usuario(d.get("usuario", ""), d.get("senha", ""), d.get("papel", ""),
                                  d.get("nome", ""), d.get("email", ""), d.get("telefone", ""), trocar_senha=True,
                                  empresa_id=empresa_atual())
    except ValueError as e:
        return erro(str(e))
    auditar("Usuário criado", d.get("usuario"), f"perfil {d.get('papel')}")
    return ok("Usuário criado. Ele vai trocar a senha no primeiro login.", id=novo)


def _ultimo_admin(u, papel_novo="admin", ativo_novo=True):
    """Impede o provedor de ficar sem administrador (o fornecedor pode, para suporte)."""
    if eh_fornecedor() or u["papel"] != "admin":
        return False
    if papel_novo == "admin" and ativo_novo:
        return False
    return auth.contar_admins_ativos(empresa_atual(), exceto_id=u["id"]) == 0


@app.post("/api/usuarios/<int:uid>")
@requer("administrar")
def api_usuario_editar(uid):
    d = corpo()
    u = usuario_da_empresa(uid)
    if not u:
        return erro("Usuário não encontrado", 404)
    papel = d.get("papel", u["papel"])
    ativo = 1 if d.get("ativo", bool(u["ativo"])) else 0
    if papel not in auth.PERMISSOES:
        return erro("Perfil inválido")
    if _ultimo_admin(u, papel, ativo):
        return erro("Não é possível remover o último administrador ativo")
    banco.executar("UPDATE usuarios SET nome = ?, email = ?, telefone = ?, papel = ?, ativo = ? WHERE id = ? AND empresa_id = ?",
                   (str(d.get("nome", u["nome"])).strip(), str(d.get("email", u["email"])).strip(),
                    str(d.get("telefone", u["telefone"])).strip(), papel, ativo, uid, empresa_atual()))
    if not ativo or papel != u["papel"]:
        auth.encerrar_sessoes_do_usuario(uid)
    auditar("Usuário alterado", u["usuario"], f"perfil={papel} ativo={ativo}")
    return ok("Usuário atualizado")


@app.post("/api/usuarios/<int:uid>/senha")
@requer("administrar")
def api_usuario_senha(uid):
    u = usuario_da_empresa(uid)
    if not u:
        return erro("Usuário não encontrado", 404)
    try:
        auth.definir_senha(uid, str(corpo().get("senha", "")), trocar_no_proximo_login=True)
    except ValueError as e:
        return erro(str(e))
    auditar("Senha redefinida pelo administrador", u["usuario"])
    return ok("Senha redefinida. O usuário vai trocá-la no próximo login.")


@app.post("/api/usuarios/<int:uid>/2fa/remover")
@requer("administrar")
def api_usuario_remover_2fa(uid):
    u = usuario_da_empresa(uid)
    if not u:
        return erro("Usuário não encontrado", 404)
    banco.executar("UPDATE usuarios SET totp_ativo = 0, totp_cif = NULL WHERE id = ?", (uid,))
    auth.encerrar_sessoes_do_usuario(uid)
    auditar("2FA removido pelo administrador", u["usuario"])
    return ok("2FA removido. O usuário poderá configurar de novo.")


@app.post("/api/usuarios/<int:uid>/remover")
@requer("administrar")
def api_usuario_remover(uid):
    u = usuario_da_empresa(uid)
    if not u:
        return erro("Usuário não encontrado", 404)
    if uid == g.sessao["usuario_id"]:
        return erro("Você não pode remover a si mesmo")
    if _ultimo_admin(u, papel_novo="", ativo_novo=False):
        return erro("Não é possível remover o último administrador")
    banco.executar("DELETE FROM usuarios WHERE id = ? AND empresa_id = ?", (uid, empresa_atual()))
    auditar("Usuário removido", u["usuario"])
    return ok("Usuário removido")


@app.get("/api/auditoria")
@requer("administrar")
def api_auditoria():
    limite = min(int(request.args.get("limite", 300)), 2000)
    busca = f"%{request.args.get('busca', '').strip()}%"
    linhas = banco.consultar(
        "SELECT * FROM auditoria WHERE empresa_id = ? AND (usuario LIKE ? OR acao LIKE ? OR alvo LIKE ? OR ip LIKE ?) "
        "ORDER BY id DESC LIMIT ?", (empresa_atual(), busca, busca, busca, busca, limite))
    return jsonify({"registros": linhas})


# ======================================================================= equipamentos e sites

def _status_da_empresa():
    return {s["equip_id"]: s for s in banco.consultar(
        "SELECT s.* FROM status s JOIN equipamentos e ON e.id = s.equip_id WHERE e.empresa_id = ?", (empresa_atual(),))}


@app.get("/api/equipamentos")
def api_equipamentos():
    status = _status_da_empresa()
    lista = []
    for e in equipamentos.listar(empresa_atual()):
        st = status.get(e["id"], {})
        e.update({"status": st.get("status", "aguardando"), "hostname": st.get("hostname"), "cpu": st.get("cpu"),
                  "memoria": st.get("memoria"), "uptime": st.get("uptime"), "verificado": st.get("verificado"),
                  "erro": st.get("erro"), "snmp_erro": st.get("snmp_erro"), "incidente": st.get("incidente"),
                  "alertas": json.loads(st.get("alertas") or "[]")})
        lista.append(e)
    return jsonify({"equipamentos": lista, "sites": equipamentos.listar_sites(empresa_atual()),
                    "tipos": fab.TIPOS, "funcoes": fab.FUNCOES})


@app.post("/api/equipamentos")
@requer("administrar")
def api_equipamento_criar():
    novo_id, mensagem = equipamentos.salvar(corpo(), empresa_atual())
    if not novo_id:
        return erro(mensagem)
    e = equipamentos.obter(novo_id, empresa_atual())
    auditar("Equipamento cadastrado", f"{e['nome']} ({e['host']})")
    TEMPO_REAL.esquecer(novo_id)
    MONITOR.verificar_agora()
    return ok("Equipamento cadastrado. Verificando agora...", id=novo_id)


@app.post("/api/equipamentos/<equip_id>")
@requer("administrar")
def api_equipamento_editar(equip_id):
    _, mensagem = equipamentos.salvar(corpo(), empresa_atual(), equip_id)
    if mensagem:
        return erro(mensagem)
    e = equipamentos.obter(equip_id, empresa_atual())
    auditar("Equipamento alterado", f"{e['nome']} ({e['host']})")
    TEMPO_REAL.esquecer(equip_id)
    MONITOR.verificar_agora()
    return ok("Equipamento atualizado. Verificando agora...")


@app.post("/api/equipamentos/<equip_id>/remover")
@requer("administrar")
def api_equipamento_remover(equip_id):
    e = equipamentos.obter(equip_id, empresa_atual())
    if not e or not equipamentos.remover(equip_id, empresa_atual()):
        return erro("Equipamento não encontrado", 404)
    from ..coletor_snmp import COLETOR
    TEMPO_REAL.esquecer(equip_id)
    COLETOR.esquecer(equip_id)
    auditar("Equipamento removido", f"{e['nome']} ({e['host']})")
    return ok("Equipamento removido. Os backups e incidentes dele continuam guardados.")


@app.get("/api/equipamentos/<equip_id>/interfaces")
def api_interfaces(equip_id):
    from ..coletor_snmp import COLETOR
    e = equipamentos.obter(equip_id, empresa_atual())
    if not e:
        return erro("Equipamento não encontrado", 404)
    with COLETOR.trava:
        lista = list(COLETOR.interfaces.get(equip_id, []))
    return jsonify({"equipamento": e["nome"], "tem_snmp": e["tem_snmp"], "interfaces": lista})


def _campos_para_teste(d, segredos):
    """Monta os dados de teste. Ao editar, completa os segredos vazios com os salvos (só da própria empresa)."""
    atual = equipamentos.obter(d["id"], empresa_atual(), segredos=True) if d.get("id") else None
    if d.get("id") and not atual:
        return None, "Equipamento não encontrado"
    campos, mensagem = equipamentos.validar(d, atual, empresa_atual())
    if mensagem:
        return None, mensagem
    for segredo in segredos:
        if not campos[segredo] and atual:
            campos[segredo] = atual.get(segredo)
    return campos, None


@app.post("/api/equipamentos/testar-snmp")
@requer("administrar")
def api_equipamento_testar_snmp():
    from .. import snmp
    campos, mensagem = _campos_para_teste(corpo(), ("snmp_community", "snmp_v3_auth", "snmp_v3_priv"))
    if mensagem:
        return erro(mensagem)
    if not campos["snmp_versao"]:
        return erro("Escolha a versão do SNMP")
    try:
        cli = snmp.cliente_do_equipamento(campos, timeout=2)
        r = cli.get("1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.1.0")
        texto = f"SNMP OK! {r.get('1.3.6.1.2.1.1.5.0', '')} · {str(r.get('1.3.6.1.2.1.1.1.0', ''))[:80]}"
        sucesso = True
    except Exception as e:
        texto, sucesso = f"Falha no SNMP: {e}", False
    auditar("Teste de SNMP", campos["host"], texto)
    return jsonify({"ok": sucesso, "mensagem": texto})


@app.post("/api/equipamentos/testar")
@requer("administrar")
def api_equipamento_testar():
    campos, mensagem = _campos_para_teste(corpo(), ("senha", "enable"))
    if mensagem:
        return erro(mensagem)
    sucesso, texto, hostname = MONITOR.testar(campos)
    auditar("Teste de conexão", campos["host"], texto)
    return jsonify({"ok": sucesso, "mensagem": texto, "hostname": hostname})


@app.post("/api/sites")
@requer("administrar")
def api_site_salvar():
    d = corpo()
    site_id, mensagem = equipamentos.salvar_site(empresa_atual(), d.get("nome"), d.get("descricao", ""), d.get("id"))
    if not site_id:
        return erro(mensagem)
    auditar("Site salvo", d.get("nome"))
    return ok("Site salvo", id=site_id)


@app.post("/api/sites/<int:site_id>/remover")
@requer("administrar")
def api_site_remover(site_id):
    if not equipamentos.remover_site(site_id, empresa_atual()):
        return erro("Site não encontrado", 404)
    auditar("Site removido", site_id)
    return ok("Site removido (os equipamentos ficaram sem site)")


# ======================================================================= monitoramento

@app.get("/api/estado")
def api_estado():
    auditoria = banco.ler_config_empresa(empresa_atual(), "ultima_auditoria")
    return jsonify({
        "monitorando": MONITOR.monitorando_empresa(empresa_atual()), "ocupado": MONITOR.ocupado,
        "ultimo_ciclo": MONITOR.ultimo_ciclo, "proximo_ciclo": MONITOR.proximo_ciclo,
        "auditoria": json.loads(auditoria) if auditoria else None,
        "config": {"intervalo": int(CFG["monitoramento"]["intervalo_minutos"]),
                   "limite_cpu": int(CFG["monitoramento"]["limite_cpu"]),
                   "limite_falhas": int(CFG["monitoramento"]["limite_falhas_login"])},
    })


@app.get("/api/aovivo")
def api_aovivo():
    return jsonify(TEMPO_REAL.estado(empresa_atual(), fornecedor=eh_fornecedor()))


@app.post("/api/verificar")
@requer("operar")
def api_verificar():
    MONITOR.verificar_agora()
    auditar("Verificação manual")
    return ok("Verificação iniciada")


@app.post("/api/backup")
@requer("operar")
def api_backup():
    threading.Thread(target=MONITOR.backup_e_auditoria, args=(empresa_atual(),), daemon=True).start()
    auditar("Backup e auditoria manual")
    return ok("Backup e auditoria iniciados")


@app.post("/api/pausar")
@requer("operar")
def api_pausar():
    MONITOR.pausar(empresa_atual())
    auditar("Monitoramento pausado")
    return ok("Monitoramento pausado (só os equipamentos desta empresa)")


@app.post("/api/retomar")
@requer("operar")
def api_retomar():
    MONITOR.retomar(empresa_atual())
    auditar("Monitoramento retomado")
    return ok("Monitoramento retomado")


@app.get("/api/incidentes")
def api_incidentes():
    lista = incidentes.listar(empresa_atual(), request.args.get("estado") or None, limite=500)
    for i in lista:
        i["arquivos"] = armazenamento.arquivos_da_pasta(i["pasta"], empresa_atual()) if i["pasta"] else []
    return jsonify({"incidentes": lista})


@app.post("/api/incidentes/<int:iid>/reconhecer")
@requer("operar")
def api_incidente_reconhecer(iid):
    if not incidentes.reconhecer(iid, usuario_atual(), empresa_atual()):
        return erro("Incidente não está aberto")
    auditar("Incidente reconhecido", iid)
    return ok("Incidente reconhecido: os alertas de escalonamento foram interrompidos")


@app.post("/api/incidentes/<int:iid>/resolver")
@requer("operar")
def api_incidente_resolver(iid):
    if not incidentes.resolver(iid, usuario_atual(), empresa_atual()):
        return erro("Incidente já resolvido ou inexistente")
    auditar("Incidente resolvido", iid)
    return ok("Incidente resolvido")


@app.get("/api/backups")
@requer("operar")
def api_backups():
    linhas = banco.consultar(
        "SELECT b.id, b.equip_id, b.hostname, b.quando, b.arquivo, b.tamanho, b.mudou, b.sha256 "
        "FROM backups b WHERE b.empresa_id = ? ORDER BY b.hostname, b.quando DESC", (empresa_atual(),))
    grupos = {}
    for l in linhas:
        grupo = grupos.setdefault(l["hostname"], {"hostname": l["hostname"], "total": 0, "arquivos": []})
        grupo["total"] += 1
        if len(grupo["arquivos"]) < 50:
            grupo["arquivos"].append(l)
    return jsonify({"grupos": sorted(grupos.values(), key=lambda x: x["hostname"].lower())})


@app.get("/api/arquivo")
@requer("operar")
def api_arquivo():
    caminho = request.args.get("caminho", "")
    texto = armazenamento.ler(caminho, empresa_atual())
    if texto is None:
        return erro("Arquivo não encontrado", 404)
    auditar("Arquivo visualizado", caminho)
    return app.response_class(texto, mimetype="text/plain; charset=utf-8")


# ======================================================================= métricas (Prometheus / Grafana / Zabbix)

def _rotulos(**valores):
    limpo = lambda v: str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
    return "{" + ",".join(f'{k}="{limpo(v)}"' for k, v in valores.items()) + "}"


@app.get("/metrics")
def metricas():
    """Métricas de TODAS as empresas (rótulo "empresa"), para o Prometheus do fornecedor."""
    import hmac
    from ..coletor_snmp import COLETOR

    token = str(CFG["metricas"]["token"] or "")
    recebido = request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
    if not token:
        return erro("Métricas desligadas: configure [metricas] token no config.toml", 404)
    if not hmac.compare_digest(recebido.encode(), token.encode()):
        return erro("Token inválido", 401)

    status = {s["equip_id"]: s for s in banco.consultar("SELECT * FROM status")}
    nomes_empresa = {l["id"]: l["nome"] for l in banco.consultar("SELECT id, nome FROM empresas")}
    linhas = []

    def metrica(nome, ajuda, amostras):
        linhas.append(f"# HELP sentinela_{nome} {ajuda}")
        linhas.append(f"# TYPE sentinela_{nome} gauge")
        for rotulos, valor in amostras:
            if valor is not None:
                linhas.append(f"sentinela_{nome}{rotulos} {valor}")

    lista = equipamentos.listar(equipamentos.TODAS)
    base = {e["id"]: dict(empresa=nomes_empresa.get(e["empresa_id"], ""), equipamento=e["nome"], host=e["host"],
                          site=e["site"], funcao=e["funcao"]) for e in lista}
    metrica("equipamento_disponivel", "1 se o equipamento respondeu na última verificação",
            [(_rotulos(**base[e["id"]]), 0 if status.get(e["id"], {}).get("status") == "erro" else 1) for e in lista])
    metrica("equipamento_sob_alerta", "1 se há alerta ativo no equipamento",
            [(_rotulos(**base[e["id"]]), 1 if TEMPO_REAL.ativos(e["id"]) else 0) for e in lista])
    for campo, nome, ajuda in (("cpu", "cpu_percentual", "Uso de CPU (%)"),
                               ("memoria", "memoria_percentual", "Uso de memória (%)"),
                               ("uptime", "uptime_segundos", "Tempo ligado (s)")):
        metrica(nome, ajuda, [(_rotulos(**base[e["id"]]), status.get(e["id"], {}).get(campo)) for e in lista])

    with COLETOR.trava:
        interfaces = {k: list(v) for k, v in COLETOR.interfaces.items()}
    amostras_bps, amostras_up = [], []
    for e in lista:
        for itf in interfaces.get(e["id"], []):
            r = dict(base[e["id"]], interface=itf["nome"])
            amostras_bps.append((_rotulos(**r, direcao="entrada"), itf["bps_in"]))
            amostras_bps.append((_rotulos(**r, direcao="saida"), itf["bps_out"]))
            amostras_up.append((_rotulos(**r), 1 if itf["estado"] == "up" else 0))
    metrica("interface_bps", "Tráfego da interface (bits por segundo)", amostras_bps)
    metrica("interface_up", "1 se a interface está operacional", amostras_up)

    contagem = banco.consultar("SELECT empresa_id, severidade, COUNT(*) AS n FROM incidentes WHERE estado != 'resolvido' "
                               "AND empresa_id IS NOT NULL GROUP BY empresa_id, severidade")
    metrica("incidentes_abertos", "Incidentes não resolvidos",
            [(_rotulos(empresa=nomes_empresa.get(c["empresa_id"], ""), severidade=c["severidade"]), c["n"]) for c in contagem])
    return app.response_class("\n".join(linhas) + "\n", mimetype="text/plain; version=0.0.4; charset=utf-8")


# ======================================================================= DDoS (fluxo)

@app.get("/api/ddos")
def api_ddos():
    from ..fluxo import FLUXO
    from ..tempo_real import descobrir_ip_local
    estado = FLUXO.estado(empresa_atual(), fornecedor=eh_fornecedor())
    estado["ip_local"] = TEMPO_REAL.ip_local or descobrir_ip_local()
    return jsonify(estado)


# ======================================================================= alertas, plantão e manutenções

@app.get("/api/config/alertas")
@requer("administrar")
def api_config_alertas():
    from .. import alertas
    plantao = banco.consultar(
        "SELECT u.id, u.usuario, u.nome, u.email, u.telefone, u.papel, u.ativo, "
        "COALESCE(p.nivel, 0) AS nivel, COALESCE(p.whatsapp, 1) AS whatsapp, COALESCE(p.email, 1) AS quer_email "
        "FROM usuarios u LEFT JOIN plantao p ON p.usuario_id = u.id "
        "WHERE u.empresa_id = ? AND u.fornecedor = 0 ORDER BY lower(u.usuario)", (empresa_atual(),))
    envios = banco.consultar("SELECT * FROM envios WHERE empresa_id = ? ORDER BY id DESC LIMIT 50", (empresa_atual(),))
    return jsonify({"config": alertas.config_publica(empresa_atual()), "plantao": plantao, "envios": envios})


@app.post("/api/config/alertas")
@requer("administrar")
def api_config_alertas_salvar():
    from .. import alertas
    try:
        alertas.salvar_config(empresa_atual(), corpo())
    except alertas.ErroAlerta as e:
        return erro(str(e))
    auditar("Configuração de alertas alterada")
    return ok("Configuração de alertas salva")


@app.post("/api/config/alertas/testar")
@requer("administrar")
def api_config_alertas_testar():
    from .. import alertas
    d = corpo()
    try:
        alertas.NOTIFICADOR.testar(empresa_atual(), d.get("canal", ""), str(d.get("destino", "")).strip())
    except alertas.ErroAlerta as e:
        auditar("Teste de alerta falhou", d.get("canal"), str(e))
        return erro(f"Falhou: {e}")
    auditar("Teste de alerta enviado", d.get("canal"), d.get("destino", ""))
    return ok("Mensagem de teste enviada. Confira se chegou.")


@app.post("/api/plantao")
@requer("administrar")
def api_plantao():
    d = corpo()
    try:
        uid, nivel = int(d.get("usuario_id")), int(d.get("nivel", 0))
    except (TypeError, ValueError):
        return erro("Dados inválidos")
    if not usuario_da_empresa(uid) or nivel not in (0, 1, 2, 3):
        return erro("Usuário ou nível inválido")
    if nivel == 0:
        banco.executar("DELETE FROM plantao WHERE usuario_id = ?", (uid,))
    else:
        banco.executar("INSERT INTO plantao (usuario_id, nivel, whatsapp, email) VALUES (?, ?, ?, ?) "
                       "ON CONFLICT(usuario_id) DO UPDATE SET nivel = excluded.nivel, whatsapp = excluded.whatsapp, "
                       "email = excluded.email", (uid, nivel, int(bool(d.get("whatsapp", True))),
                                                  int(bool(d.get("email", True)))))
    auditar("Escala de plantão alterada", uid, f"nível {nivel}")
    return ok("Escala atualizada")


@app.get("/api/manutencoes")
def api_manutencoes():
    lista = banco.consultar(
        "SELECT m.*, e.nome AS equipamento, s.nome AS site FROM manutencoes m "
        "LEFT JOIN equipamentos e ON e.id = m.equip_id LEFT JOIN sites s ON s.id = m.site_id "
        "WHERE m.empresa_id = ? AND replace(m.fim, 'T', ' ') >= datetime('now', 'localtime', '-30 days') "
        "ORDER BY m.inicio DESC", (empresa_atual(),))
    return jsonify({"manutencoes": lista, "equipamentos": equipamentos.listar(empresa_atual()),
                    "sites": equipamentos.listar_sites(empresa_atual())})


@app.post("/api/manutencoes")
@requer("operar")
def api_manutencao_criar():
    import datetime as dt
    d = corpo()
    try:
        inicio = dt.datetime.fromisoformat(str(d.get("inicio")))
        fim = dt.datetime.fromisoformat(str(d.get("fim")))
    except ValueError:
        return erro("Informe início e fim válidos")
    if fim <= inicio:
        return erro("O fim precisa ser depois do início")
    if (fim - inicio).days > 31:
        return erro("Uma janela de manutenção pode ter no máximo 31 dias")
    alvo = str(d.get("alvo", ""))
    equip_id = site_id = None
    if alvo.startswith("e:"):
        equip_id = alvo[2:]
        if not equipamentos.obter(equip_id, empresa_atual()):
            return erro("Equipamento não encontrado")
    elif alvo.startswith("s:"):
        try:
            site_id = int(alvo[2:])
        except ValueError:
            return erro("Site inválido")
        if not banco.um("SELECT id FROM sites WHERE id = ? AND empresa_id = ?", (site_id, empresa_atual())):
            return erro("Site não encontrado")
    elif alvo != "todos":
        return erro("Escolha o alvo da manutenção")
    banco.executar("INSERT INTO manutencoes (equip_id, site_id, inicio, fim, motivo, criado_por, empresa_id) "
                   "VALUES (?, ?, ?, ?, ?, ?, ?)",
                   (equip_id, site_id, inicio.strftime("%Y-%m-%d %H:%M"), fim.strftime("%Y-%m-%d %H:%M"),
                    str(d.get("motivo", ""))[:200], usuario_atual(), empresa_atual()))
    auditar("Manutenção agendada", alvo, f"{inicio} até {fim}: {d.get('motivo', '')}")
    return ok("Manutenção agendada: os alertas desse alvo ficam silenciados no período (os incidentes continuam registrados)")


@app.post("/api/manutencoes/<int:mid>/remover")
@requer("operar")
def api_manutencao_remover(mid):
    if not banco.executar("DELETE FROM manutencoes WHERE id = ? AND empresa_id = ?", (mid, empresa_atual())):
        return erro("Manutenção não encontrada", 404)
    auditar("Manutenção removida", mid)
    return ok("Manutenção removida")


# ======================================================================= relatórios

@app.get("/api/relatorios/pdf")
def api_relatorio_pdf():
    import datetime as dt
    from .. import alertas, relatorios
    mes = request.args.get("mes") or dt.date.today().strftime("%Y-%m")
    try:
        ano, numero = (int(x) for x in mes.split("-"))
        if not 1 <= numero <= 12 or not 2000 <= ano <= 2100:
            raise ValueError
    except ValueError:
        return erro("Mês inválido (use AAAA-MM)")
    nome = alertas.ler_config(empresa_atual())["geral"]["nome_empresa"]
    pdf = relatorios.gerar_pdf(empresa_atual(), ano, numero, nome)
    auditar("Relatório PDF gerado", mes)
    resposta = app.response_class(pdf, mimetype="application/pdf")
    # "inline" abre no visualizador de PDF do navegador; o Chrome bloqueia DOWNLOADS de sites com
    # certificado autoassinado, mas não bloqueia abrir o PDF numa aba (de onde dá para salvar).
    modo = "attachment" if request.args.get("baixar") else "inline"
    resposta.headers["Content-Disposition"] = f'{modo}; filename="sentinela_relatorio_{ano}-{numero:02d}.pdf"'
    return resposta


# ======================================================================= BGP / RPKI e OLTs

@app.get("/api/bgp")
def api_bgp():
    from ..bgp import BGP
    return jsonify(BGP.estado(empresa_atual()))


@app.post("/api/bgp/rpki")
@requer("operar")
def api_bgp_rpki():
    from ..bgp import BGP
    if not empresas.asn(empresa_atual()):
        return erro("Cadastre o ASN da empresa em ⚙️ Equipamentos → Minha empresa")
    threading.Thread(target=BGP.verificar_rpki, args=(empresa_atual(),), daemon=True).start()
    auditar("Verificação RPKI manual")
    return ok("Verificando RPKI e origem dos prefixos no RIPEstat...")


@app.get("/api/olts")
def api_olts():
    from ..olt import OLT
    return jsonify(OLT.estado(empresa_atual()))


@app.get("/api/olts/<equip_id>/onus")
def api_olt_onus(equip_id):
    from ..olt import OLT
    if not equipamentos.obter(equip_id, empresa_atual()):
        return erro("OLT não encontrada", 404)
    return jsonify({"onus": OLT.onus(equip_id, request.args.get("pon") or None, request.args.get("filtro") or None)})


# ======================================================================= mitigação

@app.get("/api/mitigacoes")
def api_mitigacoes():
    from ..mitigacao import MITIGADOR, TIPOS, ler_config
    cfg = ler_config(empresa_atual())
    candidatos = {tipo: [{"id": e["id"], "nome": e["nome"], "host": e["host"], "funcao": e["funcao_nome"],
                          "tem_mitigacao": e["tem_mitigacao"]}
                         for e in equipamentos.listar(empresa_atual(), somente_ativos=True)
                         if e["tipo"] in cfg["modelos"][tipo]]
                  for tipo in TIPOS}
    admin = auth.pode(g.sessao["papel"], "administrar", g.sessao["fornecedor"])
    return jsonify({"mitigacoes": MITIGADOR.listar(empresa_atual()), "tipos": TIPOS, "candidatos": candidatos,
                    "config": cfg if admin else None, "redes": empresas.redes(empresa_atual())})


@app.post("/api/mitigacoes")
@requer("operar")
def api_mitigacao_criar():
    from ..mitigacao import MITIGADOR
    d = corpo()
    try:
        duracao = int(d.get("duracao_min") or 0) or None
        m, nova = MITIGADOR.propor(empresa_atual(), d.get("tipo", ""), d.get("alvo", ""), str(d.get("motivo") or "manual"),
                                   d.get("equip_ids") or [], origem="manual", criado_por=usuario_atual(),
                                   duracao_min=duracao)
    except (ValueError, KeyError, TypeError) as e:
        return erro(str(e) or "Dados inválidos")
    auditar("Mitigação proposta manualmente", f"#{m['id']} {m['tipo']} {m['alvo']}")
    return ok("Mitigação criada: confira e aprove para aplicar" if nova else "Já existe uma mitigação para esse alvo", id=m["id"])


@app.post("/api/mitigacoes/<int:mid>/<acao>")
@requer("operar")
def api_mitigacao_acao(mid, acao):
    from ..mitigacao import MITIGADOR
    m = banco.um("SELECT estado FROM mitigacoes WHERE id = ? AND empresa_id = ?", (mid, empresa_atual()))
    if not m:
        return erro("Mitigação não encontrada", 404)
    if acao == "aprovar":
        if m["estado"] != "pendente":
            return erro("Mitigação não está pendente")
        threading.Thread(target=MITIGADOR.aprovar, args=(mid, usuario_atual(), empresa_atual()), daemon=True).start()
        auditar("Mitigação aprovada", f"#{mid}")
        return ok("Aprovada: enviando os comandos aos roteadores...")
    if acao == "rejeitar":
        if not MITIGADOR.rejeitar(mid, usuario_atual(), empresa_atual()):
            return erro("Mitigação não está pendente")
        return ok("Mitigação rejeitada")
    if acao == "remover":
        if m["estado"] not in ("ativa", "erro"):
            return erro("Mitigação não está ativa")
        threading.Thread(target=MITIGADOR.remover, args=(mid, usuario_atual(), empresa_atual()), daemon=True).start()
        auditar("Remoção de mitigação solicitada", f"#{mid}")
        return ok("Removendo dos roteadores...")
    return erro("Ação desconhecida", 404)


@app.post("/api/config/mitigacao")
@requer("administrar")
def api_config_mitigacao():
    from ..mitigacao import salvar_config
    try:
        salvar_config(empresa_atual(), corpo())
    except (ValueError, KeyError, IndexError, TypeError, AttributeError) as e:
        return erro(f"Configuração inválida: {e}")
    auditar("Configuração de mitigação alterada")
    return ok("Configuração de mitigação salva")


# ======================================================================= FORNECEDOR (cadastro de empresas)

def _empresa_publica(e):
    return {k: e[k] for k in ("id", "nome", "documento", "contato", "email", "telefone", "plano", "limite_equipamentos",
                              "validade", "ativo", "asn", "redes", "prefixos", "observacoes", "criado", "situacao",
                              "situacao_texto", "equipamentos", "usuarios", "incidentes_abertos") if k in e}


@app.get("/api/fornecedor/empresas")
def api_forn_empresas():
    lista = empresas.listar()
    for e in lista:
        e["ataques_ativos"] = sum(1 for m in TEMPO_REAL.estado(e["id"])["maquinas"] if m["estado"] == "ataque") \
            if e["situacao"] == "ok" else 0
    return jsonify({"empresas": [dict(_empresa_publica(e), ataques_ativos=e["ataques_ativos"]) for e in lista],
                    "papeis": auth.NOMES_PAPEIS})


@app.post("/api/fornecedor/empresas")
def api_forn_empresa_criar():
    d = corpo()
    admin = d.get("admin") or {}
    if admin.get("usuario"):  # valida o administrador antes de criar a empresa
        problema = auth.problema_na_senha(str(admin.get("senha", "")), str(admin.get("usuario", "")))
        if problema:
            return erro(f"Administrador: {problema}")
        if banco.um("SELECT id FROM usuarios WHERE usuario = ?", (str(admin["usuario"]).strip(),)):
            return erro("Administrador: já existe um usuário com esse nome")
    novo, mensagem = empresas.salvar(d)
    if not novo:
        return erro(mensagem)
    if admin.get("usuario"):
        try:
            auth.criar_usuario(admin["usuario"], admin.get("senha", ""), "admin", admin.get("nome", ""),
                               admin.get("email", ""), admin.get("telefone", ""), trocar_senha=True, empresa_id=novo)
        except ValueError as e:
            return erro(f"Empresa criada, mas o administrador não: {e}")
    g.empresa_id = novo
    auditar("Empresa cadastrada", d.get("nome"), f"plano={d.get('plano')} limite={d.get('limite_equipamentos')}")
    from ..fluxo import FLUXO
    FLUXO.carregar_redes()
    return ok("Empresa cadastrada" + (". O administrador vai trocar a senha no primeiro login." if admin.get("usuario") else ""),
              id=novo)


@app.post("/api/fornecedor/empresas/<int:eid>")
def api_forn_empresa_editar(eid):
    d = corpo()
    _, mensagem = empresas.salvar(d, eid)
    if mensagem:
        return erro(mensagem)
    situacao = empresas.obter(eid)["situacao"]
    if situacao != "ok":  # suspensa ou vencida: derruba as sessões abertas dos usuários dela
        for u in banco.consultar("SELECT id FROM usuarios WHERE empresa_id = ? AND fornecedor = 0", (eid,)):
            auth.encerrar_sessoes_do_usuario(u["id"])
    g.empresa_id = eid
    auditar("Empresa alterada", d.get("nome"), f"situação={situacao} limite={d.get('limite_equipamentos')} "
                                               f"validade={d.get('validade')}")
    from ..fluxo import FLUXO
    FLUXO.carregar_redes()
    return ok("Empresa atualizada")


@app.post("/api/fornecedor/empresas/<int:eid>/remover")
def api_forn_empresa_remover(eid):
    e = empresas.obter(eid)
    if not e:
        return erro("Empresa não encontrada", 404)
    if str(corpo().get("confirmar", "")).strip().lower() != e["nome"].lower():
        return erro("Para confirmar, digite o nome exato da empresa")
    for equip in equipamentos.listar(eid):
        TEMPO_REAL.esquecer(equip["id"])
    if not empresas.remover(eid):
        return erro("Não é possível remover a única empresa")
    g.empresa_id = None
    auditar("Empresa REMOVIDA com todos os dados", e["nome"])
    if g.sessao["empresa_id"] == eid:
        auth.trocar_empresa_da_sessao(g.token, auth.empresa_inicial(auth.obter_usuario(g.sessao["usuario_id"])))
    return ok("Empresa e todos os dados dela foram removidos")


# ======================================================================= licença da instalação

def _uso_licenca():
    return {"equipamentos": banco.um("SELECT COUNT(*) AS n FROM equipamentos")["n"],
            "empresas": banco.um("SELECT COUNT(*) AS n FROM empresas")["n"]}


@app.get("/api/registro")
def api_registro():
    """Tela de registro (sem login): enquanto o servidor não estiver ativado, mostra o serial."""
    lic = licenca.estado(forcar=True)
    if lic["valida"]:
        return jsonify({"valida": True})
    return jsonify({"valida": False, "situacao": lic["situacao"], "texto": lic["texto"], "maquina": lic["maquina"],
                    "serial": licenca.serial_atual(), "versao": VERSAO})


@app.post("/api/registro/ativar")
def api_registro_ativar():
    """Ativação pela tela de registro. Só funciona com o servidor sem licença válida (renovar = aba Licença).
    Não precisa de login: a chave só vale se foi assinada pelo fornecedor para ESTE servidor e serial."""
    if licenca.valida():
        return erro("Este servidor já está ativado", 409)
    try:
        lic = licenca.ativar(str(corpo().get("codigo", "")))
    except licenca.LicencaErro as e:
        auth.auditar("tela de registro", ip_cliente(), "Ativação de licença recusada", detalhes=str(e))
        return erro(f"Não foi possível ativar: {e}")
    auth.auditar("tela de registro", ip_cliente(), "Licença do sistema ativada", f"nº {lic['licenca_id']}", lic["texto"])
    return ok(f"Sistema registrado! {lic['texto']}.", licenca=lic)


@app.get("/api/fornecedor/licenca")
def api_forn_licenca():
    return jsonify({"licenca": licenca.estado(forcar=True), "uso": _uso_licenca(), "serial": licenca.serial_atual()})


@app.post("/api/fornecedor/licenca/solicitar")
def api_forn_licenca_solicitar():
    codigo = licenca.gerar_solicitacao()
    auditar("Código de solicitação de licença gerado")
    return ok("Código gerado. Envie ao fornecedor.", codigo=codigo)


@app.post("/api/fornecedor/licenca/ativar")
def api_forn_licenca_ativar():
    try:
        lic = licenca.ativar(str(corpo().get("codigo", "")))
    except licenca.LicencaErro as e:
        auditar("Ativação de licença recusada", detalhes=str(e))
        return erro(f"Não foi possível ativar: {e}")
    auditar("Licença do sistema ativada", f"nº {lic['licenca_id']}", lic["texto"])
    return ok(f"Sistema ativado. {lic['texto']}.", licenca=lic, uso=_uso_licenca())


@app.post("/api/fornecedor/entrar/<int:eid>")
def api_forn_entrar(eid):
    e = empresas.obter(eid)
    if not e:
        return erro("Empresa não encontrada", 404)
    auth.trocar_empresa_da_sessao(g.token, eid)
    g.empresa_id = eid
    auditar("Fornecedor entrou na empresa (suporte)", e["nome"])
    return ok(f"Agora você está operando: {e['nome']}")


@app.get("/api/fornecedor/auditoria")
def api_forn_auditoria():
    limite = min(int(request.args.get("limite", 300)), 2000)
    busca = f"%{request.args.get('busca', '').strip()}%"
    linhas = banco.consultar(
        "SELECT a.*, e.nome AS empresa FROM auditoria a LEFT JOIN empresas e ON e.id = a.empresa_id "
        "WHERE a.usuario LIKE ? OR a.acao LIKE ? OR a.alvo LIKE ? OR a.ip LIKE ? OR e.nome LIKE ? "
        "ORDER BY a.id DESC LIMIT ?", (busca, busca, busca, busca, busca, limite))
    return jsonify({"registros": linhas})


@app.get("/api/fornecedor/usuarios")
def api_forn_usuarios():
    linhas = banco.consultar("SELECT * FROM usuarios WHERE fornecedor = 1 ORDER BY lower(usuario)")
    return jsonify({"usuarios": [auth.usuario_publico(u) for u in linhas]})


@app.post("/api/fornecedor/usuarios")
def api_forn_usuario_criar():
    d = corpo()
    try:
        auth.criar_usuario(d.get("usuario", ""), d.get("senha", ""), "admin", d.get("nome", ""), d.get("email", ""),
                           d.get("telefone", ""), trocar_senha=True, fornecedor=True)
    except ValueError as e:
        return erro(str(e))
    auditar("Usuário do fornecedor criado", d.get("usuario"))
    return ok("Usuário do fornecedor criado. Ele vai trocar a senha no primeiro login.")


@app.post("/api/fornecedor/usuarios/<int:uid>/remover")
def api_forn_usuario_remover(uid):
    u = auth.obter_usuario(uid)
    if not u or not u["fornecedor"]:
        return erro("Usuário não encontrado", 404)
    if uid == g.sessao["usuario_id"]:
        return erro("Você não pode remover a si mesmo")
    if auth.contar_fornecedores_ativos(exceto_id=uid) == 0:
        return erro("Não é possível remover o último usuário do fornecedor")
    banco.executar("DELETE FROM usuarios WHERE id = ? AND fornecedor = 1", (uid,))
    auditar("Usuário do fornecedor removido", u["usuario"])
    return ok("Usuário removido")
