"""Cadastro de equipamentos e sites (no banco, com segredos no cofre).

Toda função recebe a empresa obrigatoriamente. Os motores em segundo plano (que monitoram todas as
empresas) passam empresa_id=TODAS de forma explícita; a API sempre passa a empresa da sessão.
"""

import ipaddress
import re
import uuid

from . import banco, cofre
from . import fabricantes as fab

TODAS = "*"   # usado só pelos motores internos, nunca pela API

CAMPOS_SEGREDO = {
    "senha": "senha_cif",
    "enable": "enable_cif",
    "snmp_community": "snmp_community_cif",
    "snmp_v3_auth": "snmp_v3_auth_cif",
    "snmp_v3_priv": "snmp_v3_priv_cif",
    "mit_senha": "mit_senha_cif",
}


def _publico(linha):
    e = {k: linha[k] for k in ("id", "nome", "host", "tipo", "porta", "usuario", "site_id", "funcao",
                                "snmp_versao", "snmp_porta", "snmp_v3_usuario", "ativo", "criado", "atualizado",
                                "mit_usuario", "empresa_id")}
    e["ativo"] = bool(e["ativo"])
    e["site"] = linha.get("site_nome") or ""
    e["tipo_nome"] = fab.TIPOS.get(e["tipo"], e["tipo"])
    e["funcao_nome"] = fab.FUNCOES.get(e["funcao"], e["funcao"])
    e["tem_senha"] = bool(linha["senha_cif"])
    e["tem_enable"] = bool(linha["enable_cif"])
    e["tem_snmp"] = bool(linha["snmp_versao"]) and bool(linha["snmp_community_cif"] or linha["snmp_v3_usuario"])
    e["tem_mitigacao"] = bool(linha["mit_usuario"] and linha["mit_senha_cif"])
    return e


def _com_segredos(linha):
    e = _publico(linha)
    for campo, coluna in CAMPOS_SEGREDO.items():
        try:
            e[campo] = cofre.decifrar(linha[coluna])
        except cofre.ErroCofre:
            e[campo] = None
    return e


_SELECT = ("SELECT e.*, s.nome AS site_nome FROM equipamentos e "
           "LEFT JOIN sites s ON s.id = e.site_id ")


def _filtro(empresa_id, alias="e"):
    if empresa_id == TODAS:
        return "1 = 1", ()
    if empresa_id is None:
        raise ValueError("empresa não informada")
    return f"{alias}.empresa_id = ?", (int(empresa_id),)


def listar(empresa_id, segredos=False, somente_ativos=False):
    onde, params = _filtro(empresa_id)
    if somente_ativos:
        from . import empresas
        ativas = empresas.ids_ativos() or {-1}
        onde += f" AND e.ativo = 1 AND e.empresa_id IN ({','.join(str(int(i)) for i in ativas)})"
    conv = _com_segredos if segredos else _publico
    return [conv(l) for l in banco.consultar(_SELECT + f"WHERE {onde} ORDER BY lower(e.nome)", params)]


def obter(equip_id, empresa_id, segredos=False):
    onde, params = _filtro(empresa_id)
    linha = banco.um(_SELECT + f"WHERE e.id = ? AND {onde}", (equip_id, *params))
    if not linha:
        return None
    return _com_segredos(linha) if segredos else _publico(linha)


def _endereco_do_proprio_servidor(host):
    import ipaddress
    import socket
    try:
        enderecos = {i[4][0] for i in socket.getaddrinfo(host, None)}
    except OSError:
        return False
    for e in enderecos:
        ip = ipaddress.ip_address(e.split("%")[0])
        if ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast:
            return True
    return False


def validar(dados, atual=None, empresa_id=None):
    """Valida o formulário. Retorna (campos_normalizados, None) ou (None, erro)."""
    g = lambda k: str(dados.get(k) if dados.get(k) is not None else "").strip()
    nome, host, tipo, usuario = g("nome"), g("host"), g("tipo"), g("usuario")
    try:
        porta = int(g("porta") or 22)
        snmp_porta = int(g("snmp_porta") or 161)
    except ValueError:
        return None, "Porta inválida"

    if not host:
        return None, "Informe o IP ou endereço do equipamento"
    if not re.fullmatch(r"[A-Za-z0-9.\-:]+", host):
        return None, "Endereço inválido (use só o IP ou nome, sem http:// nem espaços)"
    if empresa_id not in (None, TODAS, 1) and _endereco_do_proprio_servidor(host):
        # provedor cliente apontando para o próprio servidor central: seria uma porta para sondar serviços internos
        return None, "Endereço não permitido (loopback/link-local do servidor). Use o IP do equipamento."
    if tipo not in fab.TIPOS:
        return None, "Escolha o fabricante"
    if not (1 <= porta <= 65535 and 1 <= snmp_porta <= 65535):
        return None, "As portas devem estar entre 1 e 65535"
    if not usuario:
        return None, "Informe o usuário SSH"
    if not g("senha") and not (atual and atual.get("tem_senha")):
        return None, "Informe a senha SSH"

    funcao = g("funcao") or "outro"
    if funcao not in fab.FUNCOES:
        return None, "Função inválida"
    site_id = dados.get("site_id") or None
    if site_id is not None:
        try:
            site_id = int(site_id)
        except (TypeError, ValueError):
            return None, "Site inválido"
        if not banco.um("SELECT id FROM sites WHERE id = ? AND empresa_id IS ?", (site_id, empresa_id)):
            return None, "Site não encontrado"

    snmp_versao = g("snmp_versao")
    if snmp_versao not in ("", "2c", "3"):
        return None, "Versão SNMP inválida"
    if snmp_versao == "2c" and not g("snmp_community") and not (atual and atual.get("tem_snmp") and atual["snmp_versao"] == "2c"):
        return None, "Informe a community SNMP"
    if snmp_versao == "3":
        if not g("snmp_v3_usuario"):
            return None, "Informe o usuário SNMPv3"
        tem_auth = g("snmp_v3_auth") or (atual and atual.get("snmp_versao") == "3")
        if not tem_auth:
            return None, "Informe a senha de autenticação SNMPv3"
        if g("snmp_v3_auth") and len(g("snmp_v3_auth")) < 8:
            return None, "A senha SNMPv3 precisa ter pelo menos 8 caracteres"
        if g("snmp_v3_priv") and len(g("snmp_v3_priv")) < 8:
            return None, "A senha de privacidade SNMPv3 precisa ter pelo menos 8 caracteres"

    if g("mit_usuario") and not g("mit_senha") and not (atual and atual.get("tem_mitigacao")
                                                         and atual.get("mit_usuario") == g("mit_usuario")):
        return None, "Informe a senha do usuário de mitigação"

    return {
        "nome": nome or host, "host": host, "tipo": tipo, "porta": porta, "usuario": usuario,
        "site_id": site_id, "funcao": funcao, "snmp_versao": snmp_versao, "snmp_porta": snmp_porta,
        "snmp_v3_usuario": g("snmp_v3_usuario"), "ativo": 1 if dados.get("ativo", True) else 0,
        "mit_usuario": g("mit_usuario"), "mit_senha": g("mit_senha"),
        # segredos: vazio = manter o atual
        "senha": g("senha"), "enable": g("enable"), "snmp_community": g("snmp_community"),
        "snmp_v3_auth": g("snmp_v3_auth"), "snmp_v3_priv": g("snmp_v3_priv"),
    }, None


def salvar(dados, empresa_id, equip_id=None):
    """Cria ou atualiza um equipamento da empresa. Retorna (id, None) ou (None, erro)."""
    if empresa_id in (None, TODAS):
        raise ValueError("empresa não informada")
    atual = obter(equip_id, empresa_id) if equip_id else None
    if equip_id and not atual:
        return None, "Equipamento não encontrado"
    if not atual:
        from . import empresas
        motivo = empresas.pode_cadastrar_equipamento(empresa_id)
        if motivo:
            return None, motivo
    campos, erro = validar(dados, atual, empresa_id)
    if erro:
        return None, erro
    duplicado = banco.um("SELECT id, empresa_id FROM equipamentos WHERE host = ? AND porta = ? AND id != ?",
                         (campos["host"], campos["porta"], equip_id or ""))
    if duplicado:
        if duplicado["empresa_id"] == int(empresa_id):
            return None, f"Já existe um equipamento em {campos['host']}:{campos['porta']}"
        # não revela que outra empresa usa esse endereço
        return None, (f"O endereço {campos['host']}:{campos['porta']} já está em uso neste servidor. "
                      "Fale com o suporte do fornecedor.")

    colunas = {k: campos[k] for k in ("nome", "host", "tipo", "porta", "usuario", "site_id", "funcao",
                                       "snmp_versao", "snmp_porta", "snmp_v3_usuario", "ativo", "mit_usuario")}
    for campo, coluna in CAMPOS_SEGREDO.items():
        if campos[campo]:
            colunas[coluna] = cofre.cifrar(campos[campo])
        elif campo == "enable" and dados.get("limpar_enable"):
            colunas[coluna] = None
    if not campos["mit_usuario"]:
        colunas["mit_senha_cif"] = None
    if campos["snmp_versao"] == "":
        for coluna in ("snmp_community_cif", "snmp_v3_auth_cif", "snmp_v3_priv_cif"):
            colunas[coluna] = None

    if atual:
        atribuicoes = ", ".join(f"{c} = ?" for c in colunas)
        banco.executar(f"UPDATE equipamentos SET {atribuicoes}, atualizado = datetime('now', 'localtime') "
                       "WHERE id = ? AND empresa_id = ?", (*colunas.values(), equip_id, int(empresa_id)))
        if atual["host"] != campos["host"] or atual["tipo"] != campos["tipo"]:
            banco.executar("DELETE FROM status WHERE equip_id = ?", (equip_id,))
        return equip_id, None

    novo_id = uuid.uuid4().hex
    colunas["id"] = novo_id
    colunas["empresa_id"] = int(empresa_id)
    nomes = ", ".join(colunas)
    banco.executar(f"INSERT INTO equipamentos ({nomes}) VALUES ({', '.join('?' * len(colunas))})",
                   tuple(colunas.values()))
    return novo_id, None


def remover(equip_id, empresa_id):
    if empresa_id in (None, TODAS):
        raise ValueError("empresa não informada")
    return banco.executar("DELETE FROM equipamentos WHERE id = ? AND empresa_id = ?", (equip_id, int(empresa_id))) > 0


def empresa_do_equipamento(equip_id):
    linha = banco.um("SELECT empresa_id FROM equipamentos WHERE id = ?", (equip_id,))
    return linha["empresa_id"] if linha else None


# ---------------------------------------------------------------- sites

def listar_sites(empresa_id):
    return banco.consultar(
        "SELECT s.*, (SELECT COUNT(*) FROM equipamentos e WHERE e.site_id = s.id) AS equipamentos "
        "FROM sites s WHERE s.empresa_id = ? ORDER BY lower(s.nome)", (int(empresa_id),))


def salvar_site(empresa_id, nome, descricao="", site_id=None):
    nome = (nome or "").strip()
    if not nome:
        return None, "Informe o nome do site"
    if site_id and not banco.um("SELECT id FROM sites WHERE id = ? AND empresa_id = ?", (site_id, int(empresa_id))):
        return None, "Site não encontrado"
    existe = banco.um("SELECT id FROM sites WHERE nome = ? AND id != ? AND empresa_id = ?",
                      (nome, site_id or 0, int(empresa_id)))
    if existe:
        return None, "Já existe um site com esse nome"
    if site_id:
        banco.executar("UPDATE sites SET nome = ?, descricao = ? WHERE id = ? AND empresa_id = ?",
                       (nome, descricao or "", site_id, int(empresa_id)))
        return site_id, None
    return banco.executar("INSERT INTO sites (empresa_id, nome, descricao) VALUES (?, ?, ?)",
                          (int(empresa_id), nome, descricao or "")), None


def remover_site(site_id, empresa_id):
    return banco.executar("DELETE FROM sites WHERE id = ? AND empresa_id = ?", (site_id, int(empresa_id))) > 0


def ip_valido(texto):
    try:
        ipaddress.ip_address(texto)
        return True
    except ValueError:
        return False
