"""Coleta leve por SNMP (a cada minuto): CPU, memória, uptime e tráfego/estado das interfaces.

É bem mais leve que o SSH, então dá para acompanhar centenas de equipamentos com frequência.
O SSH continua sendo usado para backup, logs e coleta de evidências.
"""

import datetime
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import equipamentos, incidentes, snmp
from .config import CFG
from .monitor import MONITOR, atualizar_status

SYS_UPTIME = "1.3.6.1.2.1.1.3.0"
HR_CPU = "1.3.6.1.2.1.25.3.3.1.2"
HR_TIPO, HR_UNIDADE, HR_TAMANHO, HR_USADO = ("1.3.6.1.2.1.25.2.3.1.2", "1.3.6.1.2.1.25.2.3.1.4",
                                             "1.3.6.1.2.1.25.2.3.1.5", "1.3.6.1.2.1.25.2.3.1.6")
HR_RAM = "1.3.6.1.2.1.25.2.1.2"

CPU_FABRICANTE = {
    "cisco_ios": "1.3.6.1.4.1.9.9.109.1.1.1.1.7",       # cpmCPUTotal1minRev
    "cisco_xe": "1.3.6.1.4.1.9.9.109.1.1.1.1.7",
    "huawei": "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5",     # hwEntityCpuUsage
    "huawei_olt": "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5",
    "juniper_junos": "1.3.6.1.4.1.2636.3.1.13.1.8",     # jnxOperatingCPU
}
MEM_FABRICANTE = {
    "huawei": "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7",     # hwEntityMemUsage
    "huawei_olt": "1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7",
    "juniper_junos": "1.3.6.1.4.1.2636.3.1.13.1.11",    # jnxOperatingBuffer
}
CISCO_MEM_USADA, CISCO_MEM_LIVRE = "1.3.6.1.4.1.9.9.48.1.1.1.5.1", "1.3.6.1.4.1.9.9.48.1.1.1.6.1"

IF_NOME, IF_ALIAS, IF_ESTADO = "1.3.6.1.2.1.31.1.1.1.1", "1.3.6.1.2.1.31.1.1.1.18", "1.3.6.1.2.1.2.2.1.8"
IF_ENTRADA, IF_SAIDA, IF_VELOCIDADE = "1.3.6.1.2.1.31.1.1.1.6", "1.3.6.1.2.1.31.1.1.1.10", "1.3.6.1.2.1.31.1.1.1.15"
IF_ERROS = "1.3.6.1.2.1.2.2.1.14"

# Em quais equipamentos uma interface caindo gera alerta (em switches de acesso é normal porta cair)
FUNCOES_ALERTA_INTERFACE = {"borda", "core", "agregacao", "concentrador"}


def _indice(o, base):
    return o[len(base) + 1:]


def _tabela(cliente, base, maximo=3000):
    return {_indice(o, base): v for o, v in cliente.walk(base, maximo)}


class ColetorSnmp:
    def __init__(self):
        self.trava = threading.Lock()
        self.interfaces = {}     # equip_id -> lista de interfaces (última coleta)
        self._contadores = {}    # (equip_id, indice) -> (ts, entrada, saida)
        self._estados = {}       # (equip_id, indice) -> último estado operacional
        self._altas = {}         # equip_id -> {"cpu": n, "mem": n} amostras altas seguidas
        self._erro_anterior = {}
        self.ultimo_ciclo = None
        self.ao_alertar = []     # mesmas funções do monitor (tela ao vivo)

    # ------------------------------------------------------------ leitura

    def _cpu(self, cli, tipo):
        base = CPU_FABRICANTE.get(tipo)
        if base:
            try:
                valores = [v for _, v in cli.walk(base, 200) if isinstance(v, int)]
                validos = [v for v in valores if 0 < v <= 100]
                if validos:
                    return max(validos)
            except snmp.ErroSnmp:
                pass
        valores = [v for _, v in cli.walk(HR_CPU, 256) if isinstance(v, int)]
        return round(sum(valores) / len(valores)) if valores else None

    def _memoria(self, cli, tipo):
        if tipo in ("cisco_ios", "cisco_xe"):
            r = cli.get(CISCO_MEM_USADA, CISCO_MEM_LIVRE)
            usada, livre = r.get(CISCO_MEM_USADA), r.get(CISCO_MEM_LIVRE)
            if isinstance(usada, int) and isinstance(livre, int) and usada + livre:
                return round(usada * 100 / (usada + livre))
        base = MEM_FABRICANTE.get(tipo)
        if base:
            try:
                validos = [v for _, v in cli.walk(base, 200) if isinstance(v, int) and 0 < v <= 100]
                if validos:
                    return max(validos)
            except snmp.ErroSnmp:
                pass
        tipos = _tabela(cli, HR_TIPO, 200)
        for indice, tipo_armaz in tipos.items():
            if tipo_armaz == HR_RAM:
                r = cli.get(f"{HR_TAMANHO}.{indice}", f"{HR_USADO}.{indice}")
                tamanho, usado = r.get(f"{HR_TAMANHO}.{indice}"), r.get(f"{HR_USADO}.{indice}")
                if isinstance(tamanho, int) and tamanho > 0 and isinstance(usado, int):
                    return round(usado * 100 / tamanho)
        return None

    def _interfaces(self, cli, equip_id):
        nomes = _tabela(cli, IF_NOME)
        if not nomes:
            return []
        apelidos, estados = _tabela(cli, IF_ALIAS), _tabela(cli, IF_ESTADO)
        entradas, saidas = _tabela(cli, IF_ENTRADA), _tabela(cli, IF_SAIDA)
        velocidades, erros = _tabela(cli, IF_VELOCIDADE), _tabela(cli, IF_ERROS)
        agora = time.time()
        lista = []
        for indice, nome in nomes.items():
            entrada, saida = entradas.get(indice), saidas.get(indice)
            bps_in = bps_out = None
            anterior = self._contadores.get((equip_id, indice))
            if anterior and isinstance(entrada, int) and isinstance(saida, int):
                dt = agora - anterior[0]
                if dt > 0 and entrada >= anterior[1] and saida >= anterior[2]:
                    bps_in = int((entrada - anterior[1]) * 8 / dt)
                    bps_out = int((saida - anterior[2]) * 8 / dt)
            if isinstance(entrada, int) and isinstance(saida, int):
                self._contadores[(equip_id, indice)] = (agora, entrada, saida)
            lista.append({"indice": indice, "nome": str(nome), "descricao": str(apelidos.get(indice) or ""),
                          "estado": {1: "up", 2: "down", 5: "dormant", 7: "lowerLayerDown"}.get(estados.get(indice), "?"),
                          "velocidade_mbps": velocidades.get(indice), "bps_in": bps_in, "bps_out": bps_out,
                          "erros_in": erros.get(indice)})
        return lista

    # ------------------------------------------------------------ uma coleta

    def coletar(self, equip):
        eid = equip["id"]
        nome = f"{equip['nome']} ({equip['host']})"
        try:
            cli = snmp.cliente_do_equipamento(equip)
            uptime = cli.get(SYS_UPTIME).get(SYS_UPTIME)
            cpu = self._cpu(cli, equip["tipo"])
            memoria = self._memoria(cli, equip["tipo"])
            interfaces = self._interfaces(cli, eid)
        except Exception as e:
            erro = str(e) if isinstance(e, snmp.ErroSnmp) else f"falha SNMP: {e}"
            atualizar_status(eid, snmp_erro=erro, snmp_verificado=_agora())
            if self._erro_anterior.get(eid) != erro:
                incidentes.registrar_evento(eid, nome, "SNMP sem resposta", "erro", erro, fonte="snmp")
            self._erro_anterior[eid] = erro
            return {"id": eid, "erro": erro}

        self._erro_anterior[eid] = None
        with self.trava:
            self.interfaces[eid] = interfaces
        campos = {"cpu": cpu, "memoria": memoria, "snmp_verificado": _agora(), "snmp_erro": None}
        if isinstance(uptime, int):
            campos["uptime"] = uptime // 100
        atualizar_status(eid, **campos)
        self._avaliar(equip, nome, cpu, memoria, interfaces)
        return {"id": eid, "erro": None, "cpu": cpu, "memoria": memoria, "interfaces": len(interfaces)}

    def _avaliar(self, equip, nome, cpu, memoria, interfaces):
        eid = equip["id"]
        altas = self._altas.setdefault(eid, {"cpu": 0, "mem": 0})
        alertas = []
        for chave, valor, limite, rotulo in (
                ("cpu", cpu, int(CFG["monitoramento"]["limite_cpu"]), "CPU"),
                ("mem", memoria, int(CFG["monitoramento"]["limite_memoria"]), "Memória")):
            if valor is not None and valor >= limite:
                altas[chave] += 1
                if altas[chave] == 2:  # duas coletas seguidas, para não alertar por um pico isolado
                    alertas.append(f"{rotulo} em {valor}% há mais de 1 minuto (possível DDoS/flood)")
            else:
                altas[chave] = 0
        for texto in alertas:
            incidentes.registrar_evento(eid, nome, "DDoS/flood", "ataque", texto, fonte="snmp")
            incidente, _ = incidentes.abrir(eid, nome, "DDoS/flood", texto, detalhes=texto)
            for funcao in self.ao_alertar:
                funcao(equip, "DDoS/flood", [])
            atualizar_status(eid, status="alerta", alertas=[texto])
            MONITOR.capturar_agora(eid, [texto], "DDoS/flood", incidente["id"])

        vigiar = equip["funcao"] in FUNCOES_ALERTA_INTERFACE
        for itf in interfaces:
            chave = (eid, itf["indice"])
            anterior = self._estados.get(chave)
            self._estados[chave] = itf["estado"]
            if not vigiar or anterior is None or anterior == itf["estado"]:
                continue
            rotulo = itf["nome"] + (f" ({itf['descricao']})" if itf["descricao"] else "")
            if anterior == "up" and itf["estado"] != "up":
                texto = f"Interface {rotulo} caiu (estado: {itf['estado']})"
                incidentes.registrar_evento(eid, nome, "Interface caiu", "aviso", texto, fonte="snmp")
                incidentes.abrir(eid, nome, "Interface caiu", texto, detalhes=texto, severidade="media",
                                 chave=f"{eid}|interface|{itf['indice']}")
            elif itf["estado"] == "up":
                incidentes.registrar_evento(eid, nome, "Interface voltou", "info", f"Interface {rotulo} voltou", fonte="snmp")

    # ------------------------------------------------------------ laço

    def ciclo(self):
        lista = [e for e in equipamentos.listar(equipamentos.TODAS, segredos=True, somente_ativos=True) if e["snmp_versao"]]
        if not lista:
            return []
        with ThreadPoolExecutor(max_workers=max(4, int(CFG["monitoramento"]["conexoes_simultaneas"]) * 2)) as pool:
            resultados = list(pool.map(self.coletar, lista))
        self.ultimo_ciclo = _agora()
        return resultados

    def laco(self):
        while True:
            inicio = time.time()
            try:
                self.ciclo()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"Coleta SNMP: {e}", fonte="sistema")
            espera = int(CFG["monitoramento"]["intervalo_snmp_segundos"]) - (time.time() - inicio)
            time.sleep(max(5, espera))

    def iniciar(self):
        threading.Thread(target=self.laco, name="snmp", daemon=True).start()

    def esquecer(self, equip_id):
        with self.trava:
            self.interfaces.pop(equip_id, None)
        self._altas.pop(equip_id, None)
        for chave in [c for c in self._estados if c[0] == equip_id]:
            self._estados.pop(chave, None)
            self._contadores.pop(chave, None)


def _agora():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")


COLETOR = ColetorSnmp()
