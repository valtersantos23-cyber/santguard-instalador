"""Configuração do sistema.

A configuração vem de três lugares, nesta ordem de prioridade:
  1. Variáveis de ambiente SENTINELA_<SECAO>_<CHAVE> (ex.: SENTINELA_WEB_PORTA=9443)
  2. Arquivo <pasta de dados>/config.toml
  3. Valores padrão abaixo

A pasta de dados é ./dados, ou a indicada em SENTINELA_DADOS.
"""

import copy
import os
import pathlib
import tomllib

PADRAO = {
    "web": {
        "endereco": "0.0.0.0",
        "porta": 8443,
        "https": True,
        "certificado": "",      # vazio = gera um certificado autoassinado na pasta de dados
        "chave": "",
    },
    "monitoramento": {
        "intervalo_minutos": 5,         # verificação completa por SSH (logs, config)
        "intervalo_snmp_segundos": 60,  # coleta leve por SNMP (CPU, memória, interfaces)
        "limite_falhas_login": 5,
        "limite_cpu": 90,
        "limite_memoria": 95,
        "conexoes_simultaneas": 10,
        "timeout_conexao": 20,
        "alertar_mudanca_config": True,
    },
    "tempo_real": {
        "syslog": True,
        "syslog_porta": 514,
        "janela_forca_bruta_seg": 60,
        "janela_ataque_min": 10,
        "intervalo_captura_min": 10,
        "padrao_suspeito": r"ATAQUE|port ?scan|syn ?flood|ddos|flood|attack|intrus",
    },
    "fluxo": {
        "ativo": True,
        "porta_netflow": 2055,          # NetFlow v5/v9 e IPFIX
        "porta_sflow": 6343,
        "janela_seg": 10,               # tamanho da janela de medição
        "limite_mbps": 500,             # tráfego para um único IP acima disso = DDoS
        "limite_kpps": 100,             # pacotes por segundo (milhares) para um único IP
        "redes_proprias": [],           # ex.: ["177.10.0.0/22", "2804:abcd::/32"]
        "aceitar_qualquer_exportador": False,  # False = só aceita fluxo de equipamentos cadastrados
    },
    "bgp": {
        "ativo": True,
        "intervalo_minutos": 3,
        "asn": 0,                       # seu ASN (para RPKI e detecção de sequestro de prefixo)
        "prefixos": [],                 # prefixos anunciados; vazio = usa [fluxo] redes_proprias
        "variacao_prefixos_pct": 30,    # variação brusca de prefixos recebidos que gera alerta
        "rpki_horas": 6,
        "ripestat_url": "https://stat.ripe.net",
    },
    "olt": {
        "intervalo_minutos": 5,
        "sinal_minutos": 30,
        "sinal_minimo_dbm": -27.0,      # ONU com sinal abaixo disso = sinal ruim
        "queda_massa_pct": 50,          # % das ONUs de uma PON que caíram de uma vez
        "queda_massa_min_onus": 8,
    },
    "seguranca": {
        "sessao_horas": 12,
        "max_tentativas": 5,
        "bloqueio_minutos": 15,
        "exigir_2fa_admin": False,
        "senha_minima": 10,
        # Multiempresa: provedores clientes não podem mandar alertas (webhook, Evolution, SMTP) para IPs
        # internos do servidor. Ligue só se todos os provedores forem de confiança.
        "alertas_rede_interna_para_todos": False,
    },
    "metricas": {
        # Endpoint /metrics (Prometheus/Grafana/Zabbix). Vazio = desligado.
        # Configure um token longo e use-o no Prometheus como "bearer_token".
        "token": "",
    },
    "retencao": {
        "eventos_dias": 90,
        "backups_por_equipamento": 500,
    },
}


def pasta_dados():
    pasta = pathlib.Path(os.environ.get("SENTINELA_DADOS", "dados")).resolve()
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta


def _converter(valor_texto, exemplo):
    if isinstance(exemplo, bool):
        return valor_texto.strip().lower() in ("1", "true", "sim", "yes", "on")
    if isinstance(exemplo, int):
        return int(valor_texto)
    if isinstance(exemplo, float):
        return float(valor_texto)
    if isinstance(exemplo, list):
        return [p.strip() for p in valor_texto.split(",") if p.strip()]
    return valor_texto


def carregar():
    cfg = copy.deepcopy(PADRAO)
    arquivo = pasta_dados() / "config.toml"
    if arquivo.exists():
        with open(arquivo, "rb") as f:
            lido = tomllib.load(f)
        for secao, valores in lido.items():
            if isinstance(valores, dict):
                cfg.setdefault(secao, {}).update(valores)

    for secao, valores in cfg.items():
        for chave, atual in list(valores.items()):
            env = os.environ.get(f"SENTINELA_{secao}_{chave}".upper())
            if env is not None:
                valores[chave] = _converter(env, atual)
    return cfg


CFG = carregar()


def recarregar():
    global CFG
    CFG.clear()
    CFG.update(carregar())
    return CFG
