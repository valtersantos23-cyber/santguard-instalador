"""Lê senhas gravadas pelo script antigo (backup_auditoria.py) no Windows, para importação."""

import base64
import ctypes
import ctypes.wintypes as wintypes


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def desproteger(texto):
    dados = base64.b64decode(texto)
    buffer = ctypes.create_string_buffer(dados, len(dados))
    entrada = _DataBlob(len(dados), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_char)))
    saida = _DataBlob()
    if not ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(entrada), None, None, None, None, 0,
                                                     ctypes.byref(saida)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(saida.pbData, saida.cbData).decode("utf-8")
    finally:
        ctypes.windll.kernel32.LocalFree(saida.pbData)
