"""Cofre de segredos: senhas SSH, communities SNMP, segredos de 2FA e tokens de alerta.

Os segredos são cifrados com AES (Fernet) usando uma chave mestra que fica:
  - na variável de ambiente SENTINELA_CHAVE_MESTRA, ou
  - no arquivo dados/chave_mestra.key (criado na primeira execução).

IMPORTANTE: faça backup da chave mestra em local seguro e separado do banco.
Sem ela, as senhas cadastradas não podem ser recuperadas. Com ela e o banco
juntos, qualquer pessoa consegue ler as senhas, por isso guarde-os separados.
"""

import os
import stat
import threading

from cryptography.fernet import Fernet, InvalidToken

from . import config

_fernet = None
_trava = threading.Lock()


class ErroCofre(Exception):
    pass


def _arquivo_chave():
    return config.pasta_dados() / "chave_mestra.key"


def _carregar():
    global _fernet
    with _trava:
        if _fernet is not None:
            return _fernet
        chave = os.environ.get("SENTINELA_CHAVE_MESTRA", "").strip().encode()
        if not chave:
            arquivo = _arquivo_chave()
            if arquivo.exists():
                chave = arquivo.read_bytes().strip()
            else:
                chave = Fernet.generate_key()
                # cria o arquivo já com permissão restrita (só o dono lê)
                fd = os.open(arquivo, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(chave)
                try:
                    os.chmod(arquivo, stat.S_IRUSR | stat.S_IWUSR)
                except OSError:
                    pass
        try:
            _fernet = Fernet(chave)
        except (ValueError, TypeError) as e:
            raise ErroCofre(f"Chave mestra inválida: {e}") from e
        return _fernet


def cifrar(texto):
    if texto is None or texto == "":
        return None
    return _carregar().encrypt(texto.encode("utf-8")).decode("ascii")


def decifrar(cifrado):
    if not cifrado:
        return None
    try:
        return _carregar().decrypt(cifrado.encode("ascii")).decode("utf-8")
    except InvalidToken as e:
        raise ErroCofre("Não foi possível decifrar: a chave mestra não corresponde a este banco") from e


def reiniciar():
    """Usado nos testes, ao trocar de pasta de dados."""
    global _fernet
    with _trava:
        _fernet = None
