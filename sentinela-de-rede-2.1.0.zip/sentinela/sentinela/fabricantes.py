"""Comandos e regras de cada fabricante. Para ajustar um modelo específico, edite aqui."""

import re

TIPOS = {
    "mikrotik_routeros": "MikroTik (RouterOS)",
    "cisco_ios": "Cisco IOS",
    "cisco_xe": "Cisco IOS-XE",
    "huawei": "Huawei (VRP)",
    "juniper_junos": "Juniper (Junos)",
    "zte_zxros": "ZTE (ZXR10 / ZXROS)",
    "huawei_olt": "OLT Huawei (MA56xx/MA58xx)",
    "zte_olt": "OLT ZTE (C3xx/C6xx)",
    "fiberhome_olt": "OLT Fiberhome (AN5516/AN6000)",
    "parks_olt": "OLT Parks / Intelbras",
}

# tipo usado pelo netmiko para cada fabricante
DRIVER_NETMIKO = {
    "mikrotik_routeros": "mikrotik_routeros",
    "cisco_ios": "cisco_ios",
    "cisco_xe": "cisco_xe",
    "huawei": "huawei",
    "juniper_junos": "juniper_junos",
    "zte_zxros": "zte_zxros",
    "huawei_olt": "huawei_olt",
    "zte_olt": "zte_zxros",
    "fiberhome_olt": "generic",
    "parks_olt": "generic",
}

FUNCOES = {
    "borda": "Roteador de borda",
    "core": "Core",
    "agregacao": "Agregação",
    "acesso": "Acesso",
    "olt": "OLT",
    "concentrador": "Concentrador (BNG/PPPoE)",
    "outro": "Outro",
}

# Fabricantes que usam "enable" para entrar no modo privilegiado
USA_ENABLE = {"cisco_ios", "cisco_xe", "zte_zxros", "zte_olt", "huawei_olt", "parks_olt"}
# Fabricantes que podem paginar a saída com "more" mesmo pedindo para não paginar
PAGINA_SAIDA = {"zte_zxros", "zte_olt", "huawei_olt", "fiberhome_olt", "parks_olt"}

COMANDOS_BACKUP = {
    "cisco_ios": "show running-config",
    "cisco_xe": "show running-config",
    "mikrotik_routeros": "/export",
    "huawei": "display current-configuration",
    "juniper_junos": "show configuration | display set",
    "zte_zxros": "show running-config",
    "huawei_olt": "display current-configuration",
    "zte_olt": "show running-config",
    "fiberhome_olt": "show running-config",
    "parks_olt": "show running-config",
}

COMANDOS_LOG = {
    "cisco_ios": "show logging",
    "cisco_xe": "show logging",
    "mikrotik_routeros": "/log print",
    "huawei": "display logbuffer",
    "juniper_junos": "show log messages | last 300",
    "zte_zxros": "show logging alarm",      # em alguns modelos: "show logfile"
    "huawei_olt": "display log all",
    "zte_olt": "show logging alarm",
    "fiberhome_olt": "show log",
    "parks_olt": "show logging",
}

COMANDOS_CPU = {
    "cisco_ios": "show processes cpu | include CPU utilization",
    "cisco_xe": "show processes cpu | include CPU utilization",
    "mikrotik_routeros": "/system resource print",
    "huawei": "display cpu-usage",
    "juniper_junos": "show chassis routing-engine",
    "zte_zxros": "show processor",
    "huawei_olt": "display cpu 0/0",
    "zte_olt": "show processor",
    "fiberhome_olt": "show cpu",
    "parks_olt": "show cpu",
}

COMANDOS_EVIDENCIA = {
    "cisco_ios": ["show users", "show processes cpu sorted", "show ip interface brief"],
    "cisco_xe": ["show users", "show processes cpu sorted", "show ip interface brief"],
    "mikrotik_routeros": ["/user active print", "/system resource print",
                          "/ip firewall connection print count-only", "/interface print stats"],
    "huawei": ["display users", "display cpu-usage", "display interface brief"],
    "juniper_junos": ["show system users", "show chassis routing-engine", "show interfaces terse"],
    "zte_zxros": ["show users", "show processor", "show ip interface brief"],
    "huawei_olt": ["display client", "display cpu 0/0", "display board 0"],
    "zte_olt": ["show users", "show processor", "show card"],
    "fiberhome_olt": ["show user", "show cpu"],
    "parks_olt": ["show users", "show cpu"],
}

PADROES_HOSTNAME = {
    "cisco_ios": r"^hostname\s+(\S+)",
    "cisco_xe": r"^hostname\s+(\S+)",
    "mikrotik_routeros": r"^/system identity\s*\n\s*set name=\"?([^\"\n]+)\"?",
    "huawei": r"^\s*sysname\s+(\S+)",
    "juniper_junos": r"^set system host-name\s+(\S+)",
    "zte_zxros": r"^\s*hostname\s+(\S+)",
    "huawei_olt": r"^\s*sysname\s+(\S+)",
    "zte_olt": r"^\s*hostname\s+(\S+)",
    "fiberhome_olt": r"^\s*hostname\s+(\S+)",
    "parks_olt": r"^\s*hostname\s+(\S+)",
}

PADRAO_FALHA_LOGIN = re.compile(
    r"login fail|logon fail|LOGIN_FAILED|authentication fail|Failed password|"
    r"USERAUTH.*fail|invalid user|password.*(?:wrong|incorrect)",
    re.IGNORECASE,
)
PADRAO_IP = re.compile(r"\b(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}\b")

# Regras de auditoria: (modo, regex, mensagem, severidade)
#   "presente" = problema se APARECER; "ausente" = problema se NÃO aparecer
REGRAS = {
    "cisco_ios": [
        ("presente", r"^\s*transport input .*telnet", "Telnet habilitado nas linhas VTY", "alta"),
        ("presente", r"^snmp-server community (public|private)\b", "SNMP com community padrão", "alta"),
        ("presente", r"^ip http server", "Servidor HTTP sem criptografia ativo", "media"),
        ("presente", r"^enable password ", "Usa 'enable password' em vez de 'enable secret'", "alta"),
        ("ausente", r"^service password-encryption", "Senhas não estão criptografadas na config", "media"),
        ("ausente", r"^logging host ", "Sem servidor de syslog configurado", "media"),
        ("ausente", r"^ip ssh version 2", "SSH versão 2 não está forçado", "media"),
    ],
    "mikrotik_routeros": [
        ("ausente", r"set telnet .*disabled=yes", "Telnet não está desativado", "alta"),
        ("ausente", r"set ftp .*disabled=yes", "FTP não está desativado", "alta"),
        ("ausente", r"set www .*disabled=yes", "WebFig via HTTP (sem criptografia) não está desativado", "media"),
        ("ausente", r"set api .*disabled=yes", "API sem criptografia não está desativada", "media"),
        ("ausente", r"/system logging action", "Sem logging remoto configurado", "media"),
        ("presente", r"/ip dns\s*\n\s*set .*allow-remote-requests=yes", "DNS aberto para consultas externas (risco de amplificação)", "alta"),
    ],
    "huawei": [
        ("presente", r"^\s*telnet server enable", "Telnet habilitado", "alta"),
        ("presente", r"protocol inbound (all|telnet)", "VTY aceita Telnet", "alta"),
        ("presente", r"snmp-agent community \S+ (public|private)", "SNMP com community padrão", "alta"),
        ("ausente", r"^\s*info-center loghost ", "Sem servidor de syslog configurado", "media"),
    ],
    "juniper_junos": [
        ("presente", r"set system services telnet", "Telnet habilitado", "alta"),
        ("presente", r"set system services ftp", "FTP habilitado", "alta"),
        ("presente", r"set snmp community (public|private)", "SNMP com community padrão", "alta"),
        ("ausente", r"set system syslog host ", "Sem servidor de syslog configurado", "media"),
    ],
    "zte_zxros": [
        ("presente", r"^\s*telnet[- ]server enable", "Telnet habilitado", "alta"),
        ("presente", r"^\s*snmp-server community (public|private)\b", "SNMP com community padrão", "alta"),
        ("presente", r"^\s*enable password ", "Usa 'enable password' em texto em vez de 'enable secret'", "alta"),
        ("ausente", r"^\s*(syslog-server host|syslog server)\s", "Sem servidor de syslog configurado", "media"),
    ],
    "huawei_olt": [
        ("presente", r"snmp-agent community \S+ (public|private)", "SNMP com community padrão", "alta"),
        ("ausente", r"^\s*(syslog|loghost)", "Sem servidor de syslog configurado", "media"),
    ],
}
for _olt in ("zte_olt", "fiberhome_olt", "parks_olt"):
    REGRAS[_olt] = [
        ("presente", r"snmp-server community (public|private)\b", "SNMP com community padrão", "alta"),
    ]
REGRAS["cisco_xe"] = REGRAS["cisco_ios"]
