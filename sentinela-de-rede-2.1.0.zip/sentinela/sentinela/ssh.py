"""Conexão SSH com os equipamentos (via netmiko) e leitura das respostas."""

import re
import time

from . import fabricantes as fab
from .config import CFG

PAGINADOR = re.compile(
    r"[ \t]*-+ ?more ?-+(?:[ \t]*Press Q or Ctrl\+C to break[ \t]*-*)?[ \t]*|--\s*More\s*--|"
    r"---- More \( Press 'Q' to break \) ----",
    re.IGNORECASE,
)


class ErroConexao(Exception):
    pass


def conectar(equip):
    """Abre a sessão SSH. `equip` precisa ter os segredos já decifrados."""
    from netmiko import ConnectHandler  # importado aqui para o painel abrir mesmo sem netmiko

    if not equip.get("senha"):
        raise ErroConexao("senha não cadastrada: edite o equipamento e informe a senha")
    tipo = equip["tipo"]
    conn = ConnectHandler(
        device_type=fab.DRIVER_NETMIKO.get(tipo, tipo),
        host=equip["host"],
        username=equip["usuario"],
        password=equip["senha"],
        secret=equip.get("enable") or equip["senha"],
        port=int(equip.get("porta") or 22),
        timeout=int(CFG["monitoramento"]["timeout_conexao"]),
        conn_timeout=int(CFG["monitoramento"]["timeout_conexao"]),
    )
    if tipo in fab.USA_ENABLE:
        try:
            if not conn.check_enable_mode():
                conn.enable()
        except Exception:
            conn.disconnect()
            raise
    return conn


def executar(conn, comando, tipo, timeout=120):
    """Envia um comando. Nos fabricantes que paginam ("more"), passa as páginas sozinho."""
    if tipo not in fab.PAGINA_SAIDA:
        return conn.send_command(comando, read_timeout=timeout)

    parte = conn.send_command_timing(comando, read_timeout=timeout, last_read=1.5)
    saida = parte
    limite = time.time() + timeout
    while PAGINADOR.search(parte[-300:]) and time.time() < limite:
        parte = conn.send_command_timing(" ", read_timeout=timeout, last_read=1.5,
                                         strip_command=False, normalize=False)
        saida += parte
    saida = PAGINADOR.sub("", saida)
    return re.sub(r"\x08+|\x1b\[[0-9;?]*[A-Za-z]", "", saida)


def descobrir_hostname(conn, config, tipo):
    padrao = fab.PADROES_HOSTNAME.get(tipo)
    if padrao:
        m = re.search(padrao, config, re.MULTILINE)
        if m:
            return m.group(1).strip()
    try:
        prompt = conn.find_prompt()
    except Exception:
        return None
    m = re.search(r"@([^\]>\s]+)", prompt) or re.search(r"<?([\w.\-]+)", prompt)
    return m.group(1) if m else None


def ler_cpu(texto, tipo):
    if tipo == "juniper_junos":
        m = re.search(r"Idle\s+(\d+)\s+percent", texto)
        return 100 - int(m.group(1)) if m else None
    if tipo in ("zte_zxros", "zte_olt"):
        pos = texto.find("CPU(")
        m = re.search(r"(\d+)%", texto[pos:] if pos >= 0 else texto)
        return int(m.group(1)) if m else None
    for padrao in (r"cpu-load:\s*(\d+)%", r"five seconds:\s*(\d+)%", r"CPU [Uu]sage\s*:\s*(\d+)%",
                   r"CPU occupancy\s*:\s*(\d+)%", r"(\d+)%"):
        m = re.search(padrao, texto)
        if m:
            return int(m.group(1))
    return None


def auditar(config, tipo):
    """Retorna lista de (mensagem, severidade) com os problemas encontrados."""
    problemas = []
    for modo, padrao, mensagem, severidade in fab.REGRAS.get(tipo, []):
        achou = re.search(padrao, config, re.MULTILINE) is not None
        if (modo == "presente" and achou) or (modo == "ausente" and not achou):
            problemas.append({"mensagem": mensagem, "severidade": severidade})
    return problemas


def coletar_evidencias(conn, tipo):
    evidencias = {}
    for comando in fab.COMANDOS_EVIDENCIA.get(tipo, []):
        try:
            evidencias[comando] = executar(conn, comando, tipo, 60)
        except Exception as e:
            evidencias[comando] = f"(falha ao capturar: {e})"
    return evidencias


def descrever_erro(e):
    nome = e.__class__.__name__
    if "Authentication" in nome:
        return "usuário ou senha inválidos"
    if "Timeout" in nome or isinstance(e, TimeoutError):
        return "sem resposta (IP/porta errados, SSH desativado, queda ou ataque em andamento?)"
    if isinstance(e, ConnectionRefusedError):
        return "conexão recusada (SSH desativado ou porta errada)"
    if isinstance(e, ModuleNotFoundError):
        return "biblioteca netmiko não instalada (rode: python -m pip install -r requirements.txt)"
    return str(e) or nome
