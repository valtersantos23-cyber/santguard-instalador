"""Detecção de DDoS por fluxo: coletor NetFlow v5/v9, IPFIX e sFlow v5.

Os roteadores exportam um resumo do tráfego (fluxos ou amostras de pacotes). A cada janela
(10 s por padrão) o tráfego é somado por IP de destino; se um IP das suas redes recebe mais
que o limite de Mbps ou de pacotes/s, é aberto um ataque DDoS e o vetor é identificado
(SYN flood, UDP flood, amplificação DNS/NTP/memcached/SSDP/CLDAP...).
"""

import datetime
import ipaddress
import json
import socket
import struct
import threading
import time
from collections import Counter, defaultdict

from . import banco, incidentes
from .config import CFG

# ======================================================================= campos (NetFlow v9 / IPFIX)
F_BYTES, F_PACOTES, F_PROTO, F_FLAGS, F_SPORTA = 1, 2, 4, 6, 7
F_ORIGEM4, F_DPORTA, F_DESTINO4 = 8, 11, 12
F_ORIGEM6, F_DESTINO6 = 27, 28
F_AMOSTRAGEM, F_AMOSTRAGEM_PACOTES, F_AMOSTRAGEM_ALEATORIA = 34, 305, 50
F_BYTES_SAIDA, F_PACOTES_SAIDA = 23, 24
F_BYTES_TOTAL, F_PACOTES_TOTAL = 85, 86
# início/fim do fluxo: NetFlow v9 (uptime em ms), IPFIX em segundos e em ms
F_FIM_UPTIME, F_INICIO_UPTIME = 21, 22
F_INICIO_S, F_FIM_S, F_INICIO_MS, F_FIM_MS = 150, 151, 152, 153

# Portas de origem típicas de ataques de amplificação (UDP)
AMPLIFICACAO = {
    53: "Amplificação DNS", 123: "Amplificação NTP", 11211: "Amplificação memcached",
    1900: "Amplificação SSDP", 389: "Amplificação CLDAP", 19: "Amplificação chargen",
    161: "Amplificação SNMP", 3702: "Amplificação WS-Discovery", 3283: "Amplificação ARD (Apple)",
    10001: "Amplificação Ubiquiti", 5683: "Amplificação CoAP", 37810: "Amplificação DVR", 111: "Amplificação Portmap",
    27015: "Amplificação Steam", 1434: "Amplificação MSSQL",
}
PROTOCOLOS = {1: "ICMP", 6: "TCP", 17: "UDP", 47: "GRE", 58: "ICMPv6", 50: "ESP"}
MAX_ORIGENS = 5000


def _ip(b):
    try:
        return str(ipaddress.ip_address(b))
    except ValueError:
        return None


# ======================================================================= decodificadores

class Decodificador:
    """Guarda templates (v9/IPFIX) e taxa de amostragem por exportador."""

    def __init__(self):
        self.templates = {}       # (exportador, domínio, id) -> [(tipo, tamanho)]
        self.amostragem = {}      # exportador -> taxa (1 = sem amostragem)
        self.exportadores = {}    # ip -> {"versao", "ultimo", "fluxos", "amostragem"}

    def _registrar(self, exportador, versao, fluxos):
        info = self.exportadores.setdefault(exportador, {"versao": versao, "ultimo": 0, "fluxos": 0})
        info.update(versao=versao, ultimo=time.time(), amostragem=self.amostragem.get(exportador, 1))
        info["fluxos"] += fluxos

    # ---------------------------------------------------------------- NetFlow v5
    def netflow_v5(self, dados, exportador):
        versao, quantidade = struct.unpack_from(">HH", dados, 0)
        intervalo = struct.unpack_from(">H", dados, 22)[0] & 0x3FFF
        taxa = intervalo or self.amostragem.get(exportador, 1)
        fluxos = []
        for i in range(quantidade):
            pos = 24 + i * 48
            if pos + 48 > len(dados):
                break
            origem, destino = dados[pos:pos + 4], dados[pos + 4:pos + 8]
            pacotes, octetos = struct.unpack_from(">II", dados, pos + 16)
            primeiro, ultimo = struct.unpack_from(">II", dados, pos + 24)
            sporta, dporta = struct.unpack_from(">HH", dados, pos + 32)
            flags, proto = dados[pos + 37], dados[pos + 38]
            duracao = (ultimo - primeiro) / 1000 if ultimo >= primeiro else None
            fluxos.append((_ip(origem), _ip(destino), proto, sporta, dporta, flags, octetos * taxa, pacotes * taxa, duracao))
        self._registrar(exportador, "NetFlow v5", len(fluxos))
        return fluxos

    # ---------------------------------------------------------------- NetFlow v9 e IPFIX
    def _registro(self, campos, dados, pos, exportador):
        valores = {}
        for tipo, tamanho in campos:
            if tamanho == 0xFFFF:  # tamanho variável (IPFIX)
                tamanho = dados[pos]
                pos += 1
                if tamanho == 255:
                    tamanho = struct.unpack_from(">H", dados, pos)[0]
                    pos += 2
            bruto = dados[pos:pos + tamanho]
            pos += tamanho
            if tipo in (F_ORIGEM4, F_DESTINO4, F_ORIGEM6, F_DESTINO6):
                valores[tipo] = bruto
            elif tipo <= 0xFFFF:
                valores[tipo] = int.from_bytes(bruto, "big") if tamanho <= 8 else bruto
        return valores, pos

    def _tamanho_registro(self, campos):
        if any(t == 0xFFFF for _, t in campos):
            return None
        return sum(t for _, t in campos)

    def _fluxo_de(self, v, taxa):
        origem = _ip(v.get(F_ORIGEM4) or v.get(F_ORIGEM6) or b"")
        destino = _ip(v.get(F_DESTINO4) or v.get(F_DESTINO6) or b"")
        if not destino:
            return None
        octetos = v.get(F_BYTES) or v.get(F_BYTES_TOTAL) or v.get(F_BYTES_SAIDA) or 0
        pacotes = v.get(F_PACOTES) or v.get(F_PACOTES_TOTAL) or v.get(F_PACOTES_SAIDA) or 0
        duracao = None
        for inicio, fim, escala in ((F_INICIO_UPTIME, F_FIM_UPTIME, 1000), (F_INICIO_MS, F_FIM_MS, 1000),
                                    (F_INICIO_S, F_FIM_S, 1)):
            if isinstance(v.get(inicio), int) and isinstance(v.get(fim), int) and v[fim] >= v[inicio]:
                duracao = (v[fim] - v[inicio]) / escala
                break
        return (origem, destino, v.get(F_PROTO, 0), v.get(F_SPORTA, 0), v.get(F_DPORTA, 0),
                v.get(F_FLAGS, 0) & 0xFF, octetos * taxa, pacotes * taxa, duracao)

    def netflow_v9_ipfix(self, dados, exportador):
        versao = struct.unpack_from(">H", dados, 0)[0]
        if versao == 9:
            dominio = struct.unpack_from(">I", dados, 16)[0]
            pos, fim = 20, len(dados)
            id_template, id_opcoes = 0, 1
        else:  # IPFIX (10)
            tamanho_total, dominio = struct.unpack_from(">H", dados, 2)[0], struct.unpack_from(">I", dados, 12)[0]
            pos, fim = 16, min(len(dados), tamanho_total)
            id_template, id_opcoes = 2, 3
        fluxos = []
        while pos + 4 <= fim:
            id_conjunto, tamanho = struct.unpack_from(">HH", dados, pos)
            if tamanho < 4:
                break
            corpo_fim = min(pos + tamanho, fim)
            p = pos + 4
            if id_conjunto == id_template:
                while p + 4 <= corpo_fim:
                    tid, n = struct.unpack_from(">HH", dados, p)
                    p += 4
                    campos = []
                    for _ in range(n):
                        tipo, tam = struct.unpack_from(">HH", dados, p)
                        p += 4
                        if tipo & 0x8000 and versao == 10:  # campo de fabricante (enterprise)
                            p += 4
                            tipo = 0x10000 | (tipo & 0x7FFF)
                        campos.append((tipo, tam))
                    if campos and all(tam > 0 for _, tam in campos) and len(campos) <= 128:
                        self.templates[(exportador, dominio, tid)] = campos
                    else:  # template inválido (campo de tamanho 0 travaria a leitura)
                        self.templates.pop((exportador, dominio, tid), None)
            elif id_conjunto == id_opcoes:
                while p + 6 <= corpo_fim:
                    if versao == 9:
                        tid, escopo_tam, opcao_tam = struct.unpack_from(">HHH", dados, p)
                        p += 6
                        campos = []
                        for _ in range((escopo_tam + opcao_tam) // 4):
                            tipo, tam = struct.unpack_from(">HH", dados, p)
                            p += 4
                            campos.append((tipo, tam))
                    else:
                        tid, n, _escopo = struct.unpack_from(">HHH", dados, p)
                        p += 6
                        campos = []
                        for _ in range(n):
                            tipo, tam = struct.unpack_from(">HH", dados, p)
                            p += 4
                            if tipo & 0x8000:
                                p += 4
                                tipo = 0x10000 | (tipo & 0x7FFF)
                            campos.append((tipo, tam))
                    if campos and all(tam > 0 for _, tam in campos) and len(campos) <= 128:
                        self.templates[(exportador, dominio, tid)] = campos
                    if not campos or corpo_fim - p < 6:
                        break  # o resto é preenchimento
            elif id_conjunto >= 256:
                campos = self.templates.get((exportador, dominio, id_conjunto))
                if campos:
                    tam_fixo = self._tamanho_registro(campos)
                    taxa = self.amostragem.get(exportador, 1)
                    while p < corpo_fim and (tam_fixo is None or p + tam_fixo <= corpo_fim):
                        antes = p
                        valores, p = self._registro(campos, dados, p, exportador)
                        if p <= antes:  # nunca ficar parado no mesmo lugar
                            break
                        amostra = (valores.get(F_AMOSTRAGEM) or valores.get(F_AMOSTRAGEM_PACOTES)
                                   or valores.get(F_AMOSTRAGEM_ALEATORIA))
                        if amostra and not (valores.get(F_DESTINO4) or valores.get(F_DESTINO6)):
                            self.amostragem[exportador] = max(1, int(amostra))  # registro de opções
                            continue
                        fluxo = self._fluxo_de(valores, amostra or taxa)
                        if fluxo:
                            fluxos.append(fluxo)
                        if tam_fixo is not None and corpo_fim - p < tam_fixo:
                            break
            pos += tamanho
        self._registrar(exportador, "NetFlow v9" if versao == 9 else "IPFIX", len(fluxos))
        return fluxos

    # ---------------------------------------------------------------- sFlow v5
    def sflow_v5(self, dados, exportador):
        versao, tipo_end = struct.unpack_from(">II", dados, 0)
        pos = 8 + (4 if tipo_end == 1 else 16)
        pos += 12  # sub-agente, sequência, uptime
        n_amostras = struct.unpack_from(">I", dados, pos)[0]
        pos += 4
        fluxos = []
        for _ in range(n_amostras):
            if pos + 8 > len(dados):
                break
            formato, tamanho = struct.unpack_from(">II", dados, pos)
            corpo = dados[pos + 8:pos + 8 + tamanho]
            pos += 8 + tamanho
            if formato == 1:          # flow sample
                taxa = struct.unpack_from(">I", corpo, 8)[0]
                n_reg, p = struct.unpack_from(">I", corpo, 28)[0], 32
            elif formato == 3:        # expanded flow sample
                taxa = struct.unpack_from(">I", corpo, 12)[0]
                n_reg, p = struct.unpack_from(">I", corpo, 40)[0], 44
            else:
                continue
            self.amostragem[exportador] = taxa or 1
            for _ in range(n_reg):
                if p + 8 > len(corpo):
                    break
                fmt_reg, tam_reg = struct.unpack_from(">II", corpo, p)
                reg = corpo[p + 8:p + 8 + tam_reg]
                p += 8 + tam_reg
                if fmt_reg != 1 or len(reg) < 16:
                    continue
                protocolo_cab, tam_quadro, _removido, tam_cab = struct.unpack_from(">IIII", reg, 0)
                if protocolo_cab != 1:  # só Ethernet
                    continue
                fluxo = _ler_ethernet(reg[16:16 + tam_cab])
                if fluxo:
                    origem, destino, proto, sporta, dporta, flags = fluxo
                    fluxos.append((origem, destino, proto, sporta, dporta, flags, tam_quadro * (taxa or 1), taxa or 1, None))
        self._registrar(exportador, "sFlow v5", len(fluxos))
        return fluxos


def _ler_ethernet(quadro):
    if len(quadro) < 14:
        return None
    tipo, pos = struct.unpack_from(">H", quadro, 12)[0], 14
    while tipo in (0x8100, 0x88A8) and len(quadro) >= pos + 4:  # VLAN / QinQ
        tipo = struct.unpack_from(">H", quadro, pos + 2)[0]
        pos += 4
    if tipo == 0x0800 and len(quadro) >= pos + 20:
        ihl = (quadro[pos] & 0x0F) * 4
        proto = quadro[pos + 9]
        origem, destino = _ip(quadro[pos + 12:pos + 16]), _ip(quadro[pos + 16:pos + 20])
        l4 = pos + ihl
    elif tipo == 0x86DD and len(quadro) >= pos + 40:
        proto = quadro[pos + 6]
        origem, destino = _ip(quadro[pos + 8:pos + 24]), _ip(quadro[pos + 24:pos + 40])
        l4 = pos + 40
    else:
        return None
    sporta = dporta = flags = 0
    if proto in (6, 17) and len(quadro) >= l4 + 4:
        sporta, dporta = struct.unpack_from(">HH", quadro, l4)
        if proto == 6 and len(quadro) >= l4 + 14:
            flags = quadro[l4 + 13]
    return origem, destino, proto, sporta, dporta, flags


# ======================================================================= agregação e detecção

class _Estatistica:
    """Tráfego para um destino numa janela.

    bytes/pacotes: fluxos sem duração conhecida (sFlow, fluxos curtos), divididos pelo tempo da janela.
    bps_fluxo/pps_fluxo: fluxos com início e fim (NetFlow/IPFIX), cuja taxa real é bytes / duração.
    Isso evita superestimar o tráfego quando o roteador exporta um minuto inteiro de uma só vez.
    volume/qtd_pacotes: tudo somado, só para saber a composição do tráfego (vetor do ataque).
    """
    __slots__ = ("bytes", "pacotes", "bps_fluxo", "pps_fluxo", "volume", "qtd_pacotes", "protocolos",
                 "portas_origem", "syn", "ack", "origens", "origens_extra")

    def __init__(self):
        self.bytes = self.pacotes = self.syn = self.ack = self.origens_extra = 0
        self.bps_fluxo = self.pps_fluxo = 0.0
        self.volume = self.qtd_pacotes = 0
        self.protocolos = Counter()
        self.portas_origem = Counter()
        self.origens = Counter()


def classificar(est):
    """Identifica o vetor do ataque a partir da composição do tráfego."""
    total = est.volume or 1
    proto, b_proto = est.protocolos.most_common(1)[0] if est.protocolos else (0, 0)
    if proto == 17:
        porta, b_porta = est.portas_origem.most_common(1)[0] if est.portas_origem else (0, 0)
        if porta in AMPLIFICACAO and b_porta / total >= 0.5:
            return AMPLIFICACAO[porta], b_porta / total
        return "UDP flood", b_proto / total
    if proto == 6:
        pacotes = est.qtd_pacotes or 1
        if est.syn / pacotes >= 0.5:
            return "SYN flood", est.syn / pacotes
        if est.ack / pacotes >= 0.5:
            return "TCP ACK flood", est.ack / pacotes
        return "TCP flood", b_proto / total
    if proto in (1, 58):
        return "ICMP flood", b_proto / total
    if proto == 47:
        return "GRE flood", b_proto / total
    return f"Flood {PROTOCOLOS.get(proto, f'protocolo {proto}')}", b_proto / total


def formatar_bps(bps):
    for limite, unidade in ((1e9, "Gbps"), (1e6, "Mbps"), (1e3, "kbps")):
        if bps >= limite:
            return f"{bps / limite:.1f} {unidade}"
    return f"{bps:.0f} bps"


class ColetorFluxo:
    """Agrega o tráfego por (empresa, IP de destino) em janelas e detecta DDoS.

    A empresa de cada fluxo é a do roteador que o exportou (equipamento cadastrado). Assim, dois
    provedores podem ter os mesmos IPs privados sem que os dados se misturem.
    """

    def __init__(self):
        self.trava = threading.Lock()
        self.decodificador = Decodificador()
        self.janela = defaultdict(_Estatistica)        # (empresa_id, destino) -> estatística
        self.inicio_janela = time.time()
        self.ultima = {}                               # empresa_id -> última janela com tráfego
        self.ativos = {}                               # (empresa_id, destino) -> ataque em andamento
        self.ao_detectar = []                          # callbacks(ataque) -> mitigação
        self.erros = {"netflow": None, "sflow": None}
        self.pacotes_recebidos = Counter()             # por empresa
        self.ignorados = 0
        self.ultimo_ignorado = None
        self._redes = {"quando": 0, "por_empresa": {}}
        self._cache_nosso = {}

    # ---------------------------------------------------------------- redes de cada empresa
    def carregar_redes(self):
        from . import empresas
        por_empresa = {}
        for linha in banco.consultar("SELECT id FROM empresas"):
            redes = []
            for texto in empresas.redes(linha["id"]):
                try:
                    redes.append(ipaddress.ip_network(texto, strict=False))
                except ValueError:
                    pass
            por_empresa[linha["id"]] = redes
        self._redes = {"quando": time.time(), "por_empresa": por_empresa}
        self._cache_nosso = {}

    def redes_da_empresa(self, empresa_id):
        if time.time() - self._redes["quando"] > 30:
            self.carregar_redes()
        return self._redes["por_empresa"].get(empresa_id, [])

    def _eh_nosso(self, empresa_id, ip):
        chave = (empresa_id, ip)
        if chave in self._cache_nosso:
            return self._cache_nosso[chave]
        redes = self.redes_da_empresa(empresa_id)
        if not redes:
            resultado = True  # empresa sem redes configuradas: analisa todos os destinos
        else:
            try:
                endereco = ipaddress.ip_address(ip)
                resultado = any(endereco in rede for rede in redes)
            except ValueError:
                resultado = False
        if len(self._cache_nosso) > 200_000:
            self._cache_nosso = {}
        self._cache_nosso[chave] = resultado
        return resultado

    def _empresa_do_destino(self, destino):
        from . import empresas
        chave = ("destino", destino)
        if chave not in self._cache_nosso:
            dona = empresas.empresa_do_ip(destino)
            if dona is None and len(self._redes["por_empresa"]) <= 1:
                dona = 1  # instalação de uma empresa só: tudo é dela
            self._cache_nosso[chave] = dona
        return self._cache_nosso[chave]

    # ---------------------------------------------------------------- entrada
    def empresa_do_exportador(self, ip):
        from .tempo_real import TEMPO_REAL
        equip = TEMPO_REAL.equipamento_por_ip(ip)
        return equip["empresa_id"] if equip else None

    def processar_pacote(self, dados, exportador, verificar_origem=False):
        empresa_id = self.empresa_do_exportador(exportador)
        if empresa_id is None and verificar_origem and not CFG["fluxo"].get("aceitar_qualquer_exportador"):
            # só aceita fluxo de equipamentos cadastrados (UDP pode ter a origem falsificada)
            self.ignorados += 1
            self.ultimo_ignorado = exportador
            return []
        if len(dados) < 4:
            return []
        versao16 = struct.unpack_from(">H", dados, 0)[0]
        try:
            if versao16 == 5:
                fluxos = self.decodificador.netflow_v5(dados, exportador)
            elif versao16 in (9, 10):
                fluxos = self.decodificador.netflow_v9_ipfix(dados, exportador)
            elif struct.unpack_from(">I", dados, 0)[0] == 5:
                fluxos = self.decodificador.sflow_v5(dados, exportador)
            else:
                self.ignorados += 1
                return []
        except (struct.error, IndexError, ValueError):
            self.ignorados += 1
            return []
        self.pacotes_recebidos[empresa_id] += 1
        self.somar(fluxos, empresa_id)
        return fluxos

    def somar(self, fluxos, empresa_id=None):
        with self.trava:
            for origem, destino, proto, sporta, dporta, flags, octetos, pacotes, duracao in fluxos:
                if not destino:
                    continue
                empresa = empresa_id if empresa_id is not None else self._empresa_do_destino(destino)
                if empresa is None or not self._eh_nosso(empresa, destino):
                    continue
                est = self.janela[(empresa, destino)]
                if duracao is not None and duracao >= 1:
                    est.bps_fluxo += octetos * 8 / duracao
                    est.pps_fluxo += pacotes / duracao
                else:
                    est.bytes += octetos
                    est.pacotes += pacotes
                est.volume += octetos
                est.qtd_pacotes += pacotes
                est.protocolos[proto] += octetos
                if proto == 17:
                    est.portas_origem[sporta] += octetos
                elif proto == 6:
                    if flags & 0x02 and not flags & 0x10:
                        est.syn += pacotes
                    elif flags & 0x10 and not flags & 0x07:
                        est.ack += pacotes
                if origem:
                    if origem in est.origens or len(est.origens) < MAX_ORIGENS:
                        est.origens[origem] += octetos
                    else:
                        est.origens_extra += 1

    # ---------------------------------------------------------------- fechamento da janela
    def fechar_janela(self, agora=None):
        agora = agora or time.time()
        with self.trava:
            janela, self.janela = self.janela, defaultdict(_Estatistica)
            duracao = max(1.0, agora - self.inicio_janela)
            self.inicio_janela = agora
        limite_bps = float(CFG["fluxo"]["limite_mbps"]) * 1e6
        limite_pps = float(CFG["fluxo"]["limite_kpps"]) * 1e3

        por_empresa = defaultdict(list)
        for (empresa, destino), est in janela.items():
            bps = est.bytes * 8 / duracao + est.bps_fluxo
            pps = est.pacotes / duracao + est.pps_fluxo
            por_empresa[empresa].append((bps, pps, destino, est))

        hora = datetime.datetime.fromtimestamp(agora).strftime("%H:%M:%S")
        for empresa, top in por_empresa.items():
            top.sort(key=lambda x: x[0], reverse=True)
            self.ultima[empresa] = {
                "inicio": hora, "total_bps": sum(x[0] for x in top), "total_pps": sum(x[1] for x in top),
                "top": [{"ip": d, "bps": b, "pps": p, "vetor": classificar(e)[0],
                         "fontes": len(e.origens) + e.origens_extra} for b, p, d, e in top[:15]],
            }
            for bps, pps, destino, est in top:
                if bps >= limite_bps or pps >= limite_pps:
                    self._registrar_ataque(empresa, destino, bps, pps, est, agora)
        self._encerrar_inativos(agora)

    def _registrar_ataque(self, empresa, destino, bps, pps, est, agora):
        from .tempo_real import TEMPO_REAL

        vetor, proporcao = classificar(est)
        fontes = len(est.origens) + est.origens_extra
        top_origens = est.origens.most_common(10)
        detalhe = f"{vetor} · {formatar_bps(bps)} · {pps / 1000:.0f} kpps · {fontes} origem(ns)"
        TEMPO_REAL.registrar_ataque(TEMPO_REAL.chave_ip(empresa, destino), "DDoS volumétrico",
                                    [ip for ip, _ in top_origens], detalhe=detalhe)
        ataque = self.ativos.get((empresa, destino))
        if ataque is None:
            titulo = f"DDoS em {destino}: {detalhe}"
            incidente, _ = incidentes.abrir(None, f"Cliente {destino}", "DDoS volumétrico", titulo, detalhes=titulo,
                                            severidade="alta", chave=f"ddos|{destino}", empresa_id=empresa)
            id_ataque = banco.executar(
                "INSERT INTO ddos (alvo, inicio, ultimo, pico_bps, pico_pps, vetor, origens, fontes, incidente_id, estado, "
                "empresa_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ativo', ?)",
                (destino, agora, agora, bps, pps, vetor, json.dumps(top_origens), fontes, incidente["id"], empresa))
            ataque = {"id": id_ataque, "inicio": agora, "pico_bps": bps, "pico_pps": pps, "vetor": vetor,
                      "incidente_id": incidente["id"]}
            self.ativos[(empresa, destino)] = ataque
            incidentes.registrar_evento(None, f"Cliente {destino}", "DDoS volumétrico", "ataque", titulo,
                                        ", ".join(ip for ip, _ in top_origens[:5]), "fluxo", empresa_id=empresa)
            for funcao in self.ao_detectar:
                try:
                    funcao(dict(ataque, alvo=destino, bps=bps, pps=pps, origens=top_origens, proporcao=proporcao,
                                empresa_id=empresa))
                except Exception as e:
                    incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"Mitigação: {e}",
                                                fonte="sistema")
        ataque["ultimo"] = agora
        ataque["pico_bps"] = max(ataque["pico_bps"], bps)
        ataque["pico_pps"] = max(ataque["pico_pps"], pps)
        banco.executar("UPDATE ddos SET ultimo = ?, pico_bps = ?, pico_pps = ?, vetor = ?, origens = ?, fontes = MAX(fontes, ?) "
                       "WHERE id = ?", (agora, ataque["pico_bps"], ataque["pico_pps"], vetor, json.dumps(top_origens),
                                        fontes, ataque["id"]))

    def _encerrar_inativos(self, agora):
        espera = int(CFG["tempo_real"]["janela_ataque_min"]) * 60
        for (empresa, destino), ataque in list(self.ativos.items()):
            if agora - ataque["ultimo"] > espera:
                banco.executar("UPDATE ddos SET estado = 'encerrado', fim = ? WHERE id = ?", (ataque["ultimo"], ataque["id"]))
                incidentes.registrar_evento(None, f"Cliente {destino}", "DDoS encerrado", "info",
                                            f"DDoS em {destino} terminou (pico {formatar_bps(ataque['pico_bps'])}, "
                                            f"duração {int((ataque['ultimo'] - ataque['inicio']) / 60)} min)",
                                            fonte="fluxo", empresa_id=empresa)
                del self.ativos[(empresa, destino)]

    # ---------------------------------------------------------------- rede
    def _escutar(self, porta, nome):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
            sock.bind(("0.0.0.0", porta))
        except OSError as e:
            self.erros[nome] = f"Não consegui abrir a porta UDP {porta}: {e}"
            return
        while True:
            try:
                dados, (ip, _) = sock.recvfrom(65535)
                self.processar_pacote(dados, ip, verificar_origem=True)
            except Exception:
                continue

    def _relogio(self):
        while True:
            time.sleep(max(2, int(CFG["fluxo"]["janela_seg"])))
            try:
                self.fechar_janela()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"Fluxo: {e}", fonte="sistema")

    def iniciar(self):
        if not CFG["fluxo"]["ativo"]:
            return
        threading.Thread(target=self._escutar, args=(int(CFG["fluxo"]["porta_netflow"]), "netflow"),
                         name="netflow", daemon=True).start()
        threading.Thread(target=self._escutar, args=(int(CFG["fluxo"]["porta_sflow"]), "sflow"),
                         name="sflow", daemon=True).start()
        threading.Thread(target=self._relogio, name="fluxo-janela", daemon=True).start()

    def estado(self, empresa_id, fornecedor=False):
        """Dados da tela de DDoS DA EMPRESA informada."""
        empresa_id = int(empresa_id)
        agora = time.time()
        exportadores = [{"ip": ip, "versao": i["versao"], "fluxos": i["fluxos"], "amostragem": i.get("amostragem", 1),
                         "ha_seg": int(agora - i["ultimo"])}
                        for ip, i in list(self.decodificador.exportadores.items())
                        if self.empresa_do_exportador(ip) == empresa_id]
        ativos = [{"alvo": d, "vetor": a["vetor"], "pico_bps": a["pico_bps"], "pico_pps": a["pico_pps"],
                   "inicio": datetime.datetime.fromtimestamp(a["inicio"]).strftime("%H:%M:%S"),
                   "duracao_seg": int(agora - a["inicio"]), "id": a["id"], "incidente_id": a["incidente_id"]}
                  for (e, d), a in list(self.ativos.items()) if e == empresa_id]
        historico = banco.consultar("SELECT * FROM ddos WHERE empresa_id = ? ORDER BY id DESC LIMIT 100", (empresa_id,))
        for h in historico:
            h["origens"] = json.loads(h["origens"] or "[]")
            h["inicio_txt"] = datetime.datetime.fromtimestamp(h["inicio"]).strftime("%d/%m %H:%M:%S")
            h["duracao_seg"] = int((h["fim"] or h["ultimo"]) - h["inicio"])
        return {
            "ativo": bool(CFG["fluxo"]["ativo"]), "portas": {"netflow": int(CFG["fluxo"]["porta_netflow"]),
                                                            "sflow": int(CFG["fluxo"]["porta_sflow"])},
            "erros": self.erros, "exportadores": exportadores,
            "ultima_janela": self.ultima.get(empresa_id, {"inicio": None, "top": [], "total_bps": 0, "total_pps": 0}),
            "ativos": ativos, "historico": historico,
            "redes": [str(r) for r in self.redes_da_empresa(empresa_id)],
            "limites": {"mbps": float(CFG["fluxo"]["limite_mbps"]), "kpps": float(CFG["fluxo"]["limite_kpps"])},
            "pacotes_recebidos": self.pacotes_recebidos.get(empresa_id, 0),
            "ignorados": self.ignorados if fornecedor else 0,
            "ultimo_ignorado": self.ultimo_ignorado if fornecedor else None,
        }


FLUXO = ColetorFluxo()
