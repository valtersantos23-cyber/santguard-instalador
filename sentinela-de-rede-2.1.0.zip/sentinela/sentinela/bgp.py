"""BGP: estado das sessões e prefixos recebidos (via SSH), RPKI e detecção de sequestro de prefixo.

- Sessão BGP que cai (ou volta) em roteador de borda gera alerta.
- Variação brusca de prefixos recebidos (ex.: vazamento de rotas) gera alerta.
- RPKI dos seus prefixos (RIPEstat): inválido ou sem ROA.
- Sequestro de prefixo (hijack): seu prefixo visto na internet com origem em outro ASN.
"""

import datetime
import ipaddress
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from . import banco, equipamentos, incidentes, ssh
from .config import CFG

COMANDOS_BGP = {
    "mikrotik_routeros": "/routing/bgp/session/print detail without-paging",
    "cisco_ios": "show ip bgp all summary",
    "cisco_xe": "show ip bgp all summary",
    "huawei": "display bgp all summary",
    "juniper_junos": "show bgp summary",
    "zte_zxros": "show ip bgp summary",
}
ESTADOS = {"idle", "connect", "active", "opensent", "openconfirm", "established", "establ"}
_IP = r"(?:\d{1,3}(?:\.\d{1,3}){3}|[0-9a-fA-F:]*:[0-9a-fA-F:.]+)"


def _eh_ip(texto):
    try:
        ipaddress.ip_address(texto)
        return True
    except ValueError:
        return False


def _ler_mikrotik(texto):
    sessoes = []
    blocos = re.split(r"\n\s*(?=\d+\s+[A-Z ]*\s*name=)", "\n" + texto)
    for bloco in blocos:
        remoto = re.search(r"remote\.address=(\S+)", bloco)
        if not remoto:
            continue
        cabecalho = bloco.strip().split("name=")[0]
        estabelecida = "E" in re.sub(r"^\d+", "", cabecalho)
        asn = re.search(r"remote\.address=\S+.*?\.as=(\d+)", bloco, re.S)
        nome = re.search(r'name="?([^"\s]+)', bloco)
        prefixos = re.search(r"prefix-count=(\d+)", bloco)
        tempo = re.search(r"uptime=(\S+)", bloco)
        sessoes.append({"vizinho": remoto.group(1).split("%")[0], "asn": int(asn.group(1)) if asn else None,
                        "estado": "Established" if estabelecida else "Down", "estabelecida": estabelecida,
                        "prefixos": int(prefixos.group(1)) if prefixos else None,
                        "tempo": tempo.group(1) if tempo else "", "descricao": nome.group(1) if nome else ""})
    return sessoes


def _ler_tabela(texto):
    """Lê o resumo BGP em formato de tabela (Cisco, Huawei, ZTE e Juniper)."""
    sessoes = []
    linhas = texto.splitlines()
    i = 0
    while i < len(linhas):
        linha = linhas[i].strip()
        partes = linha.split()
        i += 1
        if not partes or not _eh_ip(partes[0]):
            continue
        if len(partes) == 1 and i < len(linhas):  # Cisco quebra a linha em vizinhos IPv6
            partes += linhas[i].split()
            i += 1
        if len(partes) < 4:
            continue
        vizinho = partes[0]
        asn_txt = partes[2] if partes[1] == "4" and len(partes) > 3 else partes[1]
        asn = int(asn_txt) if asn_txt.isdigit() else None
        ultimo, penultimo = partes[-1], partes[-2]
        prefixos, estado, tempo = None, None, ""
        if penultimo.lower() in ESTADOS and ultimo.isdigit():          # Huawei: ... Established 123
            estado, prefixos, tempo = penultimo, int(ultimo), partes[-3]
        elif ultimo.isdigit():                                          # Cisco/ZTE: número = prefixos
            estado, prefixos, tempo = "Established", int(ultimo), penultimo
        else:                                                           # Cisco: Idle/Active · Juniper: Establ
            estado = re.sub(r"\(.*\)", "", ultimo)
            tempo = penultimo
        estabelecida = estado.lower() in ("established", "establ")
        if estabelecida and prefixos is None:                           # Juniper: "inet.0: 10/900/899/0"
            while i < len(linhas) and not _eh_ip((linhas[i].split() or [""])[0]):
                m = re.search(r"inet6?\.0:\s*\d+/(\d+)/", linhas[i])
                if m:
                    prefixos = (prefixos or 0) + int(m.group(1))
                i += 1
        sessoes.append({"vizinho": vizinho, "asn": asn, "estado": "Established" if estabelecida else estado,
                        "estabelecida": estabelecida, "prefixos": prefixos, "tempo": tempo, "descricao": ""})
    return sessoes


def ler_sessoes(texto, tipo):
    if tipo == "mikrotik_routeros":
        return _ler_mikrotik(texto)
    return _ler_tabela(texto)


def _agora():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")


class MonitorBgp:
    def __init__(self):
        self.ultimo_ciclo = None
        self.ultimo_rpki = 0
        self.erros = {}

    # ------------------------------------------------------------ sessões
    def verificar(self, equip):
        tipo = equip["tipo"]
        nome = f"{equip['nome']} ({equip['host']})"
        try:
            with ssh.conectar(equip) as conn:
                saida = ssh.executar(conn, COMANDOS_BGP[tipo], tipo)
        except Exception as e:
            self.erros[equip["id"]] = ssh.descrever_erro(e)
            return None
        self.erros.pop(equip["id"], None)
        sessoes = ler_sessoes(saida, tipo)
        anteriores = {s["vizinho"]: s for s in banco.consultar("SELECT * FROM bgp_sessoes WHERE equip_id = ?", (equip["id"],))}
        critico = equip["funcao"] in ("borda", "core")
        variacao = float(CFG["bgp"]["variacao_prefixos_pct"]) / 100
        agora = _agora()
        for s in sessoes:
            ant = anteriores.get(s["vizinho"])
            rotulo = f"{s['vizinho']} (AS{s['asn']})" if s["asn"] else s["vizinho"]
            mudou_em = ant["mudou_em"] if ant else agora
            if ant and bool(ant["estabelecida"]) != s["estabelecida"]:
                mudou_em = agora
                if s["estabelecida"]:
                    incidentes.registrar_evento(equip["id"], nome, "Sessão BGP", "info",
                                                f"Sessão BGP com {rotulo} voltou", fonte="bgp")
                else:
                    texto = f"Sessão BGP com {rotulo} caiu (estado: {s['estado']})"
                    incidentes.registrar_evento(equip["id"], nome, "Sessão BGP", "ataque" if critico else "aviso",
                                                texto, fonte="bgp")
                    incidentes.abrir(equip["id"], nome, "Sessão BGP", texto, detalhes=texto,
                                     severidade="alta" if critico else "media",
                                     chave=f"{equip['id']}|bgp|{s['vizinho']}")
            if (ant and s["estabelecida"] and ant["estabelecida"] and ant["prefixos"] and s["prefixos"] is not None
                    and ant["prefixos"] >= 100 and abs(s["prefixos"] - ant["prefixos"]) / ant["prefixos"] >= variacao):
                sentido = "subiu" if s["prefixos"] > ant["prefixos"] else "caiu"
                texto = (f"Prefixos recebidos de {rotulo} {sentido} de {ant['prefixos']:,} para {s['prefixos']:,}"
                         .replace(",", "."))
                if sentido == "subiu":
                    texto += " (possível vazamento de rotas)"
                incidentes.registrar_evento(equip["id"], nome, "Prefixos BGP", "aviso", texto, fonte="bgp")
                incidentes.abrir(equip["id"], nome, "Prefixos BGP", texto, detalhes=texto, severidade="media",
                                 chave=f"{equip['id']}|bgp-prefixos|{s['vizinho']}")
            banco.executar(
                "INSERT INTO bgp_sessoes (equip_id, vizinho, asn, estado, estabelecida, prefixos, tempo, descricao, atualizado, mudou_em) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(equip_id, vizinho) DO UPDATE SET asn = excluded.asn, "
                "estado = excluded.estado, estabelecida = excluded.estabelecida, prefixos = excluded.prefixos, "
                "tempo = excluded.tempo, descricao = excluded.descricao, atualizado = excluded.atualizado, mudou_em = excluded.mudou_em",
                (equip["id"], s["vizinho"], s["asn"], s["estado"], int(s["estabelecida"]), s["prefixos"], s["tempo"],
                 s["descricao"], agora, mudou_em))
        # sessões que sumiram da saída (vizinho removido da configuração)
        atuais = {s["vizinho"] for s in sessoes}
        for vizinho in set(anteriores) - atuais:
            banco.executar("DELETE FROM bgp_sessoes WHERE equip_id = ? AND vizinho = ?", (equip["id"], vizinho))
        return sessoes

    def ciclo(self):
        lista = [e for e in equipamentos.listar(equipamentos.TODAS, segredos=True, somente_ativos=True)
                 if e["funcao"] in ("borda", "core", "concentrador") and e["tipo"] in COMANDOS_BGP]
        if lista:
            with ThreadPoolExecutor(max_workers=int(CFG["monitoramento"]["conexoes_simultaneas"])) as pool:
                list(pool.map(self.verificar, lista))
        self.ultimo_ciclo = _agora()
        if time.time() - self.ultimo_rpki > float(CFG["bgp"]["rpki_horas"]) * 3600:
            self.verificar_rpki()

    # ------------------------------------------------------------ RPKI e sequestro de prefixo
    @staticmethod
    def _ripestat(dado, **parametros):
        url = f"{CFG['bgp']['ripestat_url'].rstrip('/')}/data/{dado}/data.json?{urllib.parse.urlencode(parametros)}"
        pedido = urllib.request.Request(url, headers={"User-Agent": "Sentinela-de-Rede"})
        with urllib.request.urlopen(pedido, timeout=20) as r:
            return json.loads(r.read().decode())["data"]

    def verificar_rpki(self, empresa_id=None):
        """Verifica RPKI e origem dos prefixos de uma empresa (ou de todas as que têm ASN)."""
        from . import empresas
        self.ultimo_rpki = time.time()
        ids = [empresa_id] if empresa_id is not None else [l["id"] for l in banco.consultar("SELECT id FROM empresas")]
        resultados = []
        for eid in ids:
            asn = empresas.asn(eid)
            if not asn:
                continue
            for prefixo in empresas.prefixos(eid):
                r = {"prefixo": prefixo, "asn": asn, "status": "erro", "roas": [], "visivel": None, "origens": [],
                     "erro": None, "empresa_id": eid}
                try:
                    dados = self._ripestat("rpki-validation", resource=f"AS{asn}", prefix=prefixo)
                    r["status"] = dados.get("status", "unknown")
                    r["roas"] = [{"origem": x.get("origin"), "prefixo": x.get("prefix"), "max": x.get("max_length"),
                                  "validade": x.get("validity")} for x in dados.get("validating_roas", [])]
                    visao = self._ripestat("prefix-overview", resource=prefixo)
                    r["visivel"] = bool(visao.get("announced"))
                    r["origens"] = sorted({int(a["asn"]) for a in visao.get("asns", []) if str(a.get("asn", "")).isdigit()})
                except Exception as e:
                    r["erro"] = f"não consegui consultar o RIPEstat: {e}"
                banco.executar(
                    "INSERT INTO rpki (empresa_id, prefixo, asn, status, roas, visivel, origens, verificado, erro) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(empresa_id, prefixo) DO UPDATE SET asn = excluded.asn, "
                    "status = excluded.status, roas = excluded.roas, visivel = excluded.visivel, origens = excluded.origens, "
                    "verificado = excluded.verificado, erro = excluded.erro",
                    (eid, prefixo, asn, r["status"], json.dumps(r["roas"]),
                     None if r["visivel"] is None else int(r["visivel"]), json.dumps(r["origens"]), _agora(), r["erro"]))
                self._alertar_rpki(r, asn, eid)
                resultados.append(r)
        return resultados

    def _alertar_rpki(self, r, asn, eid):
        prefixo = r["prefixo"]
        nome = f"Prefixo {prefixo}"
        if r["status"].startswith("invalid"):
            motivo = "outro ASN autorizado no ROA" if r["status"] == "invalid_asn" else "prefixo mais específico que o max-length do ROA"
            texto = f"RPKI INVÁLIDO para {prefixo} anunciado pelo AS{asn} ({motivo}): redes que validam RPKI vão descartar essa rota"
            incidentes.registrar_evento(None, nome, "RPKI inválido", "ataque", texto, fonte="rpki", empresa_id=eid)
            incidentes.abrir(None, nome, "RPKI inválido", texto, detalhes=texto, severidade="alta",
                             chave=f"rpki|{prefixo}", empresa_id=eid)
        elif r["status"] == "unknown":
            incidentes.registrar_evento(None, nome, "Sem ROA", "aviso",
                                        f"{prefixo} não tem ROA: crie um ROA no Registro.br/LACNIC para proteger contra sequestro",
                                        fonte="rpki", empresa_id=eid)
        estranhos = [o for o in r["origens"] if o != asn]
        if estranhos:
            texto = (f"Possível SEQUESTRO de prefixo: {prefixo} está sendo anunciado na internet pelo(s) "
                     f"AS{', AS'.join(map(str, estranhos))} (o seu é AS{asn})")
            incidentes.registrar_evento(None, nome, "Sequestro de prefixo", "ataque", texto, fonte="rpki", empresa_id=eid)
            incidentes.abrir(None, nome, "Sequestro de prefixo", texto, detalhes=texto, severidade="alta",
                             chave=f"hijack|{prefixo}", empresa_id=eid)

    # ------------------------------------------------------------ laço
    def laco(self):
        while True:
            try:
                self.ciclo()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"BGP: {e}", fonte="sistema")
            time.sleep(max(60, int(CFG["bgp"]["intervalo_minutos"]) * 60))

    def iniciar(self):
        if CFG["bgp"]["ativo"]:
            threading.Thread(target=self.laco, name="bgp", daemon=True).start()

    def estado(self, empresa_id):
        from . import empresas
        empresa_id = int(empresa_id)
        sessoes = banco.consultar(
            "SELECT b.*, e.nome AS equipamento, e.host FROM bgp_sessoes b JOIN equipamentos e ON e.id = b.equip_id "
            "WHERE e.empresa_id = ? ORDER BY b.estabelecida, lower(e.nome), b.vizinho", (empresa_id,))
        rpki = banco.consultar("SELECT * FROM rpki WHERE empresa_id = ? ORDER BY prefixo", (empresa_id,))
        for r in rpki:
            r["roas"], r["origens"] = json.loads(r["roas"]), json.loads(r["origens"])
        meus = {e["id"] for e in equipamentos.listar(empresa_id)}
        return {"sessoes": sessoes, "rpki": rpki, "asn": empresas.asn(empresa_id),
                "prefixos": empresas.prefixos(empresa_id), "ultimo_ciclo": self.ultimo_ciclo,
                "erros": {k: v for k, v in self.erros.items() if k in meus}, "ativo": bool(CFG["bgp"]["ativo"])}


BGP = MonitorBgp()
