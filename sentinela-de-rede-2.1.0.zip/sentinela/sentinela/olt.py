"""OLTs (GPON): ONUs online/offline por PON, causa da queda, sinal óptico e queda em massa.

Suporte completo: Huawei (MA56xx/MA58xx) e ZTE (C3xx/C6xx).
Fiberhome e Parks: backup, logs e auditoria pelo monitor comum; ONUs ainda não.
"""

import datetime
import re
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

from . import banco, equipamentos, incidentes, ssh
from .config import CFG

SUPORTADAS = {"huawei_olt", "zte_olt"}

_HUAWEI_ONT = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*/\s*(\d+)\s+(\d+)\s+(\S+)\s+\S+\s+(online|offline)\b", re.M | re.I)
_ZTE_ONU = re.compile(r"^\s*(gpon[-_]onu[-_](\d+/\d+/\d+):(\d+))\s+\S+\s+\S+\s+(\S+)", re.M | re.I)
_ZTE_SINAL = re.compile(r"(gpon[-_]onu[-_]\d+/\d+/\d+:\d+)\s+(-?\d+(?:\.\d+)?)\s*\(?dbm", re.I)
_HUAWEI_SINAL = re.compile(r"^\s*(\d+)\s+(-\d+(?:\.\d+)?)\s+", re.M)


def _agora():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")


def ler_onus_huawei(texto):
    onus = []
    for m in _HUAWEI_ONT.finditer(texto):
        pon = f"{m.group(1)}/{m.group(2)}/{m.group(3)}"
        estado = m.group(6).lower()
        onus.append({"onu": f"{pon}:{m.group(4)}", "pon": pon, "serial": m.group(5), "estado": estado})
    return onus


def ler_onus_zte(texto):
    mapa = {"working": "online", "los": "los", "dyinggasp": "sem_energia", "offline": "offline"}
    onus = []
    for m in _ZTE_ONU.finditer(texto):
        fase = m.group(4).lower().replace("-", "").replace("_", "")
        onus.append({"onu": m.group(1), "pon": m.group(2), "serial": "", "estado": mapa.get(fase, "offline")})
    return onus


def resumir(onus):
    pons = defaultdict(lambda: {"total": 0, "online": 0, "offline": 0, "los": 0, "sem_energia": 0})
    for o in onus:
        p = pons[o["pon"]]
        p["total"] += 1
        if o["estado"] == "online":
            p["online"] += 1
        else:
            p["offline"] += 1
            if o["estado"] == "los":
                p["los"] += 1
            elif o["estado"] == "sem_energia":
                p["sem_energia"] += 1
    return dict(pons)


class MonitorOlt:
    def __init__(self):
        self.erros = {}
        self.ultimo_sinal = {}
        self.ultimo_ciclo = None

    # ------------------------------------------------------------ status das ONUs
    def coletar_onus(self, conn, equip):
        if equip["tipo"] == "huawei_olt":
            return ler_onus_huawei(ssh.executar(conn, "display ont info 0 all", "huawei_olt", 180))
        return ler_onus_zte(ssh.executar(conn, "show gpon onu state", "zte_olt", 180))

    def coletar_sinal(self, conn, equip, pons):
        sinais = {}
        if equip["tipo"] == "zte_olt":
            for pon in pons:
                prefixo = "gpon_olt-" if any("gpon_onu-" in k for k in pons[pon]) else "gpon-olt_"
                saida = ssh.executar(conn, f"show pon power onu-rx {prefixo}{pon}", "zte_olt", 60)
                for m in _ZTE_SINAL.finditer(saida):
                    sinais[m.group(1)] = float(m.group(2))
        else:
            for pon in pons:
                quadro, placa, porta = pon.split("/")
                saida = conn.send_config_set([f"interface gpon {quadro}/{placa}", f"display ont optical-info {porta} all",
                                              "quit"], read_timeout=60)
                for m in _HUAWEI_SINAL.finditer(saida):
                    sinais[f"{pon}:{m.group(1)}"] = float(m.group(2))
        return sinais

    def verificar(self, equip):
        nome = f"{equip['nome']} ({equip['host']})"
        eid = equip["id"]
        querer_sinal = time.time() - self.ultimo_sinal.get(eid, 0) >= int(CFG["olt"]["sinal_minutos"]) * 60
        try:
            with ssh.conectar(equip) as conn:
                onus = self.coletar_onus(conn, equip)
                sinais = {}
                if querer_sinal and onus:
                    por_pon = defaultdict(list)
                    for o in onus:
                        if o["estado"] == "online":
                            por_pon[o["pon"]].append(o["onu"])
                    try:
                        sinais = self.coletar_sinal(conn, equip, por_pon)
                        self.ultimo_sinal[eid] = time.time()
                    except Exception:
                        sinais = {}
        except Exception as e:
            self.erros[eid] = ssh.descrever_erro(e)
            return None
        self.erros.pop(eid, None)
        if not onus:
            self.erros[eid] = "nenhuma ONU encontrada na saída (modelo/firmware diferente do esperado?)"
            return []

        minimo = float(CFG["olt"]["sinal_minimo_dbm"])
        anteriores = {p["pon"]: p for p in banco.consultar("SELECT * FROM olt_pons WHERE equip_id = ?", (eid,))}
        sinais_antigos = {o["onu"]: o["rx_dbm"] for o in banco.consultar(
            "SELECT onu, rx_dbm FROM olt_onus WHERE equip_id = ?", (eid,))}
        agora = _agora()
        resumo = resumir(onus)
        ruins = defaultdict(int)
        with banco.transacao() as con:
            con.execute("DELETE FROM olt_onus WHERE equip_id = ?", (eid,))
            for o in onus:
                rx = sinais.get(o["onu"], sinais_antigos.get(o["onu"]) if o["estado"] == "online" else None)
                if rx is not None and rx < minimo:
                    ruins[o["pon"]] += 1
                con.execute("INSERT INTO olt_onus (equip_id, onu, pon, serial, estado, rx_dbm, atualizado) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?)", (eid, o["onu"], o["pon"], o["serial"], o["estado"], rx, agora))
            con.execute("DELETE FROM olt_pons WHERE equip_id = ?", (eid,))
            for pon, p in resumo.items():
                con.execute("INSERT INTO olt_pons (equip_id, pon, total, online, offline, los, sem_energia, sinal_ruim, atualizado) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            (eid, pon, p["total"], p["online"], p["offline"], p["los"], p["sem_energia"], ruins[pon], agora))
        self._alertar_quedas(equip, nome, anteriores, resumo)
        return onus

    def _alertar_quedas(self, equip, nome, anteriores, resumo):
        pct = float(CFG["olt"]["queda_massa_pct"]) / 100
        minimo = int(CFG["olt"]["queda_massa_min_onus"])
        for pon, p in resumo.items():
            ant = anteriores.get(pon)
            if not ant:
                continue
            caiu = ant["online"] - p["online"]
            if ant["online"] >= minimo and caiu >= minimo and caiu >= ant["online"] * pct:
                if p["los"] >= caiu * 0.6:
                    causa = "maioria com LOS: provável rompimento de fibra ou problema no splitter"
                elif p["sem_energia"] >= caiu * 0.6:
                    causa = "maioria com dying gasp: provável falta de energia na região"
                else:
                    causa = "verifique a fibra, o splitter e a energia da região"
                texto = f"Queda em massa na PON {pon}: {caiu} de {ant['online']} ONUs ficaram offline ({causa})"
                incidentes.registrar_evento(equip["id"], nome, "Queda em massa de ONUs", "ataque", texto, fonte="olt")
                incidentes.abrir(equip["id"], nome, "Queda em massa de ONUs", texto, detalhes=texto, severidade="alta",
                                 chave=f"{equip['id']}|pon|{pon}")
            elif p["online"] - ant["online"] >= minimo:
                incidentes.registrar_evento(equip["id"], nome, "ONUs voltaram", "info",
                                            f"PON {pon}: {p['online'] - ant['online']} ONUs voltaram", fonte="olt")

    # ------------------------------------------------------------ laço
    def ciclo(self):
        lista = [e for e in equipamentos.listar(equipamentos.TODAS, segredos=True, somente_ativos=True) if e["tipo"] in SUPORTADAS]
        if lista:
            with ThreadPoolExecutor(max_workers=4) as pool:
                list(pool.map(self.verificar, lista))
        self.ultimo_ciclo = _agora()

    def laco(self):
        while True:
            try:
                self.ciclo()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"OLT: {e}", fonte="sistema")
            time.sleep(max(60, int(CFG["olt"]["intervalo_minutos"]) * 60))

    def iniciar(self):
        threading.Thread(target=self.laco, name="olt", daemon=True).start()

    def estado(self, empresa_id):
        olts = [e for e in equipamentos.listar(empresa_id) if e["funcao"] == "olt" or e["tipo"].endswith("_olt")]
        pons = banco.consultar("SELECT p.* FROM olt_pons p JOIN equipamentos e ON e.id = p.equip_id "
                               "WHERE e.empresa_id = ? ORDER BY p.equip_id, p.pon", (int(empresa_id),))
        por_olt = defaultdict(list)
        for p in pons:
            por_olt[p["equip_id"]].append(p)
        resultado = []
        for e in olts:
            lista = por_olt.get(e["id"], [])
            resultado.append({
                "id": e["id"], "nome": e["nome"], "host": e["host"], "tipo_nome": e["tipo_nome"],
                "suportada": e["tipo"] in SUPORTADAS, "erro": self.erros.get(e["id"]), "pons": lista,
                "total": sum(p["total"] for p in lista), "online": sum(p["online"] for p in lista),
                "offline": sum(p["offline"] for p in lista), "los": sum(p["los"] for p in lista),
                "sem_energia": sum(p["sem_energia"] for p in lista), "sinal_ruim": sum(p["sinal_ruim"] for p in lista),
                "atualizado": lista[0]["atualizado"] if lista else None,
            })
        return {"olts": resultado, "sinal_minimo": float(CFG["olt"]["sinal_minimo_dbm"]), "ultimo_ciclo": self.ultimo_ciclo}

    @staticmethod
    def onus(equip_id, pon=None, filtro=None):
        sql = "SELECT * FROM olt_onus WHERE equip_id = ?"
        params = [equip_id]
        if pon:
            sql += " AND pon = ?"
            params.append(pon)
        if filtro == "offline":
            sql += " AND estado != 'online'"
        elif filtro == "sinal_ruim":
            sql += " AND rx_dbm IS NOT NULL AND rx_dbm < ?"
            params.append(float(CFG["olt"]["sinal_minimo_dbm"]))
        return banco.consultar(sql + " ORDER BY pon, onu LIMIT 5000", params)


OLT = MonitorOlt()
