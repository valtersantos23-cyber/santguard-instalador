"""Linha de comando: python -m sentinela [comando]

Comandos:
  (nenhum) / iniciar        inicia o painel e o monitoramento
  criar-admin               cria um administrador do FORNECEDOR (gerencia as empresas)
  redefinir-senha USUARIO   define uma nova senha (o usuário troca no próximo login)
  remover-2fa USUARIO       remove o 2FA de um usuário que perdeu o celular
  importar-json ARQUIVO     importa equipamentos do script antigo (equipamentos.json)
  licenca                   mostra a situação da licença deste servidor
  licenca-solicitar         gera o código de solicitação para enviar ao fornecedor
  licenca-ativar [CHAVE]    aplica a chave de liberação recebida do fornecedor
  versao                    mostra a versão
"""

import argparse
import getpass
import json
import sys

try:
    from . import VERSAO, autenticacao as auth, banco, equipamentos, licenca
except PermissionError as erro_permissao:
    sys.exit(f"\nSem permissão para abrir a pasta de dados ({erro_permissao.filename}).\n"
             "No Windows: feche este PowerShell e abra outro com o botão direito > "
             "'Executar como administrador'.\nNo Linux: rode com sudo (ou como o usuário 'sentinela').")


def pedir_senha_nova(usuario):
    while True:
        senha = getpass.getpass("Senha: ")
        if senha != getpass.getpass("Repita a senha: "):
            print("As senhas não conferem.\n")
            continue
        problema = auth.problema_na_senha(senha, usuario)
        if problema:
            print(f"{problema}\n")
            continue
        return senha


def criar_admin():
    usuario = input("Usuário do administrador: ").strip()
    nome = input("Nome completo (opcional): ").strip()
    senha = pedir_senha_nova(usuario)
    try:
        auth.criar_usuario(usuario, senha, "admin", nome=nome, fornecedor=True)
    except ValueError as e:
        sys.exit(f"Erro: {e}")
    auth.auditar(usuario, "linha de comando", "Administrador criado pela linha de comando")
    print(f"Administrador '{usuario}' criado.")


def redefinir_senha(usuario):
    u = banco.um("SELECT * FROM usuarios WHERE usuario = ?", (usuario,))
    if not u:
        sys.exit("Usuário não encontrado")
    auth.definir_senha(u["id"], pedir_senha_nova(usuario), trocar_no_proximo_login=True)
    auth.limpar_falhas(f"u:{usuario.lower()}")
    auth.auditar("linha de comando", "", "Senha redefinida pela linha de comando", usuario)
    print("Senha redefinida. O usuário vai trocá-la no próximo login.")


def remover_2fa(usuario):
    u = banco.um("SELECT * FROM usuarios WHERE usuario = ?", (usuario,))
    if not u:
        sys.exit("Usuário não encontrado")
    banco.executar("UPDATE usuarios SET totp_ativo = 0, totp_cif = NULL WHERE id = ?", (u["id"],))
    auth.encerrar_sessoes_do_usuario(u["id"])
    auth.auditar("linha de comando", "", "2FA removido pela linha de comando", usuario)
    print("2FA removido.")


def importar_json(arquivo, empresa_id=1):
    itens = json.loads(open(arquivo, encoding="utf-8").read())
    importados = 0
    for i in itens:
        senha = None
        if i.get("senha_protegida") and sys.platform == "win32":
            try:
                from .compat_dpapi import desproteger
                senha = desproteger(i["senha_protegida"])
            except Exception:
                senha = None
        dados = {"nome": i.get("apelido") or i.get("host"), "host": i.get("host"), "tipo": i.get("tipo"),
                 "porta": i.get("porta", 22), "usuario": i.get("usuario", ""), "senha": senha or "PENDENTE"}
        novo, mensagem = equipamentos.salvar(dados, empresa_id)
        if novo:
            if not senha:
                banco.executar("UPDATE equipamentos SET senha_cif = NULL WHERE id = ?", (novo,))
            importados += 1
            print(f"  + {dados['nome']} ({dados['host']})" + ("" if senha else "  [informe a senha no painel]"))
        else:
            print(f"  ! {dados['nome']}: {mensagem}")
    print(f"{importados} equipamento(s) importado(s).")


def mostrar_licenca():
    lic = licenca.estado(forcar=True)
    print(f"Servidor (ID) .........: {lic['maquina']}")
    print(f"Situação ..............: {lic['texto']}")
    if lic["licenca_id"]:
        print(f"Licença nº ............: {lic['licenca_id']}")
        print(f"Limite de equipamentos : {lic['limite_equipamentos'] or 'sem limite'}")
        print(f"Limite de empresas ....: {lic['limite_empresas'] or 'sem limite'}")
    if lic["aviso"]:
        print(f"\nAVISO: {lic['aviso']}")
    if not lic["valida"]:
        print("\nPara ativar: python -m sentinela licenca-solicitar")
    return 0 if lic["valida"] else 2


def licenca_solicitar():
    print("Envie este SERIAL ao fornecedor:\n")
    print("   ", licenca.serial_atual())
    print("\nDepois rode:  python -m sentinela licenca-ativar  e cole a chave recebida.")


def ler_codigo_colado(mensagem):
    """Lê uma chave colada no terminal, mesmo que venha quebrada em várias linhas (terminadas em '-')."""
    partes = [input(mensagem).strip()]
    while partes[-1].endswith("-"):
        try:
            partes.append(input().strip())
        except EOFError:
            break
    return "".join(partes)


def licenca_ativar(codigo):
    codigo = codigo or ler_codigo_colado("Cole a chave de liberação: ")
    try:
        lic = licenca.ativar(codigo)
    except licenca.LicencaErro as e:
        auth.auditar("linha de comando", "", "Ativação de licença recusada", detalhes=str(e))
        sys.exit(f"Não foi possível ativar: {e}")
    auth.auditar("linha de comando", "", "Licença do sistema ativada", f"nº {lic['licenca_id']}", lic["texto"])
    print(f"Sistema ativado. {lic['texto']}.")
    print("Se o serviço já estava rodando, o monitoramento volta sozinho em até 30 segundos.")


def main():
    parser = argparse.ArgumentParser(prog="python -m sentinela", description="Sentinela de Rede")
    parser.add_argument("comando", nargs="?", default="iniciar",
                        choices=["iniciar", "criar-admin", "redefinir-senha", "remover-2fa", "importar-json", "versao",
                                 "licenca", "licenca-solicitar", "licenca-ativar"])
    parser.add_argument("argumento", nargs="*")
    args = parser.parse_args()

    if args.comando == "versao":
        print(VERSAO)
        return
    args.argumento = " ".join(args.argumento) or None
    banco.migrar()
    if args.comando == "licenca":
        sys.exit(mostrar_licenca())
    elif args.comando == "licenca-solicitar":
        licenca_solicitar()
    elif args.comando == "licenca-ativar":
        licenca_ativar(args.argumento)
    elif args.comando == "criar-admin":
        criar_admin()
    elif args.comando in ("redefinir-senha", "remover-2fa", "importar-json"):
        if not args.argumento:
            parser.error(f"informe o {'arquivo' if args.comando == 'importar-json' else 'usuário'}")
        {"redefinir-senha": redefinir_senha, "remover-2fa": remover_2fa,
         "importar-json": importar_json}[args.comando](args.argumento)
    else:
        from . import servidor
        servidor.iniciar()


if __name__ == "__main__":
    main()
