"""Banco de dados SQLite (arquivo dados/sentinela.db).

SQLite em modo WAL aguenta tranquilamente centenas de equipamentos e
milhares de eventos por minuto, sem precisar instalar um servidor de banco.
Cada thread usa a sua própria conexão.
"""

import contextlib
import sqlite3
import threading

from . import config

_local = threading.local()

# Cada item da lista é uma migração; nunca altere uma que já foi publicada,
# apenas adicione novas no final.
MIGRACOES = [
    # 1: base (usuários, sessões, auditoria, equipamentos, backups, incidentes, eventos)
    """
    CREATE TABLE usuarios (
        id INTEGER PRIMARY KEY,
        usuario TEXT NOT NULL UNIQUE COLLATE NOCASE,
        nome TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL DEFAULT '',
        telefone TEXT NOT NULL DEFAULT '',
        senha_hash TEXT NOT NULL,
        papel TEXT NOT NULL CHECK (papel IN ('admin', 'operador', 'leitura')),
        totp_cif TEXT,
        totp_ativo INTEGER NOT NULL DEFAULT 0,
        ativo INTEGER NOT NULL DEFAULT 1,
        trocar_senha INTEGER NOT NULL DEFAULT 0,
        criado TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        ultimo_login TEXT
    );
    CREATE TABLE sessoes (
        token_hash TEXT PRIMARY KEY,
        usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
        csrf TEXT NOT NULL,
        mfa_ok INTEGER NOT NULL DEFAULT 1,
        criada REAL NOT NULL,
        expira REAL NOT NULL,
        ultimo_uso REAL NOT NULL,
        ip TEXT NOT NULL DEFAULT '',
        agente TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE tentativas_login (
        chave TEXT PRIMARY KEY,
        falhas INTEGER NOT NULL DEFAULT 0,
        bloqueado_ate REAL NOT NULL DEFAULT 0,
        ultima REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE auditoria (
        id INTEGER PRIMARY KEY,
        quando TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        usuario TEXT NOT NULL DEFAULT '',
        ip TEXT NOT NULL DEFAULT '',
        acao TEXT NOT NULL,
        alvo TEXT NOT NULL DEFAULT '',
        detalhes TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_auditoria_quando ON auditoria(quando);
    CREATE TABLE sites (
        id INTEGER PRIMARY KEY,
        nome TEXT NOT NULL UNIQUE COLLATE NOCASE,
        descricao TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE equipamentos (
        id TEXT PRIMARY KEY,
        nome TEXT NOT NULL,
        host TEXT NOT NULL,
        tipo TEXT NOT NULL,
        porta INTEGER NOT NULL DEFAULT 22,
        usuario TEXT NOT NULL DEFAULT '',
        senha_cif TEXT,
        enable_cif TEXT,
        site_id INTEGER REFERENCES sites(id) ON DELETE SET NULL,
        funcao TEXT NOT NULL DEFAULT 'outro',
        snmp_versao TEXT NOT NULL DEFAULT '',
        snmp_porta INTEGER NOT NULL DEFAULT 161,
        snmp_community_cif TEXT,
        snmp_v3_usuario TEXT NOT NULL DEFAULT '',
        snmp_v3_auth_cif TEXT,
        snmp_v3_priv_cif TEXT,
        ativo INTEGER NOT NULL DEFAULT 1,
        criado TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        atualizado TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        UNIQUE (host, porta)
    );
    CREATE TABLE status (
        equip_id TEXT PRIMARY KEY REFERENCES equipamentos(id) ON DELETE CASCADE,
        status TEXT NOT NULL DEFAULT 'aguardando',
        hostname TEXT,
        cpu INTEGER,
        memoria INTEGER,
        uptime INTEGER,
        verificado TEXT,
        snmp_verificado TEXT,
        erro TEXT,
        snmp_erro TEXT,
        alertas TEXT NOT NULL DEFAULT '[]',
        incidente TEXT
    );
    CREATE TABLE backups (
        id INTEGER PRIMARY KEY,
        equip_id TEXT REFERENCES equipamentos(id) ON DELETE SET NULL,
        hostname TEXT NOT NULL,
        quando TEXT NOT NULL,
        arquivo TEXT NOT NULL,
        sha256 TEXT NOT NULL,
        tamanho INTEGER NOT NULL,
        mudou INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX idx_backups_equip ON backups(equip_id, quando);
    CREATE TABLE incidentes (
        id INTEGER PRIMARY KEY,
        equip_id TEXT REFERENCES equipamentos(id) ON DELETE SET NULL,
        equipamento TEXT NOT NULL DEFAULT '',
        abertura TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        tipo TEXT NOT NULL,
        severidade TEXT NOT NULL DEFAULT 'alta',
        titulo TEXT NOT NULL,
        detalhes TEXT NOT NULL DEFAULT '',
        pasta TEXT,
        estado TEXT NOT NULL DEFAULT 'aberto' CHECK (estado IN ('aberto', 'reconhecido', 'resolvido')),
        chave TEXT NOT NULL DEFAULT '',
        ocorrencias INTEGER NOT NULL DEFAULT 1,
        ultima_ocorrencia TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        reconhecido_por TEXT,
        reconhecido_em TEXT,
        resolvido_por TEXT,
        resolvido_em TEXT,
        nivel_escalonamento INTEGER NOT NULL DEFAULT 0,
        proximo_escalonamento REAL
    );
    CREATE INDEX idx_incidentes_estado ON incidentes(estado, abertura);
    CREATE INDEX idx_incidentes_chave ON incidentes(chave, estado);
    CREATE TABLE eventos (
        id INTEGER PRIMARY KEY,
        ts REAL NOT NULL,
        equip_id TEXT,
        equipamento TEXT NOT NULL DEFAULT '',
        tipo TEXT NOT NULL,
        gravidade TEXT NOT NULL,
        origem TEXT NOT NULL DEFAULT '',
        mensagem TEXT NOT NULL DEFAULT '',
        fonte TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_eventos_ts ON eventos(ts);
    CREATE TABLE configuracoes (
        chave TEXT PRIMARY KEY,
        valor TEXT NOT NULL
    );
    """,
    # 2: ataques DDoS detectados por fluxo
    """
    CREATE TABLE ddos (
        id INTEGER PRIMARY KEY,
        alvo TEXT NOT NULL,
        inicio REAL NOT NULL,
        ultimo REAL NOT NULL,
        fim REAL,
        pico_bps REAL NOT NULL DEFAULT 0,
        pico_pps REAL NOT NULL DEFAULT 0,
        vetor TEXT NOT NULL DEFAULT '',
        origens TEXT NOT NULL DEFAULT '[]',
        fontes INTEGER NOT NULL DEFAULT 0,
        incidente_id INTEGER,
        mitigacao_id INTEGER,
        estado TEXT NOT NULL DEFAULT 'ativo'
    );
    CREATE INDEX idx_ddos_inicio ON ddos(inicio);
    """,
    # 3: alertas (escala de plantão, manutenções programadas e histórico de envios)
    """
    CREATE TABLE plantao (
        usuario_id INTEGER PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
        nivel INTEGER NOT NULL DEFAULT 1 CHECK (nivel BETWEEN 1 AND 3),
        whatsapp INTEGER NOT NULL DEFAULT 1,
        email INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE manutencoes (
        id INTEGER PRIMARY KEY,
        equip_id TEXT REFERENCES equipamentos(id) ON DELETE CASCADE,
        site_id INTEGER REFERENCES sites(id) ON DELETE CASCADE,
        inicio TEXT NOT NULL,
        fim TEXT NOT NULL,
        motivo TEXT NOT NULL DEFAULT '',
        criado_por TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE envios (
        id INTEGER PRIMARY KEY,
        quando TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        incidente_id INTEGER,
        canal TEXT NOT NULL,
        destino TEXT NOT NULL DEFAULT '',
        nivel INTEGER NOT NULL DEFAULT 1,
        ok INTEGER NOT NULL,
        erro TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_envios_quando ON envios(quando);
    ALTER TABLE incidentes ADD COLUMN silenciado TEXT;
    """,
    # 4: BGP, RPKI e OLTs
    """
    CREATE TABLE bgp_sessoes (
        equip_id TEXT NOT NULL REFERENCES equipamentos(id) ON DELETE CASCADE,
        vizinho TEXT NOT NULL,
        asn INTEGER,
        estado TEXT NOT NULL,
        estabelecida INTEGER NOT NULL DEFAULT 0,
        prefixos INTEGER,
        tempo TEXT NOT NULL DEFAULT '',
        descricao TEXT NOT NULL DEFAULT '',
        atualizado TEXT NOT NULL,
        mudou_em TEXT,
        PRIMARY KEY (equip_id, vizinho)
    );
    CREATE TABLE rpki (
        prefixo TEXT PRIMARY KEY,
        asn INTEGER NOT NULL,
        status TEXT NOT NULL,
        roas TEXT NOT NULL DEFAULT '[]',
        visivel INTEGER,
        origens TEXT NOT NULL DEFAULT '[]',
        verificado TEXT NOT NULL,
        erro TEXT
    );
    CREATE TABLE olt_pons (
        equip_id TEXT NOT NULL REFERENCES equipamentos(id) ON DELETE CASCADE,
        pon TEXT NOT NULL,
        total INTEGER NOT NULL DEFAULT 0,
        online INTEGER NOT NULL DEFAULT 0,
        offline INTEGER NOT NULL DEFAULT 0,
        los INTEGER NOT NULL DEFAULT 0,
        sem_energia INTEGER NOT NULL DEFAULT 0,
        sinal_ruim INTEGER NOT NULL DEFAULT 0,
        atualizado TEXT NOT NULL,
        PRIMARY KEY (equip_id, pon)
    );
    CREATE TABLE olt_onus (
        equip_id TEXT NOT NULL REFERENCES equipamentos(id) ON DELETE CASCADE,
        onu TEXT NOT NULL,
        pon TEXT NOT NULL,
        serial TEXT NOT NULL DEFAULT '',
        estado TEXT NOT NULL,
        rx_dbm REAL,
        atualizado TEXT NOT NULL,
        PRIMARY KEY (equip_id, onu)
    );
    """,
    # 5: mitigação com aprovação
    """
    ALTER TABLE equipamentos ADD COLUMN mit_usuario TEXT NOT NULL DEFAULT '';
    ALTER TABLE equipamentos ADD COLUMN mit_senha_cif TEXT;
    CREATE TABLE mitigacoes (
        id INTEGER PRIMARY KEY,
        tipo TEXT NOT NULL CHECK (tipo IN ('rtbh', 'bloqueio')),
        alvo TEXT NOT NULL,
        motivo TEXT NOT NULL DEFAULT '',
        origem TEXT NOT NULL DEFAULT 'manual',
        equip_ids TEXT NOT NULL DEFAULT '[]',
        estado TEXT NOT NULL DEFAULT 'pendente',
        duracao_min INTEGER NOT NULL DEFAULT 60,
        criado TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        criado_por TEXT NOT NULL DEFAULT 'sistema',
        aprovado_por TEXT,
        aprovado_em TEXT,
        expira REAL,
        removido_em TEXT,
        removido_por TEXT,
        incidente_id INTEGER,
        log TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_mitigacoes_estado ON mitigacoes(estado);
    """,
    # 6: multiempresa (cada provedor cliente é uma empresa; os dados existentes vão para a empresa 1)
    """
    CREATE TABLE empresas (
        id INTEGER PRIMARY KEY,
        nome TEXT NOT NULL UNIQUE COLLATE NOCASE,
        documento TEXT NOT NULL DEFAULT '',
        contato TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL DEFAULT '',
        telefone TEXT NOT NULL DEFAULT '',
        plano TEXT NOT NULL DEFAULT '',
        limite_equipamentos INTEGER NOT NULL DEFAULT 0,
        validade TEXT,
        ativo INTEGER NOT NULL DEFAULT 1,
        asn INTEGER NOT NULL DEFAULT 0,
        redes TEXT NOT NULL DEFAULT '[]',
        prefixos TEXT NOT NULL DEFAULT '[]',
        observacoes TEXT NOT NULL DEFAULT '',
        criado TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
    INSERT INTO empresas (id, nome) VALUES (1, 'Empresa principal');

    ALTER TABLE usuarios ADD COLUMN empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE;
    ALTER TABLE usuarios ADD COLUMN fornecedor INTEGER NOT NULL DEFAULT 0;
    UPDATE usuarios SET empresa_id = 1;
    UPDATE usuarios SET fornecedor = 1 WHERE papel = 'admin';
    UPDATE usuarios SET empresa_id = NULL WHERE fornecedor = 1;
    ALTER TABLE sessoes ADD COLUMN empresa_id INTEGER;
    DELETE FROM sessoes;

    ALTER TABLE equipamentos ADD COLUMN empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE;
    UPDATE equipamentos SET empresa_id = 1;
    CREATE INDEX idx_equipamentos_empresa ON equipamentos(empresa_id);

    CREATE TABLE sites_nova (
        id INTEGER PRIMARY KEY,
        empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
        nome TEXT NOT NULL COLLATE NOCASE,
        descricao TEXT NOT NULL DEFAULT '',
        UNIQUE (empresa_id, nome)
    );
    INSERT INTO sites_nova (id, empresa_id, nome, descricao) SELECT id, 1, nome, descricao FROM sites;
    DROP TABLE sites;
    ALTER TABLE sites_nova RENAME TO sites;

    CREATE TABLE rpki_nova (
        empresa_id INTEGER NOT NULL REFERENCES empresas(id) ON DELETE CASCADE,
        prefixo TEXT NOT NULL,
        asn INTEGER NOT NULL,
        status TEXT NOT NULL,
        roas TEXT NOT NULL DEFAULT '[]',
        visivel INTEGER,
        origens TEXT NOT NULL DEFAULT '[]',
        verificado TEXT NOT NULL,
        erro TEXT,
        PRIMARY KEY (empresa_id, prefixo)
    );
    INSERT INTO rpki_nova SELECT 1, prefixo, asn, status, roas, visivel, origens, verificado, erro FROM rpki;
    DROP TABLE rpki;
    ALTER TABLE rpki_nova RENAME TO rpki;

    ALTER TABLE auditoria ADD COLUMN empresa_id INTEGER;
    ALTER TABLE incidentes ADD COLUMN empresa_id INTEGER;
    ALTER TABLE eventos ADD COLUMN empresa_id INTEGER;
    ALTER TABLE ddos ADD COLUMN empresa_id INTEGER;
    ALTER TABLE manutencoes ADD COLUMN empresa_id INTEGER;
    ALTER TABLE envios ADD COLUMN empresa_id INTEGER;
    ALTER TABLE mitigacoes ADD COLUMN empresa_id INTEGER;
    ALTER TABLE backups ADD COLUMN empresa_id INTEGER;
    UPDATE auditoria SET empresa_id = 1;
    UPDATE incidentes SET empresa_id = 1;
    UPDATE eventos SET empresa_id = 1;
    UPDATE ddos SET empresa_id = 1;
    UPDATE manutencoes SET empresa_id = 1;
    UPDATE envios SET empresa_id = 1;
    UPDATE mitigacoes SET empresa_id = 1;
    UPDATE backups SET empresa_id = 1;
    CREATE INDEX idx_incidentes_empresa ON incidentes(empresa_id, estado);
    CREATE INDEX idx_eventos_empresa ON eventos(empresa_id, id);
    CREATE INDEX idx_auditoria_empresa ON auditoria(empresa_id, id);
    CREATE INDEX idx_ddos_empresa ON ddos(empresa_id, inicio);
    CREATE INDEX idx_mitigacoes_empresa ON mitigacoes(empresa_id, estado);

    UPDATE configuracoes SET chave = 'e1:' || chave WHERE chave IN ('alertas', 'mitigacao', 'ultima_auditoria');
    """,
]


def caminho():
    return config.pasta_dados() / "sentinela.db"


def conexao():
    destino = str(caminho())
    con = getattr(_local, "con", None)
    if con is None or getattr(_local, "destino", None) != destino:
        con = sqlite3.connect(destino, timeout=30, isolation_level=None, check_same_thread=False)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=30000")
        con.execute("PRAGMA synchronous=NORMAL")
        _local.con, _local.destino = con, destino
    return con


def consultar(sql, parametros=()):
    return [dict(l) for l in conexao().execute(sql, parametros).fetchall()]


def um(sql, parametros=()):
    linha = conexao().execute(sql, parametros).fetchone()
    return dict(linha) if linha else None


def executar(sql, parametros=()):
    cursor = conexao().execute(sql, parametros)
    return cursor.lastrowid if sql.lstrip().upper().startswith("INSERT") else cursor.rowcount


@contextlib.contextmanager
def transacao():
    con = conexao()
    con.execute("BEGIN IMMEDIATE")
    try:
        yield con
        con.execute("COMMIT")
    except BaseException:
        con.execute("ROLLBACK")
        raise


def migrar():
    con = conexao()
    con.execute("CREATE TABLE IF NOT EXISTS versao_esquema (versao INTEGER NOT NULL)")
    linha = con.execute("SELECT versao FROM versao_esquema").fetchone()
    atual = linha[0] if linha else 0
    if linha is None:
        con.execute("INSERT INTO versao_esquema (versao) VALUES (0)")
    for numero, sql in enumerate(MIGRACOES, start=1):
        if numero <= atual:
            continue
        # chaves estrangeiras desligadas durante a migração: algumas recriam tabelas (sem apagar referências)
        con.executescript("PRAGMA foreign_keys=OFF; BEGIN IMMEDIATE;" + sql +
                          f";UPDATE versao_esquema SET versao = {numero}; COMMIT; PRAGMA foreign_keys=ON;")
        problemas = con.execute("PRAGMA foreign_key_check").fetchall()
        if problemas:
            raise RuntimeError(f"Migração {numero} deixou referências inválidas: {problemas[:5]}")
    return len(MIGRACOES)


def ler_config(chave, padrao=None):
    linha = um("SELECT valor FROM configuracoes WHERE chave = ?", (chave,))
    return linha["valor"] if linha else padrao


def ler_config_empresa(empresa_id, chave, padrao=None):
    return ler_config(f"e{int(empresa_id)}:{chave}", padrao)


def gravar_config_empresa(empresa_id, chave, valor):
    gravar_config(f"e{int(empresa_id)}:{chave}", valor)


def gravar_config(chave, valor):
    executar("INSERT INTO configuracoes (chave, valor) VALUES (?, ?) "
             "ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor", (chave, str(valor)))
