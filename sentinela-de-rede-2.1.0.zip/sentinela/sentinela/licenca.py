"""Licença da INSTALAÇÃO (ativação por solicitação e liberação).

Cada servidor do Sentinela precisa ser ativado:
  1. o painel (aba 🔑 Licença) ou `python -m sentinela licenca-solicitar` gera um CÓDIGO DE SOLICITAÇÃO;
  2. o fornecedor gera a CHAVE DE LIBERAÇÃO no gerador dele (assinada com a chave privada);
  3. a chave é colada no painel ou em `python -m sentinela licenca-ativar CHAVE`.

A liberação traz a validade (normalmente 30 dias) e os limites de equipamentos e de empresas.
Sem licença válida o monitoramento para e só a tela de ativação fica disponível. Os dados
continuam guardados.

Esta licença vale para o SERVIDOR inteiro. A licença por empresa (empresas.py) continua
existindo por dentro dela, para quem atende vários provedores no mesmo servidor.
"""

import hashlib
import hmac
import json
import os
import secrets
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from . import ed25519
from .config import pasta_dados
from .licenca_formato import CodigoInvalido, Liberacao, Solicitacao, produto_id

# Preenchida pelo gerador do fornecedor:  python gerador.py novas-chaves --sentinela <pasta do projeto>
CHAVE_PUBLICA = ""

TOLERANCIA_RELOGIO = 3600          # 1 h de folga para ajustes automáticos de hora
VALIDADE_SOLICITACAO = 30 * 86400
MAX_PENDENTES = 5
AVISAR_DIAS = 10                   # o painel avisa quando faltar isso para vencer
CACHE_SEG = 30
GRAVAR_USO_SEG = 600               # registra o "último uso" no máximo a cada 10 minutos

PID = produto_id()
_relogio = time.time               # os testes substituem
_trava = threading.RLock()
_cache = {"em": 0.0, "estado": None}


class LicencaErro(Exception):
    """Mensagem própria para mostrar ao usuário."""


# ---------------------------------------------------------------- identificação do servidor

def _arquivo():
    return pasta_dados() / "licenca.json"


def _id_instalacao():
    """Identificador aleatório criado na primeira execução (usado quando a máquina não tem um ID estável)."""
    arq = pasta_dados() / "instalacao.id"
    try:
        valor = arq.read_text().strip()
        if len(valor) == 32:
            return valor
    except OSError:
        pass
    valor = secrets.token_hex(16)
    arq.write_text(valor + "\n")
    return valor


def _id_maquina_bruto():
    try:
        if sys.platform == "win32":
            import winreg
            chave = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                                   0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
            valor, _ = winreg.QueryValueEx(chave, "MachineGuid")
            return "win:" + str(valor)
        if sys.platform == "darwin":
            saida = subprocess.run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                                   capture_output=True, text=True, timeout=5).stdout
            for linha in saida.splitlines():
                if "IOPlatformUUID" in linha:
                    return "mac:" + linha.split('"')[-2]
        # /etc/host-machine-id: o docker-compose monta o ID do servidor (o do container muda a cada build)
        for arq in ("/etc/host-machine-id", "/etc/machine-id", "/var/lib/dbus/machine-id"):
            p = Path(arq)
            if p.is_file():
                valor = p.read_text().strip()
                if valor:
                    return "linux:" + valor
    except Exception:  # noqa: BLE001
        pass
    return "inst:" + _id_instalacao()


_maquina_memo = None


def id_maquina():
    global _maquina_memo
    if _maquina_memo is None:
        _maquina_memo = hashlib.sha256(f"sentinela|{_id_maquina_bruto()}".encode()).digest()[:8]
    return _maquina_memo


def id_maquina_texto():
    h = id_maquina().hex().upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


# ---------------------------------------------------------------- arquivo de estado

def _ler():
    try:
        return json.loads(_arquivo().read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
        return {}


def _gravar(dados):
    arq = _arquivo()
    tmp = arq.with_suffix(".tmp")
    tmp.write_text(json.dumps(dados, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, arq)


def _selo(codigo, ultimo_uso):
    # Dificulta editar o "último uso" à mão para burlar a proteção contra relógio atrasado.
    chave = hashlib.sha256(b"sentinela-licenca|" + id_maquina() + codigo.encode()).digest()
    return hmac.new(chave, str(ultimo_uso).encode(), hashlib.sha256).hexdigest()


def _limpar_cache():
    _cache["em"], _cache["estado"] = 0.0, None


# ---------------------------------------------------------------- operações

def _conferir(lib):
    if not CHAVE_PUBLICA:
        raise LicencaErro("este Sentinela foi gerado sem a chave pública do fornecedor")
    if lib.produto != PID:
        raise LicencaErro("esta chave é de outro produto")
    if not ed25519.verificar(bytes.fromhex(CHAVE_PUBLICA), lib.corpo(), lib.assinatura):
        raise LicencaErro("assinatura inválida: chave falsificada ou de outro fornecedor")
    if lib.maquina != id_maquina():
        raise LicencaErro("esta chave foi gerada para outro servidor")


def gerar_solicitacao():
    """Novo código para enviar ao fornecedor. Os 5 últimos continuam aceitos."""
    with _trava:
        agora = int(_relogio())
        sol = Solicitacao(PID, id_maquina(), secrets.token_bytes(6), agora)
        dados = _ler()
        pendentes = [p for p in dados.get("pendentes", []) if agora - p["criada"] < VALIDADE_SOLICITACAO]
        pendentes.append({"nonce": sol.nonce.hex(), "criada": agora})
        dados["pendentes"] = pendentes[-MAX_PENDENTES:]
        _gravar(dados)
        return sol.para_codigo()


def serial_atual():
    """Serial (código de solicitação) mostrado na tela de registro.

    Fica o MESMO até ser usado ou passar 30 dias, para o cliente poder fechar e abrir o sistema
    sem o número mudar. Depois de uma ativação, o próximo serial já é outro (o usado não vale mais)."""
    with _trava:
        agora = int(_relogio())
        pendentes = [p for p in _ler().get("pendentes", []) if 0 <= agora - p["criada"] < VALIDADE_SOLICITACAO]
        if pendentes:
            p = pendentes[-1]
            return Solicitacao(PID, id_maquina(), bytes.fromhex(p["nonce"]), int(p["criada"])).para_codigo()
        return gerar_solicitacao()


def ativar(codigo):
    """Aplica a chave de liberação. Levanta LicencaErro com mensagem amigável."""
    with _trava:
        try:
            lib = Liberacao.de_codigo(codigo)
        except CodigoInvalido as e:
            raise LicencaErro(str(e)) from None
        _conferir(lib)
        dados = _ler()
        pendentes = dados.get("pendentes", [])
        if not any(p.get("nonce") == lib.nonce.hex() for p in pendentes):
            raise LicencaErro("esta chave não corresponde a nenhuma solicitação recente deste servidor "
                              "(chave antiga ou já utilizada). Gere um novo código de solicitação.")
        agora = int(_relogio())
        if agora >= lib.expira:
            raise LicencaErro("esta chave já está vencida")
        codigo_limpo = lib.para_codigo()
        ultimo = max(agora, int(dados.get("ultimo_uso", 0) or 0))
        dados.update(licenca=codigo_limpo, ultimo_uso=ultimo, selo=_selo(codigo_limpo, ultimo),
                     pendentes=[p for p in pendentes if p.get("nonce") != lib.nonce.hex()])
        _gravar(dados)
        _limpar_cache()
        return estado(forcar=True)


def _calcular():
    base = {"valida": False, "situacao": "sem_licenca", "texto": "Sistema não ativado", "licenca_id": None,
            "expira": None, "dias_restantes": 0, "limite_equipamentos": 0, "limite_empresas": 0,
            "maquina": id_maquina_texto(), "aviso": ""}
    if not CHAVE_PUBLICA:
        return dict(base, situacao="invalida", texto="Este Sentinela foi gerado sem a chave pública do fornecedor")
    dados = _ler()
    codigo = dados.get("licenca")
    if not codigo:
        return base
    try:
        lib = Liberacao.de_codigo(codigo)
        _conferir(lib)
    except (CodigoInvalido, LicencaErro) as e:
        return dict(base, situacao="invalida", texto=f"Arquivo de licença inválido ({e})")

    info = dict(base, licenca_id=lib.licenca_id,
                expira=time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(lib.expira)),
                limite_equipamentos=lib.limite_equipamentos, limite_empresas=lib.limite_empresas)
    agora = int(_relogio())
    ultimo = int(dados.get("ultimo_uso", 0) or 0)
    if not hmac.compare_digest(str(dados.get("selo", "")), _selo(codigo, ultimo)):
        return dict(info, situacao="invalida", texto="O arquivo de licença foi alterado manualmente")
    if agora < ultimo - TOLERANCIA_RELOGIO or agora < lib.emitida - TOLERANCIA_RELOGIO:
        return dict(info, situacao="relogio",
                    texto="O relógio do servidor foi atrasado. Corrija a data e a hora do sistema")
    data_fim = time.strftime("%d/%m/%Y", time.localtime(lib.expira))
    if agora >= lib.expira:
        return dict(info, situacao="vencida", texto=f"Licença do sistema vencida em {data_fim}")

    if agora - ultimo >= GRAVAR_USO_SEG:
        dados["ultimo_uso"], dados["selo"] = agora, _selo(codigo, agora)
        try:
            _gravar(dados)
        except OSError:
            pass
    dias = -(-(lib.expira - agora) // 86400)
    aviso = f"A licença do sistema vence em {dias} dia(s) ({data_fim})" if dias <= AVISAR_DIAS else ""
    return dict(info, valida=True, situacao="ok", texto=f"Licença válida até {data_fim}",
                dias_restantes=dias, aviso=aviso)


def estado(forcar=False):
    """Situação atual da licença (guardada por alguns segundos para não ler o disco a cada requisição)."""
    with _trava:
        agora = time.monotonic()
        if forcar or _cache["estado"] is None or agora - _cache["em"] >= CACHE_SEG:
            _cache["estado"], _cache["em"] = _calcular(), agora
        return dict(_cache["estado"])


def valida():
    return estado()["valida"]


def limite_equipamentos():
    return estado()["limite_equipamentos"]


def limite_empresas():
    return estado()["limite_empresas"]
