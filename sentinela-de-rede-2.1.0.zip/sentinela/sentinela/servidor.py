"""Inicialização: banco, motores em segundo plano e servidor web (HTTPS)."""

import datetime
import ipaddress
import socket
import os
import ssl
import sys
import threading
import time

from . import VERSAO, armazenamento, banco, config, incidentes
from .config import CFG
from .monitor import MONITOR
from .tempo_real import TEMPO_REAL, descobrir_ip_local

# Motores extras registram aqui uma função de inicialização (SNMP, fluxo, alertas, BGP...)
INICIALIZADORES = []


def gerar_certificado(arquivo_cert, arquivo_chave):
    """Cria um certificado autoassinado (válido por 2 anos) para o HTTPS funcionar de imediato."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID

    chave = ec.generate_private_key(ec.SECP256R1())
    nome = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Sentinela de Rede"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Sentinela de Rede")])
    alternativos = [x509.DNSName("localhost"), x509.DNSName(socket.gethostname()),
                    x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
    ip = descobrir_ip_local()
    try:
        alternativos.append(x509.IPAddress(ipaddress.ip_address(ip)))
    except ValueError:
        pass
    agora = datetime.datetime.now(datetime.timezone.utc)
    certificado = (
        x509.CertificateBuilder().subject_name(nome).issuer_name(nome).public_key(chave.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(agora - datetime.timedelta(minutes=5))
        .not_valid_after(agora + datetime.timedelta(days=730))
        .add_extension(x509.SubjectAlternativeName(alternativos), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(chave, hashes.SHA256())
    )
    arquivo_chave.write_bytes(chave.private_bytes(serialization.Encoding.PEM,
                                                  serialization.PrivateFormat.PKCS8,
                                                  serialization.NoEncryption()))
    try:
        arquivo_chave.chmod(0o600)
    except OSError:
        pass
    arquivo_cert.write_bytes(certificado.public_bytes(serialization.Encoding.PEM))


def caminhos_certificado():
    dados = config.pasta_dados()
    cert = CFG["web"]["certificado"] or str(dados / "certificado.pem")
    chave = CFG["web"]["chave"] or str(dados / "certificado.key")
    from pathlib import Path
    cert, chave = Path(cert), Path(chave)
    if not cert.exists() or not chave.exists():
        if CFG["web"]["certificado"]:
            raise SystemExit(f"Certificado configurado não encontrado: {cert}")
        gerar_certificado(cert, chave)
    return cert, chave


def preparar():
    """Prepara o banco e liga os motores em segundo plano."""
    from .coletor_snmp import COLETOR

    banco.migrar()
    armazenamento.migrar_pastas()  # backups antigos (antes do multiempresa) vão para a pasta da empresa 1
    MONITOR.ao_alertar.append(TEMPO_REAL.ao_alertar_monitor)
    COLETOR.ao_alertar.append(TEMPO_REAL.ao_alertar_monitor)
    TEMPO_REAL.capturar = MONITOR.capturar_agora
    for inicializar in INICIALIZADORES:
        inicializar()
    from .alertas import NOTIFICADOR
    from .bgp import BGP
    from .fluxo import FLUXO
    from .mitigacao import MITIGADOR
    from .olt import OLT

    NOTIFICADOR.iniciar()
    FLUXO.ao_detectar.append(MITIGADOR.ao_ddos)
    TEMPO_REAL.ao_forca_bruta.append(MITIGADOR.ao_forca_bruta)
    MONITOR.ao_alertar.append(lambda equip, tipo, origens: tipo == "Força bruta" and MITIGADOR.ao_forca_bruta(equip, origens))
    MITIGADOR.iniciar()
    MONITOR.iniciar()
    TEMPO_REAL.iniciar()
    COLETOR.iniciar()
    FLUXO.iniciar()
    BGP.iniciar()
    OLT.iniciar()
    incidentes.registrar_evento(None, "Sentinela", "Sistema iniciado", "info", f"Versão {VERSAO}", fonte="sistema")


def iniciar():
    from .web.app import app
    from . import autenticacao as auth

    preparar()
    endereco, porta = CFG["web"]["endereco"], int(CFG["web"]["porta"])
    usar_https = bool(CFG["web"]["https"])
    esquema = "https" if usar_https else "http"

    print("=" * 62)
    print(f"  Sentinela de Rede {VERSAO}")
    print("=" * 62)
    print(f"  Painel:     {esquema}://localhost:{porta}   (na rede: {esquema}://{TEMPO_REAL.ip_local}:{porta})")
    print(f"  Dados:      {config.pasta_dados()}")
    if CFG["tempo_real"]["syslog"]:
        print(f"  Syslog:     UDP {CFG['tempo_real']['syslog_porta']}")
    if CFG["fluxo"]["ativo"]:
        print(f"  NetFlow:    UDP {CFG['fluxo']['porta_netflow']} (v5/v9/IPFIX) · sFlow: UDP {CFG['fluxo']['porta_sflow']}")
        if not CFG["fluxo"]["redes_proprias"]:
            print("  Aviso:      configure [fluxo] redes_proprias com os seus blocos de IP para a detecção de DDoS.")
    from . import licenca
    lic = licenca.estado(forcar=True)
    print(f"  Licença:    {lic['texto']}  (servidor {lic['maquina']})")
    if not lic["valida"]:
        print("              Abra o painel: a tela de registro mostra o SERIAL para enviar ao fornecedor.")
        print("              (sem navegador: python -m sentinela licenca-solicitar)")
    elif lic["aviso"]:
        print(f"              Aviso: {lic['aviso']}")
    if auth.contar_usuarios() == 0:
        print("\n  PRIMEIRO ACESSO: abra o painel neste servidor (localhost) para criar o administrador,")
        print("  ou rode: python -m sentinela criar-admin")
    if usar_https:
        print("\n  O certificado é autoassinado: o navegador vai mostrar um aviso na primeira vez.")
        print("  Para remover o aviso, configure um certificado próprio em config.toml ([web] certificado/chave).")
    print("\n  Ctrl+C para encerrar.\n")

    cert = chave = None
    if usar_https:
        cert, chave = caminhos_certificado()

    if os.environ.get("SENTINELA_ABRIR_NAVEGADOR") == "1":
        def abrir_navegador():
            import webbrowser
            # espera o servidor aceitar conexões antes de abrir a página
            for _ in range(60):
                try:
                    with socket.create_connection(("127.0.0.1", porta), timeout=1):
                        break
                except OSError:
                    time.sleep(0.5)
            url = f"{esquema}://localhost:{porta}"
            print(f"  Abrindo o navegador em {url} ...\n")
            try:
                webbrowser.open(url)
            except Exception:
                print(f"  Não consegui abrir o navegador: abra {url} manualmente.\n")

        threading.Thread(target=abrir_navegador, daemon=True).start()

    try:
        from cheroot import wsgi  # servidor de produção (recomendado)
        servidor = wsgi.Server((endereco, porta), app, numthreads=40, server_name="sentinela")
        if usar_https:
            from cheroot.ssl.builtin import BuiltinSSLAdapter
            servidor.ssl_adapter = BuiltinSSLAdapter(str(cert), str(chave))

        # O navegador recusa o certificado autoassinado até a pessoa aceitar o aviso, e isso gera uma
        # mensagem por conexão. Não é erro: esconde só esse ruído, mantendo os demais erros.
        log_original = servidor.error_log
        ruido = ("CERTIFICATE_UNKNOWN", "peer dropped the TLS connection", "UNEXPECTED_EOF", "HTTP_REQUEST",
                 "WRONG_VERSION_NUMBER", "Connection reset by peer", "Errno 10054")

        def log_filtrado(msg="", *args, **kwargs):
            if any(trecho in str(msg) for trecho in ruido):
                return
            log_original(msg, *args, **kwargs)

        servidor.error_log = log_filtrado

        # No Windows + Python 3.13, o cheroot às vezes tenta gravar num soquete já fechado ao descartar uma
        # conexão encerrada pelo navegador (WinError 10038/10054). É inofensivo: esconde só esse caso.
        gancho_original = sys.unraisablehook

        def gancho_filtrado(info):
            erro = info.exc_value
            if isinstance(erro, OSError) and (getattr(erro, "winerror", None) in (10038, 10053, 10054)
                                             or getattr(erro, "errno", None) in (9, 32, 104)):
                return
            gancho_original(info)

        sys.unraisablehook = gancho_filtrado
        try:
            servidor.start()
        except KeyboardInterrupt:
            servidor.stop()
    except ImportError:
        from werkzeug.serving import make_server
        contexto = None
        if usar_https:
            contexto = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            contexto.minimum_version = ssl.TLSVersion.TLSv1_2
            contexto.load_cert_chain(str(cert), str(chave))
        print("  (aviso: instale o 'cheroot' para usar o servidor de produção: pip install cheroot)\n")
        servidor = make_server(endereco, porta, app, threaded=True, ssl_context=contexto)
        try:
            servidor.serve_forever()
        except KeyboardInterrupt:
            servidor.shutdown()
    print("\nSentinela encerrado.")
