"""Gerador de QR code (modo byte, correção de erro nível M), sem dependências.

Usado para mostrar o QR code do 2FA. Segue a especificação ISO/IEC 18004.
"""

# Correção nível M: codewords de correção por bloco e número de blocos, por versão (1 a 40)
_ECC_POR_BLOCO = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
                  26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28]
_BLOCOS = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16,
           17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49]
_NIVEL_M = 0  # bits de formato do nível M


def _modulos_de_dados(versao):
    total = (16 * versao + 128) * versao + 64
    if versao >= 2:
        n = versao // 7 + 2
        total -= (25 * n - 10) * n - 55
        if versao >= 7:
            total -= 36
    return total


def _codewords_dados(versao):
    return _modulos_de_dados(versao) // 8 - _ECC_POR_BLOCO[versao] * _BLOCOS[versao]


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _divisor_rs(grau):
    resultado = [0] * (grau - 1) + [1]
    raiz = 1
    for _ in range(grau):
        for j in range(grau):
            resultado[j] = _gf_mul(resultado[j], raiz)
            if j + 1 < grau:
                resultado[j] ^= resultado[j + 1]
        raiz = _gf_mul(raiz, 0x02)
    return resultado


def _resto_rs(dados, divisor):
    resultado = [0] * len(divisor)
    for b in dados:
        fator = b ^ resultado.pop(0)
        resultado.append(0)
        for i, coef in enumerate(divisor):
            resultado[i] ^= _gf_mul(coef, fator)
    return resultado


def _posicoes_alinhamento(versao):
    if versao == 1:
        return []
    n = versao // 7 + 2
    passo = 26 if versao == 32 else (versao * 4 + n * 2 + 1) // (n * 2 - 2) * 2
    tamanho = versao * 4 + 17
    resultado = [6]
    pos = tamanho - 7
    for _ in range(n - 1):
        resultado.insert(1, pos)
        pos -= passo
    return resultado


class _Matriz:
    def __init__(self, versao):
        self.versao = versao
        self.tamanho = versao * 4 + 17
        self.mod = [[False] * self.tamanho for _ in range(self.tamanho)]
        self.funcao = [[False] * self.tamanho for _ in range(self.tamanho)]

    def fixo(self, x, y, escuro):
        self.mod[y][x] = escuro
        self.funcao[y][x] = True

    def padroes_fixos(self):
        t = self.tamanho
        for i in range(t):  # linhas de temporização
            self.fixo(6, i, i % 2 == 0)
            self.fixo(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (t - 4, 3), (3, t - 4)):  # localizadores
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < t and 0 <= y < t:
                        self.fixo(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = _posicoes_alinhamento(self.versao)
        ultimo = len(pos) - 1
        for i, px in enumerate(pos):
            for j, py in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == ultimo) or (i == ultimo and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.fixo(px + dx, py + dy, max(abs(dx), abs(dy)) != 1)
        self.formato(0)  # reserva a área (é redesenhado depois)
        if self.versao >= 7:
            resto = self.versao
            for _ in range(12):
                resto = (resto << 1) ^ ((resto >> 11) * 0x1F25)
            bits = self.versao << 12 | resto
            for i in range(18):
                bit = (bits >> i) & 1 == 1
                a, b = t - 11 + i % 3, i // 3
                self.fixo(a, b, bit)
                self.fixo(b, a, bit)

    def formato(self, mascara):
        dados = _NIVEL_M << 3 | mascara
        resto = dados
        for _ in range(10):
            resto = (resto << 1) ^ ((resto >> 9) * 0x537)
        bits = (dados << 10 | resto) ^ 0x5412
        bit = lambda i: (bits >> i) & 1 == 1
        t = self.tamanho
        for i in range(6):
            self.fixo(8, i, bit(i))
        self.fixo(8, 7, bit(6))
        self.fixo(8, 8, bit(7))
        self.fixo(7, 8, bit(8))
        for i in range(9, 15):
            self.fixo(14 - i, 8, bit(i))
        for i in range(8):
            self.fixo(t - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.fixo(8, t - 15 + i, bit(i))
        self.fixo(8, t - 8, True)

    def dados(self, codewords):
        t, i = self.tamanho, 0
        direita = t - 1
        while direita >= 1:
            if direita == 6:
                direita = 5
            for vert in range(t):
                for j in range(2):
                    x = direita - j
                    subindo = ((direita + 1) & 2) == 0
                    y = t - 1 - vert if subindo else vert
                    if not self.funcao[y][x] and i < len(codewords) * 8:
                        self.mod[y][x] = (codewords[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1
            direita -= 2

    def mascarar(self, m):
        regras = [
            lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
            lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
            lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
            lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
        ]
        regra = regras[m]
        for y in range(self.tamanho):
            for x in range(self.tamanho):
                if not self.funcao[y][x] and regra(x, y):
                    self.mod[y][x] = not self.mod[y][x]

    def penalidade(self):
        t, m, pontos = self.tamanho, self.mod, 0
        linhas = [m[y] for y in range(t)] + [[m[y][x] for y in range(t)] for x in range(t)]
        padrao_a = [True, False, True, True, True, False, True, False, False, False, False]
        padrao_b = padrao_a[::-1]
        for linha in linhas:
            sequencia, anterior = 0, None
            for v in linha:
                if v == anterior:
                    sequencia += 1
                    if sequencia == 5:
                        pontos += 3
                    elif sequencia > 5:
                        pontos += 1
                else:
                    sequencia, anterior = 1, v
            for i in range(t - 10):
                trecho = linha[i:i + 11]
                if trecho == padrao_a or trecho == padrao_b:
                    pontos += 40
        for y in range(t - 1):
            for x in range(t - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    pontos += 3
        escuros = sum(sum(l) for l in m)
        total = t * t
        k = (abs(escuros * 20 - total * 10) + total - 1) // total - 1
        return pontos + max(k, 0) * 10


def gerar(texto):
    """Retorna a matriz (lista de listas de bool) do QR code para o texto."""
    dados = texto.encode("utf-8")
    versao = None
    for v in range(1, 41):
        bits_contagem = 8 if v < 10 else 16
        if 4 + bits_contagem + len(dados) * 8 <= _codewords_dados(v) * 8:
            versao = v
            break
    if versao is None:
        raise ValueError("Texto longo demais para um QR code")

    bits = [0, 1, 0, 0]  # modo byte
    bits_contagem = 8 if versao < 10 else 16
    bits += [(len(dados) >> i) & 1 for i in reversed(range(bits_contagem))]
    for b in dados:
        bits += [(b >> i) & 1 for i in reversed(range(8))]
    capacidade = _codewords_dados(versao) * 8
    bits += [0] * min(4, capacidade - len(bits))
    bits += [0] * (-len(bits) % 8)
    palavras = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    preenchimento = 0xEC
    while len(palavras) < _codewords_dados(versao):
        palavras.append(preenchimento)
        preenchimento ^= 0xEC ^ 0x11

    n_blocos, ecc = _BLOCOS[versao], _ECC_POR_BLOCO[versao]
    total_palavras = _modulos_de_dados(versao) // 8
    curtos = n_blocos - total_palavras % n_blocos
    tam_curto = total_palavras // n_blocos
    divisor = _divisor_rs(ecc)
    blocos, k = [], 0
    for i in range(n_blocos):
        fim = k + tam_curto - ecc + (0 if i < curtos else 1)
        bloco = palavras[k:fim]
        k = fim
        correcao = _resto_rs(bloco, divisor)
        if i < curtos:
            bloco.append(0)
        blocos.append(bloco + correcao)
    final = []
    for i in range(len(blocos[0])):
        for j, bloco in enumerate(blocos):
            if i != tam_curto - ecc or j >= curtos:
                final.append(bloco[i])

    melhor, melhor_pontos = None, None
    for mascara in range(8):
        matriz = _Matriz(versao)
        matriz.padroes_fixos()
        matriz.dados(final)
        matriz.mascarar(mascara)
        matriz.formato(mascara)
        pontos = matriz.penalidade()
        if melhor_pontos is None or pontos < melhor_pontos:
            melhor, melhor_pontos = matriz, pontos
    return melhor.mod


def svg(texto, borda=4):
    matriz = gerar(texto)
    t = len(matriz) + borda * 2
    caminho = "".join(f"M{x + borda} {y + borda}h1v1h-1z"
                      for y, linha in enumerate(matriz) for x, v in enumerate(linha) if v)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {t} {t}" shape-rendering="crispEdges">'
            f'<rect width="{t}" height="{t}" fill="#fff"/><path d="{caminho}" fill="#000"/></svg>')
