"""Mitigação com aprovação humana: RTBH (blackhole do IP atacado) e bloqueio de IPs atacantes.

Fluxo:
  1. O Sentinela detecta um ataque e PROPÕE a mitigação (estado "pendente").
  2. Um operador aprova no painel; só então os comandos são enviados aos roteadores
     (usando a credencial de mitigação do equipamento, com permissão de escrita).
  3. A mitigação expira sozinha (ou é removida antes, no painel) e os comandos são desfeitos.

Travas de segurança: só faz RTBH de IPs das suas redes, nunca bloqueia IPs da lista
"nunca_bloquear", só atua em um IP por vez (/32 ou /128) e registra tudo na auditoria.
"""

import datetime
import ipaddress
import json
import re
import threading
import time

from . import autenticacao as auth, banco, equipamentos, incidentes, ssh

# Comandos por fabricante. Variáveis: {alvo} {mascara} {mascara_decimal} {id} {minutos} {familia_mikrotik}
MODELOS_PADRAO = {
    "rtbh": {
        "mikrotik_routeros": {
            "aplicar": ['/{familia_mikrotik} route add dst-address={alvo}/{mascara} blackhole comment="sentinela-rtbh-{id}"'],
            "remover": ['/{familia_mikrotik} route remove [find comment="sentinela-rtbh-{id}"]'],
        },
        "cisco_ios": {"aplicar": ["ip route {alvo} {mascara_decimal} Null0 tag 666"],
                      "remover": ["no ip route {alvo} {mascara_decimal} Null0 tag 666"]},
        "cisco_xe": {"aplicar": ["ip route {alvo} {mascara_decimal} Null0 tag 666"],
                     "remover": ["no ip route {alvo} {mascara_decimal} Null0 tag 666"]},
        "huawei": {"aplicar": ["ip route-static {alvo} {mascara} NULL0 tag 666"],
                   "remover": ["undo ip route-static {alvo} {mascara} NULL0"]},
        "juniper_junos": {"aplicar": ["set routing-options static route {alvo}/{mascara} discard tag 666"],
                          "remover": ["delete routing-options static route {alvo}/{mascara}"]},
    },
    "bloqueio": {
        "mikrotik_routeros": {
            "aplicar": ['/{familia_mikrotik} firewall address-list add list=sentinela-bloqueio address={alvo} '
                        'timeout={minutos}m comment="sentinela-{id}"'],
            "remover": ['/{familia_mikrotik} firewall address-list remove [find comment="sentinela-{id}"]'],
        },
    },
}
PADRAO = {"duracao_rtbh_min": 60, "duracao_bloqueio_min": 1440, "propor_rtbh": True, "propor_bloqueio": True,
          "automatico_rtbh": False, "automatico_rtbh_gbps": 5.0, "nunca_bloquear": [], "modelos": MODELOS_PADRAO}
TIPOS = {"rtbh": "RTBH (blackhole do IP atacado)", "bloqueio": "Bloqueio de IP atacante"}


def ler_config(empresa_id):
    """Regras e comandos de mitigação DA EMPRESA."""
    salvo = json.loads(banco.ler_config_empresa(empresa_id, "mitigacao", "{}") or "{}")
    cfg = json.loads(json.dumps(PADRAO))
    cfg.update({k: v for k, v in salvo.items() if k in PADRAO})
    return cfg


def salvar_config(empresa_id, novos):
    cfg = ler_config(empresa_id)
    for chave in ("duracao_rtbh_min", "duracao_bloqueio_min"):
        if chave in novos:
            valor = int(novos[chave])
            if not 5 <= valor <= 10080:
                raise ValueError("A duração deve ficar entre 5 minutos e 7 dias")
            cfg[chave] = valor
    for chave in ("propor_rtbh", "propor_bloqueio", "automatico_rtbh"):
        if chave in novos:
            cfg[chave] = bool(novos[chave])
    if "automatico_rtbh_gbps" in novos:
        cfg["automatico_rtbh_gbps"] = max(0.1, float(novos["automatico_rtbh_gbps"]))
    if "nunca_bloquear" in novos:
        lista = [x.strip() for x in str(novos["nunca_bloquear"]).replace(",", "\n").splitlines() if x.strip()]
        for item in lista:
            ipaddress.ip_network(item, strict=False)  # valida
        cfg["nunca_bloquear"] = lista
    if "modelos" in novos:
        modelos = novos["modelos"]
        for tipo, por_fab in modelos.items():
            if tipo not in TIPOS or not isinstance(por_fab, dict):
                raise ValueError("Modelo inválido")
            for fabricante, cmds in por_fab.items():
                for fase in ("aplicar", "remover"):
                    linhas = cmds.get(fase, [])
                    if isinstance(linhas, str):
                        linhas = [l for l in linhas.splitlines() if l.strip()]
                    for l in linhas:
                        try:  # valida as variáveis antes de salvar
                            l.format(alvo="1.1.1.1", mascara=32, mascara_decimal="255.255.255.255", id=1, minutos=1,
                                     familia_mikrotik="ip")
                        except (KeyError, IndexError, ValueError) as e:
                            raise ValueError(f"comando com variável desconhecida ou chave sem par: {l} ({e})") from e
                    cmds[fase] = linhas
        cfg["modelos"] = modelos
    banco.gravar_config_empresa(empresa_id, "mitigacao", json.dumps(cfg, ensure_ascii=False))
    return cfg


def _protegido(endereco, cfg):
    for item in cfg["nunca_bloquear"]:
        try:
            if endereco in ipaddress.ip_network(item, strict=False):
                return item
        except ValueError:
            continue
    return None


def validar_alvo(tipo, alvo, cfg, empresa_id):
    texto = str(alvo).strip()
    # só dígitos hexadecimais, ":" e "." (bloqueia scope-id de IPv6 como "%eth0", espaços e quebras de linha,
    # que seriam repassados aos comandos do roteador)
    if not re.fullmatch(r"[0-9A-Fa-f:.]{2,45}", texto):
        raise ValueError("Informe um único endereço IP (sem /máscara, sem %interface)")
    try:
        endereco = ipaddress.ip_address(texto)
    except ValueError:
        raise ValueError("Informe um único endereço IP (sem /máscara)")
    if tipo == "rtbh":
        from . import empresas
        redes = [ipaddress.ip_network(r, strict=False) for r in empresas.redes(empresa_id)]
        if not redes:
            raise ValueError("Cadastre as redes (blocos de IP) da empresa: RTBH só é permitido para IPs das suas redes")
        if not any(endereco in r for r in redes):
            raise ValueError(f"{endereco} não pertence às suas redes: RTBH recusado")
    protegido = _protegido(endereco, cfg)
    if protegido:
        raise ValueError(f"{endereco} está na lista 'nunca bloquear' ({protegido})")
    if endereco.is_loopback or endereco.is_unspecified or endereco.is_multicast:
        raise ValueError("Endereço inválido para mitigação")
    return str(endereco)


def _agora():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _variaveis(m):
    endereco = ipaddress.ip_address(m["alvo"])
    v6 = endereco.version == 6
    return {"alvo": m["alvo"], "mascara": 128 if v6 else 32, "mascara_decimal": "255.255.255.255",
            "id": m["id"], "minutos": m["duracao_min"], "familia_mikrotik": "ipv6" if v6 else "ip"}


class Mitigador:
    def __init__(self):
        self.trava = threading.Lock()

    # ------------------------------------------------------------ propostas
    def propor(self, empresa_id, tipo, alvo, motivo, equip_ids, origem="manual", criado_por="sistema",
               incidente_id=None, duracao_min=None):
        if empresa_id is None:
            raise ValueError("Empresa não informada")
        empresa_id = int(empresa_id)
        cfg = ler_config(empresa_id)
        alvo = validar_alvo(tipo, alvo, cfg, empresa_id)
        equip_ids = list(dict.fromkeys(str(e) for e in (equip_ids or [])))
        if not equip_ids:
            raise ValueError("Nenhum equipamento para aplicar a mitigação")
        # só roteadores DA PRÓPRIA empresa (nunca envia comandos ao equipamento de outro provedor)
        for eid in equip_ids:
            if not equipamentos.obter(eid, empresa_id):
                raise ValueError("Equipamento inválido para esta empresa")
        duplicada = banco.um("SELECT id FROM mitigacoes WHERE empresa_id = ? AND tipo = ? AND alvo = ? "
                             "AND estado IN ('pendente', 'aplicando', 'ativa')", (empresa_id, tipo, alvo))
        if duplicada:
            return banco.um("SELECT * FROM mitigacoes WHERE id = ?", (duplicada["id"],)), False
        duracao = int(duracao_min or cfg["duracao_rtbh_min" if tipo == "rtbh" else "duracao_bloqueio_min"])
        if not 5 <= duracao <= 10080:
            raise ValueError("A duração deve ficar entre 5 minutos e 7 dias")
        mid = banco.executar(
            "INSERT INTO mitigacoes (tipo, alvo, motivo, origem, equip_ids, duracao_min, criado_por, incidente_id, empresa_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (tipo, alvo, motivo[:500], origem, json.dumps(equip_ids), duracao,
                                                criado_por, incidente_id, empresa_id))
        incidentes.registrar_evento(None, alvo, "Mitigação", "aviso",
                                    f"Mitigação #{mid} proposta: {TIPOS[tipo]} de {alvo} ({motivo[:120]}). Aguardando aprovação.",
                                    fonte="mitigacao", empresa_id=empresa_id)
        return banco.um("SELECT * FROM mitigacoes WHERE id = ?", (mid,)), True

    def equipamentos_de_borda(self, tipo, empresa_id):
        modelos = ler_config(empresa_id)["modelos"][tipo]
        return [e["id"] for e in equipamentos.listar(empresa_id, somente_ativos=True)
                if e["funcao"] == "borda" and e["tipo"] in modelos]

    def ao_ddos(self, ataque):
        """Chamado pela detecção por fluxo quando um DDoS começa."""
        empresa_id = ataque.get("empresa_id")
        if empresa_id is None:
            return
        cfg = ler_config(empresa_id)
        if not cfg["propor_rtbh"]:
            return
        bordas = self.equipamentos_de_borda("rtbh", empresa_id)
        if not bordas:
            incidentes.registrar_evento(None, ataque["alvo"], "Mitigação", "aviso",
                                        "DDoS detectado, mas não há roteador de borda compatível para propor RTBH",
                                        fonte="mitigacao", empresa_id=empresa_id)
            return
        motivo = f"DDoS {ataque['vetor']} de {ataque['bps'] / 1e9:.2f} Gbps"
        try:
            m, nova = self.propor(empresa_id, "rtbh", ataque["alvo"], motivo, bordas, origem="ddos",
                                  incidente_id=ataque.get("incidente_id"))
        except ValueError as e:
            incidentes.registrar_evento(None, ataque["alvo"], "Mitigação", "aviso", f"RTBH não proposto: {e}",
                                        fonte="mitigacao", empresa_id=empresa_id)
            return
        if nova and cfg["automatico_rtbh"] and ataque["bps"] >= float(cfg["automatico_rtbh_gbps"]) * 1e9:
            threading.Thread(target=self.aprovar, args=(m["id"], "automático (acima do limite)", empresa_id),
                             daemon=True).start()

    def ao_forca_bruta(self, equip, origens, incidente_id=None):
        """Propõe bloquear os IPs atacantes no próprio equipamento atacado (se o fabricante tiver modelo)."""
        empresa_id = equip.get("empresa_id")
        if empresa_id is None:
            return
        cfg = ler_config(empresa_id)
        if not cfg["propor_bloqueio"] or equip["tipo"] not in cfg["modelos"]["bloqueio"]:
            return
        for ip in list(dict.fromkeys(origens))[:5]:
            try:
                self.propor(empresa_id, "bloqueio", ip, f"Força bruta contra {equip['nome']}", [equip["id"]],
                            origem="forca_bruta", incidente_id=incidente_id)
            except ValueError:
                continue

    # ------------------------------------------------------------ execução
    def _executar(self, m, fase):
        cfg = ler_config(m["empresa_id"])
        variaveis = _variaveis(m)
        log = []
        sucesso = True
        for eid in json.loads(m["equip_ids"]):
            equip = equipamentos.obter(eid, m["empresa_id"], segredos=True)   # só da empresa da mitigação
            if not equip:
                log.append(f"[{eid}] equipamento não existe mais nesta empresa")
                continue
            modelos = cfg["modelos"][m["tipo"]].get(equip["tipo"])
            if not modelos:
                log.append(f"[{equip['nome']}] sem modelo de comandos para {equip['tipo_nome']}")
                sucesso = False
                continue
            comandos = [c.format(**variaveis) for c in modelos[fase]]
            if any("\n" in c or "\r" in c for c in comandos):  # defesa extra contra injeção de comandos
                log.append(f"[{equip['nome']}] RECUSADO: comando com quebra de linha")
                sucesso = False
                continue
            credencial = dict(equip)
            if equip.get("mit_usuario") and equip.get("mit_senha"):
                credencial.update(usuario=equip["mit_usuario"], senha=equip["mit_senha"], enable=equip["mit_senha"])
            try:
                with ssh.conectar(credencial) as conn:
                    saida = conn.send_config_set(comandos, read_timeout=60)
                    if equip["tipo"] == "juniper_junos":
                        saida += conn.commit(comment=f"sentinela mitigacao {m['id']}")
                    elif equip["tipo"] in ("cisco_ios", "cisco_xe"):
                        conn.save_config()
                erro = next((l for l in saida.splitlines() if l.strip().lower().startswith(("% invalid", "error", "failure", "bad command", "expected end"))), None)
                if erro:
                    raise RuntimeError(erro.strip())
                log.append(f"[{equip['nome']}] OK: {' | '.join(comandos)}")
            except Exception as e:
                sucesso = False
                log.append(f"[{equip['nome']}] FALHOU: {ssh.descrever_erro(e)}")
        return sucesso, log

    def aprovar(self, mid, usuario, empresa_id):
        with self.trava:
            m = banco.um("SELECT * FROM mitigacoes WHERE id = ? AND empresa_id = ?", (mid, int(empresa_id)))
            if not m or m["estado"] != "pendente":
                return False, "Mitigação não está pendente"
            banco.executar("UPDATE mitigacoes SET estado = 'aplicando', aprovado_por = ?, aprovado_em = ? WHERE id = ?",
                           (usuario, _agora(), mid))
        sucesso, log = self._executar(m, "aplicar")
        expira = time.time() + m["duracao_min"] * 60
        estado = "ativa" if sucesso else "erro"
        banco.executar("UPDATE mitigacoes SET estado = ?, expira = ?, log = log || ? WHERE id = ?",
                       (estado, expira if sucesso else None, f"{_agora()} APLICAR\n" + "\n".join(log) + "\n", mid))
        auth.auditar(usuario, "", "Mitigação aplicada" if sucesso else "Mitigação falhou", f"#{mid} {m['tipo']} {m['alvo']}",
                     "; ".join(log), empresa_id=m["empresa_id"])
        incidentes.registrar_evento(None, m["alvo"], "Mitigação", "info" if sucesso else "erro",
                                    f"Mitigação #{mid} ({TIPOS[m['tipo']]} de {m['alvo']}) "
                                    f"{'aplicada por ' + usuario if sucesso else 'FALHOU'}: {log[0] if log else ''}",
                                    fonte="mitigacao", empresa_id=m["empresa_id"])
        return sucesso, "\n".join(log)

    def remover(self, mid, usuario, empresa_id, motivo="manual"):
        with self.trava:
            m = banco.um("SELECT * FROM mitigacoes WHERE id = ? AND empresa_id = ?", (mid, int(empresa_id)))
            if not m or m["estado"] not in ("ativa", "erro"):
                return False, "Mitigação não está ativa"
            banco.executar("UPDATE mitigacoes SET estado = 'removendo' WHERE id = ?", (mid,))
        sucesso, log = self._executar(m, "remover")
        banco.executar("UPDATE mitigacoes SET estado = ?, removido_em = ?, removido_por = ?, log = log || ? WHERE id = ?",
                       ("removida" if sucesso else "erro", _agora(), usuario,
                        f"{_agora()} REMOVER ({motivo})\n" + "\n".join(log) + "\n", mid))
        auth.auditar(usuario, "", "Mitigação removida" if sucesso else "Falha ao remover mitigação",
                     f"#{mid} {m['tipo']} {m['alvo']}", "; ".join(log), empresa_id=m["empresa_id"])
        incidentes.registrar_evento(None, m["alvo"], "Mitigação", "info" if sucesso else "erro",
                                    f"Mitigação #{mid} de {m['alvo']} {'removida' if sucesso else 'NÃO removida'} ({motivo})",
                                    fonte="mitigacao", empresa_id=m["empresa_id"])
        return sucesso, "\n".join(log)

    def rejeitar(self, mid, usuario, empresa_id):
        alterou = banco.executar("UPDATE mitigacoes SET estado = 'rejeitada', aprovado_por = ?, aprovado_em = ? "
                                 "WHERE id = ? AND empresa_id = ? AND estado = 'pendente'",
                                 (usuario, _agora(), mid, int(empresa_id)))
        if alterou:
            auth.auditar(usuario, "", "Mitigação rejeitada", f"#{mid}", empresa_id=empresa_id)
        return bool(alterou)

    def expirar(self, agora=None):
        agora = agora or time.time()
        vencidas = banco.consultar("SELECT id, empresa_id FROM mitigacoes WHERE estado = 'ativa' AND expira <= ?", (agora,))
        for m in vencidas:
            self.remover(m["id"], "sistema", m["empresa_id"], "expirou")
        # propostas pendentes há mais de 2 horas perdem o sentido
        banco.executar("UPDATE mitigacoes SET estado = 'expirada' WHERE estado = 'pendente' "
                       "AND criado < datetime('now', 'localtime', '-2 hours')")
        return len(vencidas)

    def laco(self):
        while True:
            time.sleep(30)
            try:
                self.expirar()
            except Exception as e:
                incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro", f"Mitigação: {e}", fonte="sistema")

    def iniciar(self):
        threading.Thread(target=self.laco, name="mitigacao", daemon=True).start()

    def listar(self, empresa_id):
        lista = banco.consultar("SELECT * FROM mitigacoes WHERE empresa_id = ? ORDER BY id DESC LIMIT 200",
                                (int(empresa_id),))
        nomes = {e["id"]: e["nome"] for e in equipamentos.listar(empresa_id)}
        agora = time.time()
        for m in lista:
            m["equipamentos"] = [nomes.get(e, "(removido)") for e in json.loads(m["equip_ids"])]
            m["restante_seg"] = int(m["expira"] - agora) if m["estado"] == "ativa" and m["expira"] else None
            m["tipo_nome"] = TIPOS[m["tipo"]]
        return lista


MITIGADOR = Mitigador()
