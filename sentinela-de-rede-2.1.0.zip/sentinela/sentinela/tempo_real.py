"""Tela "Ao vivo": recebe syslog dos equipamentos e mantém a lista de ataques em andamento."""

import datetime
import re
import socket
import threading
import time
from collections import Counter, deque

from . import banco, equipamentos, incidentes
from . import fabricantes as fab
from .config import CFG


def _hora(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M:%S")


class TempoReal:
    def __init__(self):
        self.trava = threading.Lock()
        self.ataques = {}       # chave (equip_id ou "ip:<empresa>:<ip>") -> {tipo: registro}
        self.recebidas = Counter()   # logs aceitos por empresa
        self.ultima_por_empresa = {}
        self.falhas = {}        # equip_id -> deque[(ts, origens)]
        self.syslog = {"ativo": False, "porta": int(CFG["tempo_real"]["syslog_porta"]), "erro": None,
                       "recebidas": 0, "ignoradas": 0, "ultima": None, "ultimo_ip_ignorado": None}
        self._mapa = {"quando": 0, "mapa": {}}
        self.capturar = None    # função do monitor para capturar evidências (ligada na inicialização)
        self.ao_forca_bruta = []  # callbacks(equip, origens, incidente_id) -> propor bloqueio
        self.ip_local = "IP_DESTE_SERVIDOR"
        self.padrao_suspeito = re.compile(CFG["tempo_real"]["padrao_suspeito"], re.IGNORECASE)

    # ------------------------------------------------------------ ataques ativos

    def janela(self):
        return int(CFG["tempo_real"]["janela_ataque_min"]) * 60

    def registrar_ataque(self, chave, tipo, origens, qtd=1, detalhe=None):
        """Abre ou atualiza um ataque ativo. Retorna True se for um ataque novo."""
        agora = time.time()
        with self.trava:
            ataques = self.ataques.setdefault(chave, {})
            reg = ataques.get(tipo)
            novo = reg is None or agora - reg["ultimo"] > self.janela()
            if novo:
                reg = ataques[tipo] = {"inicio": agora, "ultimo": agora, "qtd": 0, "origens": Counter(),
                                       "detalhe": None}
            reg["ultimo"] = agora
            reg["qtd"] += qtd
            reg["origens"].update(o for o in origens if o)
            if detalhe:
                reg["detalhe"] = detalhe
        return novo

    def ao_alertar_monitor(self, equip, tipo, origens):
        """Chamado pelo monitor quando a verificação periódica encontra um ataque."""
        self.registrar_ataque(equip["id"], tipo, origens)

    def esquecer(self, equip_id):
        with self.trava:
            self.ataques.pop(equip_id, None)
            self.falhas.pop(equip_id, None)
        self._mapa["quando"] = 0

    # ------------------------------------------------------------ syslog

    def equipamento_por_ip(self, ip):
        agora = time.time()
        if agora - self._mapa["quando"] > 30:
            mapa = {}
            for e in equipamentos.listar(equipamentos.TODAS, somente_ativos=True):
                mapa[e["host"]] = e
                try:
                    mapa[socket.gethostbyname(e["host"])] = e
                except OSError:
                    pass
            self._mapa = {"quando": agora, "mapa": mapa}
        return self._mapa["mapa"].get(ip)

    def tratar_syslog(self, texto, ip_remetente):
        equip = self.equipamento_por_ip(ip_remetente)
        with self.trava:
            self.syslog["recebidas"] += 1
            self.syslog["ultima"] = time.time()
            if equip is None:  # só aceita logs de equipamentos cadastrados
                self.syslog["ignoradas"] += 1
                self.syslog["ultimo_ip_ignorado"] = ip_remetente
                return
            self.recebidas[equip["empresa_id"]] += 1
            self.ultima_por_empresa[equip["empresa_id"]] = time.time()

        msg = re.sub(r"^<\d+>\s*", "", texto).strip()
        origens = [ip for ip in fab.PADRAO_IP.findall(msg) if ip not in (equip["host"], ip_remetente)]
        st = banco.um("SELECT hostname FROM status WHERE equip_id = ?", (equip["id"],))
        nome = f"{(st and st['hostname']) or equip['nome']} ({equip['host']})"
        agora = time.time()
        alerta, tipo = None, None

        if fab.PADRAO_FALHA_LOGIN.search(msg):
            janela_fb = int(CFG["tempo_real"]["janela_forca_bruta_seg"])
            limite = int(CFG["monitoramento"]["limite_falhas_login"])
            with self.trava:
                fila = self.falhas.setdefault(equip["id"], deque())
                fila.append((agora, origens))
                while fila and agora - fila[0][0] > janela_fb:
                    fila.popleft()
                quantas = len(fila)
                todas = [o for _, lista in fila for o in lista]
                reg = self.ataques.get(equip["id"], {}).get("Força bruta")
                ativo = reg is not None and agora - reg["ultimo"] <= self.janela()
            if quantas >= limite:
                tipo = "Força bruta"
                novo = self.registrar_ataque(equip["id"], tipo, origens if ativo else todas,
                                             qtd=1 if ativo else quantas)
                incidentes.registrar_evento(equip["id"], nome, tipo, "ataque", msg, ", ".join(origens), "syslog")
                if novo:
                    top = Counter(todas).most_common(5)
                    alerta = (f"Força bruta em tempo real: {quantas} falhas de login em {janela_fb}s. Origem: "
                              + (", ".join(f"{ip} ({n}x)" for ip, n in top) or "não identificada"))
            else:
                incidentes.registrar_evento(equip["id"], nome, "Falha de login", "aviso", msg,
                                            ", ".join(origens), "syslog")
        elif self.padrao_suspeito.search(msg):
            tipo = "Tráfego suspeito"
            novo = self.registrar_ataque(equip["id"], tipo, origens)
            incidentes.registrar_evento(equip["id"], nome, tipo, "ataque", msg, ", ".join(origens), "syslog")
            if novo:
                alerta = f"Tráfego suspeito em tempo real: {msg[:200]}"

        if alerta:
            incidente, _ = incidentes.abrir(equip["id"], nome, tipo, alerta, detalhes=alerta)
            if self.capturar:
                self.capturar(equip["id"], [alerta], tipo, incidente["id"])
            if tipo == "Força bruta":
                for funcao in self.ao_forca_bruta:
                    try:
                        funcao(equip, [ip for ip, _ in Counter(todas).most_common(5)], incidente["id"])
                    except Exception:
                        pass

    def servidor_syslog(self):
        porta = int(CFG["tempo_real"]["syslog_porta"])
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", porta))
        except OSError as e:
            with self.trava:
                self.syslog["erro"] = f"Não consegui abrir a porta UDP {porta}: {e}"
            return
        with self.trava:
            self.syslog["ativo"] = True
        while True:
            try:
                dados, (ip, _) = sock.recvfrom(8192)
                self.tratar_syslog(dados.decode("utf-8", errors="replace"), ip)
            except Exception:
                continue

    def iniciar(self):
        self.ip_local = descobrir_ip_local()
        if CFG["tempo_real"]["syslog"]:
            threading.Thread(target=self.servidor_syslog, name="syslog", daemon=True).start()

    # ------------------------------------------------------------ dados da tela

    def ativos(self, chave):
        agora = time.time()
        lista = []
        with self.trava:
            for tipo, reg in self.ataques.get(chave, {}).items():
                if agora - reg["ultimo"] <= self.janela():
                    lista.append({"tipo": tipo, "inicio": _hora(reg["inicio"]), "qtd": reg["qtd"],
                                  "ha_seg": int(agora - reg["ultimo"]), "duracao_seg": int(agora - reg["inicio"]),
                                  "origens": reg["origens"].most_common(5), "detalhe": reg["detalhe"]})
        lista.sort(key=lambda a: a["ha_seg"])
        return lista

    @staticmethod
    def chave_ip(empresa_id, ip):
        return f"ip:{int(empresa_id)}:{ip}"

    def estado(self, empresa_id, fornecedor=False):
        """Dados da tela Ao vivo DA EMPRESA informada."""
        empresa_id = int(empresa_id)
        agora = time.time()
        status = {s["equip_id"]: s for s in banco.consultar(
            "SELECT s.* FROM status s JOIN equipamentos e ON e.id = s.equip_id WHERE e.empresa_id = ?", (empresa_id,))}
        maquinas, origens_total = [], Counter()
        for e in equipamentos.listar(empresa_id, somente_ativos=True):
            st = status.get(e["id"], {})
            ativos = self.ativos(e["id"])
            for a in ativos:
                origens_total.update(dict(a["origens"]))
            if ativos:
                estado = "ataque"
            elif st.get("status") in ("erro", "aguardando", None):
                estado = st.get("status") or "aguardando"
            else:
                estado = "ok"
            maquinas.append({
                "id": e["id"], "nome": f"{st.get('hostname') or e['nome']} ({e['host']})", "apelido": e["nome"],
                "tipo_nome": e["tipo_nome"], "funcao": e["funcao_nome"], "site": e["site"], "estado": estado,
                "ataques": ativos, "erro": st.get("erro"), "cpu": st.get("cpu"), "memoria": st.get("memoria"),
                "incidente": st.get("incidente"),
            })

        # alvos de DDoS (IPs de clientes) vêm da detecção por fluxo
        alvos = []
        prefixo = f"ip:{empresa_id}:"
        with self.trava:
            chaves_ip = [c for c in self.ataques if str(c).startswith(prefixo)]
        for chave in chaves_ip:
            ativos = self.ativos(chave)
            if ativos:
                for a in ativos:
                    origens_total.update(dict(a["origens"]))
                alvos.append({"ip": chave[len(prefixo):], "ataques": ativos})

        ordem = {"ataque": 0, "erro": 1, "aguardando": 2, "ok": 3}
        maquinas.sort(key=lambda m: (ordem.get(m["estado"], 9), m["nome"].lower()))

        eventos = incidentes.eventos_recentes(empresa_id, 150)
        for ev in eventos:
            ev["hora"] = _hora(ev["ts"])
        por_minuto = [0] * 30
        for linha in banco.consultar(
                "SELECT CAST((? - ts) / 60 AS INTEGER) AS idade, COUNT(*) AS n FROM eventos "
                "WHERE empresa_id = ? AND ts > ? AND gravidade IN ('ataque', 'aviso') GROUP BY idade",
                (agora, empresa_id, agora - 1800)):
            if 0 <= linha["idade"] < 30:
                por_minuto[29 - linha["idade"]] = linha["n"]

        with self.trava:
            geral = dict(self.syslog)
            ultima = self.ultima_por_empresa.get(empresa_id)
            syslog = {"ativo": geral["ativo"], "porta": geral["porta"], "erro": geral["erro"],
                      "recebidas": self.recebidas.get(empresa_id, 0), "ultima": _hora(ultima) if ultima else None,
                      # IPs não cadastrados: só o fornecedor vê (podem ser de qualquer empresa)
                      "ignoradas": geral["ignoradas"] if fornecedor else 0,
                      "ultimo_ip_ignorado": geral["ultimo_ip_ignorado"] if fornecedor else None}
        seq = banco.um("SELECT COALESCE(MAX(id), 0) AS m FROM eventos WHERE empresa_id = ?", (empresa_id,))["m"]
        abertos = banco.um("SELECT COUNT(*) AS n FROM incidentes WHERE estado = 'aberto' AND empresa_id = ?",
                           (empresa_id,))["n"]
        return {
            "agora": _hora(agora), "seq": seq, "maquinas": maquinas, "alvos": alvos, "eventos": eventos,
            "origens": origens_total.most_common(10), "por_minuto": por_minuto, "syslog": syslog,
            "ip_local": self.ip_local, "janela_min": int(CFG["tempo_real"]["janela_ataque_min"]),
            "syslog_ligado": bool(CFG["tempo_real"]["syslog"]), "incidentes_abertos": abertos,
            "intervalo": int(CFG["monitoramento"]["intervalo_minutos"]),
        }


def descobrir_ip_local():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "IP_DESTE_SERVIDOR"


TEMPO_REAL = TempoReal()
