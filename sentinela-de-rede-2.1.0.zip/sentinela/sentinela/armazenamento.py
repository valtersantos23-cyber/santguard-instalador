"""Arquivos de backup e de evidências (pasta dados/backups), indexados no banco."""

import datetime
import difflib
import hashlib
import pathlib
import re

from . import banco, config


def raiz():
    pasta = config.pasta_dados() / "backups"
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta


def nome_seguro(texto):
    return re.sub(r"[^\w.\-]", "_", texto or "sem_nome")[:80]


def carimbo():
    return datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")


def normalizar_config(texto):
    """Remove comentários, datas e linhas vazias, para comparar só o que importa."""
    ignorar = re.compile(r"^\s*(#|!|Building configuration|Current configuration|## Last commit)")
    return [l.rstrip() for l in texto.splitlines() if l.strip() and not ignorar.match(l)]


def pasta_empresa(empresa_id):
    return f"empresa_{int(empresa_id)}"


def migrar_pastas():
    """Versões antigas (uma empresa só) guardavam tudo direto em backups/. Move para backups/empresa_1/."""
    base = raiz()
    destino = base / pasta_empresa(1)
    antigas = [d for d in base.iterdir() if d.is_dir() and not d.name.startswith(("empresa_", "_"))]
    if antigas:
        destino.mkdir(exist_ok=True)
    for d in antigas:
        alvo = destino / d.name
        if not alvo.exists():
            d.rename(alvo)
    # sempre (idempotente): se uma execução anterior parou no meio, os registros ainda são corrigidos
    prefixo = pasta_empresa(1) + "/"
    banco.executar("UPDATE backups SET arquivo = ? || arquivo WHERE arquivo NOT LIKE 'empresa_%'", (prefixo,))
    banco.executar("UPDATE incidentes SET pasta = ? || pasta WHERE pasta IS NOT NULL AND pasta NOT LIKE 'empresa_%'",
                   (prefixo,))
    banco.executar("UPDATE status SET incidente = ? || incidente WHERE incidente IS NOT NULL "
                   "AND incidente NOT LIKE 'empresa_%'", (prefixo,))
    return len(antigas)


def _dentro_da_empresa(relativo, empresa_id):
    """Resolve o caminho e garante que fica dentro da pasta da empresa (bloqueia ../ e caminhos absolutos)."""
    base = (raiz() / pasta_empresa(empresa_id)).resolve()
    alvo = (base.parent / relativo).resolve()
    return alvo if alvo.is_relative_to(base) else None


def ler(relativo, empresa_id):
    """Lê um arquivo de backup/evidência DA EMPRESA informada."""
    alvo = _dentro_da_empresa(relativo, empresa_id)
    if alvo is None or not alvo.is_file():
        return None
    return alvo.read_text(encoding="utf-8", errors="replace")


def _ler_interno(relativo):
    base = raiz().resolve()
    alvo = (base / relativo).resolve()
    if not alvo.is_file() or not alvo.is_relative_to(base):
        return None
    return alvo.read_text(encoding="utf-8", errors="replace")


def ultimo_backup(equip_id):
    return banco.um("SELECT * FROM backups WHERE equip_id = ? ORDER BY quando DESC, id DESC LIMIT 1", (equip_id,))


def salvar_backup(equip_id, hostname, host, texto, forcar=False):
    """Guarda a configuração se ela mudou (ou se forcar=True).

    Retorna {"arquivo", "mudou", "diff", "primeiro"}.
    """
    anterior = ultimo_backup(equip_id)
    texto_anterior = _ler_interno(anterior["arquivo"]) if anterior else None
    empresa = banco.um("SELECT empresa_id FROM equipamentos WHERE id = ?", (equip_id,))
    empresa_id = empresa["empresa_id"] if empresa else 0
    diff = ""
    mudou = False
    if texto_anterior is not None:
        antigo, novo = normalizar_config(texto_anterior), normalizar_config(texto)
        if antigo != novo:
            mudou = True
            diff = "\n".join(difflib.unified_diff(antigo, novo, fromfile=pathlib.Path(anterior["arquivo"]).name,
                                                  tofile="configuracao_atual", lineterm=""))

    if anterior and not mudou and not forcar:
        return {"arquivo": anterior["arquivo"], "mudou": False, "diff": "", "primeiro": False}

    pasta = raiz() / pasta_empresa(empresa_id) / nome_seguro(hostname)
    pasta.mkdir(parents=True, exist_ok=True)
    arquivo = pasta / f"{nome_seguro(hostname)}_{nome_seguro(host)}_{carimbo()}.txt"
    n = 1
    while arquivo.exists():
        n += 1
        arquivo = arquivo.with_name(f"{arquivo.stem}_{n}.txt")
    dados = texto.encode("utf-8")
    arquivo.write_bytes(dados)
    relativo = arquivo.relative_to(raiz()).as_posix()
    banco.executar(
        "INSERT INTO backups (equip_id, hostname, quando, arquivo, sha256, tamanho, mudou, empresa_id) "
        "VALUES (?, ?, datetime('now', 'localtime'), ?, ?, ?, ?, ?)",
        (equip_id, hostname, relativo, hashlib.sha256(dados).hexdigest(), len(dados), int(mudou), empresa_id))
    limpar_antigos(equip_id)
    return {"arquivo": relativo, "mudou": mudou, "diff": diff, "primeiro": anterior is None}


def limpar_antigos(equip_id):
    manter = int(config.CFG["retencao"]["backups_por_equipamento"])
    sobra = banco.consultar("SELECT id, arquivo FROM backups WHERE equip_id = ? ORDER BY quando DESC, id DESC "
                            "LIMIT -1 OFFSET ?", (equip_id, manter))
    for linha in sobra:
        try:
            (raiz() / linha["arquivo"]).unlink(missing_ok=True)
        except OSError:
            pass
        banco.executar("DELETE FROM backups WHERE id = ?", (linha["id"],))


def salvar_evidencias(empresa_id, hostname, host, alertas, config_texto, logs, falhas, diff, evidencias):
    """Grava backup + evidências do momento do ataque. Retorna a pasta relativa."""
    base = raiz() / pasta_empresa(empresa_id) / nome_seguro(hostname) / "incidentes" / carimbo()
    pasta, n = base, 1
    while pasta.exists():
        n += 1
        pasta = base.with_name(f"{base.name}_{n}")
    pasta.mkdir(parents=True)

    if config_texto:
        (pasta / "backup_config.txt").write_text(config_texto, encoding="utf-8")
    if logs:
        (pasta / "logs.txt").write_text(logs, encoding="utf-8")
    if falhas:
        (pasta / "falhas_login.txt").write_text("\n".join(falhas), encoding="utf-8")
    if diff:
        (pasta / "alteracoes_config.diff").write_text(diff, encoding="utf-8")
    if evidencias:
        partes = [f"===== {cmd} =====\n{saida}\n" for cmd, saida in evidencias.items()]
        (pasta / "evidencias.txt").write_text("\n".join(partes), encoding="utf-8")

    hashes = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(pasta.iterdir())}
    resumo = [
        "INCIDENTE DE SEGURANÇA",
        f"Equipamento: {hostname} ({host})",
        f"Capturado em: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
        "",
        "Alertas:",
        *[f"  - {a}" for a in alertas],
        "",
        "Arquivos capturados (SHA-256, para provar que não foram alterados):",
        *[f"  * {nome}  {h}" for nome, h in hashes.items()],
    ]
    (pasta / "resumo.txt").write_text("\n".join(resumo), encoding="utf-8")
    return pasta.relative_to(raiz()).as_posix()


def arquivos_da_pasta(relativo, empresa_id):
    pasta = _dentro_da_empresa(relativo, empresa_id)
    if pasta is None or not pasta.is_dir():
        return []
    base = raiz().resolve()
    return [f.relative_to(base).as_posix() for f in sorted(pasta.iterdir()) if f.is_file()]
