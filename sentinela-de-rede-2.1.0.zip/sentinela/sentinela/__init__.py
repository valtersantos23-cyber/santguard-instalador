"""Sentinela de Rede: monitoramento de segurança para provedores de internet."""

VERSAO = "2.1.0"
