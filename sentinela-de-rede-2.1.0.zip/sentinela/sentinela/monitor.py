"""Verificação periódica por SSH: backup com detecção de mudança, logs (força bruta), CPU e auditoria."""

import datetime
import json
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from . import armazenamento, banco, equipamentos, incidentes, ssh
from . import fabricantes as fab
from .config import CFG


def agora_txt():
    return datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")


def nome_exibicao(equip, hostname=None):
    st = banco.um("SELECT hostname FROM status WHERE equip_id = ?", (equip["id"],)) if not hostname else None
    return f"{hostname or (st and st['hostname']) or equip['nome']} ({equip['host']})"


def atualizar_status(equip_id, **campos):
    if "alertas" in campos and not isinstance(campos["alertas"], str):
        campos["alertas"] = json.dumps(campos["alertas"], ensure_ascii=False)
    banco.executar("INSERT OR IGNORE INTO status (equip_id) VALUES (?)", (equip_id,))
    if campos:
        atribuicoes = ", ".join(f"{c} = ?" for c in campos)
        banco.executar(f"UPDATE status SET {atribuicoes} WHERE equip_id = ?", (*campos.values(), equip_id))


def tipo_do_alerta(texto):
    if texto.startswith("Possível força bruta") or texto.startswith("Força bruta"):
        return "Força bruta"
    if texto.startswith("CPU") or texto.startswith("Memória"):
        return "DDoS/flood"
    if texto.startswith("Configuração alterada"):
        return "Configuração alterada"
    return "Alerta"


class Monitor:
    def __init__(self):
        self.falhas_vistas = {}           # equip_id -> linhas de falha de login já vistas
        self.acordar = threading.Event()
        self.operacao = threading.Lock()  # um ciclo em massa por vez
        self.trava = threading.Lock()
        self.monitorando = True       # chave geral (só o fornecedor mexe)
        self.pausadas = set()         # empresas que pausaram o próprio monitoramento
        self.forcar = False
        self.ocupado = None
        self.ultimo_ciclo = None
        self.proximo_ciclo = None
        self.ultima_captura = {}
        self.ao_alertar = []              # callbacks(equip, tipo, origens) -> tela ao vivo

    # ------------------------------------------------------------ uma verificação

    def verificar(self, equip):
        """Verifica um equipamento. Retorna dict com nome, alertas, erro, cpu, incidentes."""
        tipo = equip["tipo"]
        r = {"id": equip["id"], "nome": nome_exibicao(equip), "alertas": [], "erro": None, "cpu": None}
        try:
            with ssh.conectar(equip) as conn:
                texto_config = ssh.executar(conn, fab.COMANDOS_BACKUP[tipo], tipo)
                hostname = ssh.descobrir_hostname(conn, texto_config, tipo) or equip["nome"]
                r["nome"] = nome_exibicao(equip, hostname)
                logs = ssh.executar(conn, fab.COMANDOS_LOG[tipo], tipo)
                cpu = ssh.ler_cpu(ssh.executar(conn, fab.COMANDOS_CPU[tipo], tipo, 60), tipo)
                r["cpu"] = cpu

                alertas = []
                # 1) força bruta: falhas de login novas desde a última verificação
                falhas = [l for l in logs.splitlines() if fab.PADRAO_FALHA_LOGIN.search(l)]
                anteriores = self.falhas_vistas.get(equip["id"])
                novas = [] if anteriores is None else [l for l in falhas if l not in anteriores]
                self.falhas_vistas[equip["id"]] = set(falhas)
                if len(novas) >= int(CFG["monitoramento"]["limite_falhas_login"]):
                    ips = Counter(ip for l in novas for ip in fab.PADRAO_IP.findall(l) if ip != equip["host"])
                    origem = ", ".join(f"{ip} ({n}x)" for ip, n in ips.most_common(5))
                    alertas.append(("Força bruta",
                                    f"Possível força bruta: {len(novas)} falhas de login novas. "
                                    f"Origem: {origem or 'IP não identificado no log'}", list(ips)))
                # 2) CPU alta
                if cpu is not None and cpu >= int(CFG["monitoramento"]["limite_cpu"]):
                    alertas.append(("DDoS/flood", f"CPU em {cpu}% (possível DDoS/flood)", []))
                # 3) mudança de configuração
                backup = armazenamento.salvar_backup(equip["id"], hostname, equip["host"], texto_config)
                if backup["mudou"] and CFG["monitoramento"]["alertar_mudanca_config"]:
                    alertas.append(("Configuração alterada",
                                    "Configuração alterada (confirme se foi uma mudança autorizada)", []))

                pasta = None
                if alertas:
                    evidencias = ssh.coletar_evidencias(conn, tipo)
                    pasta = armazenamento.salvar_evidencias(
                        equip["empresa_id"], hostname, equip["host"], [a[1] for a in alertas], texto_config, logs,
                        novas, backup["diff"], evidencias)

            for tipo_alerta, texto, origens in alertas:
                incidentes.registrar_evento(equip["id"], r["nome"], tipo_alerta, "ataque", texto,
                                            ", ".join(origens), "verificação")
                incidentes.abrir(equip["id"], r["nome"], tipo_alerta, texto,
                                 detalhes=texto, severidade="media" if tipo_alerta == "Configuração alterada" else "alta",
                                 pasta=pasta)
                for funcao in self.ao_alertar:
                    funcao(equip, tipo_alerta, origens)
            r["alertas"] = [a[1] for a in alertas]
            campos = {"status": "alerta" if alertas else "ok", "hostname": hostname, "cpu": cpu,
                      "verificado": agora_txt(), "erro": None, "alertas": r["alertas"]}
            if pasta:
                campos["incidente"] = pasta
            atualizar_status(equip["id"], **campos)
        except Exception as e:
            r["erro"] = ssh.descrever_erro(e)
            atualizar_status(equip["id"], status="erro", erro=r["erro"], verificado=agora_txt(), alertas=[])
            if r["erro"].startswith("sem resposta"):
                incidentes.registrar_evento(equip["id"], r["nome"], "Sem resposta", "erro", r["erro"], "", "verificação")
        return r

    # ------------------------------------------------------------ ciclo completo

    def ciclo(self):
        lista = [e for e in equipamentos.listar(equipamentos.TODAS, segredos=True, somente_ativos=True)
                 if e["empresa_id"] not in self.pausadas]
        if not lista:
            return []
        with ThreadPoolExecutor(max_workers=int(CFG["monitoramento"]["conexoes_simultaneas"])) as pool:
            resultados = list(pool.map(self.verificar, lista))
        self.ultimo_ciclo = agora_txt()
        return resultados

    def laco(self):
        while True:
            with self.trava:
                rodar = self.monitorando or self.forcar
                self.forcar = False
            if rodar:
                with self.operacao:
                    self.ocupado = "Verificando equipamentos..."
                    try:
                        self.ciclo()
                        incidentes.limpar_eventos_antigos()
                    except Exception as e:
                        incidentes.registrar_evento(None, "Sentinela", "Erro interno", "erro",
                                                    f"Erro no ciclo de verificação: {e}", fonte="sistema")
                    finally:
                        self.ocupado = None
            intervalo = int(CFG["monitoramento"]["intervalo_minutos"]) * 60
            self.proximo_ciclo = (datetime.datetime.now() + datetime.timedelta(seconds=intervalo)).strftime(
                "%H:%M:%S") if self.monitorando else None
            self.acordar.wait(intervalo)
            self.acordar.clear()

    def iniciar(self):
        threading.Thread(target=self.laco, name="monitor", daemon=True).start()

    def verificar_agora(self):
        with self.trava:
            self.forcar = True
        self.acordar.set()

    def pausar(self, empresa_id=None):
        """Sem empresa: pausa a plataforma inteira (fornecedor). Com empresa: só os equipamentos dela."""
        if empresa_id is None:
            self.monitorando = False
            self.proximo_ciclo = None
        else:
            self.pausadas.add(int(empresa_id))

    def retomar(self, empresa_id=None):
        if empresa_id is None:
            self.monitorando = True
        else:
            self.pausadas.discard(int(empresa_id))
        self.acordar.set()

    def monitorando_empresa(self, empresa_id):
        return self.monitorando and int(empresa_id) not in self.pausadas

    # ------------------------------------------------------------ backup + auditoria

    def backup_e_auditoria(self, empresa_id):
        """Backup forçado dos equipamentos DA EMPRESA + auditoria de segurança. Guarda o resultado no banco."""
        lista = equipamentos.listar(empresa_id, segredos=True, somente_ativos=True)

        def um(equip):
            try:
                with ssh.conectar(equip) as conn:
                    texto = ssh.executar(conn, fab.COMANDOS_BACKUP[equip["tipo"]], equip["tipo"])
                    hostname = ssh.descobrir_hostname(conn, texto, equip["tipo"]) or equip["nome"]
                armazenamento.salvar_backup(equip["id"], hostname, equip["host"], texto, forcar=True)
                atualizar_status(equip["id"], hostname=hostname)
                return {"id": equip["id"], "nome": f"{hostname} ({equip['host']})", "ok": True,
                        "erro": None, "problemas": ssh.auditar(texto, equip["tipo"])}
            except Exception as e:
                return {"id": equip["id"], "nome": nome_exibicao(equip), "ok": False,
                        "erro": ssh.descrever_erro(e), "problemas": []}

        with self.operacao:
            self.ocupado = "Fazendo backup e auditoria..."
            try:
                with ThreadPoolExecutor(max_workers=int(CFG["monitoramento"]["conexoes_simultaneas"])) as pool:
                    resultados = list(pool.map(um, lista))
            finally:
                self.ocupado = None
        relatorio = {"quando": agora_txt(), "resultados": resultados}
        banco.gravar_config_empresa(empresa_id, "ultima_auditoria", json.dumps(relatorio, ensure_ascii=False))
        return relatorio

    # ------------------------------------------------------------ captura imediata (tempo real)

    def capturar_agora(self, equip_id, alertas, tipo_incidente, incidente_id=None):
        """Conecta no equipamento atacado e guarda backup + evidências (no máximo 1x a cada N minutos)."""
        intervalo = int(CFG["tempo_real"]["intervalo_captura_min"]) * 60
        with self.trava:
            if time.time() - self.ultima_captura.get(equip_id, 0) < intervalo:
                return False
            self.ultima_captura[equip_id] = time.time()

        def tarefa():
            equip = equipamentos.obter(equip_id, equipamentos.TODAS, segredos=True)
            if not equip:
                return
            tipo = equip["tipo"]
            try:
                with ssh.conectar(equip) as conn:
                    texto = ssh.executar(conn, fab.COMANDOS_BACKUP[tipo], tipo)
                    hostname = ssh.descobrir_hostname(conn, texto, tipo) or equip["nome"]
                    logs = ssh.executar(conn, fab.COMANDOS_LOG[tipo], tipo)
                    evidencias = ssh.coletar_evidencias(conn, tipo)
                falhas = [l for l in logs.splitlines() if fab.PADRAO_FALHA_LOGIN.search(l)][-200:]
                pasta = armazenamento.salvar_evidencias(equip["empresa_id"], hostname, equip["host"], alertas, texto,
                                                        logs, falhas, "", evidencias)
                if incidente_id:
                    incidentes.anexar_pasta(incidente_id, pasta)
                atualizar_status(equip_id, status="alerta", hostname=hostname, incidente=pasta,
                                 alertas=alertas, verificado=agora_txt(), erro=None)
                incidentes.registrar_evento(equip_id, f"{hostname} ({equip['host']})", "Evidências capturadas",
                                            "info", f"Backup e evidências salvos em {pasta}", fonte="captura")
            except Exception as e:
                incidentes.registrar_evento(equip_id, nome_exibicao(equip), "Falha na captura", "erro",
                                            f"Não consegui capturar evidências: {ssh.descrever_erro(e)}",
                                            fonte="captura")

        threading.Thread(target=tarefa, name="captura", daemon=True).start()
        return True

    # ------------------------------------------------------------ teste de conexão

    @staticmethod
    def testar(equip):
        try:
            with ssh.conectar(equip) as conn:
                texto = ssh.executar(conn, fab.COMANDOS_BACKUP[equip["tipo"]], equip["tipo"])
                hostname = ssh.descobrir_hostname(conn, texto, equip["tipo"])
            return True, f"Conexão OK! Hostname: {hostname or 'não identificado'}", hostname
        except Exception as e:
            return False, f"Falha na conexão: {ssh.descrever_erro(e)}", None


MONITOR = Monitor()
