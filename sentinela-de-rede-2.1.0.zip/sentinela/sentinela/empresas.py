"""Empresas (provedores clientes) e licenças.

Cada provedor cliente é uma empresa. Usuários, equipamentos, incidentes, alertas, mitigações e
relatórios pertencem a uma empresa e nunca são vistos por outra. O "fornecedor" (quem opera a
plataforma) cadastra as empresas e define a licença: limite de equipamentos e validade.
"""

import datetime
import ipaddress
import json

from . import banco, licenca
from .config import CFG

CAMPOS = ("nome", "documento", "contato", "email", "telefone", "plano", "limite_equipamentos", "validade",
          "ativo", "asn", "redes", "prefixos", "observacoes")


def _normalizar(linha):
    if not linha:
        return None
    e = dict(linha)
    e["redes"] = json.loads(e["redes"] or "[]")
    e["prefixos"] = json.loads(e["prefixos"] or "[]")
    e["ativo"] = bool(e["ativo"])
    e["situacao"], e["situacao_texto"] = situacao(e)
    return e


def situacao(e):
    """Retorna (codigo, texto): ok | suspensa | vencida."""
    if not e["ativo"]:
        return "suspensa", "Empresa suspensa pelo fornecedor"
    if e.get("validade"):
        try:
            validade = datetime.date.fromisoformat(e["validade"])
        except ValueError:
            return "ok", ""
        if validade < datetime.date.today():
            return "vencida", f"Licença vencida em {validade.strftime('%d/%m/%Y')}"
        dias = (validade - datetime.date.today()).days
        if dias <= 15:
            return "ok", f"Licença vence em {dias} dia(s)"
    return "ok", ""


def obter(empresa_id):
    if empresa_id is None:
        return None
    return _normalizar(banco.um("SELECT * FROM empresas WHERE id = ?", (empresa_id,)))


def listar():
    lista = [_normalizar(l) for l in banco.consultar("SELECT * FROM empresas ORDER BY lower(nome)")]
    contagem = {l["empresa_id"]: l for l in banco.consultar(
        "SELECT empresa_id, COUNT(*) AS equipamentos FROM equipamentos GROUP BY empresa_id")}
    usuarios = {l["empresa_id"]: l["n"] for l in banco.consultar(
        "SELECT empresa_id, COUNT(*) AS n FROM usuarios WHERE fornecedor = 0 GROUP BY empresa_id")}
    abertos = {l["empresa_id"]: l["n"] for l in banco.consultar(
        "SELECT empresa_id, COUNT(*) AS n FROM incidentes WHERE estado != 'resolvido' GROUP BY empresa_id")}
    for e in lista:
        e["equipamentos"] = contagem.get(e["id"], {}).get("equipamentos", 0)
        e["usuarios"] = usuarios.get(e["id"], 0)
        e["incidentes_abertos"] = abertos.get(e["id"], 0)
    return lista


def ids_ativos():
    """Empresas cujo monitoramento deve rodar (não suspensas e com licença válida).

    Sem licença válida da INSTALAÇÃO nenhuma empresa é monitorada."""
    if not licenca.valida():
        return set()
    return {e["id"] for e in (_normalizar(l) for l in banco.consultar("SELECT * FROM empresas")) if e["situacao"] == "ok"}


def validar(dados, atual=None):
    g = lambda k: str(dados.get(k) if dados.get(k) is not None else "").strip()
    nome = g("nome")
    if not nome:
        return None, "Informe o nome da empresa"
    try:
        limite = int(g("limite_equipamentos") or 0)
        asn = int(g("asn") or 0)
    except ValueError:
        return None, "Limite de equipamentos e ASN devem ser números"
    if limite < 0 or not 0 <= asn <= 4294967295:
        return None, "Limite ou ASN inválido"
    validade = g("validade") or None
    if validade:
        try:
            datetime.date.fromisoformat(validade)
        except ValueError:
            return None, "Validade inválida (use AAAA-MM-DD)"

    def lista_redes(chave):
        bruto = dados.get(chave) or []
        if isinstance(bruto, str):
            bruto = [x for x in bruto.replace(",", "\n").split() if x.strip()]
        redes = []
        for item in bruto:
            try:
                redes.append(str(ipaddress.ip_network(str(item).strip(), strict=False)))
            except ValueError:
                raise ValueError(f"Rede inválida: {item}")
        return redes

    try:
        redes, prefixos = lista_redes("redes"), lista_redes("prefixos")
    except ValueError as e:
        return None, str(e)
    # uma rede só pode ter UMA dona: senão um provedor poderia pedir RTBH/bloqueio nos IPs de outro
    proprias = [ipaddress.ip_network(r) for r in redes + prefixos]
    for outra in banco.consultar("SELECT id, nome, redes, prefixos FROM empresas WHERE id != ?",
                                 ((atual or {}).get("id", 0),)):
        for texto in json.loads(outra["redes"] or "[]") + json.loads(outra["prefixos"] or "[]"):
            try:
                rede = ipaddress.ip_network(texto)
            except ValueError:
                continue
            for minha in proprias:
                if minha.version == rede.version and minha.overlaps(rede):
                    return None, f"A rede {minha} já pertence a outra empresa deste servidor"
    duplicada = banco.um("SELECT id FROM empresas WHERE nome = ? AND id != ?", (nome, (atual or {}).get("id", 0)))
    if duplicada:
        return None, "Já existe uma empresa com esse nome"
    return {
        "nome": nome, "documento": g("documento"), "contato": g("contato"), "email": g("email"),
        "telefone": g("telefone"), "plano": g("plano"), "limite_equipamentos": limite, "validade": validade,
        "ativo": 1 if dados.get("ativo", True) else 0, "asn": asn, "redes": json.dumps(redes),
        "prefixos": json.dumps(prefixos), "observacoes": g("observacoes"),
    }, None


def salvar(dados, empresa_id=None):
    atual = obter(empresa_id) if empresa_id else None
    if empresa_id and not atual:
        return None, "Empresa não encontrada"
    if not atual:
        limite = licenca.limite_empresas()
        if limite and banco.um("SELECT COUNT(*) AS n FROM empresas")["n"] >= limite:
            return None, f"Limite da licença do sistema atingido ({limite} empresa(s)). Fale com o fornecedor."
    if atual:  # edição parcial: o que não veio continua como está
        dados = {**{k: atual[k] for k in CAMPOS}, **{k: v for k, v in dados.items() if k in CAMPOS}}
    campos, erro = validar(dados, atual)
    if erro:
        return None, erro
    if atual:
        banco.executar(f"UPDATE empresas SET {', '.join(f'{c} = ?' for c in campos)} WHERE id = ?",
                       (*campos.values(), empresa_id))
        return empresa_id, None
    novo = banco.executar(f"INSERT INTO empresas ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})",
                          tuple(campos.values()))
    return novo, None


def salvar_rede(empresa_id, dados):
    """O administrador da empresa ajusta o próprio ASN e redes (sem mexer na licença)."""
    atual = obter(empresa_id)
    if not atual:
        return "Empresa não encontrada"
    mistura = dict(atual, asn=dados.get("asn", atual["asn"]), redes=dados.get("redes", atual["redes"]),
                   prefixos=dados.get("prefixos", atual["prefixos"]))
    campos, erro = validar(mistura, atual)
    if erro:
        return erro
    banco.executar("UPDATE empresas SET asn = ?, redes = ?, prefixos = ? WHERE id = ?",
                   (campos["asn"], campos["redes"], campos["prefixos"], empresa_id))
    return None


def remover(empresa_id):
    """Apaga a empresa e TODOS os dados dela (usuários, equipamentos, histórico)."""
    if empresa_id == 1 and banco.um("SELECT COUNT(*) AS n FROM empresas")["n"] == 1:
        return False
    with banco.transacao() as con:
        for tabela in ("incidentes", "eventos", "ddos", "manutencoes", "envios", "mitigacoes", "backups", "auditoria"):
            con.execute(f"DELETE FROM {tabela} WHERE empresa_id = ?", (empresa_id,))
        con.execute("DELETE FROM configuracoes WHERE chave LIKE ?", (f"e{int(empresa_id)}:%",))
        apagou = con.execute("DELETE FROM empresas WHERE id = ?", (empresa_id,)).rowcount
    if apagou:
        import shutil
        from . import armazenamento
        shutil.rmtree(armazenamento.raiz() / armazenamento.pasta_empresa(empresa_id), ignore_errors=True)
    return apagou > 0


def pode_cadastrar_equipamento(empresa_id):
    e = obter(empresa_id)
    if not e:
        return "Empresa não encontrada"
    if e["situacao"] != "ok":
        return e["situacao_texto"]
    lic = licenca.estado()
    if not lic["valida"]:
        return lic["texto"]
    if lic["limite_equipamentos"]:
        total = banco.um("SELECT COUNT(*) AS n FROM equipamentos")["n"]
        if total >= lic["limite_equipamentos"]:
            return (f"Limite da licença do sistema atingido ({lic['limite_equipamentos']} equipamentos). "
                    "Fale com o fornecedor.")
    if e["limite_equipamentos"]:
        n = banco.um("SELECT COUNT(*) AS n FROM equipamentos WHERE empresa_id = ?", (empresa_id,))["n"]
        if n >= e["limite_equipamentos"]:
            return f"Limite da licença atingido ({e['limite_equipamentos']} equipamentos). Fale com o fornecedor."
    return None


# ---------------------------------------------------------------- dados de rede da empresa

# O config.toml ([fluxo] redes_proprias, [bgp] asn/prefixos) vale SÓ para a empresa 1 (instalações antigas,
# de uma empresa só). Nunca para as outras: senão um provedor "herdaria" as redes de outro e poderia
# pedir RTBH/bloqueio nos IPs dele.

def redes(empresa_id):
    """Blocos de IP da empresa."""
    e = obter(empresa_id)
    if e and e["redes"]:
        return e["redes"]
    return list(CFG["fluxo"]["redes_proprias"] or []) if e and e["id"] == 1 else []


def asn(empresa_id):
    e = obter(empresa_id)
    if e and e["asn"]:
        return e["asn"]
    return int(CFG["bgp"]["asn"] or 0) if e and e["id"] == 1 else 0


def prefixos(empresa_id):
    e = obter(empresa_id)
    if e and e["prefixos"]:
        return e["prefixos"]
    if e and e["id"] == 1 and CFG["bgp"]["prefixos"]:
        return list(CFG["bgp"]["prefixos"])
    return redes(empresa_id)


def empresa_do_ip(ip):
    """Qual empresa é dona do IP (pelas redes cadastradas). Retorna o id ou None."""
    try:
        endereco = ipaddress.ip_address(ip)
    except ValueError:
        return None
    melhor, melhor_tamanho = None, -1
    for e in banco.consultar("SELECT id, redes FROM empresas"):
        for rede in json.loads(e["redes"] or "[]"):
            r = ipaddress.ip_network(rede, strict=False)
            if endereco.version == r.version and endereco in r and r.prefixlen > melhor_tamanho:
                melhor, melhor_tamanho = e["id"], r.prefixlen
    return melhor
