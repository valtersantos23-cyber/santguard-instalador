"""Cliente SNMP (v2c e v3 com autenticação SHA-1 e criptografia AES-128), sem dependências externas.

Implementa o necessário para monitoramento: GET e GETBULK (walk).
  - SNMPv2c: RFC 1905 / 3416
  - SNMPv3 USM: RFC 3414 (autenticação HMAC-SHA-96) e RFC 3826 (AES-128-CFB)
"""

import hashlib
import hmac
import os
import random
import socket
import struct
import time

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms

try:  # CFB foi movido para 'decrepit' nas versões novas da biblioteca
    from cryptography.hazmat.decrepit.ciphers.modes import CFB
except ImportError:  # versões antigas
    from cryptography.hazmat.primitives.ciphers.modes import CFB


class ErroSnmp(Exception):
    pass


# ======================================================================= BER (codificação ASN.1)

def _comprimento(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def tlv(tag, valor):
    return bytes([tag]) + _comprimento(len(valor)) + valor


def inteiro(n, tag=0x02):
    tam = max(1, (n.bit_length() + 8) // 8)
    return tlv(tag, n.to_bytes(tam, "big", signed=True))


def texto(b):
    return tlv(0x04, b if isinstance(b, bytes) else b.encode())


def nulo():
    return b"\x05\x00"


def oid(texto_oid):
    partes = [int(p) for p in texto_oid.strip(".").split(".")]
    corpo = bytes([partes[0] * 40 + partes[1]])
    for p in partes[2:]:
        grupo = [p & 0x7F]
        p >>= 7
        while p:
            grupo.insert(0, 0x80 | (p & 0x7F))
            p >>= 7
        corpo += bytes(grupo)
    return tlv(0x06, corpo)


def sequencia(*itens, tag=0x30):
    return tlv(tag, b"".join(itens))


def ler_tlv(dados, pos=0):
    tag = dados[pos]
    tam = dados[pos + 1]
    pos += 2
    if tam & 0x80:
        n = tam & 0x7F
        tam = int.from_bytes(dados[pos:pos + n], "big")
        pos += n
    return tag, dados[pos:pos + tam], pos + tam


def ler_sequencia(dados):
    itens, pos = [], 0
    while pos < len(dados):
        tag, valor, pos = ler_tlv(dados, pos)
        itens.append((tag, valor))
    return itens


def oid_para_texto(b):
    partes = [b[0] // 40, b[0] % 40]
    n = 0
    for byte in b[1:]:
        n = (n << 7) | (byte & 0x7F)
        if not byte & 0x80:
            partes.append(n)
            n = 0
    return ".".join(map(str, partes))


FIM = object()  # noSuchObject / noSuchInstance / endOfMibView


def valor_python(tag, valor):
    if tag in (0x02,):
        return int.from_bytes(valor, "big", signed=True)
    if tag in (0x41, 0x42, 0x43, 0x46, 0x47):  # Counter32, Gauge32, TimeTicks, Counter64, UInteger32
        return int.from_bytes(valor, "big", signed=False)
    if tag == 0x04:
        try:
            return valor.decode("utf-8")
        except UnicodeDecodeError:
            return valor.hex(":")
    if tag == 0x06:
        return oid_para_texto(valor)
    if tag == 0x40:
        return ".".join(str(b) for b in valor)
    if tag in (0x80, 0x81, 0x82):
        return FIM
    if tag == 0x05:
        return None
    return valor


# ======================================================================= PDU

GET, GETNEXT, RESPOSTA, GETBULK, REPORT = 0xA0, 0xA1, 0xA2, 0xA5, 0xA8


def montar_pdu(tipo, id_req, oids, nao_repetir=0, max_repeticoes=0):
    varbinds = sequencia(*[sequencia(oid(o), nulo()) for o in oids])
    if tipo == GETBULK:
        return sequencia(inteiro(id_req), inteiro(nao_repetir), inteiro(max_repeticoes), varbinds, tag=tipo)
    return sequencia(inteiro(id_req), inteiro(0), inteiro(0), varbinds, tag=tipo)


def ler_pdu(dados_pdu):
    """Retorna (tipo, id_req, erro_status, erro_indice, [(oid, valor)])."""
    tag, corpo, _ = ler_tlv(dados_pdu)
    campos = ler_sequencia(corpo)
    id_req = valor_python(*campos[0])
    erro_status = valor_python(*campos[1])
    erro_indice = valor_python(*campos[2])
    varbinds = []
    for _, vb in ler_sequencia(campos[3][1]):
        (t_oid, v_oid), (t_val, v_val) = ler_sequencia(vb)
        varbinds.append((oid_para_texto(v_oid), valor_python(t_val, v_val)))
    return tag, id_req, erro_status, erro_indice, varbinds


ERROS_PDU = {1: "resposta grande demais", 2: "OID não existe", 3: "valor inválido", 5: "erro genérico",
             6: "acesso negado", 16: "falha de autorização"}

# ======================================================================= USM (SNMPv3)

USM_ERROS = {
    "1.3.6.1.6.3.15.1.1.1.0": "nível de segurança não suportado pelo equipamento",
    "1.3.6.1.6.3.15.1.1.2.0": "fora da janela de tempo",
    "1.3.6.1.6.3.15.1.1.3.0": "usuário SNMPv3 desconhecido no equipamento",
    "1.3.6.1.6.3.15.1.1.4.0": "engine ID desconhecido",
    "1.3.6.1.6.3.15.1.1.5.0": "senha de autenticação SNMPv3 incorreta",
    "1.3.6.1.6.3.15.1.1.6.0": "senha de privacidade SNMPv3 incorreta",
}


def chave_localizada(senha, engine_id, algoritmo=hashlib.sha1):
    """RFC 3414 A.2: expande a senha para 1 MB, faz o hash e localiza com o engine ID."""
    senha = senha.encode() if isinstance(senha, str) else senha
    repeticoes = (1048576 // len(senha)) + 1
    ku = algoritmo((senha * repeticoes)[:1048576]).digest()
    return algoritmo(ku + engine_id + ku).digest()


class ClienteSnmp:
    def __init__(self, host, porta=161, versao="2c", community=None, usuario=None,
                 senha_auth=None, senha_priv=None, timeout=2.0, tentativas=2):
        self.host, self.porta, self.versao = host, int(porta), versao
        self.community = (community or "").encode()
        self.usuario = (usuario or "").encode()
        self.senha_auth, self.senha_priv = senha_auth, senha_priv
        self.timeout, self.tentativas = timeout, tentativas
        self.engine_id = None
        self.boots = self.engine_time = 0
        self.descoberto_em = 0
        self.k_auth = self.k_priv = None
        self._id = random.randint(1, 2 ** 30)

    def _proximo_id(self):
        self._id = (self._id + 1) % 2 ** 31
        return self._id

    def _enviar(self, mensagem, id_esperado=None):
        destino = socket.getaddrinfo(self.host, self.porta, type=socket.SOCK_DGRAM)[0]
        with socket.socket(destino[0], socket.SOCK_DGRAM) as s:
            s.settimeout(self.timeout)
            for _ in range(self.tentativas):
                s.sendto(mensagem, destino[4])
                fim = time.time() + self.timeout
                try:
                    while time.time() < fim:
                        resposta, _ = s.recvfrom(65535)
                        return resposta
                except socket.timeout:
                    continue
        raise ErroSnmp("sem resposta SNMP (IP/porta, community/usuário ou ACL de SNMP no equipamento)")

    # ------------------------------------------------------------ v2c

    def _pedido_v2c(self, pdu_bytes):
        mensagem = sequencia(inteiro(1), texto(self.community), pdu_bytes)
        resposta = self._enviar(mensagem)
        campos = ler_sequencia(ler_tlv(resposta)[1])
        return ler_pdu(tlv(campos[2][0], campos[2][1]))

    # ------------------------------------------------------------ v3

    def _descobrir(self):
        id_msg = self._proximo_id()
        params = sequencia(texto(b""), inteiro(0), inteiro(0), texto(b""), texto(b""), texto(b""))
        scoped = sequencia(texto(b""), texto(b""), montar_pdu(GET, self._proximo_id(), []))
        mensagem = sequencia(inteiro(3), sequencia(inteiro(id_msg), inteiro(65507), texto(b"\x04"), inteiro(3)),
                             texto(params), scoped)
        resposta = self._enviar(mensagem)
        self._ler_parametros_seguranca(resposta)
        if not self.engine_id:
            raise ErroSnmp("o equipamento não informou o engine ID (SNMPv3 habilitado?)")
        self.k_auth = chave_localizada(self.senha_auth, self.engine_id) if self.senha_auth else None
        self.k_priv = chave_localizada(self.senha_priv, self.engine_id)[:16] if self.senha_priv else None

    def _ler_parametros_seguranca(self, resposta):
        campos = ler_sequencia(ler_tlv(resposta)[1])
        seg = ler_sequencia(ler_tlv(campos[2][1])[1])
        self.engine_id = seg[0][1]
        self.boots = valor_python(*seg[1])
        self.engine_time = valor_python(*seg[2])
        self.descoberto_em = time.time()
        return campos, seg

    def _pedido_v3(self, pdu_bytes, segunda_tentativa=False):
        if self.engine_id is None or time.time() - self.descoberto_em > 120:
            self._descobrir()
        tempo = self.engine_time + int(time.time() - self.descoberto_em)
        flags = (0x01 if self.k_auth else 0) | (0x02 if self.k_priv else 0) | 0x04
        scoped = sequencia(texto(self.engine_id), texto(b""), pdu_bytes)
        sal = b""
        if self.k_priv:
            sal = os.urandom(8)
            iv = struct.pack(">II", self.boots, tempo) + sal
            cifra = Cipher(algorithms.AES(self.k_priv), CFB(iv)).encryptor()
            dados_scoped = texto(cifra.update(scoped) + cifra.finalize())
        else:
            dados_scoped = scoped
        marcador = b"\x00" * 12 if self.k_auth else b""

        def montar(auth_params):
            params = sequencia(texto(self.engine_id), inteiro(self.boots), inteiro(tempo), texto(self.usuario),
                               texto(auth_params), texto(sal))
            return sequencia(inteiro(3), sequencia(inteiro(self._id_msg), inteiro(65507), texto(bytes([flags])),
                                                   inteiro(3)), texto(params), dados_scoped)

        self._id_msg = self._proximo_id()
        mensagem = montar(marcador)
        if self.k_auth:
            assinatura = hmac.new(self.k_auth, mensagem, hashlib.sha1).digest()[:12]
            mensagem = montar(assinatura)

        resposta = self._enviar(mensagem)
        campos, seg = self._ler_parametros_seguranca(resposta)
        flags_resp = ler_sequencia(campos[1][1])[2][1][0]

        if self.k_auth and flags_resp & 0x01:
            recebida = seg[4][1]
            zerada = resposta.replace(recebida, b"\x00" * 12, 1)
            if not hmac.compare_digest(hmac.new(self.k_auth, zerada, hashlib.sha1).digest()[:12], recebida):
                raise ErroSnmp("resposta SNMPv3 com assinatura inválida")
        corpo = campos[3]
        if flags_resp & 0x02:
            iv = struct.pack(">II", self.boots, self.engine_time) + seg[5][1]
            decifra = Cipher(algorithms.AES(self.k_priv), CFB(iv)).decryptor()
            claro = decifra.update(corpo[1]) + decifra.finalize()
            corpo = ler_tlv(claro)[:2]
        partes = ler_sequencia(corpo[1])
        resultado = ler_pdu(tlv(partes[2][0], partes[2][1]))
        if resultado[0] == REPORT:
            oid_relatorio = resultado[4][0][0] if resultado[4] else ""
            if oid_relatorio == "1.3.6.1.6.3.15.1.1.2.0" and not segunda_tentativa:
                return self._pedido_v3(pdu_bytes, segunda_tentativa=True)
            raise ErroSnmp(USM_ERROS.get(oid_relatorio, f"erro SNMPv3 ({oid_relatorio})"))
        return resultado

    # ------------------------------------------------------------ operações

    def _pedido(self, pdu_bytes):
        resultado = self._pedido_v3(pdu_bytes) if self.versao == "3" else self._pedido_v2c(pdu_bytes)
        _, _, erro_status, _, varbinds = resultado
        if erro_status:
            raise ErroSnmp(ERROS_PDU.get(erro_status, f"erro SNMP {erro_status}"))
        return varbinds

    def get(self, *oids):
        varbinds = self._pedido(montar_pdu(GET, self._proximo_id(), oids))
        return {o: v for o, v in varbinds if v is not FIM}

    def walk(self, base, maximo=5000):
        base = base.strip(".")
        resultado, atual = [], base
        while len(resultado) < maximo:
            varbinds = self._pedido(montar_pdu(GETBULK, self._proximo_id(), [atual], 0, 25))
            if not varbinds:
                break
            continuar = True
            for o, v in varbinds:
                if v is FIM or not o.startswith(base + "."):
                    continuar = False
                    break
                resultado.append((o, v))
                atual = o
            if not continuar:
                break
        return resultado


def cliente_do_equipamento(equip, timeout=2.0):
    if equip.get("snmp_versao") == "3":
        return ClienteSnmp(equip["host"], equip.get("snmp_porta") or 161, "3", usuario=equip.get("snmp_v3_usuario"),
                           senha_auth=equip.get("snmp_v3_auth"), senha_priv=equip.get("snmp_v3_priv"), timeout=timeout)
    return ClienteSnmp(equip["host"], equip.get("snmp_porta") or 161, "2c", community=equip.get("snmp_community"),
                       timeout=timeout)
