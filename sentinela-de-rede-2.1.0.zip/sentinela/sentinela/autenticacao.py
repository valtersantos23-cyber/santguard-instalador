"""Usuários, senhas, sessões, 2FA (TOTP), bloqueio por tentativas e auditoria."""

import base64
import hashlib
import hmac
import secrets
import struct
import threading
import time
import urllib.parse

from . import banco, cofre
from .config import CFG

# O que cada perfil pode fazer
PERMISSOES = {
    "leitura": {"ver"},
    "operador": {"ver", "operar"},                    # verificar, backup, reconhecer incidentes, mitigar
    "admin": {"ver", "operar", "administrar"},        # equipamentos, usuários, configurações
}
NOMES_PAPEIS = {"admin": "Administrador", "operador": "Operador (NOC)", "leitura": "Somente leitura"}
NOME_FORNECEDOR = "Fornecedor (todas as empresas)"

SENHAS_COMUNS = {
    "123456", "12345678", "123456789", "1234567890", "senha", "senha123", "password", "admin",
    "admin123", "qwerty", "abc123", "mudar123", "provedor", "internet", "mikrotik", "cisco",
}


# ---------------------------------------------------------------- senhas

def gerar_hash(senha):
    sal = secrets.token_bytes(16)
    n, r, p = 2 ** 14, 8, 1
    derivada = hashlib.scrypt(senha.encode("utf-8"), salt=sal, n=n, r=r, p=p, dklen=32)
    return "scrypt${}${}${}${}${}".format(
        n, r, p, base64.b64encode(sal).decode(), base64.b64encode(derivada).decode())


def conferir_hash(senha, armazenado):
    try:
        _, n, r, p, sal, derivada = armazenado.split("$")
        calculada = hashlib.scrypt(senha.encode("utf-8"), salt=base64.b64decode(sal),
                                   n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(calculada, base64.b64decode(derivada))
    except (ValueError, TypeError):
        return False


# Hash "falso" usado quando o usuário não existe, para o tempo de resposta não revelar isso
_HASH_FALSO = gerar_hash(secrets.token_hex(8))


def problema_na_senha(senha, usuario=""):
    """Retorna a mensagem de erro, ou None se a senha for aceitável."""
    minimo = int(CFG["seguranca"]["senha_minima"])
    if len(senha) < minimo:
        return f"A senha precisa ter pelo menos {minimo} caracteres"
    if senha.lower() in SENHAS_COMUNS or (usuario and usuario.lower() in senha.lower()):
        return "Senha fácil demais: não use senhas comuns nem o nome de usuário"
    tipos = sum([any(c.islower() for c in senha), any(c.isupper() for c in senha),
                 any(c.isdigit() for c in senha), any(not c.isalnum() for c in senha)])
    if tipos < 3:
        return "Use pelo menos 3 destes: minúsculas, maiúsculas, números e símbolos"
    return None


# ---------------------------------------------------------------- usuários

def contar_usuarios():
    return banco.um("SELECT COUNT(*) AS n FROM usuarios")["n"]


def criar_usuario(usuario, senha, papel, nome="", email="", telefone="", trocar_senha=False, empresa_id=None,
                  fornecedor=False):
    """Cria um usuário de uma empresa, ou um usuário do fornecedor (fornecedor=True, sem empresa)."""
    if fornecedor:
        empresa_id, papel = None, "admin"
    elif empresa_id is None:
        raise ValueError("Informe a empresa do usuário")
    usuario = usuario.strip()
    if not usuario or not usuario.replace(".", "").replace("_", "").replace("-", "").isalnum():
        raise ValueError("Usuário inválido: use letras, números, ponto, hífen ou sublinhado")
    if papel not in PERMISSOES:
        raise ValueError("Perfil inválido")
    erro = problema_na_senha(senha, usuario)
    if erro:
        raise ValueError(erro)
    if banco.um("SELECT id FROM usuarios WHERE usuario = ?", (usuario,)):
        raise ValueError("Já existe um usuário com esse nome")
    return banco.executar(
        "INSERT INTO usuarios (usuario, nome, email, telefone, senha_hash, papel, trocar_senha, empresa_id, fornecedor) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (usuario, nome.strip(), email.strip(), telefone.strip(), gerar_hash(senha), papel, int(trocar_senha),
         None if empresa_id is None else int(empresa_id), int(bool(fornecedor))))


def obter_usuario(usuario_id):
    return banco.um("SELECT * FROM usuarios WHERE id = ?", (usuario_id,))


def usuario_publico(u):
    return {
        "id": u["id"], "usuario": u["usuario"], "nome": u["nome"], "email": u["email"],
        "telefone": u["telefone"], "papel": u["papel"], "papel_nome": NOMES_PAPEIS[u["papel"]],
        "totp_ativo": bool(u["totp_ativo"]), "ativo": bool(u["ativo"]),
        "trocar_senha": bool(u["trocar_senha"]), "criado": u["criado"], "ultimo_login": u["ultimo_login"],
        "empresa_id": u["empresa_id"], "fornecedor": bool(u["fornecedor"]),
    }


def definir_senha(usuario_id, senha, trocar_no_proximo_login=False):
    u = obter_usuario(usuario_id)
    erro = problema_na_senha(senha, u["usuario"] if u else "")
    if erro:
        raise ValueError(erro)
    banco.executar("UPDATE usuarios SET senha_hash = ?, trocar_senha = ? WHERE id = ?",
                   (gerar_hash(senha), int(trocar_no_proximo_login), usuario_id))
    encerrar_sessoes_do_usuario(usuario_id)


def contar_admins_ativos(empresa_id, exceto_id=None):
    return banco.um("SELECT COUNT(*) AS n FROM usuarios WHERE papel = 'admin' AND ativo = 1 AND fornecedor = 0 "
                    "AND empresa_id = ? AND id != ?", (empresa_id, exceto_id or 0))["n"]


def contar_fornecedores_ativos(exceto_id=None):
    return banco.um("SELECT COUNT(*) AS n FROM usuarios WHERE fornecedor = 1 AND ativo = 1 AND id != ?",
                    (exceto_id or 0,))["n"]


# ---------------------------------------------------------------- bloqueio por tentativas

def segundos_bloqueado(chave):
    linha = banco.um("SELECT bloqueado_ate FROM tentativas_login WHERE chave = ?", (chave,))
    restante = (linha["bloqueado_ate"] - time.time()) if linha else 0
    return int(restante) + 1 if restante > 0 else 0


def registrar_falha(chave):
    agora = time.time()
    maximo = int(CFG["seguranca"]["max_tentativas"])
    bloqueio = int(CFG["seguranca"]["bloqueio_minutos"]) * 60
    with banco.transacao() as con:
        linha = con.execute("SELECT falhas, ultima FROM tentativas_login WHERE chave = ?", (chave,)).fetchone()
        falhas = 1 if not linha or agora - linha["ultima"] > bloqueio else linha["falhas"] + 1
        bloqueado_ate = agora + bloqueio if falhas >= maximo else 0
        con.execute(
            "INSERT INTO tentativas_login (chave, falhas, bloqueado_ate, ultima) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(chave) DO UPDATE SET falhas = excluded.falhas, "
            "bloqueado_ate = excluded.bloqueado_ate, ultima = excluded.ultima",
            (chave, falhas, bloqueado_ate, agora))
    return falhas


def limpar_falhas(*chaves):
    for chave in chaves:
        banco.executar("DELETE FROM tentativas_login WHERE chave = ?", (chave,))


def autenticar(usuario, senha, ip):
    """Confere usuário e senha. Retorna (usuario_dict, None) ou (None, mensagem)."""
    chave_usuario, chave_ip = f"u:{usuario.lower()}", f"ip:{ip}"
    espera = max(segundos_bloqueado(chave_usuario), segundos_bloqueado(chave_ip))
    if espera:
        return None, f"Muitas tentativas. Tente novamente em {espera // 60 + 1} minuto(s)."

    u = banco.um("SELECT * FROM usuarios WHERE usuario = ?", (usuario,))
    ok = conferir_hash(senha, u["senha_hash"] if u else _HASH_FALSO)
    if not u or not ok or not u["ativo"]:
        registrar_falha(chave_usuario)
        registrar_falha(chave_ip)
        return None, "Usuário ou senha incorretos"
    limpar_falhas(chave_usuario)
    if not u["fornecedor"]:
        from . import empresas
        empresa = empresas.obter(u["empresa_id"])
        if not empresa:
            return None, "Usuário sem empresa: fale com o fornecedor"
        if empresa["situacao"] != "ok":
            return None, f"{empresa['situacao_texto']}. Fale com o fornecedor do sistema."
    return u, None


# ---------------------------------------------------------------- 2FA (TOTP, RFC 6238)

_ultimo_passo_usado = {}
_trava_totp = threading.Lock()


def gerar_segredo_totp():
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def uri_totp(segredo, usuario, emissor="Sentinela de Rede"):
    rotulo = urllib.parse.quote(f"{emissor}:{usuario}")
    return (f"otpauth://totp/{rotulo}?secret={segredo}&issuer={urllib.parse.quote(emissor)}"
            "&algorithm=SHA1&digits=6&period=30")


def codigo_totp(segredo, passo):
    chave = base64.b32decode(segredo + "=" * (-len(segredo) % 8), casefold=True)
    digest = hmac.new(chave, struct.pack(">Q", passo), hashlib.sha1).digest()
    deslocamento = digest[-1] & 0x0F
    numero = struct.unpack(">I", digest[deslocamento:deslocamento + 4])[0] & 0x7FFFFFFF
    return f"{numero % 1_000_000:06d}"


def conferir_totp(segredo, codigo, usuario_id=None, agora=None):
    codigo = "".join(c for c in str(codigo) if c.isdigit())
    if len(codigo) != 6 or not segredo:
        return False
    passo_atual = int((agora or time.time()) // 30)
    for passo in (passo_atual - 1, passo_atual, passo_atual + 1):
        if hmac.compare_digest(codigo_totp(segredo, passo), codigo):
            if usuario_id is not None:
                with _trava_totp:  # impede reutilizar o mesmo código (guardado no banco: vale após reiniciar)
                    linha = banco.um("SELECT falhas FROM tentativas_login WHERE chave = ?", (f"totp:{usuario_id}",))
                    ultimo = max(_ultimo_passo_usado.get(usuario_id, -1), linha["falhas"] if linha else -1)
                    if ultimo >= passo:
                        return False
                    _ultimo_passo_usado[usuario_id] = passo
                    banco.executar("INSERT INTO tentativas_login (chave, falhas, ultima) VALUES (?, ?, ?) "
                                   "ON CONFLICT(chave) DO UPDATE SET falhas = excluded.falhas, ultima = excluded.ultima",
                                   (f"totp:{usuario_id}", passo, time.time()))
            return True
    return False


def segredo_totp_do_usuario(u):
    return cofre.decifrar(u["totp_cif"]) if u and u["totp_cif"] else None


# ---------------------------------------------------------------- sessões

NOME_COOKIE = "sentinela_sessao"


def _hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def empresa_inicial(u):
    if not u["fornecedor"]:
        return u["empresa_id"]
    primeira = banco.um("SELECT id FROM empresas ORDER BY id LIMIT 1")
    return primeira["id"] if primeira else None


def criar_sessao(usuario_id, ip, agente, mfa_ok=True, empresa_id=None):
    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(24)
    agora = time.time()
    duracao = 600 if not mfa_ok else int(CFG["seguranca"]["sessao_horas"]) * 3600
    if empresa_id is None:
        empresa_id = empresa_inicial(obter_usuario(usuario_id))
    banco.executar(
        "INSERT INTO sessoes (token_hash, usuario_id, csrf, mfa_ok, criada, expira, ultimo_uso, ip, agente, empresa_id) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (_hash_token(token), usuario_id, csrf, int(mfa_ok), agora, agora + duracao, agora, ip, agente[:200], empresa_id))
    banco.executar("DELETE FROM sessoes WHERE expira < ?", (agora,))
    return token, csrf


def obter_sessao(token):
    if not token:
        return None
    linha = banco.um(
        "SELECT s.*, u.usuario, u.nome, u.papel, u.ativo, u.trocar_senha, u.totp_ativo, u.fornecedor, "
        "u.empresa_id AS empresa_do_usuario "
        "FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id WHERE s.token_hash = ?", (_hash_token(token),))
    agora = time.time()
    if not linha or linha["expira"] < agora or not linha["ativo"]:
        return None
    if not linha["fornecedor"]:
        # usuário de provedor: a empresa é SEMPRE a do cadastro dele (nunca a gravada na sessão)
        linha["empresa_id"] = linha["empresa_do_usuario"]
    if agora - linha["ultimo_uso"] > 60:
        banco.executar("UPDATE sessoes SET ultimo_uso = ? WHERE token_hash = ?", (agora, linha["token_hash"]))
    return linha


def trocar_empresa_da_sessao(token, empresa_id):
    """Só para o fornecedor: passa a operar outra empresa (suporte)."""
    banco.executar("UPDATE sessoes SET empresa_id = ? WHERE token_hash = ?", (empresa_id, _hash_token(token)))


def promover_sessao(token):
    """Depois do 2FA, a sessão provisória vira sessão completa."""
    agora = time.time()
    duracao = int(CFG["seguranca"]["sessao_horas"]) * 3600
    banco.executar("UPDATE sessoes SET mfa_ok = 1, expira = ? WHERE token_hash = ?",
                   (agora + duracao, _hash_token(token)))


def encerrar_sessao(token):
    banco.executar("DELETE FROM sessoes WHERE token_hash = ?", (_hash_token(token),))


def encerrar_sessoes_do_usuario(usuario_id, exceto_token=None):
    if exceto_token:
        banco.executar("DELETE FROM sessoes WHERE usuario_id = ? AND token_hash != ?",
                       (usuario_id, _hash_token(exceto_token)))
    else:
        banco.executar("DELETE FROM sessoes WHERE usuario_id = ?", (usuario_id,))


def pode(papel, permissao, fornecedor=False):
    if permissao == "fornecedor":
        return bool(fornecedor)
    return bool(fornecedor) or permissao in PERMISSOES.get(papel, set())


# ---------------------------------------------------------------- auditoria

def auditar(usuario, ip, acao, alvo="", detalhes="", empresa_id=None):
    banco.executar("INSERT INTO auditoria (usuario, ip, acao, alvo, detalhes, empresa_id) VALUES (?, ?, ?, ?, ?, ?)",
                   (usuario or "", ip or "", acao, str(alvo)[:300], str(detalhes)[:2000], empresa_id))
