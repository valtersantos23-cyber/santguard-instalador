"""Relatório mensal de segurança em PDF (reportlab)."""

import calendar
import datetime
import io
import json
from collections import Counter

from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

from . import banco, equipamentos

MESES = ["", "janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
         "outubro", "novembro", "dezembro"]
AZUL, CINZA, VERMELHO, VERDE, CLARO = (colors.HexColor("#1f3b63"), colors.HexColor("#5b6773"),
                                       colors.HexColor("#c62828"), colors.HexColor("#2e7d32"),
                                       colors.HexColor("#eef2f7"))


def _data(texto):
    try:
        return datetime.datetime.strptime(texto[:19], "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError):
        return None


def _duracao(segundos):
    if segundos is None:
        return "—"
    segundos = int(segundos)
    if segundos < 3600:
        return f"{segundos // 60} min"
    if segundos < 86400:
        return f"{segundos // 3600} h {segundos % 3600 // 60} min"
    return f"{segundos // 86400} d {segundos % 86400 // 3600} h"


def _bps(v):
    for limite, unidade in ((1e9, "Gbps"), (1e6, "Mbps"), (1e3, "kbps")):
        if v >= limite:
            return f"{v / limite:.1f} {unidade}"
    return f"{v:.0f} bps"


def dados_do_periodo(empresa_id, ano, mes):
    empresa_id = int(empresa_id)
    inicio = datetime.datetime(ano, mes, 1)
    fim = datetime.datetime(ano + (mes == 12), mes % 12 + 1, 1)
    ini_txt, fim_txt = inicio.strftime("%Y-%m-%d %H:%M:%S"), fim.strftime("%Y-%m-%d %H:%M:%S")
    lista = banco.consultar("SELECT * FROM incidentes WHERE empresa_id = ? AND abertura >= ? AND abertura < ? ORDER BY abertura",
                            (empresa_id, ini_txt, fim_txt))
    ddos = banco.consultar("SELECT * FROM ddos WHERE empresa_id = ? AND inicio >= ? AND inicio < ? ORDER BY pico_bps DESC",
                           (empresa_id, inicio.timestamp(), fim.timestamp()))
    envios = banco.consultar("SELECT canal, ok, COUNT(*) AS n FROM envios WHERE empresa_id = ? AND quando >= ? AND quando < ? "
                             "GROUP BY canal, ok", (empresa_id, ini_txt, fim_txt))
    reconhecer, resolver = [], []
    for i in lista:
        a, r, s = _data(i["abertura"]), _data(i["reconhecido_em"]), _data(i["resolvido_em"])
        if a and r:
            reconhecer.append((r - a).total_seconds())
        if a and s:
            resolver.append((s - a).total_seconds())
    por_dia = Counter(_data(i["abertura"]).day for i in lista if _data(i["abertura"]))
    auditoria = banco.ler_config_empresa(empresa_id, "ultima_auditoria")
    return {
        "inicio": inicio, "fim": fim, "incidentes": lista, "ddos": ddos, "envios": envios,
        "mtta": sum(reconhecer) / len(reconhecer) if reconhecer else None,
        "mttr": sum(resolver) / len(resolver) if resolver else None,
        "por_tipo": Counter(i["tipo"] for i in lista).most_common(),
        "por_severidade": Counter(i["severidade"] for i in lista),
        "por_equipamento": Counter(i["equipamento"] for i in lista).most_common(10),
        "por_dia": [por_dia.get(d, 0) for d in range(1, calendar.monthrange(ano, mes)[1] + 1)],
        "auditoria": json.loads(auditoria) if auditoria else None,
        "equipamentos": equipamentos.listar(empresa_id),
    }


def _tabela(linhas, larguras, cabecalho=True, alinhar_direita=()):
    t = Table(linhas, colWidths=larguras, repeatRows=1 if cabecalho else 0)
    estilo = [("FONTNAME", (0, 0), (-1, -1), "Helvetica"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
              ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#d5dbe3")),
              ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if cabecalho:
        estilo += [("BACKGROUND", (0, 0), (-1, 0), AZUL), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                   ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                   ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, CLARO])]
    for coluna in alinhar_direita:
        estilo.append(("ALIGN", (coluna, 0), (coluna, -1), "RIGHT"))
    t.setStyle(TableStyle(estilo))
    return t


def gerar_pdf(empresa_id, ano, mes, nome_empresa="Meu Provedor"):
    d = dados_do_periodo(empresa_id, ano, mes)
    estilos = getSampleStyleSheet()
    titulo = ParagraphStyle("titulo", parent=estilos["Title"], textColor=AZUL, fontSize=22, spaceAfter=4)
    sub = ParagraphStyle("sub", parent=estilos["Normal"], textColor=CINZA, fontSize=10, alignment=TA_CENTER)
    h2 = ParagraphStyle("h2", parent=estilos["Heading2"], textColor=AZUL, fontSize=13, spaceBefore=14, spaceAfter=6)
    normal = ParagraphStyle("n", parent=estilos["Normal"], fontSize=9.5, leading=13)
    celula = ParagraphStyle("c", parent=normal, fontSize=8.5, leading=10.5)
    P = lambda t, s=celula: Paragraph(str(t).replace("&", "&amp;").replace("<", "&lt;"), s)

    buffer = io.BytesIO()
    periodo = f"{MESES[mes]} de {ano}"

    def rodape(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(CINZA)
        canvas.drawString(1.8 * cm, 1.1 * cm, f"Sentinela de Rede · {nome_empresa} · Relatório de segurança de {periodo}")
        canvas.drawRightString(A4[0] - 1.8 * cm, 1.1 * cm, f"Página {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.6 * cm,
                            bottomMargin=1.8 * cm, title=f"Relatório de segurança - {periodo}", author="Sentinela de Rede")
    h = []
    h.append(Paragraph("Relatório de Segurança da Rede", titulo))
    h.append(Paragraph(f"{nome_empresa} · {periodo} · gerado em "
                       f"{datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}", sub))
    h.append(Spacer(1, 16))

    # ---------------------------------------------------------------- resumo
    sev = d["por_severidade"]
    maior = d["ddos"][0] if d["ddos"] else None
    cartoes = [
        ["Incidentes", "Alta severidade", "Ataques DDoS", "Maior DDoS", "Média p/ reconhecer", "Média p/ resolver"],
        [str(len(d["incidentes"])), str(sev.get("alta", 0)), str(len(d["ddos"])),
         _bps(maior["pico_bps"]) if maior else "—", _duracao(d["mtta"]), _duracao(d["mttr"])],
    ]
    t = Table(cartoes, colWidths=[2.9 * cm] * 6)
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica"), ("FONTSIZE", (0, 0), (-1, 0), 7), ("TEXTCOLOR", (0, 0), (-1, 0), CINZA),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"), ("FONTSIZE", (0, 1), (-1, 1), 14), ("TEXTCOLOR", (0, 1), (-1, 1), AZUL),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"), ("BACKGROUND", (0, 0), (-1, -1), CLARO),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#c9d3df")), ("TOPPADDING", (0, 1), (-1, 1), 6),
        ("BOTTOMPADDING", (0, 1), (-1, 1), 8)]))
    h.append(t)
    h.append(Spacer(1, 10))

    resumo = (f"No período foram monitorados <b>{len(d['equipamentos'])}</b> equipamento(s). "
              f"Foram registrados <b>{len(d['incidentes'])}</b> incidente(s) de segurança "
              f"({sev.get('alta', 0)} de severidade alta, {sev.get('media', 0)} média e {sev.get('baixa', 0)} baixa)")
    resumo += f" e <b>{len(d['ddos'])}</b> ataque(s) DDoS." if d["ddos"] else ". Nenhum ataque DDoS volumétrico foi detectado."
    if maior:
        resumo += (f" O maior ataque atingiu <b>{_bps(maior['pico_bps'])}</b> contra {maior['alvo']} "
                   f"({maior['vetor']}).")
    h.append(Paragraph(resumo, normal))

    # ---------------------------------------------------------------- gráfico por dia
    if d["incidentes"]:
        desenho = Drawing(17.4 * cm, 5.2 * cm)
        grafico = VerticalBarChart()
        grafico.x, grafico.y, grafico.width, grafico.height = 30, 25, 17.4 * cm - 40, 5.2 * cm - 45
        grafico.data = [d["por_dia"]]
        grafico.categoryAxis.categoryNames = [str(i) if i % 2 or len(d["por_dia"]) < 16 else ""
                                              for i in range(1, len(d["por_dia"]) + 1)]
        grafico.categoryAxis.labels.fontSize = 6.5
        grafico.categoryAxis.labels.fontName = "Helvetica"
        grafico.valueAxis.labels.fontSize = 7
        grafico.valueAxis.labels.fontName = "Helvetica"
        grafico.valueAxis.valueMin = 0
        grafico.valueAxis.valueStep = max(1, max(d["por_dia"]) // 4 or 1)
        grafico.bars[0].fillColor = AZUL
        grafico.bars[0].strokeColor = None
        desenho.add(grafico)
        desenho.add(String(30, 5.2 * cm - 12, "Incidentes por dia", fontSize=9, fontName="Helvetica", fillColor=CINZA))
        h.append(Spacer(1, 8))
        h.append(desenho)

    # ---------------------------------------------------------------- por tipo e por equipamento
    if d["por_tipo"]:
        h.append(Paragraph("Incidentes por tipo", h2))
        h.append(_tabela([["Tipo", "Quantidade"]] + [[P(t), str(n)] for t, n in d["por_tipo"]],
                         [13 * cm, 4.4 * cm], alinhar_direita=(1,)))
    if d["por_equipamento"]:
        h.append(Paragraph("Equipamentos/clientes mais atingidos", h2))
        h.append(_tabela([["Equipamento / alvo", "Incidentes"]] + [[P(t), str(n)] for t, n in d["por_equipamento"]],
                         [13 * cm, 4.4 * cm], alinhar_direita=(1,)))

    # ---------------------------------------------------------------- DDoS
    if d["ddos"]:
        h.append(Paragraph("Ataques DDoS", h2))
        linhas = [["Início", "Alvo", "Vetor", "Pico", "Pacotes/s", "Duração"]]
        for x in d["ddos"][:60]:
            linhas.append([datetime.datetime.fromtimestamp(x["inicio"]).strftime("%d/%m %H:%M"), P(x["alvo"]), P(x["vetor"]),
                           _bps(x["pico_bps"]), f"{x['pico_pps'] / 1000:.0f} mil",
                           _duracao((x["fim"] or x["ultimo"]) - x["inicio"])])
        h.append(_tabela(linhas, [2.4 * cm, 3.6 * cm, 4.4 * cm, 2.4 * cm, 2.3 * cm, 2.3 * cm], alinhar_direita=(3, 4)))

    # ---------------------------------------------------------------- alertas
    if d["envios"]:
        h.append(Paragraph("Alertas enviados", h2))
        canais = {}
        for e in d["envios"]:
            canais.setdefault(e["canal"], [0, 0])[0 if e["ok"] else 1] += e["n"]
        h.append(_tabela([["Canal", "Entregues", "Falharam"]] + [[c, str(v[0]), str(v[1])] for c, v in canais.items()],
                         [9 * cm, 4.2 * cm, 4.2 * cm], alinhar_direita=(1, 2)))

    # ---------------------------------------------------------------- auditoria
    a = d["auditoria"]
    if a:
        h.append(Paragraph(f"Auditoria de configuração (última em {a['quando']})", h2))
        linhas = [["Equipamento", "Situação"]]
        for r in a["resultados"]:
            if not r["ok"]:
                situacao = f"Não verificado: {r['erro']}"
            elif r["problemas"]:
                situacao = "; ".join(f"[{p['severidade']}] {p['mensagem']}" for p in r["problemas"])
            else:
                situacao = "Nenhum problema encontrado"
            linhas.append([P(r["nome"]), P(situacao)])
        h.append(_tabela(linhas, [5.4 * cm, 12 * cm]))

    # ---------------------------------------------------------------- lista de incidentes
    if d["incidentes"]:
        h.append(PageBreak())
        h.append(Paragraph("Lista de incidentes", h2))
        linhas = [["#", "Abertura", "Equipamento", "Tipo", "Sev.", "Estado", "Reconhecido por"]]
        for i in d["incidentes"][-300:]:
            linhas.append([str(i["id"]), i["abertura"][5:16], P(i["equipamento"]), P(i["tipo"]), i["severidade"],
                           i["estado"], P(i["reconhecido_por"] or "—")])
        h.append(_tabela(linhas, [1 * cm, 2.4 * cm, 4.2 * cm, 3.6 * cm, 1.4 * cm, 2.2 * cm, 2.6 * cm]))

    h.append(Spacer(1, 18))
    h.append(KeepTogether([Paragraph(
        "Este relatório foi gerado automaticamente pelo Sentinela de Rede a partir dos registros de monitoramento "
        "(SSH, SNMP, syslog e fluxo NetFlow/sFlow/IPFIX). Os horários estão no fuso do servidor.",
        ParagraphStyle("nota", parent=normal, fontSize=8, textColor=CINZA))]))
    doc.build(h, onFirstPage=rodape, onLaterPages=rodape)
    return buffer.getvalue()
