"""Eventos (linha do tempo) e incidentes (com agrupamento, reconhecimento e resolução)."""

import threading
import time

from . import banco, config

TODAS = "*"


def _empresa(equip_id, empresa_id):
    if empresa_id is not None:
        return empresa_id
    if equip_id:
        linha = banco.um("SELECT empresa_id FROM equipamentos WHERE id = ?", (equip_id,))
        return linha["empresa_id"] if linha else None
    return None

# Funções chamadas quando um incidente NOVO é aberto (ex.: enviar alertas). Recebem o incidente.
AO_ABRIR = []
# Funções chamadas a cada evento registrado (ex.: tela ao vivo). Recebem o evento.
AO_EVENTO = []

JANELA_AGRUPAMENTO_MIN = 60   # ocorrências do mesmo tipo no mesmo equipamento viram um incidente só

_trava = threading.Lock()


def registrar_evento(equip_id, equipamento, tipo, gravidade, mensagem, origem="", fonte="", empresa_id=None):
    """Registra na linha do tempo. Sem empresa (nem equipamento) = evento da plataforma (só o fornecedor vê)."""
    evento = {"ts": time.time(), "equip_id": equip_id, "equipamento": equipamento, "tipo": tipo,
              "gravidade": gravidade, "origem": origem, "mensagem": mensagem[:500], "fonte": fonte,
              "empresa_id": _empresa(equip_id, empresa_id)}
    evento["id"] = banco.executar(
        "INSERT INTO eventos (ts, equip_id, equipamento, tipo, gravidade, origem, mensagem, fonte, empresa_id) "
        "VALUES (:ts, :equip_id, :equipamento, :tipo, :gravidade, :origem, :mensagem, :fonte, :empresa_id)", evento)
    for funcao in AO_EVENTO:
        try:
            funcao(evento)
        except Exception:
            pass
    return evento


def eventos_recentes(empresa_id, limite=150, desde_id=0):
    if empresa_id == TODAS:
        return banco.consultar("SELECT * FROM eventos WHERE id > ? ORDER BY id DESC LIMIT ?", (desde_id, limite))
    return banco.consultar("SELECT * FROM eventos WHERE empresa_id = ? AND id > ? ORDER BY id DESC LIMIT ?",
                           (int(empresa_id), desde_id, limite))


def abrir(equip_id, equipamento, tipo, titulo, detalhes="", severidade="alta", pasta=None, chave=None,
          empresa_id=None):
    """Abre um incidente, ou soma uma ocorrência a um aberto recente do mesmo tipo.

    Retorna (incidente, novo).
    """
    empresa_id = _empresa(equip_id, empresa_id)
    chave = f"e{empresa_id}|" + (chave or f"{equip_id}|{tipo}")
    limite = time.time() - JANELA_AGRUPAMENTO_MIN * 60
    with _trava:
        existente = banco.um(
            "SELECT * FROM incidentes WHERE chave = ? AND estado != 'resolvido' "
            "AND strftime('%s', ultima_ocorrencia, 'utc') >= ? ORDER BY id DESC LIMIT 1",
            (chave, str(int(limite))))
        if existente:
            banco.executar(
                "UPDATE incidentes SET ocorrencias = ocorrencias + 1, ultima_ocorrencia = datetime('now', 'localtime'), "
                "detalhes = ?, pasta = COALESCE(?, pasta) WHERE id = ?",
                (detalhes or existente["detalhes"], pasta, existente["id"]))
            return obter(existente["id"]), False
        novo_id = banco.executar(
            "INSERT INTO incidentes (equip_id, equipamento, tipo, severidade, titulo, detalhes, pasta, chave, empresa_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (equip_id, equipamento, tipo, severidade, titulo, detalhes, pasta, chave, empresa_id))
    incidente = obter(novo_id)
    for funcao in AO_ABRIR:
        try:
            funcao(incidente)
        except Exception as e:  # um canal de alerta com problema não pode derrubar a detecção
            registrar_evento(equip_id, equipamento, "Falha no alerta", "erro", str(e), fonte="alertas",
                             empresa_id=empresa_id)
    return incidente, True


def anexar_pasta(incidente_id, pasta):
    banco.executar("UPDATE incidentes SET pasta = ? WHERE id = ?", (pasta, incidente_id))


def obter(incidente_id, empresa_id=TODAS):
    if empresa_id == TODAS:
        return banco.um("SELECT * FROM incidentes WHERE id = ?", (incidente_id,))
    return banco.um("SELECT * FROM incidentes WHERE id = ? AND empresa_id = ?", (incidente_id, int(empresa_id)))


def listar(empresa_id, estado=None, limite=300, equip_id=None, desde=None, ate=None):
    filtros, params = [], []
    if empresa_id != TODAS:
        filtros.append("empresa_id = ?")
        params.append(int(empresa_id))
    if estado == "abertos":
        filtros.append("estado != 'resolvido'")
    elif estado:
        filtros.append("estado = ?")
        params.append(estado)
    if equip_id:
        filtros.append("equip_id = ?")
        params.append(equip_id)
    if desde:
        filtros.append("abertura >= ?")
        params.append(desde)
    if ate:
        filtros.append("abertura < ?")
        params.append(ate)
    onde = ("WHERE " + " AND ".join(filtros)) if filtros else ""
    return banco.consultar(f"SELECT * FROM incidentes {onde} ORDER BY id DESC LIMIT ?", (*params, limite))


def reconhecer(incidente_id, usuario, empresa_id):
    return banco.executar(
        "UPDATE incidentes SET estado = 'reconhecido', reconhecido_por = ?, reconhecido_em = datetime('now', 'localtime'), "
        "proximo_escalonamento = NULL WHERE id = ? AND empresa_id = ? AND estado = 'aberto'",
        (usuario, incidente_id, int(empresa_id))) > 0


def resolver(incidente_id, usuario, empresa_id):
    return banco.executar(
        "UPDATE incidentes SET estado = 'resolvido', resolvido_por = ?, resolvido_em = datetime('now', 'localtime'), "
        "reconhecido_por = COALESCE(reconhecido_por, ?), reconhecido_em = COALESCE(reconhecido_em, datetime('now', 'localtime')), "
        "proximo_escalonamento = NULL WHERE id = ? AND empresa_id = ? AND estado != 'resolvido'",
        (usuario, usuario, incidente_id, int(empresa_id))) > 0


def limpar_eventos_antigos():
    dias = int(config.CFG["retencao"]["eventos_dias"])
    banco.executar("DELETE FROM eventos WHERE ts < ?", (time.time() - dias * 86400,))
