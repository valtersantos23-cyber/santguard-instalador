"""Gerador de liberação em janela (abre no navegador, só neste computador).

    python gerador.py            (ou dois cliques em GERADOR.cmd)

Cola o SERIAL que aparece na tela de registro do cliente, clica em "Gerar liberação" e copia
a chave para enviar ao cliente. O servidor escuta só em 127.0.0.1 e exige um token aleatório
em toda requisição: outro computador ou outro site não consegue gerar licenças por ele.

A chave privada fica cifrada com a senha do fornecedor: a janela pede a senha ao abrir, guarda a
chave aberta só na memória e se tranca sozinha depois de 15 minutos sem uso.
"""

import json
import secrets
import threading
import time
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

import cofre_chave
import ed25519
import gerador
from gerador import DIAS_PADRAO, Emissor, ErroLiberacao, maquina_texto

TOKEN = secrets.token_urlsafe(24)
INATIVIDADE = 15 * 60          # tranca sozinho depois disso sem uso
ESTADO = {"semente": None, "ultimo": 0.0, "falhas": 0, "espera_ate": 0.0}
_trava = threading.Lock()


class Trancado(Exception):
    pass


def _semente():
    with _trava:
        if ESTADO["semente"] is None:
            raise Trancado()
        if time.monotonic() - ESTADO["ultimo"] > INATIVIDADE:
            ESTADO["semente"] = None
            raise Trancado()
        ESTADO["ultimo"] = time.monotonic()
        return ESTADO["semente"]


def _abrir(semente):
    with _trava:
        ESTADO.update(semente=semente, ultimo=time.monotonic(), falhas=0, espera_ate=0.0)


def _emissor():
    return Emissor(_semente())


def acao_estado(d):
    arq = gerador.ARQ_CHAVE
    aberto = True
    try:
        _semente()
    except Trancado:
        aberto = False
    return {"tem_chave": arq.exists(), "tem_senha": gerador.chave_tem_senha(), "aberto": aberto}


def acao_entrar(d):
    agora = time.monotonic()
    if agora < ESTADO["espera_ate"]:
        raise ErroLiberacao(f"muitas tentativas: aguarde {int(ESTADO['espera_ate'] - agora) + 1} segundos")
    try:
        semente = cofre_chave.ler(gerador.ARQ_CHAVE, str(d.get("senha", "")))
    except cofre_chave.SenhaErrada:
        with _trava:
            ESTADO["falhas"] += 1
            if ESTADO["falhas"] >= 3:  # espera cresce a cada erro: 5 s, 10 s, 20 s... até 5 min
                ESTADO["espera_ate"] = time.monotonic() + min(300, 5 * 2 ** (ESTADO["falhas"] - 3))
        time.sleep(1)
        raise ErroLiberacao("senha incorreta") from None
    if not gerador.chave_tem_senha():
        raise ErroLiberacao("defina uma senha primeiro")
    _abrir(semente)
    return {}


def acao_sair(d):
    with _trava:
        ESTADO["semente"] = None
    return {}


def acao_definir_senha(d):
    """Arquivo antigo, sem senha: protege com a senha nova."""
    if gerador.chave_tem_senha():
        raise ErroLiberacao("a chave já tem senha. Para trocar, use a opção Trocar senha.")
    semente = cofre_chave.ler(gerador.ARQ_CHAVE, "")
    try:
        cofre_chave.gravar(gerador.ARQ_CHAVE, semente, str(d.get("senha", "")))
    except ValueError as e:
        raise ErroLiberacao(str(e)) from None
    _abrir(semente)
    return {}


def acao_trocar_senha(d):
    semente = _semente()
    try:
        if cofre_chave.ler(gerador.ARQ_CHAVE, str(d.get("atual", ""))) != semente:
            raise cofre_chave.SenhaErrada()
    except cofre_chave.SenhaErrada:
        time.sleep(1)
        raise ErroLiberacao("a senha atual está incorreta") from None
    try:
        cofre_chave.gravar(gerador.ARQ_CHAVE, semente, str(d.get("nova", "")))
    except ValueError as e:
        raise ErroLiberacao(str(e)) from None
    return {}


def acao_ler(d):
    em = _emissor()
    sol = em.ler_solicitacao(d.get("serial", ""))
    ant = em.anterior(sol.maquina.hex())
    idade = int(time.time()) - sol.criada
    return {"servidor": maquina_texto(sol.maquina.hex()),
            "pedido": datetime.fromtimestamp(sol.criada).strftime("%d/%m/%Y %H:%M"),
            "antigo": idade > gerador.IDADE_MAX_SOLICITACAO,
            "anterior": {"cliente": ant[1], "licenca": ant[0],
                         "vence": datetime.fromtimestamp(ant[2]).strftime("%d/%m/%Y"),
                         "equipamentos": ant[3], "empresas": ant[4]} if ant else None}


def acao_liberar(d):
    def inteiro(chave, padrao=None):
        valor = str(d.get(chave, "")).strip()
        if valor == "":
            return padrao
        try:
            return int(valor)
        except ValueError:
            raise ErroLiberacao(f"'{chave}' precisa ser um número") from None
    r = _emissor().liberar(d.get("serial", ""), d.get("cliente", ""), inteiro("dias", DIAS_PADRAO),
                           inteiro("equipamentos"), inteiro("empresas"))
    return {"codigo": r.codigo, "licenca": r.licenca_id, "cliente": r.cliente, "servidor": r.maquina,
            "vence": r.expira.strftime("%d/%m/%Y %H:%M"), "equipamentos": r.equipamentos,
            "empresas": r.empresas, "renovacao": r.renovacao, "avisos": r.avisos}


def acao_historico(d):
    agora = time.time()
    return {"linhas": [{"licenca": lid, "cliente": cli, "servidor": maquina_texto(maq),
                        "emitida": datetime.fromtimestamp(em).strftime("%d/%m/%Y"),
                        "vence": datetime.fromtimestamp(ex).strftime("%d/%m/%Y"),
                        "equipamentos": leq, "empresas": lemp, "ativa": ex > agora}
                       for lid, cli, maq, em, ex, leq, lemp in _emissor().historico(d.get("busca", ""))]}


def acao_criar_chaves(d):
    if gerador.ARQ_CHAVE.exists():
        raise ErroLiberacao("já existe uma chave privada. Para trocar, use a linha de comando (--forcar).")
    senha = str(d.get("senha", ""))
    problema = cofre_chave.problema_na_senha(senha)
    if problema:
        raise ErroLiberacao(problema)
    pasta = str(d.get("pasta", "")).strip().strip('"')
    gerador.cmd_novas_chaves(pasta or None, False, senha=senha)
    semente = cofre_chave.ler(gerador.ARQ_CHAVE, senha)
    _abrir(semente)
    return {"publica": ed25519.chave_publica(semente).hex(), "arquivo": str(gerador.ARQ_CHAVE)}


def acao_aplicar_chave(d):
    gerador.aplicar_chave(str(d.get("pasta", "")).strip().strip('"'), ed25519.chave_publica(_semente()).hex())
    return {}


ACOES = {"/api/ler": acao_ler, "/api/liberar": acao_liberar, "/api/historico": acao_historico,
         "/api/criar-chaves": acao_criar_chaves, "/api/aplicar-chave": acao_aplicar_chave,
         "/api/estado": acao_estado, "/api/entrar": acao_entrar, "/api/sair": acao_sair,
         "/api/definir-senha": acao_definir_senha, "/api/trocar-senha": acao_trocar_senha}


class Tratador(BaseHTTPRequestHandler):
    server_version = "GeradorSentinela"

    def log_message(self, *args):
        pass

    def _host_ok(self):
        # protege contra "DNS rebinding": só aceita o próprio endereço local
        return self.headers.get("Host", "") in (f"127.0.0.1:{self.server.server_port}",
                                                f"localhost:{self.server.server_port}")

    def _responder(self, codigo, corpo, tipo="application/json; charset=utf-8"):
        dados = corpo if isinstance(corpo, bytes) else json.dumps(corpo, ensure_ascii=False).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(dados)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                         "connect-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(dados)

    def do_GET(self):
        url = urlparse(self.path)
        if not self._host_ok() or parse_qs(url.query).get("t", [""])[0] != TOKEN or url.path != "/":
            return self._responder(403, b"Acesso negado. Abra pelo GERADOR.cmd.", "text/plain; charset=utf-8")
        pagina = PAGINA.replace("__TOKEN__", TOKEN)
        self._responder(200, pagina.encode(), "text/html; charset=utf-8")

    def do_POST(self):
        acao = ACOES.get(urlparse(self.path).path)
        if not acao or not self._host_ok() or self.headers.get("X-Token") != TOKEN:
            return self._responder(403, {"ok": False, "mensagem": "Acesso negado"})
        try:
            tamanho = min(int(self.headers.get("Content-Length") or 0), 65536)
            dados = json.loads(self.rfile.read(tamanho) or b"{}")
            if not isinstance(dados, dict):
                raise ValueError
        except ValueError:
            return self._responder(400, {"ok": False, "mensagem": "Requisição inválida"})
        try:
            return self._responder(200, {"ok": True, **acao(dados)})
        except Trancado:
            return self._responder(200, {"ok": False, "trancado": True, "mensagem": "Digite a senha para continuar"})
        except ErroLiberacao as e:
            return self._responder(200, {"ok": False, "mensagem": str(e)})
        except SystemExit as e:
            return self._responder(200, {"ok": False, "mensagem": str(e)})


def iniciar(abrir=True, porta=0):
    servidor = HTTPServer(("127.0.0.1", porta), Tratador)
    url = f"http://127.0.0.1:{servidor.server_port}/?t={TOKEN}"
    print("=" * 60)
    print("  Gerador de liberação do Sentinela de Rede")
    print("=" * 60)
    print(f"\n  Abrindo no navegador: {url}")
    print("  (se não abrir, copie o endereço acima no navegador)")
    print("\n  Mantenha esta janela aberta. Feche-a para encerrar o gerador.\n")
    if abrir:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    acao_sair({})
    return servidor


PAGINA = r"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gerador de liberação</title>
<style>
:root { --bg:#0f141b; --painel:#171e27; --borda:#2a3441; --texto:#e6edf3; --fraco:#8b98a7; --azul:#2f81f7;
        --verde:#3fb950; --alerta:#f85149; --amarelo:#d29922; }
* { box-sizing:border-box; }
body { margin:0; background:var(--bg); color:var(--texto); font:15px/1.5 "Segoe UI", system-ui, sans-serif; }
header { padding:18px 24px; border-bottom:1px solid var(--borda); display:flex; align-items:center; gap:12px; }
header h1 { font-size:19px; margin:0; } header span { color:var(--fraco); font-size:13px; }
main { max-width:980px; margin:0 auto; padding:24px 16px 60px; }
.card { background:var(--painel); border:1px solid var(--borda); border-radius:10px; padding:20px; margin-bottom:20px; }
h2 { font-size:16px; margin:0 0 14px; }
label { display:block; color:var(--fraco); font-size:13px; margin:10px 0 4px; }
input, textarea { width:100%; background:var(--bg); color:var(--texto); border:1px solid var(--borda); border-radius:6px;
  padding:9px 11px; font:inherit; }
input:focus, textarea:focus { outline:2px solid var(--azul); border-color:transparent; }
.mono, textarea { font-family:Consolas, "Cascadia Mono", monospace; }
#serial { font-size:19px; letter-spacing:1px; text-transform:uppercase; }
.linha { display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px; align-items:end; }
@media (max-width:640px) { .linha { grid-template-columns:1fr 1fr; } }
button { background:#222c38; color:var(--texto); border:1px solid var(--borda); border-radius:6px; padding:9px 16px;
  font:inherit; cursor:pointer; } button:hover { border-color:var(--fraco); }
button.primario { background:var(--azul); border-color:var(--azul); color:#fff; font-weight:600; }
.botoes { display:flex; gap:10px; margin-top:16px; flex-wrap:wrap; align-items:center; }
.info { color:var(--fraco); font-size:13px; margin-top:8px; min-height:20px; }
.info b { color:var(--texto); } .erro { color:var(--alerta); } .aviso { color:var(--amarelo); }
#resultado { border-left:4px solid var(--verde); }
#chave { height:120px; font-size:15px; resize:vertical; }
table { width:100%; border-collapse:collapse; font-size:13.5px; }
th, td { text-align:left; padding:7px 8px; border-bottom:1px solid var(--borda); } th { color:var(--fraco); font-weight:500; }
.selo { font-size:12px; padding:1px 8px; border-radius:10px; } .ativa { background:rgba(63,185,80,.15); color:var(--verde); }
.vencida { background:rgba(248,81,73,.15); color:var(--alerta); }
.tabela { overflow-x:auto; }
#toast { position:fixed; right:20px; bottom:20px; background:var(--azul); color:#fff; padding:10px 16px; border-radius:6px;
  opacity:0; transition:opacity .2s; } #toast.ver { opacity:1; }
[hidden] { display:none !important; }
.estreito { max-width:520px; margin:40px auto; }
.linha2 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
@media (max-width:640px) { .linha2 { grid-template-columns:1fr; } }
p.aviso { color:var(--amarelo); }
</style></head><body>
<header><h1>🔑 Gerador de liberação</h1><span>Sentinela de Rede · uso exclusivo do fornecedor</span>
  <button id="trancar" style="margin-left:auto" hidden>🔒 Trancar</button></header>
<main>
<section class="card estreito" id="tela-criar" hidden>
  <h2>Primeiro uso: crie a sua chave</h2>
  <p>Isso é feito <b>uma única vez</b>. A chave privada fica nesta pasta (<span class="mono">chave_privada.key</span>),
     <b>cifrada com a senha</b> que você criar agora. Quem copiar a pasta não consegue gerar licenças sem a senha.</p>
  <p class="aviso">Faça backup do arquivo e guarde a senha num gerenciador de senhas. Sem os dois, os clientes
     instalados não aceitam mais renovação.</p>
  <label>Pasta do projeto do Sentinela (para gravar a chave pública nele)</label>
  <input id="pasta" placeholder="C:\Users\...\sentinela">
  <label>Senha (mínimo 8 caracteres)</label><input id="senha-nova" type="password" autocomplete="new-password">
  <label>Repita a senha</label><input id="senha-nova2" type="password" autocomplete="new-password">
  <div class="botoes"><button class="primario" id="criar">Criar chave</button><span class="info erro" id="erro-criar"></span></div>
</section>

<section class="card estreito" id="tela-definir" hidden>
  <h2>Proteja a sua chave com uma senha</h2>
  <p>A sua chave privada está <b>sem senha</b>: quem copiar a pasta do gerador consegue gerar licenças.
     Defina uma senha agora. A chave continua a mesma, então nada muda para os clientes.</p>
  <label>Nova senha (mínimo 8 caracteres)</label><input id="senha-def" type="password" autocomplete="new-password">
  <label>Repita a senha</label><input id="senha-def2" type="password" autocomplete="new-password">
  <div class="botoes"><button class="primario" id="definir">Proteger com senha</button><span class="info erro" id="erro-definir"></span></div>
</section>

<section class="card estreito" id="tela-entrar" hidden>
  <h2>🔒 Digite a senha da chave</h2>
  <form id="form-entrar"><input id="senha" type="password" autocomplete="current-password" autofocus>
  <div class="botoes"><button class="primario" type="submit">Entrar</button><span class="info erro" id="erro-entrar"></span></div></form>
  <p class="info">O gerador se tranca sozinho depois de 15 minutos sem uso.</p>
</section>

<div id="principal" hidden>
<section class="card" id="gerar">
  <h2>1. Serial do cliente</h2>
  <input id="serial" class="mono" placeholder="KEAQN-6TGZ6-E3BDT-O3GIP-NI47I-T7242-W2RVY-BPXI" autocomplete="off" autofocus>
  <div class="info" id="info-serial">Cole o serial que aparece na tela de registro do cliente.</div>
  <div class="linha">
    <div><label>Cliente</label><input id="cliente" placeholder="Nome do provedor"></div>
    <div><label>Dias de validade</label><input id="dias" type="number" min="1" max="3650" value="30"></div>
    <div><label>Equipamentos (0 = sem limite)</label><input id="equipamentos" type="number" min="0" value="0"></div>
    <div><label>Empresas (0 = sem limite)</label><input id="empresas" type="number" min="0" value="1"></div>
  </div>
  <div class="botoes"><button class="primario" id="liberar">Gerar liberação</button><span class="info erro" id="erro"></span></div>
</section>

<section class="card" id="resultado" hidden>
  <h2>2. Chave de liberação: envie ao cliente</h2>
  <div class="info" id="resumo"></div>
  <textarea id="chave" readonly></textarea>
  <div class="botoes"><button class="primario" id="copiar">📋 Copiar chave</button><button id="nova">Nova liberação</button></div>
</section>

<section class="card">
  <h2>Histórico</h2>
  <input id="busca" placeholder="Buscar por cliente ou ID do servidor">
  <div class="tabela"><table><thead><tr><th>Nº</th><th>Cliente</th><th>Servidor</th><th>Emitida</th><th>Vence</th>
    <th>Equip.</th><th>Empr.</th><th></th></tr></thead><tbody id="historico"></tbody></table></div>
</section>

<section class="card">
  <h2>Versão nova do Sentinela</h2>
  <p class="info">Antes de gerar o instalador de uma versão nova, grave a sua chave pública nela.</p>
  <label>Pasta do projeto do Sentinela</label><input id="pasta2" placeholder="C:\Users\...\sentinela">
  <div class="botoes"><button id="aplicar">Gravar chave pública</button><span class="info" id="info-aplicar"></span></div>
</section>

<section class="card">
  <h2>Trocar a senha da chave</h2>
  <div class="linha2">
    <div><label>Senha atual</label><input id="senha-atual" type="password" autocomplete="current-password"></div>
    <div><label>Nova senha</label><input id="senha-troca" type="password" autocomplete="new-password"></div>
    <div><label>Repita a nova senha</label><input id="senha-troca2" type="password" autocomplete="new-password"></div>
  </div>
  <div class="botoes"><button id="trocar">Trocar senha</button><span class="info" id="info-trocar"></span></div>
</section>
</div>
</main>
<div id="toast"></div>
<script>
"use strict";
const TOKEN = "__TOKEN__";
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(rota, dados) {
  try {
    const r = await fetch(rota, { method: "POST", headers: { "Content-Type": "application/json", "X-Token": TOKEN },
                                  body: JSON.stringify(dados || {}) });
    const j = await r.json();
    if (j.trancado) mostrar("tela-entrar");
    return j;
  } catch (e) { return { ok: false, mensagem: "O gerador foi fechado. Abra de novo pelo GERADOR.cmd." }; }
}
function mostrar(tela) {
  for (const id of ["tela-criar", "tela-definir", "tela-entrar", "principal"]) $("#" + id).hidden = id !== tela;
  $("#trancar").hidden = tela !== "principal";
  if (tela === "tela-entrar") { $("#senha").value = ""; $("#senha").focus(); }
  if (tela === "principal") { historico(); $("#serial").focus(); }
}
async function comecar() {
  const e = await api("/api/estado");
  mostrar(!e.tem_chave ? "tela-criar" : !e.tem_senha ? "tela-definir" : e.aberto ? "principal" : "tela-entrar");
}
function conferir(a, b, erro) {
  if ($(a).value !== $(b).value) { $(erro).textContent = "As senhas não conferem"; return false; }
  return true;
}
$("#form-entrar").onsubmit = async ev => {
  ev.preventDefault();
  $("#erro-entrar").textContent = "Conferindo...";
  const j = await api("/api/entrar", { senha: $("#senha").value });
  if (j.ok) { $("#erro-entrar").textContent = ""; mostrar("principal"); }
  else { $("#erro-entrar").textContent = j.mensagem; $("#senha").select(); }
};
$("#definir").onclick = async () => {
  if (!conferir("#senha-def", "#senha-def2", "#erro-definir")) return;
  const j = await api("/api/definir-senha", { senha: $("#senha-def").value });
  if (j.ok) { toast("Chave protegida com senha"); mostrar("principal"); } else $("#erro-definir").textContent = j.mensagem;
};
$("#trancar").onclick = async () => { await api("/api/sair"); mostrar("tela-entrar"); };
$("#trocar").onclick = async () => {
  if (!conferir("#senha-troca", "#senha-troca2", "#info-trocar")) return;
  const j = await api("/api/trocar-senha", { atual: $("#senha-atual").value, nova: $("#senha-troca").value });
  $("#info-trocar").innerHTML = j.ok ? "✔ Senha trocada. Atualize o backup do arquivo." : `<span class="erro">${esc(j.mensagem)}</span>`;
  if (j.ok) for (const id of ["#senha-atual", "#senha-troca", "#senha-troca2"]) $(id).value = "";
};
function toast(t) { const el = $("#toast"); el.textContent = t; el.classList.add("ver"); setTimeout(() => el.classList.remove("ver"), 2500); }

$("#criar").onclick = async () => {
  if (!conferir("#senha-nova", "#senha-nova2", "#erro-criar")) return;
  const j = await api("/api/criar-chaves", { pasta: $("#pasta").value, senha: $("#senha-nova").value });
  if (!j.ok) { $("#erro-criar").textContent = j.mensagem; return; }
  toast("Chave criada. Faça o backup do arquivo agora.");
  mostrar("principal");
};

let tempo;
$("#serial").addEventListener("input", () => { clearTimeout(tempo); tempo = setTimeout(lerSerial, 300); });
async function lerSerial() {
  const serial = $("#serial").value.trim(), info = $("#info-serial");
  $("#erro").textContent = "";
  if (!serial) { info.textContent = "Cole o serial que aparece na tela de registro do cliente."; return; }
  const j = await api("/api/ler", { serial });
  if (!j.ok) { info.innerHTML = `<span class="erro">${esc(j.mensagem)}</span>`; return; }
  let h = `✔ Serial válido · servidor <b class="mono">${esc(j.servidor)}</b> · pedido em ${esc(j.pedido)}`;
  if (j.antigo) h += ` · <span class="aviso">serial antigo: confirme se é o atual</span>`;
  if (j.anterior) {
    const a = j.anterior;
    h += `<br>Cliente já conhecido: <b>${esc(a.cliente)}</b> (licença nº ${a.licenca}, vence ${esc(a.vence)}). Renovando, os dias se somam.`;
    $("#cliente").value = a.cliente; $("#equipamentos").value = a.equipamentos; $("#empresas").value = a.empresas;
  }
  info.innerHTML = h;
}

$("#liberar").onclick = async () => {
  const d = { serial: $("#serial").value, cliente: $("#cliente").value, dias: $("#dias").value,
              equipamentos: $("#equipamentos").value, empresas: $("#empresas").value };
  const j = await api("/api/liberar", d);
  if (!j.ok) { $("#erro").textContent = j.mensagem; return; }
  $("#erro").textContent = "";
  $("#chave").value = j.codigo;
  $("#resumo").innerHTML = `Licença nº <b>${j.licenca}</b>${j.renovacao ? " (renovação)" : ""} · <b>${esc(j.cliente)}</b> ·
    servidor <span class="mono">${esc(j.servidor)}</span> · válida até <b>${esc(j.vence)}</b> ·
    equipamentos: <b>${j.equipamentos || "sem limite"}</b> · empresas: <b>${j.empresas || "sem limite"}</b>` +
    (j.avisos || []).map(a => `<br><span class="aviso">⚠ ${esc(a)}</span>`).join("");
  $("#resultado").hidden = false;
  $("#resultado").scrollIntoView({ behavior: "smooth" });
  historico();
};
$("#copiar").onclick = async () => {
  try { await navigator.clipboard.writeText($("#chave").value); toast("Chave copiada"); }
  catch (e) { $("#chave").select(); document.execCommand("copy"); toast("Chave copiada"); }
};
$("#nova").onclick = () => {
  $("#resultado").hidden = true; $("#serial").value = ""; $("#cliente").value = "";
  $("#equipamentos").value = 0; $("#empresas").value = 1; $("#dias").value = 30;
  $("#info-serial").textContent = "Cole o serial que aparece na tela de registro do cliente."; $("#serial").focus();
};
$("#aplicar").onclick = async () => {
  const j = await api("/api/aplicar-chave", { pasta: $("#pasta2").value });
  $("#info-aplicar").innerHTML = j.ok ? "✔ Chave pública gravada." : `<span class="erro">${esc(j.mensagem)}</span>`;
};

let tempoBusca;
$("#busca").addEventListener("input", () => { clearTimeout(tempoBusca); tempoBusca = setTimeout(historico, 300); });
async function historico() {
  if ($("#principal").hidden) return;
  const j = await api("/api/historico", { busca: $("#busca").value });
  if (!j.ok) return;
  $("#historico").innerHTML = j.linhas.length ? j.linhas.map(l => `<tr><td>${l.licenca}</td><td>${esc(l.cliente)}</td>
    <td class="mono">${esc(l.servidor)}</td><td>${esc(l.emitida)}</td><td>${esc(l.vence)}</td>
    <td>${l.equipamentos || "∞"}</td><td>${l.empresas || "∞"}</td>
    <td><span class="selo ${l.ativa ? "ativa" : "vencida"}">${l.ativa ? "ativa" : "vencida"}</span></td></tr>`).join("")
    : '<tr><td colspan="8" class="info">Nenhuma liberação ainda.</td></tr>';
}
comecar();
</script></body></html>
"""
