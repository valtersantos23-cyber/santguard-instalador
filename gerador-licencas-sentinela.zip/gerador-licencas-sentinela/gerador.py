"""Gerador de licenças do Sentinela de Rede. USO EXCLUSIVO DO FORNECEDOR: nunca envie esta pasta ao cliente.

    python gerador.py                                   abre o gerador em janela (ou dois cliques em GERADOR.cmd)
    python gerador.py menu                              menu no terminal
    python gerador.py novas-chaves --sentinela PASTA    cria o par de chaves (UMA vez) e grava a chave
                                                        pública no Sentinela (PASTA = pasta do projeto)
    python gerador.py aplicar-chave --sentinela PASTA   grava a chave pública numa versão nova do Sentinela
    python gerador.py liberar CODIGO --cliente "Provedor X" [--dias 30] [--equipamentos 50] [--empresas 1]
    python gerador.py historico [--busca TEXTO]
    python gerador.py senha                             define ou troca a senha da chave privada

Arquivos desta pasta:
    chave_privada.key   SEGREDO, cifrado com a SUA SENHA. Faça backup em local seguro.
                        Se perder o arquivo ou esquecer a senha, os servidores já instalados não
                        aceitarão liberações novas.
    licencas.db         histórico de todas as liberações (SQLite)
"""

import argparse
import getpass
import os
import re
import sqlite3
import sys
import time
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path

import cofre_chave
import ed25519
from licenca_formato import PRODUTO, CodigoInvalido, Liberacao, Solicitacao, produto_id

PASTA = Path(__file__).resolve().parent
ARQ_CHAVE = PASTA / "chave_privada.key"
ARQ_DB = PASTA / "licencas.db"

DIAS_PADRAO = 30
IDADE_MAX_SOLICITACAO = 7 * 86400
TOLERANCIA = 3600
MAX_LIMITE = 65535


class ErroLiberacao(Exception):
    pass


def maquina_texto(maquina_hex):
    h = maquina_hex.upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


@dataclass
class Resultado:
    codigo: str
    licenca_id: int
    cliente: str
    maquina: str
    expira: datetime
    equipamentos: int
    empresas: int
    renovacao: bool
    avisos: list


class Emissor:
    def __init__(self, chave_privada, db=ARQ_DB, relogio=time.time):
        self.privada = chave_privada
        self.relogio = relogio
        self.pid = produto_id(PRODUTO)
        self.db = sqlite3.connect(str(db))
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS licencas (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente       TEXT NOT NULL,
                maquina       TEXT NOT NULL,
                nonce         TEXT NOT NULL,
                emitida       INTEGER NOT NULL,
                expira        INTEGER NOT NULL,
                equipamentos  INTEGER NOT NULL,
                empresas      INTEGER NOT NULL,
                codigo        TEXT NOT NULL,
                UNIQUE (maquina, nonce)
            )""")
        self.db.commit()

    def anterior(self, maquina_hex):
        """Última licença emitida para este servidor (para renovar com o mesmo cliente e limites)."""
        return self.db.execute(
            "SELECT id, cliente, expira, equipamentos, empresas FROM licencas WHERE maquina = ? "
            "ORDER BY expira DESC LIMIT 1", (maquina_hex,)).fetchone()

    def ler_solicitacao(self, codigo):
        try:
            sol = Solicitacao.de_codigo(codigo)
        except CodigoInvalido as e:
            raise ErroLiberacao(str(e)) from None
        if sol.produto != self.pid:
            raise ErroLiberacao("esta solicitação não é do Sentinela de Rede")
        return sol

    def liberar(self, codigo_solicitacao, cliente="", dias=DIAS_PADRAO, equipamentos=None, empresas=None):
        if not 1 <= dias <= 3650:
            raise ErroLiberacao("dias deve estar entre 1 e 3650")
        sol = self.ler_solicitacao(codigo_solicitacao)
        agora = int(self.relogio())
        maq = sol.maquina.hex()
        avisos = []

        idade = agora - sol.criada
        if idade > IDADE_MAX_SOLICITACAO:
            avisos.append(f"a solicitação foi gerada há {idade // 86400} dias; o cliente pode já ter gerado outra")
        if idade < -TOLERANCIA:
            avisos.append("a data da solicitação está no futuro: o relógio do servidor do cliente está adiantado")

        repetida = self.db.execute(
            "SELECT id, cliente, expira, equipamentos, empresas, codigo FROM licencas WHERE maquina = ? AND nonce = ?",
            (maq, sol.nonce.hex())).fetchone()
        if repetida:  # mesma solicitação de novo: devolve a mesma chave, sem dias extras
            lid, cli, exp, leq, lemp, cod = repetida
            return Resultado(cod, lid, cli, maquina_texto(maq), datetime.fromtimestamp(exp), leq, lemp, False,
                             ["esta solicitação já foi liberada antes; reenviando a mesma chave"])

        ant = self.anterior(maq)
        cliente = (cliente or "").strip() or (ant[1] if ant else "")
        if not cliente:
            raise ErroLiberacao("informe o nome do cliente")
        if equipamentos is None:
            equipamentos = ant[3] if ant else 0
        if empresas is None:
            empresas = ant[4] if ant else 1
        if not (0 <= equipamentos <= MAX_LIMITE and 0 <= empresas <= MAX_LIMITE):
            raise ErroLiberacao(f"limites devem estar entre 0 (sem limite) e {MAX_LIMITE}")

        # Renovação antecipada: soma a partir do vencimento atual, sem o cliente perder dias.
        renovacao = bool(ant and ant[2] > agora)
        expira = (ant[2] if renovacao else agora) + dias * 86400

        cur = self.db.execute(
            "INSERT INTO licencas (cliente, maquina, nonce, emitida, expira, equipamentos, empresas, codigo) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, '')", (cliente, maq, sol.nonce.hex(), agora, expira, equipamentos, empresas))
        lid = cur.lastrowid
        lib = Liberacao(sol.produto, sol.maquina, sol.nonce, lid, agora, expira, equipamentos, empresas)
        lib = replace(lib, assinatura=ed25519.assinar(self.privada, lib.corpo()))
        codigo = lib.para_codigo()
        self.db.execute("UPDATE licencas SET codigo = ? WHERE id = ?", (codigo, lid))
        self.db.commit()
        return Resultado(codigo, lid, cliente, maquina_texto(maq), datetime.fromtimestamp(expira),
                         equipamentos, empresas, renovacao, avisos)

    def historico(self, busca="", limite=100):
        return self.db.execute(
            "SELECT id, cliente, maquina, emitida, expira, equipamentos, empresas FROM licencas "
            "WHERE cliente LIKE ? OR maquina LIKE ? ORDER BY id DESC LIMIT ?",
            (f"%{busca}%", f"%{busca.replace('-', '').lower()}%", limite)).fetchall()


# --------------------------------------------------------------------------- chaves

def chave_tem_senha():
    return ARQ_CHAVE.exists() and cofre_chave.tem_senha(ARQ_CHAVE.read_text())


def pedir_senha_nova():
    while True:
        senha = getpass.getpass("Crie uma senha para a chave privada: ")
        problema = cofre_chave.problema_na_senha(senha)
        if problema:
            print(f"  {problema}")
            continue
        if senha != getpass.getpass("Repita a senha: "):
            print("  As senhas não conferem.")
            continue
        return senha


_semente_aberta = []


def carregar_chave(senha=None):
    """Abre a chave privada. Sem `senha`, pergunta no terminal (uma vez por execução)."""
    if not ARQ_CHAVE.exists():
        raise SystemExit("Chave privada não encontrada. Rode primeiro: python gerador.py novas-chaves --sentinela PASTA")
    if senha is None and _semente_aberta:
        return _semente_aberta[0]
    if not chave_tem_senha():
        semente = cofre_chave.ler(ARQ_CHAVE, "")
        if senha is None:  # arquivo antigo, sem senha: protege agora
            print("A chave privada está SEM senha. Defina uma agora para protegê-la.")
            cofre_chave.gravar(ARQ_CHAVE, semente, pedir_senha_nova())
            print("Senha definida.\n")
        _semente_aberta[:] = [semente]
        return semente
    for tentativa in range(3):
        try:
            semente = cofre_chave.ler(ARQ_CHAVE, senha if senha is not None else getpass.getpass("Senha da chave privada: "))
            _semente_aberta[:] = [semente]
            return semente
        except cofre_chave.SenhaErrada:
            if senha is not None:
                raise ErroLiberacao("senha incorreta") from None
            print("  Senha incorreta.")
            time.sleep(1)
    raise SystemExit("Senha incorreta. Tente de novo.")


def cmd_senha():
    semente = carregar_chave()
    print("Defina a NOVA senha.")
    cofre_chave.gravar(ARQ_CHAVE, semente, pedir_senha_nova())
    print("Senha trocada. Se tinha backup do arquivo antigo, atualize o backup também.")


def aplicar_chave(pasta_sentinela, publica_hex):
    """Grava a chave pública em <pasta>/sentinela/licenca.py."""
    pasta = Path(pasta_sentinela)
    alvo = pasta / "sentinela" / "licenca.py"
    if not alvo.exists():
        alvo = pasta / "licenca.py"  # aceita também a pasta do pacote
    if not alvo.exists():
        raise SystemExit(f"Não encontrei sentinela{os.sep}licenca.py em {pasta}")
    texto = alvo.read_text(encoding="utf-8")
    novo, n = re.subn(r'^CHAVE_PUBLICA = ".*"$', f'CHAVE_PUBLICA = "{publica_hex}"', texto, flags=re.M)
    if not n:
        raise SystemExit(f"Não encontrei a linha CHAVE_PUBLICA em {alvo}")
    alvo.write_text(novo, encoding="utf-8")
    print(f"Chave pública gravada em {alvo}")


def cmd_novas_chaves(pasta_sentinela, forcar, senha=None):
    if ARQ_CHAVE.exists() and not forcar:
        raise SystemExit(
            "Já existe uma chave_privada.key. Gerar outra INVALIDA todos os servidores já instalados\n"
            "(eles não aceitarão liberações da chave nova). Para uma versão nova do Sentinela use:\n"
            "    python gerador.py aplicar-chave --sentinela PASTA\n"
            "Se tem certeza de que quer trocar a chave, use --forcar.")
    if senha is None:
        senha = pedir_senha_nova()
    privada = ed25519.gerar_chave_privada()
    cofre_chave.gravar(ARQ_CHAVE, privada, senha)
    _semente_aberta[:] = [privada]
    publica = ed25519.chave_publica(privada).hex()
    print(f"Chave privada salva em: {ARQ_CHAVE}")
    print("  -> Ela está cifrada com a sua senha. FAÇA BACKUP do arquivo e guarde a senha num")
    print("     gerenciador de senhas: sem os dois, não há como gerar novas liberações.\n")
    print(f"Chave pública: {publica}")
    if pasta_sentinela:
        aplicar_chave(pasta_sentinela, publica)
    else:
        print("Grave-a no Sentinela com:  python gerador.py aplicar-chave --sentinela PASTA")


# --------------------------------------------------------------------------- saída

def mostrar(r):
    print()
    for a in r.avisos:
        print(f"  AVISO: {a}")
    print(f"  Licença nº .......: {r.licenca_id}{'  (renovação: dias somados ao vencimento atual)' if r.renovacao else ''}")
    print(f"  Cliente ..........: {r.cliente}")
    print(f"  Servidor (ID) ....: {r.maquina}")
    print(f"  Válida até .......: {r.expira:%d/%m/%Y %H:%M}")
    print(f"  Equipamentos .....: {r.equipamentos or 'sem limite'}")
    print(f"  Empresas .........: {r.empresas or 'sem limite'}")
    print("\n  CHAVE DE LIBERAÇÃO (envie ao cliente):\n")
    grupos = r.codigo.split("-")
    for i in range(0, len(grupos), 8):
        print("   ", "-".join(grupos[i:i + 8]) + ("-" if i + 8 < len(grupos) else ""))
    print()


def mostrar_historico(linhas):
    if not linhas:
        print("Nenhuma licença encontrada.")
        return
    agora = time.time()
    print(f"{'Nº':>4}  {'Cliente':<24} {'Servidor':<20} {'Emitida':<10}  {'Vence':<10}  {'Equip':>5} {'Empr':>4}  Situação")
    for lid, cli, maq, em, ex, leq, lemp in linhas:
        print(f"{lid:>4}  {cli[:24]:<24} {maquina_texto(maq):<20} {datetime.fromtimestamp(em):%d/%m/%Y}  "
              f"{datetime.fromtimestamp(ex):%d/%m/%Y}  {leq or '∞':>5} {lemp or '∞':>4}  "
              f"{'ativa' if ex > agora else 'vencida'}")


def ler_codigo_colado(mensagem):
    partes = [input(mensagem).strip()]
    while partes[-1].endswith("-"):
        try:
            partes.append(input().strip())
        except EOFError:
            break
    return "".join(partes)


def perguntar_int(texto, padrao):
    while True:
        valor = input(f"{texto} [{padrao}]: ").strip()
        if not valor:
            return padrao
        try:
            return int(valor)
        except ValueError:
            print("  Digite um número.")


def menu():
    while True:
        print("\n=== Gerador de licenças do Sentinela de Rede ===")
        print("1) Liberar um serial")
        print("2) Ver histórico")
        print("3) Gravar a chave pública numa versão do Sentinela")
        print("4) Criar o par de chaves (só na primeira vez)")
        print("0) Sair")
        op = input("> ").strip()
        try:
            if op == "1":
                emissor = Emissor(carregar_chave())
                cod = ler_codigo_colado("Cole o serial do cliente: ")
                sol = emissor.ler_solicitacao(cod)
                ant = emissor.anterior(sol.maquina.hex())
                if ant:
                    print(f"  Servidor já conhecido: {ant[1]} (última licença nº {ant[0]})")
                cliente = input(f"Nome do cliente [{ant[1] if ant else ''}]: ").strip() or (ant[1] if ant else "")
                dias = perguntar_int("Dias de validade", DIAS_PADRAO)
                equip = perguntar_int("Limite de equipamentos (0 = sem limite)", ant[3] if ant else 0)
                empr = perguntar_int("Limite de empresas (0 = sem limite)", ant[4] if ant else 1)
                mostrar(emissor.liberar(cod, cliente, dias, equip, empr))
            elif op == "2":
                mostrar_historico(Emissor(carregar_chave()).historico(input("Buscar (Enter = todos): ").strip()))
            elif op == "3":
                pasta = input("Pasta do projeto do Sentinela: ").strip().strip('"')
                aplicar_chave(pasta, ed25519.chave_publica(carregar_chave()).hex())
            elif op == "4":
                if ARQ_CHAVE.exists():
                    print("ATENÇÃO: já existe uma chave. Trocar invalida todos os servidores instalados.")
                    if input("Digite SUBSTITUIR para confirmar: ").strip().upper() != "SUBSTITUIR":
                        continue
                pasta = input("Pasta do projeto do Sentinela (Enter para pular): ").strip().strip('"')
                cmd_novas_chaves(pasta or None, True)
            elif op == "0":
                return
        except ErroLiberacao as e:
            print(f"Erro: {e}")
        except SystemExit as e:
            print(e)
        except (EOFError, KeyboardInterrupt):
            return


def main(argv=None):
    ap = argparse.ArgumentParser(description="Gerador de licenças do Sentinela de Rede")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("janela", help="abre o gerador no navegador (padrão)")
    sub.add_parser("menu", help="menu no terminal")
    k = sub.add_parser("novas-chaves", help="cria o par de chaves (uma vez)")
    k.add_argument("--sentinela", help="pasta do projeto do Sentinela para gravar a chave pública")
    k.add_argument("--forcar", action="store_true")
    a = sub.add_parser("aplicar-chave", help="grava a chave pública numa versão do Sentinela")
    a.add_argument("--sentinela", required=True)
    lb = sub.add_parser("liberar", help="gera a chave de liberação")
    lb.add_argument("codigo", nargs="+")
    lb.add_argument("--cliente", default="")
    lb.add_argument("--dias", type=int, default=DIAS_PADRAO)
    lb.add_argument("--equipamentos", type=int, help="0 = sem limite (padrão: o da licença anterior, ou 0)")
    lb.add_argument("--empresas", type=int, help="0 = sem limite (padrão: o da licença anterior, ou 1)")
    h = sub.add_parser("historico")
    h.add_argument("--busca", default="")
    sub.add_parser("senha", help="define ou troca a senha da chave privada")
    args = ap.parse_args(argv)

    if args.cmd in (None, "janela"):
        import janela
        janela.iniciar()
        return 0
    if args.cmd == "menu":
        menu()
        return 0
    if args.cmd == "novas-chaves":
        cmd_novas_chaves(args.sentinela, args.forcar)
        return 0
    if args.cmd == "senha":
        cmd_senha()
        return 0
    if args.cmd == "aplicar-chave":
        aplicar_chave(args.sentinela, ed25519.chave_publica(carregar_chave()).hex())
        return 0
    emissor = Emissor(carregar_chave())
    if args.cmd == "historico":
        mostrar_historico(emissor.historico(args.busca))
        return 0
    try:
        mostrar(emissor.liberar(" ".join(args.codigo), args.cliente, args.dias, args.equipamentos, args.empresas))
        return 0
    except ErroLiberacao as e:
        print(f"Erro: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
