"""Gerador em janela: proteções de acesso e liberação pelo navegador."""

import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

import ed25519
import janela
from gerador import Emissor
from licenca_formato import Liberacao, Solicitacao, produto_id


class TestJanela(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        cls.priv = ed25519.gerar_chave_privada()
        janela._emissor = lambda: Emissor(cls.priv, cls.tmp / "db.sqlite")
        cls.srv = janela.HTTPServer(("127.0.0.1", 0), janela.Tratador)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def pedir(self, caminho, dados=None, token=janela.TOKEN, host=None):
        cab = {"Content-Type": "application/json"}
        if token:
            cab["X-Token"] = token
        if host:
            cab["Host"] = host
        req = urllib.request.Request(self.base + caminho, data=None if dados is None else json.dumps(dados).encode(),
                                     headers=cab)
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    def test_protecoes(self):
        self.assertEqual(self.pedir("/")[0], 403)                                     # sem token na URL
        self.assertEqual(self.pedir(f"/?t={janela.TOKEN}")[0], 200)
        self.assertEqual(self.pedir(f"/?t={janela.TOKEN}", host="evil.example")[0], 403)  # DNS rebinding
        self.assertEqual(self.pedir("/api/historico", {}, token="errado")[0], 403)
        self.assertEqual(self.pedir("/api/historico", {}, token=None)[0], 403)

    def test_ler_e_liberar(self):
        serial = Solicitacao(produto_id(), b"SERVIDOR", b"ABCDEF", int(__import__("time").time())).para_codigo()
        st, corpo = self.pedir("/api/ler", {"serial": serial})
        d = json.loads(corpo)
        self.assertTrue(d["ok"], d)
        self.assertEqual(d["servidor"], "5345-5256-4944-4F52")
        st, corpo = self.pedir("/api/liberar", {"serial": serial, "cliente": "Provedor Web", "dias": "30",
                                                "equipamentos": "12", "empresas": "1"})
        d = json.loads(corpo)
        self.assertTrue(d["ok"], d)
        lib = Liberacao.de_codigo(d["codigo"])
        self.assertTrue(ed25519.verificar(ed25519.chave_publica(self.priv), lib.corpo(), lib.assinatura))
        self.assertEqual(lib.limite_equipamentos, 12)
        d = json.loads(self.pedir("/api/liberar", {"serial": "XXXX"})[1])
        self.assertFalse(d["ok"])
        d = json.loads(self.pedir("/api/historico", {"busca": "web"})[1])
        self.assertEqual(len(d["linhas"]), 1)


if __name__ == "__main__":
    unittest.main()
