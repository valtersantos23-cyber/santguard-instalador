"""Senha da chave privada: cifra, senha errada, adulteração, arquivo antigo e a janela trancada."""

import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import cofre_chave
import ed25519
import gerador
import janela

SENHA = "Minha#Senha2026"


class TestCofre(unittest.TestCase):
    def setUp(self):
        self.arq = Path(tempfile.mkdtemp()) / "chave_privada.key"
        self.semente = ed25519.gerar_chave_privada()

    def test_ida_e_volta(self):
        cofre_chave.gravar(self.arq, self.semente, SENHA)
        texto = self.arq.read_text()
        self.assertTrue(cofre_chave.tem_senha(texto))
        self.assertNotIn(self.semente.hex(), texto)          # a chave não aparece no arquivo
        self.assertEqual(cofre_chave.ler(self.arq, SENHA), self.semente)

    def test_senha_errada_e_adulteracao(self):
        cofre_chave.gravar(self.arq, self.semente, SENHA)
        with self.assertRaises(cofre_chave.SenhaErrada):
            cofre_chave.ler(self.arq, SENHA + "x")
        texto = self.arq.read_text()
        cifra = texto.split("cifra=")[1][:64]
        trocado = ("0" if cifra[0] != "0" else "1") + cifra[1:]
        self.arq.write_text(texto.replace(cifra, trocado))
        with self.assertRaises(cofre_chave.SenhaErrada):
            cofre_chave.ler(self.arq, SENHA)

    def test_senha_curta(self):
        with self.assertRaisesRegex(ValueError, "8 caracteres"):
            cofre_chave.cifrar(self.semente, "1234")

    def test_cada_gravacao_e_diferente(self):
        a, b = cofre_chave.cifrar(self.semente, SENHA), cofre_chave.cifrar(self.semente, SENHA)
        self.assertNotEqual(a, b)  # sal novo a cada vez

    def test_arquivo_antigo_sem_senha(self):
        self.arq.write_text(self.semente.hex() + "\n")
        self.assertEqual(cofre_chave.ler(self.arq, ""), self.semente)

    def test_carregar_chave_com_senha(self):
        cofre_chave.gravar(self.arq, self.semente, SENHA)
        with mock.patch.object(gerador, "ARQ_CHAVE", self.arq):
            gerador._semente_aberta.clear()
            self.assertEqual(gerador.carregar_chave(SENHA), self.semente)
            with self.assertRaisesRegex(gerador.ErroLiberacao, "senha incorreta"):
                gerador.carregar_chave("errada123")
        gerador._semente_aberta.clear()


class TestJanelaTrancada(unittest.TestCase):
    def setUp(self):
        self.pasta = Path(tempfile.mkdtemp())
        self.p = mock.patch.object(gerador, "ARQ_CHAVE", self.pasta / "chave_privada.key")
        self.p.start()
        janela.acao_sair({})
        janela.ESTADO.update(falhas=0, espera_ate=0.0)
        (self.pasta / "sentinela").mkdir()
        (self.pasta / "sentinela" / "licenca.py").write_text('CHAVE_PUBLICA = ""\n')

    def tearDown(self):
        self.p.stop()
        janela.acao_sair({})

    def test_fluxo(self):
        self.assertEqual(janela.acao_estado({}), {"tem_chave": False, "tem_senha": False, "aberto": False})
        with self.assertRaisesRegex(gerador.ErroLiberacao, "8 caracteres"):
            janela.acao_criar_chaves({"senha": "curta"})
        r = janela.acao_criar_chaves({"senha": SENHA, "pasta": str(self.pasta)})
        self.assertIn(r["publica"], (self.pasta / "sentinela" / "licenca.py").read_text())
        self.assertTrue(janela.acao_estado({})["aberto"])

        janela.acao_sair({})
        with self.assertRaises(janela.Trancado):
            janela.acao_aplicar_chave({"pasta": str(self.pasta)})
        with self.assertRaisesRegex(gerador.ErroLiberacao, "senha incorreta"):
            janela.acao_entrar({"senha": "errada123"})
        janela.acao_entrar({"senha": SENHA})
        janela.acao_aplicar_chave({"pasta": str(self.pasta)})

        # troca de senha
        with self.assertRaisesRegex(gerador.ErroLiberacao, "atual está incorreta"):
            janela.acao_trocar_senha({"atual": "errada123", "nova": "OutraSenha#1"})
        janela.acao_trocar_senha({"atual": SENHA, "nova": "OutraSenha#1"})
        janela.acao_sair({})
        janela.acao_entrar({"senha": "OutraSenha#1"})

    def test_tranca_por_inatividade_e_espera_apos_erros(self):
        janela.acao_criar_chaves({"senha": SENHA})
        janela.ESTADO["ultimo"] -= janela.INATIVIDADE + 1
        self.assertFalse(janela.acao_estado({})["aberto"])
        with mock.patch.object(janela.time, "sleep"):
            for _ in range(3):
                with self.assertRaises(gerador.ErroLiberacao):
                    janela.acao_entrar({"senha": "errada123"})
            with self.assertRaisesRegex(gerador.ErroLiberacao, "aguarde"):
                janela.acao_entrar({"senha": SENHA})  # nem a certa entra durante a espera

    def test_chave_antiga_sem_senha(self):
        semente = ed25519.gerar_chave_privada()
        gerador.ARQ_CHAVE.write_text(semente.hex() + "\n")
        self.assertEqual(janela.acao_estado({})["tem_senha"], False)
        with self.assertRaisesRegex(gerador.ErroLiberacao, "defina uma senha"):
            janela.acao_entrar({"senha": ""})
        janela.acao_definir_senha({"senha": SENHA})
        self.assertTrue(gerador.chave_tem_senha())
        self.assertEqual(cofre_chave.ler(gerador.ARQ_CHAVE, SENHA), semente)  # mesma chave: clientes não mudam


if __name__ == "__main__":
    unittest.main()
