"""Testes do gerador:  python -m unittest discover -s testes -t .   (na pasta do gerador)"""

import sqlite3
import tempfile
import unittest
from pathlib import Path

import ed25519
from gerador import Emissor, ErroLiberacao, aplicar_chave
from licenca_formato import PRODUTO, Liberacao, Solicitacao, produto_id

DIA = 86400
T0 = 1_790_000_000


class Relogio:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t


def solicitacao(maquina=b"MAQUINA1", nonce=b"NONCE1", criada=T0, produto=PRODUTO):
    return Solicitacao(produto_id(produto), maquina, nonce, criada).para_codigo()


class TestGerador(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.priv = ed25519.gerar_chave_privada()
        self.pub = ed25519.chave_publica(self.priv)
        self.relogio = Relogio()
        self.e = Emissor(self.priv, self.tmp / "db.sqlite", relogio=self.relogio)

    def test_liberacao_assinada_com_limites(self):
        r = self.e.liberar(solicitacao(), "Provedor X", 30, 50, 2)
        lib = Liberacao.de_codigo(r.codigo)
        self.assertTrue(ed25519.verificar(self.pub, lib.corpo(), lib.assinatura))
        self.assertEqual((lib.maquina, lib.nonce), (b"MAQUINA1", b"NONCE1"))
        self.assertEqual(lib.expira - lib.emitida, 30 * DIA)
        self.assertEqual((lib.limite_equipamentos, lib.limite_empresas), (50, 2))
        self.assertEqual(r.maquina, "4D41-5155-494E-4131")

    def test_renovacao_soma_dias_e_herda_cliente_e_limites(self):
        self.e.liberar(solicitacao(nonce=b"AAAAAA"), "Provedor X", 30, 50, 2)
        self.relogio.t += 25 * DIA
        r = self.e.liberar(solicitacao(nonce=b"BBBBBB", criada=self.relogio.t))
        self.assertTrue(r.renovacao)
        self.assertEqual((r.cliente, r.equipamentos, r.empresas), ("Provedor X", 50, 2))
        lib = Liberacao.de_codigo(r.codigo)
        self.assertEqual(lib.expira, T0 + 60 * DIA)

    def test_depois_de_vencer_conta_de_hoje(self):
        self.e.liberar(solicitacao(nonce=b"AAAAAA"), "X")
        self.relogio.t += 45 * DIA
        r = self.e.liberar(solicitacao(nonce=b"BBBBBB", criada=self.relogio.t))
        self.assertFalse(r.renovacao)
        self.assertEqual(Liberacao.de_codigo(r.codigo).expira, self.relogio.t + 30 * DIA)

    def test_mesma_solicitacao_nao_da_dias_extras(self):
        a = self.e.liberar(solicitacao(), "X")
        b = self.e.liberar(solicitacao(), "X")
        self.assertEqual(a.codigo, b.codigo)
        self.assertEqual(len(self.e.historico()), 1)

    def test_validacoes(self):
        with self.assertRaisesRegex(ErroLiberacao, "nome do cliente"):
            self.e.liberar(solicitacao())
        with self.assertRaisesRegex(ErroLiberacao, "não é do Sentinela"):
            self.e.liberar(solicitacao(produto="Outro produto"), "X")
        with self.assertRaisesRegex(ErroLiberacao, "LIBERAÇÃO"):
            self.e.liberar(self.e.liberar(solicitacao(), "X").codigo, "X")
        with self.assertRaisesRegex(ErroLiberacao, "digitado errado|incompleto"):
            self.e.liberar(solicitacao()[:-3], "X")
        r = self.e.liberar(solicitacao(nonce=b"VELHO1", criada=T0 - 10 * DIA), "X")
        self.assertTrue(any("há 10 dias" in a for a in r.avisos))

    def test_aplicar_chave(self):
        pasta = self.tmp / "projeto" / "sentinela"
        pasta.mkdir(parents=True)
        (pasta / "licenca.py").write_text('x = 1\nCHAVE_PUBLICA = ""\ny = 2\n', encoding="utf-8")
        aplicar_chave(self.tmp / "projeto", self.pub.hex())
        self.assertIn(f'CHAVE_PUBLICA = "{self.pub.hex()}"', (pasta / "licenca.py").read_text(encoding="utf-8"))

    def test_historico_por_servidor(self):
        self.e.liberar(solicitacao(), "Provedor Alfa")
        self.assertEqual(len(self.e.historico("alfa")), 1)
        self.assertEqual(len(self.e.historico("4D41-5155")), 1)
        self.assertEqual(len(self.e.historico("beta")), 0)


if __name__ == "__main__":
    unittest.main()
