"""Guarda a chave privada CIFRADA com a senha do fornecedor.

Sem a senha, o arquivo chave_privada.key não serve para nada: quem copiar a pasta do gerador
não consegue gerar licenças. Usa só a biblioteca padrão:

  - scrypt (hashlib) transforma a senha em 64 bytes; é lento de propósito (~0,1 s e 32 MB por
    tentativa), o que torna inviável testar milhões de senhas;
  - os primeiros 32 bytes cifram a chave (XOR: a chave tem 32 bytes e o sal é novo a cada
    gravação, então cada combinação é usada uma única vez);
  - os outros 32 bytes geram um HMAC-SHA256 que detecta senha errada e arquivo adulterado.

Se você esquecer a senha, a chave é perdida. Guarde a senha num gerenciador de senhas.
"""

import hashlib
import hmac
import os
import secrets

CABECALHO = "SENTINELA-CHAVE-PRIVADA v2"
N, R, P = 2**15, 8, 1
SENHA_MINIMA = 8


class SenhaErrada(Exception):
    pass


def _derivar(senha, sal, n=N, r=R, p=P):
    return hashlib.scrypt(senha.encode("utf-8"), salt=sal, n=n, r=r, p=p, dklen=64, maxmem=128 * 1024 * 1024)


def problema_na_senha(senha):
    if len(senha) < SENHA_MINIMA:
        return f"a senha precisa ter pelo menos {SENHA_MINIMA} caracteres"
    if senha.strip() != senha:
        return "a senha não pode começar nem terminar com espaço"
    return None


def cifrar(semente, senha):
    if len(semente) != 32:
        raise ValueError("chave privada inválida")
    problema = problema_na_senha(senha)
    if problema:
        raise ValueError(problema)
    sal = secrets.token_bytes(16)
    dk = _derivar(senha, sal)
    cifra = bytes(a ^ b for a, b in zip(semente, dk[:32]))
    mac = hmac.new(dk[32:], sal + cifra, hashlib.sha256).hexdigest()
    return (f"{CABECALHO}\nsal={sal.hex()}\nn={N} r={R} p={P}\ncifra={cifra.hex()}\nmac={mac}\n")


def decifrar(texto, senha):
    linhas = dict(l.split("=", 1) for l in texto.strip().splitlines()[1:] if "=" in l)
    try:
        sal = bytes.fromhex(linhas["sal"])
        cifra = bytes.fromhex(linhas["cifra"])
        params = dict(x.split("=") for x in ("n=" + linhas["n"]).split())
        n, r, p = int(params["n"]), int(params["r"]), int(params["p"])
    except (KeyError, ValueError):
        raise ValueError("arquivo da chave privada corrompido") from None
    dk = _derivar(senha, sal, n, r, p)
    esperado = hmac.new(dk[32:], sal + cifra, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(esperado, linhas.get("mac", "")):
        raise SenhaErrada("senha incorreta")
    return bytes(a ^ b for a, b in zip(cifra, dk[:32]))


def tem_senha(texto):
    return texto.startswith(CABECALHO)


def gravar(caminho, semente, senha):
    tmp = caminho.with_suffix(".tmp")
    tmp.write_text(cifrar(semente, senha))
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, caminho)


def ler(caminho, senha):
    """Devolve a chave privada (32 bytes). Arquivo antigo sem senha: devolve a chave mesmo assim."""
    texto = caminho.read_text()
    if tem_senha(texto):
        return decifrar(texto, senha)
    return bytes.fromhex(texto.strip())
