@echo off
rem Abre o menu do gerador de licencas (dois cliques).
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 gerador.py) else (python gerador.py)
pause
