"""Formato dos códigos de licença (solicitação e liberação).

ESTE ARQUIVO É COMPARTILHADO com o gerador do fornecedor: a cópia de lá precisa ser idêntica.
Por isso usa só a biblioteca padrão e não importa nada do pacote.

  SOLICITAÇÃO (instalação -> fornecedor)   ~39 caracteres
      tipo | versão | produto | id da máquina | nonce | data do pedido

  LIBERAÇÃO   (fornecedor -> instalação)   ~170 caracteres
      tipo | versão | produto | id da máquina | nonce | nº licença | emitida | expira
      | limite de equipamentos | limite de empresas   + assinatura Ed25519 (64 bytes)

O nonce amarra cada liberação a UMA solicitação: uma liberação antiga não reativa o sistema
nem funciona em outro servidor. Base32 em grupos de 5, com 2 bytes de verificação para
detectar erro de digitação.
"""

import base64
import binascii
import hashlib
import re
import struct
from dataclasses import dataclass

PRODUTO = "Sentinela de Rede"
VERSAO = 1
TIPO_SOLICITACAO = 0x51   # 'Q'
TIPO_LIBERACAO = 0x4C     # 'L'

_FMT_SOL = ">BBH8s6sI"          # 22 bytes
_FMT_LIB = ">BBH8s6sIIIHH"      # 34 bytes + 64 de assinatura
TAM_ASSINATURA = 64


class CodigoInvalido(ValueError):
    """O código não pôde ser lido (digitação errada, cortado, tipo errado...)."""


def produto_id(nome=PRODUTO):
    return int.from_bytes(hashlib.sha256(nome.strip().lower().encode()).digest()[:2], "big")


def _checksum(dados):
    return hashlib.sha256(b"chk" + dados).digest()[:2]


def codificar(dados):
    s = base64.b32encode(dados + _checksum(dados)).decode().rstrip("=")
    return "-".join(s[i:i + 5] for i in range(0, len(s), 5))


def decodificar(codigo):
    # Aceita minúsculas, espaços, quebras de linha e confusões comuns (0->O, 1->I, 8->B).
    s = re.sub(r"[\s\-_.]", "", str(codigo).upper()).translate(str.maketrans("018", "OIB"))
    if not s:
        raise CodigoInvalido("código vazio")
    if re.search(r"[^A-Z2-7]", s):
        raise CodigoInvalido("o código tem caracteres que não existem neste formato")
    try:
        bruto = base64.b32decode(s + "=" * (-len(s) % 8))
    except (binascii.Error, ValueError):
        raise CodigoInvalido("código incompleto ou digitado errado") from None
    if len(bruto) < 3:
        raise CodigoInvalido("código curto demais")
    dados, chk = bruto[:-2], bruto[-2:]
    if _checksum(dados) != chk:
        raise CodigoInvalido("código digitado errado ou incompleto (verificação falhou)")
    return dados


@dataclass(frozen=True)
class Solicitacao:
    produto: int
    maquina: bytes      # 8 bytes
    nonce: bytes        # 6 bytes
    criada: int         # epoch (s)

    def para_codigo(self):
        return codificar(struct.pack(_FMT_SOL, TIPO_SOLICITACAO, VERSAO, self.produto,
                                     self.maquina, self.nonce, self.criada))

    @classmethod
    def de_codigo(cls, codigo):
        dados = decodificar(codigo)
        if dados[:1] == bytes([TIPO_LIBERACAO]):
            raise CodigoInvalido("isto é uma CHAVE DE LIBERAÇÃO, não um código de solicitação")
        if len(dados) != struct.calcsize(_FMT_SOL) or dados[0] != TIPO_SOLICITACAO:
            raise CodigoInvalido("isto não é um código de solicitação")
        _, versao, produto, maquina, nonce, criada = struct.unpack(_FMT_SOL, dados)
        if versao != VERSAO:
            raise CodigoInvalido(f"versão de solicitação não suportada ({versao})")
        return cls(produto, maquina, nonce, criada)


@dataclass(frozen=True)
class Liberacao:
    produto: int
    maquina: bytes
    nonce: bytes
    licenca_id: int
    emitida: int                # epoch (s)
    expira: int                 # epoch (s)
    limite_equipamentos: int    # 0 = sem limite
    limite_empresas: int        # 0 = sem limite
    assinatura: bytes = b""

    def corpo(self):
        """Bytes cobertos pela assinatura."""
        return struct.pack(_FMT_LIB, TIPO_LIBERACAO, VERSAO, self.produto, self.maquina, self.nonce,
                           self.licenca_id, self.emitida, self.expira,
                           self.limite_equipamentos, self.limite_empresas)

    def para_codigo(self):
        if len(self.assinatura) != TAM_ASSINATURA:
            raise ValueError("liberação sem assinatura")
        return codificar(self.corpo() + self.assinatura)

    @classmethod
    def de_codigo(cls, codigo):
        dados = decodificar(codigo)
        if dados[:1] == bytes([TIPO_SOLICITACAO]):
            raise CodigoInvalido("isto é um CÓDIGO DE SOLICITAÇÃO, não uma chave de liberação")
        n = struct.calcsize(_FMT_LIB)
        if len(dados) != n + TAM_ASSINATURA or dados[0] != TIPO_LIBERACAO:
            raise CodigoInvalido("isto não é uma chave de liberação")
        _, versao, produto, maquina, nonce, lid, emitida, expira, leq, lemp = struct.unpack(_FMT_LIB, dados[:n])
        if versao != VERSAO:
            raise CodigoInvalido(f"versão de liberação não suportada ({versao})")
        return cls(produto, maquina, nonce, lid, emitida, expira, leq, lemp, dados[n:])
