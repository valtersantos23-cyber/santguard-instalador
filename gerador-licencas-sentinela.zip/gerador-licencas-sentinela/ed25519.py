"""Assinatura digital Ed25519 (RFC 8032) em Python puro, sem dependências.

Por que assinatura digital: só quem tem a CHAVE PRIVADA (você, o fornecedor) consegue
gerar uma liberação válida. O sistema do cliente tem apenas a CHAVE PÚBLICA, que serve
para conferir a assinatura mas não para criar uma nova. Por isso, mesmo que alguém
leia o código do cliente, não consegue fazer um "gerador de chaves" pirata.

Implementação baseada no código de referência da RFC 8032, seção 6.
"""
from __future__ import annotations

import hashlib
import secrets

_p = 2**255 - 19
_d = -121665 * pow(121666, _p - 2, _p) % _p
_q = 2**252 + 27742317777372353535851937790883648493
_SQRT_M1 = pow(2, (_p - 1) // 4, _p)


def _inv(x: int) -> int:
    return pow(x, _p - 2, _p)


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s: int, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q) -> bool:
    return ((P[0] * Q[2] - Q[0] * P[2]) % _p == 0
            and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0)


def _recover_x(y: int, sign: int):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _SQRT_M1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P) -> bytes:
    zinv = _inv(P[2])
    x, y = P[0] * zinv % _p, P[1] * zinv % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _p)


def _expand(secret: bytes):
    h = hashlib.sha512(secret).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def _hq(data: bytes) -> int:
    return int.from_bytes(hashlib.sha512(data).digest(), "little") % _q


# ----------------------------------------------------------------- API pública
def gerar_chave_privada() -> bytes:
    """32 bytes aleatórios criptograficamente seguros."""
    return secrets.token_bytes(32)


def chave_publica(privada: bytes) -> bytes:
    a, _ = _expand(privada)
    return _compress(_mul(a, _G))


def assinar(privada: bytes, mensagem: bytes) -> bytes:
    a, prefixo = _expand(privada)
    A = _compress(_mul(a, _G))
    r = _hq(prefixo + mensagem)
    R = _compress(_mul(r, _G))
    s = (r + _hq(R + A + mensagem) * a) % _q
    return R + int.to_bytes(s, 32, "little")


def verificar(publica: bytes, mensagem: bytes, assinatura: bytes) -> bool:
    if len(publica) != 32 or len(assinatura) != 64:
        return False
    A = _decompress(publica)
    R = _decompress(assinatura[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(assinatura[32:], "little")
    if s >= _q:
        return False
    h = _hq(assinatura[:32] + publica + mensagem)
    return _equal(_mul(s, _G), _add(R, _mul(h, A)))
