# Gerador de licenças do Sentinela de Rede

**Uso exclusivo do fornecedor.** Esta pasta nunca vai para o cliente, nem dentro do instalador.
Só precisa de Python 3.9 ou mais novo, sem nada para instalar.

## Senha

A chave privada fica **cifrada com a sua senha**. Quem copiar esta pasta (outra empresa, um funcionário,
alguém com acesso ao seu PC ou ao seu backup) **não consegue gerar licenças sem a senha**.

- O gerador pede a senha ao abrir e **se tranca sozinho depois de 15 minutos sem uso** (ou no botão 🔒 Trancar).
- Senha errada: a partir do 3º erro, cada tentativa nova espera mais (5 s, 10 s, 20 s... até 5 min).
- Para trocar a senha, use "Trocar a senha da chave" na janela, ou `python gerador.py senha`. A chave continua a
  mesma, então nada muda para os clientes já instalados.
- Se você tinha uma chave criada antes, **sem senha**, o gerador pede para definir uma na primeira vez que abrir.
- **Se esquecer a senha, a chave é perdida.** Guarde-a num gerenciador de senhas (Bitwarden, 1Password, KeePass).
  Faça backup do arquivo `chave_privada.key`: ele já está cifrado, então o backup também fica protegido.

Detalhes técnicos: scrypt (N=32768, r=8) para transformar a senha em chave, mais HMAC-SHA256 para detectar senha
errada ou arquivo adulterado. Só usa a biblioteca padrão do Python (`cofre_chave.py`).

## Como usar

Dê dois cliques em **`GERADOR.cmd`**. O gerador abre no navegador (roda só no seu computador). Digite a senha. Depois:

1. cole o **serial** que aparece na tela de registro do cliente (os dados do servidor aparecem na hora;
   se for um cliente que já existe, o nome e os limites são preenchidos sozinhos);
2. confira o cliente, os dias e os limites e clique em **Gerar liberação**;
3. clique em **Copiar chave** e envie ao cliente. Ele cola a chave na tela de registro e clica em **Registrar**.

Mantenha a janela preta aberta enquanto usa o gerador. Fechar a janela encerra o gerador.

## Primeira vez (uma única vez na vida)

Na primeira vez o gerador mostra **"Primeiro uso: crie a sua chave"**: informe a pasta do projeto do
Sentinela, crie a senha e clique em **Criar chave**. Pela linha de comando, o equivalente é:

```powershell
python gerador.py novas-chaves --sentinela "C:\caminho\do\projeto\sentinela"
```

- Cria a `chave_privada.key` nesta pasta. **Faça backup agora**, num pendrive ou cofre de senhas.
  Se ela for perdida, os servidores já instalados não aceitarão mais renovações.
- Grava a chave pública em `sentinela\licenca.py` do projeto. Ela não é secreta e pode ir para o
  GitHub junto com o código.

## A cada versão nova do Sentinela

Antes de gerar o instalador ou a imagem Docker:

```powershell
python gerador.py aplicar-chave --sentinela "C:\caminho\do\projeto\sentinela"
```

O `GERAR_INSTALADOR.cmd` do Sentinela se recusa a gerar o instalador sem a chave gravada.

## Linha de comando (opcional)

O mesmo pode ser feito no terminal (`python gerador.py menu` abre um menu de texto):

```powershell
python gerador.py liberar KEAQN-6TGZ6-E3BDT-O3GIP-NI47I-T7242-W2RVY-BPXI --cliente "Provedor X" --equipamentos 50 --empresas 1
python gerador.py historico
python gerador.py historico --busca "Provedor X"
```

| Opção            | Padrão                                              |
|------------------|-----------------------------------------------------|
| `--dias`         | 30                                                  |
| `--equipamentos` | o da licença anterior deste servidor, ou 0 (sem limite) |
| `--empresas`     | o da licença anterior deste servidor, ou 1          |
| `--cliente`      | o da licença anterior deste servidor                |

Copie a **chave de liberação** que aparecer e envie ao cliente. Ele cola a chave na aba 🔑 Licença do painel.

**Renovação antecipada:** se o servidor ainda tem dias de licença, os dias novos se somam ao
vencimento atual. O cliente não perde nada por renovar cedo. Se a mesma solicitação for colada duas
vezes, o gerador devolve a mesma chave, sem dar dias extras.

**Seu próprio servidor central (multiempresa):** emita uma licença longa para ele, por exemplo:
`--dias 3650 --equipamentos 0 --empresas 0`.

## Arquivos

| Arquivo              | O que é                                                        |
|----------------------|----------------------------------------------------------------|
| `gerador.py`         | o gerador (linha de comando)                                   |
| `janela.py`          | o gerador em janela, no navegador                              |
| `GERADOR.cmd`        | abre a janela com dois cliques (Windows)                       |
| `chave_privada.key`  | **SEGREDO**, cifrado com a sua senha (criado no primeiro uso)  |
| `cofre_chave.py`     | cifra e decifra a chave com a senha                            |
| `licencas.db`        | histórico de todas as liberações (faça backup também)          |
| `ed25519.py`, `licenca_formato.py` | cópias idênticas das que estão no Sentinela. Se mudar uma, mude a outra |

Testes: `python -m unittest discover -s testes -t .`
